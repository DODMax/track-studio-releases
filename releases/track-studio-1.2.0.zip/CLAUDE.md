# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Setup & commands

Always work inside the local venv:

```bash
source venv/bin/activate
pip install -r requirements.txt   # one-time
```

Run the app (the primary interface — NiceGUI, opens on :8080):

```bash
venv/bin/python main.py
```

Run the tagger directly on a folder:

```bash
venv/bin/python energy.py /path/to/folder [--dry-run] [--force] [--rich]
```

Several domain modules have a `__main__` self-test that prints real numbers off
the live library — the fastest way to sanity-check a change:

```bash
venv/bin/python history.py
venv/bin/python mixmodel.py
```

There is no test suite, linter, or build step configured. `app.py` is the
superseded Streamlit GUI, kept only as a reference; `main.py` is the live app.

## The Comments tag is the database

Everything the analyzer learns is encoded as one human-readable string in the
audio file's **Comments** tag. There is no sidecar DB and no write to the
rekordbox DB:

```
Energy 07 | A 5.67 | Dance 0.95 | Valence 5.81 | Style House | Mood summer,deep
       | Bright 1450 | Dyn 3.21 | Spec 12.4 | Onset 4.10
LUFS -8.20 | LRA 4.10 | TP -0.30
```

Rekordbox's Intelligent Playlists then filter on `Comments contains "Energy 0[1-3]"`.

**If you add a field, change all three sides or re-runs will corrupt it:**
`energy.write_energy` (write), `tagging.parse_comment` (read), and the
`_merge_comment` regex (strips the prior payload so re-runs don't accumulate).
Loudness has its own pair (`write_loudness` / `_merge_loudness_comment`).

## Vocabulary

The app leans on three distinct words; keeping them straight is most of
understanding the Build page:

- **crate** — a source you dig through: a rekordbox playlist, or several pooled.
- **block** — 3-10 tracks grouped by feel, ordered harmonically and given an arc
  role ("Warm-up" … "Climax"). A programmed run *within* a set. Called
  "micro-sets" in earlier versions, which muddled it with the next one.
- **the set** — the ordered list of tracks you assemble, out of blocks and
  individual picks (`microsets.SetEntry` keeps the provenance of each).

The set outlives the crate: swapping or widening the pool mid-build keeps it and
only changes what the suggestions and blocks are drawn from — running dry in one
playlist and ticking another is how a set actually gets built. `Clear` is the
only thing that empties a set, and `_load_pool` re-points surviving entries at
the new pool's objects so a re-analysis refreshes them in place.

## Architecture

### Analysis pipeline

- **`energy.py`** — the core. Lazy-downloads Essentia `.pb` models into `models/`,
  loads them once via `build_predictors(rich=…)`, runs `analyze(path, predictors)`,
  then `write_energy` merges the payload into the existing Comments. MP3 uses
  mutagen `ID3/COMM`; M4A uses `MP4` `\xa9cmt`. Energy 1–10 comes from
  `_arousal_to_energy`, which maps DEAM arousal **3.0..7.0 → 1..10** (not the full
  1..9 range) because real tracks cluster in the middle. Also owns EBU R128
  loudness (`extract_loudness` / `normalize_loudness`).
- **`tagging.py`** — the read side: `parse_comment(text) → dict`.
- **`analysis.py`** — `AnalysisJob` / `LoudnessJob` / `NormalizeJob`: cancellable
  background jobs with progress, driven from the UI.

### Domain

- **`library.py`** — `Library` + the `Track` aggregate, the single source of truth
  the UI renders, merged across local files / rekordbox / Spotify / Beatport.
  `mix_tracks_from` maps these to the set-building `microsets.Track` (BPM required).
- **`microsets.py`** — the set-building domain (despite the legacy filename):
  `Track`, `Block`, `BlockPreset`, `SetEntry`, Camelot helpers, `cluster()`,
  `compatibility()`, `generate_sequences()`. Leaf: it takes the learned model
  duck-typed rather than importing it.
- **`history.py`** — reconstructs real gigs from rekordbox's play log. Most
  sessions aren't performances; the discriminator is *harmonic adjacency* (real
  sets run 60-72% vs a ~17% random baseline), with an alphabetical-order check to
  reject sorted playlists clicked through. Read-only.
- **`mixmodel.py`** — turns that history into advice. One rule throughout: **a
  one-off can be a practice miss; only repetition across nights is proof.** Pair
  evidence (2+ nights = "confirmed", teal ♥ in the UI), a night-weighted move
  profile that generalizes to pairs never played, and playlist affinity ("often
  gigged with").
- **`rekordbox.py`** (read the live DB / an XML export) and **`rekordbox_io.py`**
  (write an importable `collection.xml`; `export_folder` is the one used by Build).
- **`rbprefs.py`** — read-only view of rekordbox's *own* preferences
  (`rekordbox3.settings`): is rekordbox's xml view pointed at our export file,
  and is the sidebar tree enabled? Turns the one-time setup into a verifiable
  check (Settings checklist, header badge, post-export dialog). Never writes.
- **`sync.py`**, **`sources.py`**, **`spotify.py`**, **`beatport.py`**, **`bpdl.py`**,
  **`ytdl.py`**, **`inbox.py`**, **`match.py`** — the Spotify→Beatport→local
  sourcing pipeline. ISRC is the identity key.
- **`dupes.py`** — "do I already have this?", asked *before* a download commits.
  Rekordbox dedups on file location alone, so a second copy at a second path
  imports as a second entry however identical the tags — and since `history` and
  `mixmodel` key on the rekordbox track id, that splits a track's play evidence
  across both copies. Reuses `match.match_track` (never a fresh comparison) plus
  a remix-credit guard, and only ever *warns*: replacing a 128 kbps rip with
  lossless is a real reason to fetch a second copy.
- **`setline_import.py`** — brings in a set planned in Setline (the shared online
  planner in `~/Code/setline`): reads its `.setline.json` export (format
  `setline-set` v1), matches each track by Beatport id, then ISRC, then
  `dupes.Index`; the Download page fetches the missing ones from Beatport into a
  "Setline - <set>" batch, then either exports the set to rekordbox
  (`to_playlists`: the set in order plus a leaf per moment, under a folder named
  for the set and *only* the set — `export_name` deliberately drops the slice so
  a re-export lands on the same folder you delete to replace it) or saves it as a
  Build draft (`to_draft`: moment → entry `role`, ids as Build keys them:
  rekordbox id, else ISRC, else display). **Build is not on the way out.** A set
  that arrived already programmed is playable as it stands; going through Build
  is for *re*-programming it, and the export needs no Energy tag (a BPM is a
  Build requirement, not rekordbox's).
  `Plan.keep_moments` / `keep_added_by` narrow it to a slice — the hour you're
  preparing, or your own picks out of a b2b — and `Plan.selected` is what the
  counts, the download, the export and the draft all read, so a slice is never a
  second file. The filter lives on `runtime.setline_state`, not the plan, so a
  re-plan after downloading lands you back on the same slice. The
  draft carries no `batch_name` on purpose, so resuming pools every matched
  track, not just the downloaded ones.
- **`setline_push.py`** — the other direction: the Build page's "Setline"
  button (the set) and each block's send icon post tracks to a Setline crate,
  new or existing, with the Beatport id and ISRC the library knows so Setline
  can match exactly. Needs `SETLINE_URL`, `SETLINE_TOKEN` (Setline's
  `SETLINE_MCP_TOKEN`) and `SETLINE_NAME` (who gets the credit) in `.env`.
- **`drafts.py`** — a set-in-progress on disk, so one can be finished another day.
  Stores what it takes to *rebuild* the session, never a copy of it: the pool's
  source (playlist nodes / download batch, with the pool's track ids as the
  fallback when that source is gone), the knobs, and the set as ordered track
  ids. The library stays the source of truth for what a track is. Two slots,
  same shape: **named drafts** (`.set_drafts.json`, deliberate, kept until
  deleted) and **the session** (`.build_session.json`, one slot rewritten as you
  work and restored on the next launch). The autosave's one rule: an empty set
  only overwrites the saved one once the process has *restored* it — open the
  app before rekordbox has loaded and writing "nothing here" would delete last
  night's work (`build_page._autosave` / `restore_autosave`).
- **`store.py`**, **`config.py`**, **`staging.py`** — local persistence and config.

### App

- **`main.py`** — entry point. The `if __name__ == "__main__"` guard matters: the
  analysis pool uses multiprocessing "spawn", which re-imports this module in
  every worker.
- **`runtime.py`** — the process-wide singletons every page reads (`library`,
  `download_batches`, `history_state`, `mix_state`, `build_state`,
  `setline_state`). Only ever *mutated*, never rebound — `import runtime` and
  reference `runtime.library`, so a rebinding can't strand a stale alias.
  **A NiceGUI page body re-runs from scratch on every visit**, so anything a page
  function holds is lost the moment you click another tab — which is why a
  page's working session lives here: `build_state` (pool + blocks + the set) and
  `setline_state` (the dropped `.setline.json`, its match against the library,
  and the slice you narrowed it to). Neither holds UI elements — those die with
  their client, and the pages keep them in a per-visit dict instead.
- **`shell.py`** — theme, header/nav (with the setup-needed badge on the ⚙),
  quick settings dialog, and `PLAYER_ASSETS` (the CSS+JS behind the custom audio
  transport). Deliberately free of `runtime`.
- **`export_ui.py`** — `export_handoff`, the persistent dialog every "Export to
  rekordbox" ends in (setup check → refresh/drag steps → "Done — reload
  library"), plus the reusable xml-wiring panel Settings shows. UI layer: unlike
  `widgets` it imports `runtime`; imported by pages only.
- **`widgets.py`** — pure render helpers: `render_track_row`, `audio_player`,
  `energy_arc_svg`, `set_arc_svg`, `_chip`, the energy/Camelot color language.
- **`media.py`** — the `/media` endpoint; serves audio only for files the library
  knows about.
- **`pages/`** — one module per route, registered by import side effect:
  `/` (library), `/sync`, `/build`, `/download`, `/history`, `/settings`.
  `/microsets` and `/builder` are redirects to `/build`, which merged them.

### The window

`window.py` is the app as macOS sees it: a WKWebView (pywebview) on
`127.0.0.1:8080`, run by the bundle's launcher in the **foreground**, which is
what gives Track Studio a Dock icon, ⌘Tab and a menu bar instead of a browser
tab. It is a **separate process from the server** on purpose — closing the window
leaves a four-hour analysis running, reopening is instant, and an update can
restart the server underneath it while the page just reloads. (pywebview also
insists on the main thread, which the analysis pool's parent already owns.)

- **`claim_identity`** overrides `CFBundleName` and the Dock icon at runtime: the
  process is the framework's `Python.app`, so without it the app is called
  "Python". Cosmetic failure only — never fatal.
- **`raise_existing_window`** makes a second launch bring the first window
  forward (`NSRunningApplication`, no accessibility permission needed) instead of
  stacking windows, because the launcher runs on every ⌘Space.
- ⌘R / ⌘0 / ⌘+ / ⌘− are wired in JS; the rest is Cocoa's.

### Self-update

The whole endpoint is a **static JSON file** — Tauri's updater pattern, with
Sparkle's signing habit; there is no update server. A release is two files in a
public repo (`stable.json` + `releases/track-studio-<v>.zip`), so publishing is a
commit in GitHub Desktop.

- **`VERSION`** — one line, the only place the number lives. `build_app.sh` stamps
  it into the bundle's plist, so Get Info and the app can't disagree.
- **`updates.py`** — check (twice a day and at launch), download, verify, and the
  `/api/version` route. Registered from `main.py`'s `__main__` guard, so the
  analysis workers don't each start a checker. `available()` reads the last
  answer off disk, which is what the header chip renders on every page.
- **`signing.py`** — ed25519, the RFC 8032 reference code, no dependency: the one
  component that must keep working mid-upgrade can't be broken by a package
  install. Private key in `~/.config/track-studio/release_key`, public half baked
  into `updates.RELEASE_PUBLIC_KEY`.
- **`scripts/apply_update.py`** — the swap, detached, because it stops the server
  whose files it replaces. Stdlib only and no project imports.
- **`scripts/release.py`** — build + sign + write the manifest. `keygen` once.

Four things it is easy to get wrong, each of which was got wrong first:

1. **What the signature covers is `version\ntheir sha256`**, not the zip alone.
   The manifest and the payload sit in the same public repo, so signing the file
   by itself would leave the manifest free to point a version number at some
   other validly-signed zip.
2. **Nothing is swapped until the port is actually free.** The pid the helper is
   handed is only a hint (it's whoever asked); `stop_server` falls back to
   whatever `lsof` says is listening and *returns whether it worked*.
3. **"It answers" is not proof the new version is running.** `current_version()`
   reads `VERSION` from disk, so a server that never stopped happily reports the
   number it was just handed — the `/api/version` **pid** is what tells the two
   apart. (This is the bug that made a failed install look successful.)
4. **The payload is what git tracks *or would track*** (`release.payload_files`).
   Tracked-only is the obvious rule and the wrong one: a release cut before the
   commit ships without its newest modules and then refuses to install. Ignored
   paths stay out, which is what keeps the venv, models, `.env` and local state
   out of a zip that gets unpacked over someone's install.

A failed start rolls back: the previous files are restored from
`data/updates/rollback/`, the old version is started again, and an alert says so.
A version that dies on import is noticed the moment the child process exits, not
at the end of the 120s wait. `data/update.log` has every step of every attempt.

Testing a release without publishing one: `TRACK_STUDIO_FEED=file:///…` in `.env`
— `urllib` reads `file://` URLs, so the whole flow runs with no server anywhere.

### Two model families

`build_predictors` loads two backbones depending on `rich`:

- Always: **MusiCNN** backbone → DEAM head (arousal+valence). This alone gives Energy.
- `--rich` only: additionally **MusiCNN→danceability**, and the **Discogs-EffNet**
  backbone → genre (400 classes) + moodtheme (56 classes, sigmoid, top-2 ≥ 0.10).

Texture descriptors (brightness / dynamic / spectral complexity / onset rate) come
from plain DSP in `_extract_texture`, not a model — they discriminate inside a
tight genre cluster where danceability and valence saturate.

Model files and URLs live in `MODEL_FILES` at the top of `energy.py`;
`ensure_models()` downloads any missing ones on first use.

### File handling conventions

- Supported: `.mp3`, `.m4a`. WAV/AIFF/FLAC/AAC are listed in `find_skipped_files`
  and reported but not tagged (rekordbox WAV tagging is non-standard).
- `find_audio_files` is non-recursive (single folder) and ignores dotfiles.
- The pre-analysis partition in `main()` calls `read_existing_energy` *before*
  importing Essentia, so a fully-tagged folder exits without paying the TF import.

## Conventions worth respecting

- **Defer heavy imports** (`essentia`, `mutagen.id3`, `mutagen.mp4`, `pyrekordbox`)
  into function bodies so `--help` / `--dry-run` and page opens stay fast.
- **Long jobs outlive the browser tab.** Wrap UI updates from a background job in
  `runtime._safe_ui` — touching a dead client's elements raises `RuntimeError`.
- **A notification is an element, and NiceGUI runs a handler in the *sender's*
  parent slot.** So a spinner started from a button inside a list belongs to that
  list: a handler that re-renders its own list (`col.clear()`) deletes its own
  message mid-job, and the result it notifies afterwards is created in a dead
  slot and never reaches the browser — a download that silently reported nothing,
  not even its error. Anchor both to a container the handler doesn't clear
  (`download_page.toast` / `spinner`).
- **Read tags from the file, not from rekordbox's `Commnt`**, which only refreshes
  when the user clicks "Reload Tag" and can lag by days.
- **Everything exports to one file** (`runtime.export_path()`), so rekordbox's XML
  view is pointed at it once and just refreshed.
- Rekordbox's XML import requires **numeric TrackIDs**; the exporters synthesize
  them because a logical id may be an ISRC or a title.
- **Never fetch audio over HLS** (`bpdl.BROKEN_QUALITIES`). beatportdl's
  `medium-hls` stitches a track out of ~5s encrypted segments and remuxes them
  with ffmpeg; every join carries a timestamp discontinuity. Measured here: 91
  and 98 breaks in two tracks, one every ~5s, up to 93ms each — a fifth of a beat
  at 133 BPM, audible as a jump, and a beatgrid that can't be made to fit. It was
  never an upgrade: identical 128 kbps AAC to `medium`. Two free tells that a
  file came down this way — an encoder atom (a store download has *none*; a
  remux is stamped `Lavf…`), and rekordbox gridding it at 133.xx where the
  Beatport tag says a flat 133. `scripts/find_broken_audio.py` uses both to
  decide what to ffprobe, and the packet check to decide. Withdrawn from the
  Settings picker but still recognised there, so a config already set to it is
  shouted about rather than silently honoured.
