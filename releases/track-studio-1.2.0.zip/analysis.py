"""Background energy-analysis job.

Wraps the blocking Essentia pipeline in energy.py with live progress and
cancellation. The per-track cost is dominated by single-threaded DSP (audio
decode + the MusicExtractor texture pass), so the work is spread across a
process pool: each worker builds its OWN predictors once via an initializer and
analyzes whole tracks, so the (unpicklable) predictors are created inside the
child and never crossed over IPC — only the small result dict comes back.

Set workers=1 to fall back to the original single-thread, shared-predictor path.
"""
from __future__ import annotations

import os
import threading
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from multiprocessing import get_context
from pathlib import Path
from typing import Optional

import energy
from library import Track


def _default_workers() -> int:
    """Leave a couple of cores for the UI / main loop; never below 1."""
    return max(1, (os.cpu_count() or 4) - 2)


def _apply_result(t: Track, res: dict, rich: bool) -> None:
    """Reflect an analyze() result into the in-memory Track (parent side)."""
    t.energy = res["energy"]
    t.arousal = res.get("arousal")
    for attr in ("brightness", "dynamic_complexity", "spectral_complexity", "onset_rate"):
        if attr in res:
            setattr(t, attr, res[attr])
    if rich:
        t.valence = res.get("valence", t.valence)
        t.danceability = res.get("danceability", t.danceability)
        if res.get("genre"):
            t.style = res["genre"]
        if res.get("moods"):
            t.moods = res["moods"]


# ----------------------------------------------------------------------
# Pool worker — predictors live in each child process, built once on init.
# ----------------------------------------------------------------------

_WORKER: dict = {"predictors": None, "rich": False}


def _worker_init(rich: bool) -> None:
    """Per-process setup: pin thread counts (so N workers don't oversubscribe the
    cores) then build this process's own predictors once."""
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("TF_NUM_INTRAOP_THREADS", "1")
    os.environ.setdefault("TF_NUM_INTEROP_THREADS", "1")
    models = energy.ensure_models()
    _WORKER["predictors"] = energy.build_predictors(models, rich=rich)
    _WORKER["rich"] = rich


def _worker_analyze(path_str: str) -> tuple[str, dict]:
    """Analyze one file and write its tag, in the worker process. Returns the
    result dict for the parent to fold into its in-memory Track."""
    p = Path(path_str)
    res = energy.analyze(p, _WORKER["predictors"])
    energy.write_energy(p, res["energy"],
                        extras=energy.extras_from_result(res, _WORKER["rich"]))
    return path_str, res


def _worker_loudness(path_str: str) -> tuple[str, dict]:
    """Measure EBU R128 loudness for one file and write its tag, in the worker."""
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    p = Path(path_str)
    res = energy.extract_loudness(p)
    if "lufs" in res:
        energy.write_loudness(p, res)
    return path_str, res


class LoudnessJob:
    """Measure integrated loudness (LUFS), loudness range and true peak across a
    list of Tracks — the per-playlist "is this library mastered consistently?" pass.

    Deliberately separate from AnalysisJob: this is pure DSP, so workers need no
    predictors and never import TensorFlow, making it far cheaper to re-run.
    """

    def __init__(self, force: bool = False, workers: Optional[int] = None) -> None:
        self.force = force
        self.workers = workers if workers and workers > 0 else _default_workers()
        self.total = 0
        self.done = 0
        self.measured = 0
        self.current = ""
        self.errors: list[tuple[str, str]] = []
        self.running = False
        self.finished = False
        self._cancel = threading.Event()

    def cancel(self) -> None:
        self._cancel.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    @property
    def fraction(self) -> float:
        return (self.done / self.total) if self.total else 0.0

    def _partition(self, tracks: list[Track]) -> list[Track]:
        todo: list[Track] = []
        for t in tracks:
            p = t.local_path
            if not p or not p.exists() or p.suffix.lower() not in energy.SUPPORTED_EXTS:
                continue
            if not self.force and energy.read_existing_loudness(p) is not None:
                continue
            todo.append(t)
        return todo

    def _apply(self, t: Track, res: dict) -> None:
        for k in ("lufs", "lra", "true_peak"):
            if k in res:
                setattr(t, k, res[k])

    def run(self, tracks: list[Track]) -> None:
        """Measure the given tracks. Runs on a worker thread; never raises."""
        self.running = True
        try:
            todo = self._partition(tracks)
            self.total = len(todo)
            if not todo:
                return
            workers = min(self.workers, len(todo))
            if workers <= 1:
                self._run_inline(todo)
            else:
                self._run_pool(todo, workers)
        except Exception as e:  # noqa: BLE001
            self.errors.append(("<setup>", str(e)))
        finally:
            self.running = False
            self.finished = True

    def _run_inline(self, todo: list[Track]) -> None:
        for t in todo:
            if self._cancel.is_set():
                break
            p = t.local_path
            self.current = p.name
            try:
                res = energy.extract_loudness(p)
                if "lufs" in res:
                    energy.write_loudness(p, res)
                    self.measured += 1
                self._apply(t, res)
            except Exception as e:  # noqa: BLE001
                self.errors.append((p.name, str(e)))
            finally:
                self.done += 1

    def _run_pool(self, todo: list[Track], workers: int) -> None:
        by_path = {str(t.local_path): t for t in todo}
        ctx = get_context("spawn")
        with ProcessPoolExecutor(max_workers=workers, mp_context=ctx) as ex:
            futs = {ex.submit(_worker_loudness, sp): sp for sp in by_path}
            for fut in as_completed(futs):
                if self._cancel.is_set():
                    ex.shutdown(cancel_futures=True)
                    break
                sp = futs[fut]
                t = by_path[sp]
                self.current = Path(sp).name
                try:
                    _, res = fut.result()
                    self._apply(t, res)
                    if "lufs" in res:
                        self.measured += 1
                except Exception as e:  # noqa: BLE001
                    self.errors.append((Path(sp).name, str(e)))
                finally:
                    self.done += 1


class IntegrityJob:
    """Check a playlist's files for discontinuous audio — see `integrity`.

    Threads, not processes, unlike the jobs either side of it: the work is one
    `ffprobe` per file, so this is waiting on subprocesses rather than competing
    for CPU, and a spawn pool would pay to re-import the world for nothing.

    Two stages per file, and the first is free — `integrity.worth_probing` reads
    tags and compares them against the BPM rekordbox measured. On this library
    that clears about a quarter of files without decoding anything.
    """

    def __init__(self, sample_seconds: Optional[int] = None,
                 workers: Optional[int] = None) -> None:
        import integrity
        self.sample_seconds = (integrity.DEFAULT_SAMPLE_SECONDS
                               if sample_seconds is None else sample_seconds)
        self.workers = workers if workers and workers > 0 else min(8, _default_workers() * 2)
        self.total = 0
        self.done = 0
        self.probed = 0
        self.current = ""
        self.findings: list = []          # integrity.Finding, worst first
        self.errors: list[tuple[str, str]] = []
        self.running = False
        self.finished = False
        self._cancel = threading.Event()
        self._lock = threading.Lock()

    def cancel(self) -> None:
        self._cancel.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    @property
    def fraction(self) -> float:
        return (self.done / self.total) if self.total else 0.0

    @property
    def stitched(self) -> list:
        import integrity
        return [f for f in self.findings if f.verdict == integrity.STITCHED]

    def _grid_bpm(self, t: Track) -> Optional[float]:
        """What rekordbox measured, if it knows this track — read, never recomputed."""
        return t.bpm if t.in_rekordbox else None

    def _one(self, t: Track):
        import integrity
        p = t.local_path
        self.current = p.name
        try:
            find = integrity.check_track(p, self._grid_bpm(t), self.sample_seconds)
        except Exception as e:  # noqa: BLE001
            with self._lock:
                self.errors.append((p.name, str(e)))
            return None
        finally:
            with self._lock:
                self.done += 1
        if find is None:
            return None                   # cleared for free, never probed
        with self._lock:
            self.probed += 1
        return find if find.breaks else None

    def run(self, tracks: list[Track]) -> None:
        """Check the given tracks. Runs on a worker thread; never raises."""
        self.running = True
        try:
            todo = [t for t in tracks
                    if t.local_path and t.local_path.exists()]
            self.total = len(todo)
            if not todo:
                return
            with ThreadPoolExecutor(max_workers=min(self.workers, len(todo))) as ex:
                futs = [ex.submit(self._one, t) for t in todo]
                for fut in as_completed(futs):
                    if self._cancel.is_set():
                        ex.shutdown(cancel_futures=True)
                        break
                    find = fut.result()
                    if find is not None:
                        self.findings.append(find)
            self.findings.sort(key=lambda f: -f.worst_ms)
        except Exception as e:  # noqa: BLE001
            self.errors.append(("<setup>", str(e)))
        finally:
            self.running = False
            self.finished = True


class RefetchJob:
    """Re-download stitched tracks and swap them in — see `refetch`.

    Two phases, deliberately separated by a human. `run_plan` only *looks*: one
    Beatport search per file, threaded because it's network-bound. `run_apply`
    is the half that touches the library, and it runs on what the person
    confirmed, never on what the search guessed. Replacing the wrong record
    under a track rekordbox still recognises is worse than the glitch being
    fixed, and there is no way to notice it later.
    """

    def __init__(self, workers: Optional[int] = None) -> None:
        self.workers = workers if workers and workers > 0 else 6
        self.total = 0
        self.done = 0
        self.current = ""
        self.candidates: list = []        # refetch.Candidate, worst damage first
        self.replaced = 0
        self.errors: list[tuple[str, str]] = []
        self.running = False
        self.finished = False
        self._cancel = threading.Event()
        self._lock = threading.Lock()

    def cancel(self) -> None:
        self._cancel.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    @property
    def fraction(self) -> float:
        return (self.done / self.total) if self.total else 0.0

    @property
    def confident(self) -> list:
        import refetch
        return [c for c in self.candidates if c.verdict == refetch.CONFIDENT]

    def run_plan(self, findings) -> None:
        """Find each broken file on Beatport. Touches nothing."""
        import refetch

        self.running = True
        try:
            findings = list(findings)
            self.total = len(findings)
            if not findings:
                return
            def _one(f):
                self.current = f.path.name
                try:
                    c = refetch.find_on_beatport(f.path)
                    c.worst_ms = f.worst_ms
                    return c
                except Exception as e:      # noqa: BLE001
                    with self._lock:
                        self.errors.append((f.path.name, str(e)))
                    return None
                finally:
                    with self._lock:
                        self.done += 1

            with ThreadPoolExecutor(max_workers=min(self.workers, len(findings))) as ex:
                futs = [ex.submit(_one, f) for f in findings]
                for fut in as_completed(futs):
                    if self._cancel.is_set():
                        ex.shutdown(cancel_futures=True)
                        break
                    c = fut.result()
                    if c is not None:
                        self.candidates.append(c)
            self.candidates.sort(key=lambda c: -c.worst_ms)
        except Exception as e:  # noqa: BLE001
            self.errors.append(("<setup>", str(e)))
        finally:
            self.running = False
            self.finished = True

    def run_apply(self, candidates, dest: Path) -> None:
        """Download the given candidates and replace their files. Never raises."""
        import bpdl
        import refetch

        self.running = True
        self.done = 0
        self.total = len(candidates)
        try:
            if not candidates:
                return
            if bpdl.get_quality() in bpdl.BROKEN_QUALITIES:
                self.errors.append(("<quality>",
                                    f"beatportdl is set to {bpdl.get_quality()}, which is "
                                    "what produced these files — refusing"))
                return
            dest = Path(dest)
            dest.mkdir(parents=True, exist_ok=True)
            self.current = f"downloading {len(candidates)}…"
            files, log = bpdl.download([c.beatport_id for c in candidates], dest)
            if not files:
                self.errors.append(("<download>", bpdl.failure_reason(log)))
                return
            pairs = refetch.pair_downloads(files, candidates)
            for c in candidates:
                if self._cancel.is_set():
                    break
                self.current = c.path.name
                new = pairs.get(c.path)
                if new is None:
                    self.errors.append((c.path.name, "no download matched this track"))
                else:
                    ok, msg = refetch.replace_in_place(new, c.path)
                    if ok:
                        self.replaced += 1
                    else:
                        self.errors.append((c.path.name, msg))
                self.done += 1
        except Exception as e:  # noqa: BLE001
            self.errors.append(("<setup>", str(e)))
        finally:
            self.running = False
            self.finished = True


class NormalizeJob:
    """Loudness-normalize a chosen set of Tracks toward `target_lufs` by baking in
    a single linear EBU R128 gain, clamped to ±`max_gain` dB. Deliberately operates
    on an explicit list the user confirmed — never a whole-playlist sweep — so only
    the outliers get re-encoded. ffmpeg does the heavy lifting in its own process,
    so a thread pool (not a process pool) is enough to run several in parallel.
    """

    def __init__(self, target_lufs: float, max_gain: float = 12.0,
                 workers: Optional[int] = None) -> None:
        self.target_lufs = target_lufs
        self.max_gain = max_gain
        self.workers = workers if workers and workers > 0 else _default_workers()
        self.total = 0
        self.done = 0
        self.fixed = 0
        self.current = ""
        self.errors: list[tuple[str, str]] = []
        self.running = False
        self.finished = False
        self._cancel = threading.Event()

    def cancel(self) -> None:
        self._cancel.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    @property
    def fraction(self) -> float:
        return (self.done / self.total) if self.total else 0.0

    def _one(self, t: Track) -> tuple[Track, dict]:
        res = energy.normalize_loudness(t.local_path, self.target_lufs, self.max_gain)
        return t, res

    def run(self, tracks: list[Track]) -> None:
        """Normalize the given tracks (each must have a local file). Runs on a
        worker thread; never raises — per-track errors are collected."""
        self.running = True
        try:
            todo = [t for t in tracks
                    if t.local_path and Path(t.local_path).exists()
                    and Path(t.local_path).suffix.lower() in energy.SUPPORTED_EXTS]
            self.total = len(todo)
            if not todo:
                return
            workers = min(self.workers, len(todo))
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs = {ex.submit(self._one, t): t for t in todo}
                for fut in as_completed(futs):
                    if self._cancel.is_set():
                        for f in futs:
                            f.cancel()
                        break
                    t = futs[fut]
                    self.current = Path(t.local_path).name
                    try:
                        _, res = fut.result()
                        for k in ("lufs", "lra", "true_peak"):
                            if k in res:
                                setattr(t, k, res[k])
                        self.fixed += 1
                    except Exception as e:  # noqa: BLE001
                        self.errors.append((Path(t.local_path).name, str(e)))
                    finally:
                        self.done += 1
        except Exception as e:  # noqa: BLE001
            self.errors.append(("<setup>", str(e)))
        finally:
            self.running = False
            self.finished = True


class AnalysisJob:
    """A single run over a list of library Tracks. Poll its fields for progress."""

    def __init__(self, force: bool = False, rich: bool = False,
                 workers: Optional[int] = None) -> None:
        self.force = force
        self.rich = rich
        self.workers = workers if workers and workers > 0 else _default_workers()
        self.total = 0
        self.done = 0
        self.tagged = 0
        self.current = ""
        self.errors: list[tuple[str, str]] = []
        self.running = False
        self.finished = False
        self._cancel = threading.Event()

    def cancel(self) -> None:
        self._cancel.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    @property
    def fraction(self) -> float:
        return (self.done / self.total) if self.total else 0.0

    def _partition(self, tracks: list[Track]) -> list[Track]:
        """Tracks with a usable local file that still need analysis (fast, no essentia)."""
        todo: list[Track] = []
        for t in tracks:
            p = t.local_path
            if not p or not p.exists() or p.suffix.lower() not in energy.SUPPORTED_EXTS:
                continue
            if not self.force and energy.read_existing_energy(p) is not None:
                continue
            todo.append(t)
        return todo

    def run(self, tracks: list[Track]) -> None:
        """Analyze the given tracks, writing energy to each file and the Track.

        Runs on a worker thread. Never raises — per-track errors are collected.
        Fans out across `self.workers` processes (workers==1 stays in-thread).
        """
        self.running = True
        try:
            todo = self._partition(tracks)
            self.total = len(todo)
            if not todo:
                return
            workers = min(self.workers, len(todo))
            if workers <= 1:
                self._run_inline(todo)
            else:
                self._run_pool(todo, workers)
        except Exception as e:  # noqa: BLE001 — model load / import / pool failure
            self.errors.append(("<setup>", str(e)))
        finally:
            self.running = False
            self.finished = True

    def _run_inline(self, todo: list[Track]) -> None:
        """Single-thread fallback: build predictors once, loop sequentially."""
        models = energy.ensure_models()
        predictors = energy.build_predictors(models, rich=self.rich)
        for t in todo:
            if self._cancel.is_set():
                break
            p = t.local_path
            self.current = p.name
            try:
                res = energy.analyze(p, predictors)
                energy.write_energy(p, res["energy"],
                                    extras=energy.extras_from_result(res, self.rich))
                _apply_result(t, res, self.rich)
                self.tagged += 1
            except Exception as e:  # noqa: BLE001 — never let the thread die
                self.errors.append((p.name, str(e)))
            finally:
                self.done += 1

    def _run_pool(self, todo: list[Track], workers: int) -> None:
        """Fan out across `workers` processes; reflect results as they complete."""
        by_path = {str(t.local_path): t for t in todo}
        # 'spawn' avoids the TensorFlow/Essentia-after-fork deadlock on macOS.
        ctx = get_context("spawn")
        with ProcessPoolExecutor(max_workers=workers, mp_context=ctx,
                                 initializer=_worker_init,
                                 initargs=(self.rich,)) as ex:
            futs = {ex.submit(_worker_analyze, sp): sp for sp in by_path}
            for fut in as_completed(futs):
                if self._cancel.is_set():
                    ex.shutdown(cancel_futures=True)
                    break
                sp = futs[fut]
                t = by_path[sp]
                self.current = Path(sp).name
                try:
                    _, res = fut.result()
                    _apply_result(t, res, self.rich)
                    self.tagged += 1
                except Exception as e:  # noqa: BLE001
                    self.errors.append((Path(sp).name, str(e)))
                finally:
                    self.done += 1
