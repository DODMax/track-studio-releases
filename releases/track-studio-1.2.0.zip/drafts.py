"""Named set drafts — the on-disk half of the Build page's working session.

A set is rarely finished in one sitting. `runtime.build_state` already keeps one
alive while the app runs (so switching tabs doesn't discard it), but that dies
with the process; a draft is the same session written to disk.

What's stored is what it takes to *rebuild* the session, not a copy of it: the
pool's source (the playlist nodes or download batch it was dug from), the knobs,
and the set as an ordered list of track ids. Ids rather than track copies,
because the library is the source of truth for what a track is — a resumed draft
picks up a re-analyzed energy, a corrected BPM or a moved file for free. The
cost is that a track which has since left the library can't come back, so
`resume` reports those rather than failing.

Drafts are a list, not a single slot: a Saturday set and a Sunday set are
different work, and finishing one shouldn't overwrite the other.

Two kinds of save, same shape on disk:

- **named drafts** (`.set_drafts.json`) — deliberate, kept until deleted.
- **the session** (`.build_session.json`) — one slot, rewritten as you work and
  restored on the next launch. Nobody should have to remember to press Save to
  keep the work they're in the middle of; the named drafts are for deciding a
  set is worth keeping *apart* from whatever you do next.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime
from pathlib import Path

from config import ROOT

DRAFTS_PATH = ROOT / ".set_drafts.json"
SESSION_PATH = ROOT / ".build_session.json"


@dataclass
class Draft:
    """One saved set-in-progress. `entries` is [{track_id, block_id, role}]."""
    name: str
    pool_name: str = ""
    saved: str = ""                     # ISO timestamp
    # --- how to rebuild the pool ---
    # The named source is tried first, so a resumed draft sees the crate as it
    # is *today* (tracks added to the playlist since are in the pool). The id
    # list is the fallback for when that source is gone or was never named —
    # a pool seeded from a played gig has no playlist to point at.
    pool_ids: list[str] = field(default_factory=list)
    node_id: str | None = None
    batch_name: str | None = None
    pool_track_ids: list[str] = field(default_factory=list)
    include_dl: bool = True
    # --- the knobs ---
    preset: str = ""
    grain: str = "track"
    energy_dir: int = 1
    valence_dir: int = 0
    scope: str = "pool"
    # --- the set ---
    entries: list[dict] = field(default_factory=list)

    @property
    def n_tracks(self) -> int:
        return len(self.entries)

    @property
    def when(self) -> str:
        """'today 14:32' / 'yesterday 02:10' / '12 Aug' — a saved-at you can scan."""
        try:
            ts = datetime.fromisoformat(self.saved)
        except ValueError:
            return ""
        days = (datetime.now().date() - ts.date()).days
        if days == 0:
            return f"today {ts:%H:%M}"
        if days == 1:
            return f"yesterday {ts:%H:%M}"
        if days < 7:
            return f"{days} days ago"
        return f"{ts:%d %b}"


def _read() -> dict:
    if not DRAFTS_PATH.exists():
        return {}
    try:
        data = json.loads(DRAFTS_PATH.read_text())
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}


def _write(data: dict) -> None:
    DRAFTS_PATH.write_text(json.dumps(data, indent=1, ensure_ascii=False))


def _from_raw(name: str, raw: dict) -> Draft:
    """Tolerant of drafts written by an older shape — unknown keys are dropped
    and missing ones fall back to the dataclass defaults."""
    known = {f.name for f in fields(Draft)}
    return Draft(**{"name": name, **{k: v for k, v in raw.items() if k in known}})


def all_drafts() -> list[Draft]:
    """Every saved draft, most recently saved first."""
    out = [_from_raw(name, raw) for name, raw in _read().items()]
    out.sort(key=lambda d: d.saved, reverse=True)
    return out


def get(name: str) -> Draft | None:
    raw = _read().get(name)
    return _from_raw(name, raw) if raw else None


def exists(name: str) -> bool:
    return name in _read()


def save(draft: Draft) -> Draft:
    """Write a draft under its name, stamping it as saved now. Overwrites."""
    draft.saved = datetime.now().isoformat(timespec="seconds")
    data = _read()
    data[draft.name] = {k: v for k, v in asdict(draft).items() if k != "name"}
    _write(data)
    return draft


def delete(name: str) -> None:
    data = _read()
    if data.pop(name, None) is not None:
        _write(data)


def unique_name(base: str) -> str:
    """`base`, or 'base (2)' etc. — a default that never silently overwrites."""
    base = (base or "Untitled set").strip() or "Untitled set"
    data = _read()
    if base not in data:
        return base
    n = 2
    while f"{base} ({n})" in data:
        n += 1
    return f"{base} ({n})"


def save_session(draft: Draft) -> None:
    """Overwrite the autosaved working session. Best-effort: a set being built
    is worth keeping, but never at the price of an exception mid-click."""
    draft.saved = datetime.now().isoformat(timespec="seconds")
    try:
        SESSION_PATH.write_text(json.dumps(asdict(draft), indent=1,
                                           ensure_ascii=False))
    except OSError:
        pass


def load_session() -> Draft | None:
    """The session the last run left behind, if any."""
    if not SESSION_PATH.exists():
        return None
    try:
        raw = json.loads(SESSION_PATH.read_text())
    except (json.JSONDecodeError, OSError):
        return None
    if not isinstance(raw, dict) or not raw.get("entries"):
        return None
    return _from_raw(raw.get("name") or "", raw)


def clear_session() -> None:
    try:
        SESSION_PATH.unlink(missing_ok=True)
    except OSError:
        pass


def entries_payload(entries) -> list[dict]:
    """`microsets.SetEntry` list → the stored shape."""
    return [{"track_id": e.track.id, "block_id": e.block_id, "role": e.role}
            for e in entries]


def rehydrate(payload: list[dict], *pools) -> tuple[list, list[str]]:
    """Stored entries → (SetEntry list, ids that no longer resolve).

    `pools` are searched in order — the draft's own pool first, then whatever
    wider net the caller offers (the library) — so a track that has since left
    the playlist still comes back rather than silently vanishing from the set.
    """
    import microsets

    by_id: dict[str, object] = {}
    for pool in reversed(pools):            # earlier pools win
        by_id.update({t.id: t for t in pool})
    out, missing = [], []
    for row in payload:
        track = by_id.get(row.get("track_id"))
        if track is None:
            missing.append(row.get("track_id"))
            continue
        out.append(microsets.SetEntry(track=track,
                                      block_id=row.get("block_id"),
                                      role=row.get("role")))
    return out, missing


if __name__ == "__main__":       # quick look at what's on disk
    print(f"{DRAFTS_PATH}\n")
    for d in all_drafts():
        print(f"  {d.name:<30} {d.n_tracks:>3} tracks  "
              f"from {d.pool_name!r:<30} {d.when}")
