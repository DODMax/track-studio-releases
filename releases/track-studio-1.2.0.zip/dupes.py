"""“Do I already have this?” — the check that runs before a download.

Rekordbox cannot answer this for you. Its collection is keyed by file location,
so a second copy of a track at a second path imports as a second entry, silently,
however identical the tags. And two entries costs more than disk: `history` and
`mixmodel` key on the rekordbox track id, so a duplicate splits a track's play
evidence across both copies — precisely what the "2+ nights = confirmed" rule is
most sensitive to.

So the check lives here, and runs at the point of *intent* — when a link is
fetched and when the inbox is listed, before any bytes move. It never blocks:
there are good reasons to fetch a second copy (a lossless replacement for a
128 kbps rip, a mix that only looks like one you own). It just refuses to let it
happen silently.

Matching reuses `match.match_track` rather than inventing a comparison,
deliberately: that one scores title and artist independently and strips generic
mix qualifiers ("Original Mix") while keeping "remix" and the remixer's name, so
a remix never collapses into the original it is named after.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

from match import match_track, prep_choices

# Where a match was found, best answer first: owning a track in rekordbox is a
# stronger "you have this" than a file downloaded and not yet imported.
REKORDBOX, DOWNLOADED = "rekordbox", "downloaded"

# A remix *attribution* — "(Kolsch Remix)", "- Someone's Rework", "[X VIP]".
# Generic mix qualifiers ("Extended Mix", "Radio Edit") are deliberately not in
# here: those describe a rendition of the same record, this describes a new one.
_REMIX = re.compile(
    r"(?:[(\[]|\s[-–]\s)\s*"
    r"([^)\]]*?\b(?:remix|rework|bootleg|flip|vip|refix|mashup)\b[^)\]]*?)"
    r"\s*(?:[)\]]|$)",
    re.IGNORECASE)
_NONWORD = re.compile(r"[^a-z0-9 ]+")
_WS = re.compile(r"\s+")


def remix_tag(title: str) -> str:
    """The remix attribution in a title, normalized — '' when there is none.

    `match` keeps "remix" and the remixer's name in its comparison, but a long
    title can still clear the certainty bar with a whole remix credit bolted on:
    "Visual Distortion of Reality" against the same title + "(Kolsch Remix)"
    scores 88, and a longer one would score higher still. A remix is a different
    record, so when the two sides disagree here the match is never reported as
    certain — it drops to "possible dupe", which is honestly what it is.
    """
    m = _REMIX.search(title or "")
    if not m:
        return ""
    # Apostrophes are dropped rather than spaced, so a straight quote, a curly
    # one and none at all all reduce to the same credit.
    s = m.group(1).lower().replace("'", "").replace("’", "")
    return _WS.sub(" ", _NONWORD.sub(" ", s)).strip()


def isrc_index(tracks: list) -> dict[str, int]:
    """Map ISRC -> first track index, for exact matching when ids are present."""
    out: dict[str, int] = {}
    for i, t in enumerate(tracks):
        if t.isrc:
            out.setdefault(t.isrc.upper(), i)
    return out


@dataclass
class Existing:
    """A track already in the library that a pending download looks like."""
    track: "Track"          # noqa: F821 - library.Track, duck-typed (leaf module)
    where: str              # REKORDBOX / DOWNLOADED
    via: str                # isrc / fuzzy
    score: float            # 0..100 (100 for an ISRC hit)
    same_rendition: bool = True   # the two titles agree on the remix credit

    @property
    def certain(self) -> bool:
        """An ISRC hit is identity; a high fuzzy score is as good as one here.

        Below that the names merely line up, which is worth showing but not
        worth stating as fact — see `match.Match.confidence` for the tiers. A
        disagreement over the remix credit caps it regardless of score.
        """
        return (self.via == "isrc" or self.score >= 92) and self.same_rendition

    @property
    def where_label(self) -> str:
        if self.where == REKORDBOX:
            # Live-DB playlists are leaf names, XML ones are "Folder / Name"
            # paths; the leaf is what you'd recognise either way.
            names = [p.split(" / ")[-1] for p in (self.track.rekordbox_playlists or [])]
            return f"in rekordbox — {names[0]}" if names else "in rekordbox"
        folder = self.track.local_path.parent.name if self.track.local_path else ""
        return f"downloaded — {folder}" if folder else "downloaded, not yet imported"

    @property
    def chip(self) -> str:
        return "already have" if self.certain else "possible dupe"

    @property
    def detail(self) -> str:
        """One line for a tooltip: what matched, where it lives, how sure we are."""
        how = "same ISRC" if self.via == "isrc" else f"{self.score:.0f}% name match"
        if not self.same_rendition:
            how += ", different remix credit"
        return f"{self.track.display} · {self.where_label} ({how})"


class Index:
    """The library, prepared once for repeated lookups.

    Building the pools costs a normalization pass over every track, so build one
    Index per scan and reuse it across candidates — never one per candidate.
    """

    def __init__(self, tracks: list) -> None:
        # A track you own is one with a file or a rekordbox entry. Spotify-only
        # rows (wanted, never sourced) are exactly what you're downloading, so
        # they must not count as having it.
        pools = [
            (REKORDBOX, [t for t in tracks if t.in_rekordbox]),
            (DOWNLOADED, [t for t in tracks if t.local_path and not t.in_rekordbox]),
        ]
        self._pools = [
            (where, pool, prep_choices((t.artist, t.title) for t in pool),
             isrc_index(pool))
            for where, pool in pools
        ]

    def lookup(self, artist: str, title: str, isrc: Optional[str] = None,
               cutoff: float = 78.0) -> Optional[Existing]:
        """The library track this candidate looks like, or None.

        `artist` matters: `match_track` requires both fields to clear a bar, so a
        candidate with no artist (an unparseable video title, say) never matches.
        That's the intended trade — title-only matching is the false-positive
        trap `match` was written to avoid.
        """
        isrc = (isrc or "").strip().upper() or None
        # ISRC across *both* pools first: an exact id in the download folder beats
        # a name that merely resembles something in rekordbox.
        if isrc:
            for where, pool, _choices, by_isrc in self._pools:
                i = by_isrc.get(isrc)
                if i is not None:
                    return Existing(pool[i], where, "isrc", 100.0)
        want_remix = remix_tag(title)
        for where, pool, choices, _by_isrc in self._pools:
            if not choices:
                continue
            m = match_track(artist or "", title or "", choices, cutoff=cutoff)
            if m.hit:
                hit = pool[m.target_index]
                return Existing(hit, where, "fuzzy", m.score,
                                same_rendition=want_remix == remix_tag(hit.title))
        return None


if __name__ == "__main__":
    # Self-test against the live library: how much of the download root is
    # already sitting in rekordbox under a different path?
    import runtime
    runtime._bootstrap()
    idx = Index(runtime.library.tracks)
    pending = [t for t in runtime.library.tracks if t.local_path and not t.in_rekordbox]
    print(f"{len(runtime.library.tracks)} tracks indexed, {len(pending)} pending local")
    hits = 0
    for t in pending:
        e = idx.lookup(t.artist, t.title, t.isrc)
        # A pending track finds *itself* in the DOWNLOADED pool — only a
        # rekordbox hit means the same music is already in the collection.
        if e and e.where == REKORDBOX:
            hits += 1
            print(f"  {t.display}  ->  {e.detail}")
    print(f"{hits} pending file(s) look like something already in rekordbox")
