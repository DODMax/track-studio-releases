#!/usr/bin/env python3
"""Track Energy Tagger — analyze MP3/M4A files with Essentia and write Energy 1-10 to Comments.

Usage:
    python energy.py /path/to/folder              # analyze + tag
    python energy.py /path/to/folder --dry-run    # preview only
    python energy.py /path/to/folder --force      # re-analyze even if already tagged
    python energy.py /path/to/folder --rich       # also write Dance score + Valence

Energy is written into the file's Comments tag as `Energy NN` (zero-padded, NN in 01..10).
This is read by rekordbox into the Comments column and is filterable in Intelligent Playlists.
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import urllib.request
from pathlib import Path

# Heavy ML imports are deferred until we actually need to analyze a track
# (so --dry-run / `--help` stays snappy).

ROOT = Path(__file__).resolve().parent
MODELS_DIR = ROOT / "models"

# (filename, url) for each model we download lazily on first run.
MODEL_FILES = {
    # MusiCNN backbone — pairs with the DEAM (arousal/valence) and danceability heads.
    "embeddings": (
        "msd-musicnn-1.pb",
        "https://essentia.upf.edu/models/feature-extractors/musicnn/msd-musicnn-1.pb",
    ),
    "deam": (
        "deam-msd-musicnn-2.pb",
        "https://essentia.upf.edu/models/classification-heads/deam/deam-msd-musicnn-2.pb",
    ),
    "danceability": (
        "danceability-msd-musicnn-1.pb",
        "https://essentia.upf.edu/models/classification-heads/danceability/danceability-msd-musicnn-1.pb",
    ),
    # Discogs-EffNet backbone — pairs with the genre and moodtheme heads (rich only).
    "effnet": (
        "discogs-effnet-bs64-1.pb",
        "https://essentia.upf.edu/models/feature-extractors/discogs-effnet/discogs-effnet-bs64-1.pb",
    ),
    "genre": (
        "genre_discogs400-discogs-effnet-1.pb",
        "https://essentia.upf.edu/models/classification-heads/genre_discogs400/genre_discogs400-discogs-effnet-1.pb",
    ),
    "moodtheme": (
        "mtg_jamendo_moodtheme-discogs-effnet-1.pb",
        "https://essentia.upf.edu/models/classification-heads/mtg_jamendo_moodtheme/mtg_jamendo_moodtheme-discogs-effnet-1.pb",
    ),
    # Class-label JSONs paired with the genre and moodtheme heads. Tiny.
    "genre_classes": (
        "genre_discogs400-discogs-effnet-1.json",
        "https://essentia.upf.edu/models/classification-heads/genre_discogs400/genre_discogs400-discogs-effnet-1.json",
    ),
    "moodtheme_classes": (
        "mtg_jamendo_moodtheme-discogs-effnet-1.json",
        "https://essentia.upf.edu/models/classification-heads/mtg_jamendo_moodtheme/mtg_jamendo_moodtheme-discogs-effnet-1.json",
    ),
}

SUPPORTED_EXTS = {".mp3", ".m4a"}
ENERGY_RE = re.compile(r"Energy\s+(\d{1,2})", re.IGNORECASE)


def ensure_models() -> dict[str, Path]:
    """Download model files into ./models/ if missing. Returns {role: path}."""
    MODELS_DIR.mkdir(exist_ok=True)
    paths = {}
    for role, (name, url) in MODEL_FILES.items():
        target = MODELS_DIR / name
        if not target.exists():
            print(f"  ↳ downloading {name} ...", flush=True)
            urllib.request.urlretrieve(url, target)
        paths[role] = target
    return paths


def find_audio_files(folder: Path) -> list[Path]:
    """Walk folder for supported audio files; ignore hidden/macOS metadata."""
    out = []
    for p in sorted(folder.iterdir()):
        if p.name.startswith("."):
            continue
        if p.suffix.lower() in SUPPORTED_EXTS:
            out.append(p)
    return out


def find_skipped_files(folder: Path) -> list[Path]:
    """Audio files we deliberately skip (WAV, etc.) — for the summary report."""
    out = []
    skip_exts = {".wav", ".aiff", ".flac", ".aac"}
    for p in sorted(folder.iterdir()):
        if p.name.startswith("."):
            continue
        if p.suffix.lower() in skip_exts:
            out.append(p)
    return out


def read_existing_energy(path: Path) -> int | None:
    """Return the Energy NN already tagged on this file, or None."""
    from mutagen import File as MutagenFile

    f = MutagenFile(path)
    if f is None or f.tags is None:
        return None
    comments = _read_comments(f, path)
    if not comments:
        return None
    m = ENERGY_RE.search(comments)
    return int(m.group(1)) if m else None


def _read_comments(mf, path: Path) -> str:
    """Pull the human-readable Comments string from any supported tag container."""
    suffix = path.suffix.lower()
    if suffix == ".mp3":
        # COMM frames are keyed `COMM::eng` etc.; take the first non-empty.
        for key, frame in mf.tags.items():
            if key.startswith("COMM"):
                text = "".join(str(s) for s in frame.text)
                if text:
                    return text
        return ""
    if suffix == ".m4a":
        vals = mf.tags.get("\xa9cmt") or mf.tags.get("©cmt") or []
        return vals[0] if vals else ""
    return ""


# Texture descriptors are always written (independent of --rich); see analyze().
TEXTURE_KEYS = ("brightness", "dynamic_complexity", "spectral_complexity", "onset_rate")

# EBU R128 loudness (ITU-R BS.1770-4) — written as its own Comments segment,
# independent of the Energy payload, so it can be measured without re-running the
# ML pass. Kept in sync with tagging.LUFS_RE/LRA_RE/TP_RE.
LOUDNESS_KEYS = ("lufs", "lra", "true_peak")

_LOUDNESS_SEG_RE = re.compile(
    r"\bLUFS\s+-?[\d.]+"
    r"(?:\s*\|\s*LRA\s+[\d.]+)?"
    r"(?:\s*\|\s*TP\s+-?[\d.]+)?"
    r"(?=\s*\||$)",
    re.IGNORECASE,
)


def extras_from_result(res: dict, rich: bool) -> dict:
    """Assemble write_energy's `extras` from an analyze() result. Always carries
    arousal + texture; `rich` also adds valence / danceability / genre / moods.
    Single source of truth shared by the CLI, AnalysisJob, and the pool worker."""
    extras = {"arousal": res["arousal"]}
    if rich:
        for k in ("valence", "danceability", "genre", "moods"):
            if k in res:
                extras[k] = res[k]
    for k in TEXTURE_KEYS:
        if k in res:
            extras[k] = res[k]
    return extras


def write_energy(path: Path, energy: int, extras: dict | None = None) -> None:
    """Write Energy NN (and optional extras) into the file's Comments tag."""
    bits = [f"Energy {energy:02d}"]
    if extras:
        if "arousal" in extras:
            bits.append(f"A {extras['arousal']:.2f}")
        if "danceability" in extras:
            bits.append(f"Dance {extras['danceability']:.2f}")
        if "valence" in extras:
            bits.append(f"Valence {extras['valence']:.2f}")
        if extras.get("genre"):
            bits.append(f"Style {extras['genre']}")
        if extras.get("moods"):
            bits.append(f"Mood {','.join(extras['moods'])}")
        if "brightness" in extras:
            bits.append(f"Bright {extras['brightness']:.0f}")
        if "dynamic_complexity" in extras:
            bits.append(f"Dyn {extras['dynamic_complexity']:.2f}")
        if "spectral_complexity" in extras:
            bits.append(f"Spec {extras['spectral_complexity']:.1f}")
        if "onset_rate" in extras:
            bits.append(f"Onset {extras['onset_rate']:.2f}")
    new_comment_payload = " | ".join(bits)
    _rewrite_comment(path, lambda existing: _merge_comment(existing, new_comment_payload))


def _rewrite_comment(path: Path, transform) -> None:
    """Read the Comments tag, apply `transform(existing) -> merged`, write it back.

    Shared by write_energy and write_loudness so the mp3/m4a tag plumbing lives in
    one place. MP3 uses ID3/COMM; M4A uses the MP4 `\xa9cmt` atom.
    """
    from mutagen.id3 import ID3, COMM
    from mutagen.mp4 import MP4

    suffix = path.suffix.lower()
    if suffix == ".mp3":
        try:
            tags = ID3(path)
        except Exception:
            tags = ID3()
        # Find an existing COMM frame to update; otherwise add a fresh one.
        existing_text = ""
        comm_key = None
        for key, frame in list(tags.items()):
            if key.startswith("COMM"):
                comm_key = key
                existing_text = "".join(str(s) for s in frame.text)
                break
        merged = transform(existing_text)
        if comm_key:
            del tags[comm_key]
        tags.add(COMM(encoding=3, lang="eng", desc="", text=merged))
        tags.save(path, v2_version=3)
        return

    if suffix == ".m4a":
        mp4 = MP4(path)
        existing = (mp4.tags.get("\xa9cmt") or [""])[0] if mp4.tags else ""
        mp4["\xa9cmt"] = [transform(existing)]
        mp4.save()
        return

    raise ValueError(f"unsupported file type: {path}")


def _merge_comment(existing: str, energy_payload: str) -> str:
    """Replace any prior `Energy NN` (and Dance/Valence) in `existing` with the new payload."""
    if not existing:
        return energy_payload
    # Strip any prior tagger-output line/segment so we don't accumulate cruft on re-runs.
    cleaned = re.sub(
        r"Energy\s+\d{1,2}"
        r"(?:\s*\|\s*A\s+[-\d.]+)?"
        r"(?:\s*\|\s*Dance\s+[\d.]+)?"
        r"(?:\s*\|\s*Valence\s+[-\d.]+)?"
        r"(?:\s*\|\s*Style\s+[^|]+?)?"
        r"(?:\s*\|\s*Mood\s+[^|]+?)?"
        r"(?:\s*\|\s*Bright\s+[\d.]+)?"
        r"(?:\s*\|\s*Dyn\s+[\d.]+)?"
        r"(?:\s*\|\s*Spec\s+[\d.]+)?"
        r"(?:\s*\|\s*Onset\s+[\d.]+)?"
        r"(?=\s*\||$)",
        "",
        existing,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(r"\s*\|\s*\|\s*", " | ", cleaned).strip(" |")
    return f"{energy_payload} | {cleaned}" if cleaned else energy_payload


def _merge_loudness_comment(existing: str, payload: str) -> str:
    """Replace any prior LUFS/LRA/TP segment, leaving the rest (incl. the Energy
    block) intact — loudness is measured independently of the energy pass."""
    if not existing:
        return payload
    cleaned = _LOUDNESS_SEG_RE.sub("", existing)
    cleaned = re.sub(r"\s*\|\s*\|\s*", " | ", cleaned).strip(" |")
    return f"{cleaned} | {payload}" if cleaned else payload


def write_loudness(path: Path, loudness: dict) -> None:
    """Merge `LUFS x | LRA y | TP z` into Comments, leaving the Energy payload
    untouched. Requires a finite `lufs` (silent files are skipped upstream)."""
    bits = [f"LUFS {loudness['lufs']:.2f}"]
    if loudness.get("lra") is not None:
        bits.append(f"LRA {loudness['lra']:.2f}")
    if loudness.get("true_peak") is not None:
        bits.append(f"TP {loudness['true_peak']:.2f}")
    payload = " | ".join(bits)
    _rewrite_comment(path, lambda existing: _merge_loudness_comment(existing, payload))


def read_existing_loudness(path: Path) -> float | None:
    """The integrated LUFS already tagged on this file, or None."""
    from mutagen import File as MutagenFile

    from tagging import LUFS_RE

    f = MutagenFile(path)
    if f is None or f.tags is None:
        return None
    comments = _read_comments(f, path)
    if not comments:
        return None
    m = LUFS_RE.search(comments)
    return float(m.group(1)) if m else None


def extract_loudness(path: Path) -> dict:
    """EBU R128 loudness: integrated LUFS, loudness range (LU), true peak (dBTP).

    The pro standard (ITU-R BS.1770-4) for comparing how tracks are mastered.
    Pure DSP — no ML models — so this runs standalone, per playlist, without
    paying the predictor build/TensorFlow import cost.
    """
    import essentia.standard as es
    import numpy as np

    audio, sr, _ch, _md5, _br, _codec = es.AudioLoader(filename=str(path))()
    # LoudnessEBUR128 needs stereo; duplicate mono so the measurement is valid.
    if audio.ndim == 1:
        audio = np.column_stack([audio, audio])
    elif audio.shape[1] == 1:
        audio = np.repeat(audio, 2, axis=1)
    _mom, _short, integrated, lra = es.LoudnessEBUR128(sampleRate=sr)(audio)

    # True peak catches inter-sample overs that plain sample-peak misses — loud
    # club masters routinely sit above 0 dBTP. Measure each channel and take the
    # max: downmixing to mono first cancels out-of-phase peaks and under-reports
    # the true peak (matches ffmpeg's per-channel loudnorm reading).
    peak = 0.0
    for c in range(audio.shape[1]):
        chan = np.ascontiguousarray(audio[:, c], dtype=np.float32)
        p = es.TruePeakDetector(sampleRate=sr)(chan)[1]
        if len(p):
            peak = max(peak, float(np.max(np.abs(p))))

    out = {"lra": float(lra), "true_peak": float(20.0 * np.log10(max(peak, 1e-9)))}
    # Digital silence integrates to -inf; omit so it reads as unmeasured.
    if np.isfinite(integrated):
        out["lufs"] = float(integrated)
    return out


import json as _json
import shutil as _shutil
import subprocess as _subprocess

FFMPEG = _shutil.which("ffmpeg") or "ffmpeg"
FFPROBE = _shutil.which("ffprobe") or "ffprobe"
BACKUP_DIR_NAME = ".loudness_backup"


def _source_bitrate(path: Path) -> int:
    """Source audio bitrate in bps (0 if unknown), via ffprobe."""
    try:
        out = _subprocess.run(
            [FFPROBE, "-v", "error", "-select_streams", "a:0",
             "-show_entries", "stream=bit_rate", "-of", "csv=p=0", str(path)],
            capture_output=True, text=True)
        return int((out.stdout or "0").strip() or 0)
    except Exception:
        return 0


def _copy_tags(src: Path, dst: Path) -> None:
    """Copy the full tag container (incl. Comments + cover art) from src to dst."""
    suffix = src.suffix.lower()
    if suffix == ".m4a":
        from mutagen.mp4 import MP4
        s = MP4(src)
        d = MP4(dst)
        if s.tags:
            d.delete()
            for k, v in s.tags.items():
                d[k] = v
            d.save()
    elif suffix == ".mp3":
        from mutagen.id3 import ID3
        try:
            ID3(src).save(dst)   # writes src's frames (APIC cover, COMM) onto dst
        except Exception:
            pass


def normalize_loudness(path: Path, target_lufs: float, max_gain: float = 12.0) -> dict:
    """EBU R128 loudness normalization: bake a single linear gain of
    `target_lufs − measured_lufs` into the audio so the track matches the reference
    loudness. This is the ReplayGain *algorithm* applied destructively to the
    samples (via a re-encode) — NOT a ReplayGain tag, which rekordbox ignores; the
    level change is physically in the file, so any player reproduces it.

    Transparent by design — only the level changes, dynamics and relative peaks are
    untouched. That's the right tool for equalizing a set of already-mastered tracks
    (unlike a true-peak-limited normalize, which would *lower* hot-peaked club
    masters and squash their dynamics to hit a peak ceiling). `max_gain` clamps
    pathological corrections.

    Re-encodes (AAC for m4a, LAME for mp3) at ≥ the source bitrate, preserves all
    tags + cover art, backs the original up to a hidden `.loudness_backup/` folder,
    replaces the file in place (so rekordbox's path link holds), then re-measures
    and rewrites the loudness tag. Returns the new measurement dict.
    """
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix not in (".m4a", ".mp3"):
        raise ValueError(f"unsupported file type for normalize: {path}")

    pre = extract_loudness(path)
    if "lufs" not in pre:
        raise RuntimeError("track is silent / loudness unmeasurable")
    # abs(): a negative max_gain would make this clamp degenerate — it would
    # collapse every correction to the same wrong constant instead of limiting it.
    limit = abs(max_gain)
    gain = max(-limit, min(limit, target_lufs - pre["lufs"]))
    bitrate = max(_source_bitrate(path), 256_000)
    codec = "aac" if suffix == ".m4a" else "libmp3lame"

    tmp = path.with_name(f"{path.stem}.ltmp{suffix}")
    p2 = _subprocess.run(
        [FFMPEG, "-hide_banner", "-nostats", "-y", "-i", str(path),
         "-map", "0:a", "-map_metadata", "-1", "-af", f"volume={gain:.2f}dB",
         "-c:a", codec, "-b:a", str(bitrate), "-ar", "44100", str(tmp)],
        capture_output=True, text=True)
    if p2.returncode != 0 or not tmp.exists():
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"gain apply failed: {p2.stderr[-300:]}")

    try:
        _copy_tags(path, tmp)              # carry Energy/texture tags + cover
        backup_dir = path.parent / BACKUP_DIR_NAME
        backup_dir.mkdir(exist_ok=True)
        backup = backup_dir / path.name
        if not backup.exists():            # keep the first (true) original
            _shutil.copy2(path, backup)
        os.replace(tmp, path)              # atomic in-place swap
    except Exception:
        tmp.unlink(missing_ok=True)
        raise

    res = extract_loudness(path)
    if "lufs" in res:
        write_loudness(path, res)
    return res


def build_predictors(models: dict[str, Path], rich: bool):
    """Construct Essentia algorithm instances once; reused across tracks.

    Returns a dict with the loaded predictors. When `rich`, the Discogs-EffNet
    embedding model and the genre + moodtheme heads are also loaded.
    """
    import essentia.standard as es

    bag = {
        "musicnn": es.TensorflowPredictMusiCNN(
            graphFilename=str(models["embeddings"]),
            output="model/dense/BiasAdd",
        ),
        "deam": es.TensorflowPredict2D(
            graphFilename=str(models["deam"]),
            output="model/Identity",
        ),
        # Texture pass is computed by _extract_texture() (a handful of targeted
        # Essentia DSP algorithms, ~7x faster than a full MusicExtractor); it needs
        # no loaded model, so nothing is added to the predictor bag for it.
    }
    if rich:
        bag["danceability"] = es.TensorflowPredict2D(
            graphFilename=str(models["danceability"]),
            output="model/Softmax",
        )
        bag["effnet"] = es.TensorflowPredictEffnetDiscogs(
            graphFilename=str(models["effnet"]),
            output="PartitionedCall:1",
        )
        bag["genre"] = es.TensorflowPredict2D(
            graphFilename=str(models["genre"]),
            input="serving_default_model_Placeholder",
            output="PartitionedCall:0",
        )
        bag["moodtheme"] = es.TensorflowPredict2D(
            graphFilename=str(models["moodtheme"]),
            output="model/Sigmoid",
        )
        bag["genre_classes"] = _load_classes(models["genre_classes"])
        bag["moodtheme_classes"] = _load_classes(models["moodtheme_classes"])
    return bag


def _load_classes(json_path: Path) -> list[str]:
    """Read class label list from the model's JSON metadata."""
    import json

    if not json_path.exists():
        return []
    with open(json_path) as f:
        return json.load(f).get("classes", [])


def _shorten_genre(label: str) -> str:
    """Discogs labels look like 'Electronic---Tropical House' → 'Tropical House'."""
    return label.split("---", 1)[-1].strip()


# Spectral centroid via the targeted pipeline runs ~2x the scale of a full
# MusicExtractor; this calibrates it back to ~Hz (within ~10% across test tracks),
# so brightness stays comparable to the reference and to the UI display ranges.
_BRIGHTNESS_CALIBRATION = 0.5


def _extract_texture(path: Path) -> dict:
    """Targeted DSP texture pass — only the four descriptors we keep, computed with
    a few small Essentia algorithms instead of a full MusicExtractor (~7x faster).

    brightness = spectral centroid (Hz, dark↔bright); dynamic_complexity = loudness
    deviation (flat↔punchy); spectral_complexity = spectral-peak density
    (clean↔busy); onset_rate = onsets/sec (sparse↔busy). Algorithms are built per
    call: OnsetRate in particular is stateful and must not be reused across files.
    """
    import essentia.standard as es
    import numpy as np

    audio = es.MonoLoader(filename=str(path), sampleRate=44100)()
    if len(audio) == 0:
        return {}
    eq = es.EqualLoudness(sampleRate=44100)(audio)
    window = es.Windowing(type="blackmanharris62")
    spectrum = es.Spectrum()
    centroid = es.Centroid(range=22050)
    spec_complexity = es.SpectralComplexity()

    cents, comps = [], []
    for frame in es.FrameGenerator(eq, frameSize=2048, hopSize=1024):
        spec = spectrum(window(frame))
        cents.append(centroid(spec))
        comps.append(spec_complexity(spec))

    dyn, _loudness = es.DynamicComplexity(sampleRate=44100)(audio)
    _onsets, onset_rate = es.OnsetRate()(audio)  # fresh instance — OnsetRate is stateful

    out: dict = {"dynamic_complexity": float(dyn), "onset_rate": float(onset_rate)}
    if cents:
        out["brightness"] = float(np.mean(cents)) * _BRIGHTNESS_CALIBRATION
        out["spectral_complexity"] = float(np.mean(comps))
    return out


def analyze(path: Path, predictors: dict) -> dict:
    """Run already-loaded Essentia predictors on `path`."""
    import essentia.standard as es

    audio = es.MonoLoader(filename=str(path), sampleRate=16000, resampleQuality=4)()
    musicnn_emb = predictors["musicnn"](audio)

    deam = predictors["deam"](musicnn_emb)
    # deam shape: (frames, 2) → [valence, arousal] in DEAM 1..9 scale; average over frames.
    valence = float(deam[:, 0].mean())
    arousal = float(deam[:, 1].mean())
    energy = _arousal_to_energy(arousal)

    out = {"energy": energy, "arousal": arousal, "valence": valence}

    if "danceability" in predictors:
        dance = predictors["danceability"](musicnn_emb)
        # danceability head returns (frames, 2): [danceable, not_danceable] probs.
        out["danceability"] = float(dance[:, 0].mean())

    if "effnet" in predictors:
        effnet_emb = predictors["effnet"](audio)
        # Genre: 400 sigmoid probs averaged over frames; pick top label.
        genre_probs = predictors["genre"](effnet_emb).mean(axis=0)
        genre_classes = predictors["genre_classes"]
        if len(genre_classes):
            top_idx = int(genre_probs.argmax())
            out["genre"] = _shorten_genre(genre_classes[top_idx])
            out["genre_prob"] = float(genre_probs[top_idx])
        # Moodtheme: 56 sigmoid probs; pick top 2 with prob >= 0.10.
        mood_probs = predictors["moodtheme"](effnet_emb).mean(axis=0)
        mood_classes = predictors["moodtheme_classes"]
        if len(mood_classes):
            order = mood_probs.argsort()[::-1]
            picks = [(mood_classes[i], float(mood_probs[i]))
                     for i in order[:3] if mood_probs[i] >= 0.10][:2]
            if picks:
                out["moods"] = [name for name, _ in picks]
                out["mood_probs"] = [p for _, p in picks]

    # Texture is always-on (independent of `rich`) and best-effort: never fail a
    # whole analysis over it. See _extract_texture for the descriptor meanings.
    try:
        out.update(_extract_texture(path))
    except Exception:
        pass

    return out


def _arousal_to_energy(arousal: float) -> int:
    """Map DEAM arousal onto an integer 1..10 DJ energy bucket.

    DEAM annotations use a 1..9 scale, but real-world music rarely fills the
    extremes. Empirically electronic dance music sits in arousal 5.0..6.5.
    Mapping 3.0..7.0 → 1..10 gives a useful spread for typical libraries
    while still keeping the rare ambient/peaktime extremes well-bounded.
    """
    scaled = (arousal - 3.0) / 4.0 * 9.0 + 1.0
    return max(1, min(10, int(round(scaled))))


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Tag MP3/M4A tracks with an AI-derived Energy 1-10 score (rekordbox-compatible).",
    )
    parser.add_argument("folder", type=Path, help="folder containing audio files")
    parser.add_argument("--dry-run", action="store_true", help="analyze and print, don't write tags")
    parser.add_argument("--force", action="store_true", help="re-analyze tracks already tagged")
    parser.add_argument("--rich", action="store_true", help="also write Dance + Valence")
    args = parser.parse_args()

    folder = args.folder.resolve()
    if not folder.is_dir():
        print(f"error: {folder} is not a directory", file=sys.stderr)
        return 2

    files = find_audio_files(folder)
    skipped_format = find_skipped_files(folder)

    if not files:
        print(f"No supported audio files (.mp3, .m4a) in {folder}")
        if skipped_format:
            print(f"  ({len(skipped_format)} unsupported file(s) present, e.g. WAV)")
        return 1

    print(f"Found {len(files)} supported file(s) in {folder}")
    if skipped_format:
        print(f"Skipping {len(skipped_format)} unsupported file(s) (WAV/AIFF/FLAC).")

    # Quickly partition: already-tagged vs needs-analysis (no models loaded yet).
    needs = []
    already = []
    for p in files:
        existing = read_existing_energy(p)
        if existing is not None and not args.force:
            already.append((p, existing))
        else:
            needs.append(p)

    print(f"  {len(already)} already tagged, {len(needs)} to analyze")
    if not needs:
        print("Nothing to do. Use --force to re-analyze.")
        return 0

    print("Loading models (downloads on first run, ~26 MB)...", flush=True)
    models = ensure_models()
    print("Importing essentia (slow)...", flush=True)
    predictors = build_predictors(models, rich=args.rich)

    try:
        from tqdm import tqdm
    except ImportError:
        tqdm = lambda x, **kw: x  # noqa: E731

    tagged = 0
    errors: list[tuple[Path, str]] = []
    results: list[tuple[Path, dict]] = []

    for p in tqdm(needs, desc="analyzing", unit="track"):
        try:
            res = analyze(p, predictors)
            results.append((p, res))
            if not args.dry_run:
                write_energy(p, res["energy"],
                             extras=extras_from_result(res, args.rich))
            tagged += 1
        except Exception as e:
            errors.append((p, str(e)))

    print()
    print("=" * 80)
    header = "  energy   arousal  valence  file"
    if args.rich:
        header += "  | style / mood"
    print(header)
    for p, res in results:
        line = f"  {res['energy']:>4}     {res['arousal']:>5.2f}    {res['valence']:>5.2f}  {p.name[:50]}"
        if args.rich:
            extras = []
            if res.get("genre"):
                extras.append(res["genre"])
            if res.get("moods"):
                extras.append(",".join(res["moods"]))
            line += "  | " + " · ".join(extras) if extras else ""
        print(line)
    print("=" * 80)
    action = "would-tag" if args.dry_run else "tagged"
    print(f"{action}: {tagged}   skipped (already tagged): {len(already)}   errors: {len(errors)}")
    if skipped_format:
        print(f"unsupported (WAV/etc.) not analyzed: {len(skipped_format)}")
    if errors:
        print("\nErrors:")
        for p, msg in errors:
            print(f"  ✗ {p.name}: {msg}")

    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
