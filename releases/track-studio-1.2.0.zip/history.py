"""Play history — reconstruct real DJ sets from rekordbox's history log.

Rekordbox logs every track loaded onto a deck into a `DjmdHistory` node, nested
in a year/month folder tree (folders `Attribute=1`, leaf sessions `Attribute=0`).
That log is the only record of what was *actually played*, and it is the one
signal in this app that flows backwards — everything else pushes tracks toward
rekordbox, this reads back out.

Two things make the raw log unusable as-is:

**Most sessions aren't performances.** Auditioning a crate writes history exactly
like playing a gig does. The discriminator is *harmonic adjacency* — the share of
consecutive tracks that are Camelot-compatible. Measured over this library it
separates cleanly: real sets run 60-72% against a ~17% random baseline, browsing
sits at 0-30%. Note that BPM smoothness does **not** work here: a playlist sorted
by BPM scores a near-perfect 0.2 BPM mean delta while being pure browsing, so we
also reject sequences whose artists run alphabetically (the tell of a sorted
playlist being clicked through).

**Rekordbox splits one night into several sessions.** Roughly two thirds of gig
days carry more than one leaf. Sessions are classified individually (so a digging
session doesn't contaminate the gig it shares a day with), then the performances
of one day merge into a single `Gig`.

Read-only, like `rekordbox.py`, and deliberately leaf: it resolves tracks to
rekordbox metadata (bpm/key/path) but never touches the Library — energy is
joined one level up, by `rekordbox_id`.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from statistics import mean
from typing import Iterable, Optional

from microsets import _camelot_distance

# History before 2024 describes a library that no longer exists: pre-2024 sessions
# reference ~400 tracks since deleted, and buy only 2 extra repeated transitions
# over the 171 found from 2024 on. Not worth the noise.
DEFAULT_SINCE = "2024-01-01"

# Classification thresholds — see module docstring for the measured distributions.
MIN_TRACKS = 10           # below this the rates are too noisy to judge
MIN_HARMONIC = 0.35       # vs ~0.17 expected by chance
MAX_ALPHABETICAL = 0.65   # vs 0.50 expected by chance; higher ⇒ sorted playlist
HARMONIC_COMPATIBLE = 80  # _camelot_distance: 100 same key, 80 ±1 hour or A/B flip


# ----------------------------------------------------------------------
# Data classes
# ----------------------------------------------------------------------

@dataclass
class PlayedTrack:
    """One track as it appeared in a session, in play order."""
    track_id: str
    order: int
    name: str
    artist: str
    bpm: Optional[float] = None
    key: Optional[str] = None
    path: Optional[Path] = None
    energy: Optional[int] = None   # filled on demand by `hydrate_energy`

    @property
    def display(self) -> str:
        return f"{self.artist} - {self.name}" if self.artist else self.name


@dataclass
class Session:
    """One raw rekordbox history leaf, with the metrics that classify it."""
    id: str
    name: str
    day: str                      # YYYY-MM-DD
    started: str                  # full DateCreated, orders sessions within a day
    tracks: list[PlayedTrack] = field(default_factory=list)
    # metrics (computed in `_measure`)
    harmonic_rate: float = 0.0    # share of consecutive pairs Camelot-compatible
    bpm_jitter: float = 0.0       # mean |ΔBPM| between consecutive tracks
    alphabetical_rate: float = 0.0
    repeat_rate: float = 0.0

    @property
    def n(self) -> int:
        return len(self.tracks)

    @property
    def is_performance(self) -> bool:
        """A played set rather than a crate-dig."""
        return (self.n >= MIN_TRACKS
                and self.harmonic_rate >= MIN_HARMONIC
                and self.alphabetical_rate < MAX_ALPHABETICAL)

    @property
    def verdict(self) -> str:
        if self.is_performance:
            return "performance"
        if self.n < MIN_TRACKS:
            return "short"
        if self.alphabetical_rate >= MAX_ALPHABETICAL:
            return "sorted"      # a BPM/artist-sorted playlist clicked through
        return "browsing"


@dataclass
class Gig:
    """One night: every performance session recorded on the same day, in order."""
    day: str
    sessions: list[Session] = field(default_factory=list)
    tracks: list[PlayedTrack] = field(default_factory=list)

    @property
    def n(self) -> int:
        return len(self.tracks)

    @property
    def harmonic_rate(self) -> float:
        return _harmonic_rate(self.tracks)

    @property
    def bpm_range(self) -> Optional[tuple[float, float]]:
        bpms = [t.bpm for t in self.tracks if t.bpm]
        return (min(bpms), max(bpms)) if bpms else None

    @property
    def label(self) -> str:
        try:
            d = date.fromisoformat(self.day)
        except ValueError:
            return self.day
        return d.strftime("%a %d %b %Y")


# ----------------------------------------------------------------------
# Metrics
# ----------------------------------------------------------------------

def _pairs(tracks: list[PlayedTrack]) -> Iterable[tuple[PlayedTrack, PlayedTrack]]:
    return zip(tracks, tracks[1:])


def _harmonic_rate(tracks: list[PlayedTrack]) -> float:
    """Share of consecutive pairs that are Camelot-compatible (same key, ±1 hour,
    or the relative major/minor flip). Pairs with an unparseable key are skipped
    rather than counted as misses, so a few odd keys don't sink a real set."""
    scored = [_camelot_distance(a.key or "", b.key or "") for a, b in _pairs(tracks)]
    scored = [s for s in scored if s > 0]          # 0 ⇒ key unparseable
    if not scored:
        return 0.0
    return sum(1 for s in scored if s >= HARMONIC_COMPATIBLE) / len(scored)


def _measure(s: Session) -> None:
    """Fill in the four classification metrics on a session, in place."""
    ts = s.tracks
    if len(ts) < 2:
        return
    s.harmonic_rate = _harmonic_rate(ts)
    bpms = [(a.bpm, b.bpm) for a, b in _pairs(ts) if a.bpm and b.bpm]
    s.bpm_jitter = mean(abs(a - b) for a, b in bpms) if bpms else 0.0
    artists = [(a.artist or "").lower() for a in ts]
    s.alphabetical_rate = mean(1 if a <= b else 0 for a, b in zip(artists, artists[1:]))
    s.repeat_rate = 1 - len({t.track_id for t in ts}) / len(ts)


# ----------------------------------------------------------------------
# Loading
# ----------------------------------------------------------------------

def load_sessions(since: str = DEFAULT_SINCE) -> list[Session]:
    """Read every history leaf since `since` from the live rekordbox DB.

    Tracks that have left the collection are dropped: they can't be resolved to
    metadata, and a set full of holes scores meaninglessly.
    """
    from pyrekordbox import Rekordbox6Database

    from store import load_studio_state
    db_dir = load_studio_state().get("rekordbox_db_path")
    db = Rekordbox6Database(db_dir) if db_dir else Rekordbox6Database()

    alive = {str(c.ID): c for c in db.get_content()
             if not getattr(c, "rb_local_deleted", 0)}

    sessions: list[Session] = []
    for node in db.get_history():
        if getattr(node, "rb_local_deleted", 0) or getattr(node, "Attribute", 1) != 0:
            continue                                   # deleted, or a year/month folder
        started = str(node.DateCreated or "")
        day = started[:10]
        if day < since:
            continue
        s = Session(id=str(node.ID), name=node.Name or "", day=day, started=started)
        try:
            songs = node.Songs or []
        except Exception:
            songs = []
        for entry in sorted(songs, key=lambda x: int(getattr(x, "TrackNo", 0) or 0)):
            c = alive.get(str(entry.ContentID))
            if c is None:
                continue
            raw = c.FolderPath or ""
            s.tracks.append(PlayedTrack(
                track_id=str(c.ID),
                order=int(getattr(entry, "TrackNo", 0) or 0),
                name=c.Title or "",
                artist=(c.ArtistName or (c.Artist.Name if c.Artist else "") or ""),
                bpm=(c.BPM / 100.0) if c.BPM else None,
                key=(c.KeyName or (c.Key.ScaleName if c.Key else None)) or None,
                path=Path(raw) if raw.startswith("/") else None,
            ))
        _measure(s)
        sessions.append(s)

    sessions.sort(key=lambda x: x.started)
    return sessions


def build_gigs(sessions: list[Session]) -> list[Gig]:
    """Merge each day's performance sessions into one Gig, newest first.

    Only performance sessions merge. Folding in the day's short leaves as well
    was the obvious thing to try — a gig chopped into a 30-track and a 6-track
    leaf is still one night — but measured against this library it added 271
    tracks of warm-up noise and dragged five gigs below the harmonic bar they'd
    passed individually. Days with no performance session contribute no gig.
    """
    by_day: dict[str, list[Session]] = defaultdict(list)
    for s in sessions:
        by_day[s.day].append(s)

    gigs: list[Gig] = []
    for day, day_sessions in by_day.items():
        keep = [s for s in sorted(day_sessions, key=lambda x: x.started)
                if s.is_performance]
        if not keep:
            continue
        gig = Gig(day=day, sessions=keep)
        for s in keep:
            gig.tracks.extend(s.tracks)
        gigs.append(gig)

    gigs.sort(key=lambda g: g.day, reverse=True)
    return gigs


def hydrate_energy(gig: "Gig", cache: Optional[dict] = None) -> int:
    """Fill `PlayedTrack.energy` for one gig from the files' Comments tags.

    Read off disk rather than from rekordbox's `Commnt`, which only refreshes
    when the user clicks "Reload Tag" and so lags the tagger by days. Done per
    gig (tens of files, not thousands) at the moment one is opened. Returns how
    many tracks came back tagged.
    """
    from library import _read_file_fields
    from tagging import parse_comment

    seen = cache if cache is not None else {}
    hits = 0
    for t in gig.tracks:
        if t.path is None:
            continue
        key = str(t.path)
        if key not in seen:
            try:
                seen[key] = parse_comment(_read_file_fields(t.path).get("comment") or "")
            except Exception:
                seen[key] = {}
        t.energy = seen[key].get("energy")
        hits += t.energy is not None
    return hits


# ----------------------------------------------------------------------
# Where a gig came from
# ----------------------------------------------------------------------

@dataclass
class Source:
    """A rekordbox playlist a gig drew tracks from."""
    path: str            # full tree path, e.g. "Max 2025 / 860 - Techno Peak Time"
    count: int
    share: float         # of the gig's tracks

    @property
    def name(self) -> str:
        return self.path.rsplit(" / ", 1)[-1]

    @property
    def folders(self) -> list[str]:
        """The parent folders, for mirroring the location on export."""
        return self.path.split(" / ")[:-1]


def build_membership(index: dict) -> dict[str, list[str]]:
    """track_id → the full paths of every playlist holding it.

    Full paths, not leaf names: this library has two playlists called "All"
    (`803 - Retro Dance / All` and `806 - High Chase / All`, both set-builder
    exports), and collapsing them would misattribute a gig to the wrong set.

    Takes the playlist index (`RekordboxCollection.playlist_index`, which the
    Library retains as `rekordbox_index`) rather than a collection, so this
    module stays free of `rekordbox` and callers reuse the already-loaded tree
    instead of paying for a second full DB read.
    """
    out: dict[str, list[str]] = defaultdict(list)
    for node in index.values():
        if node.is_folder:
            continue
        parts = [node.name]
        parent = index.get(node.parent_id)
        while parent is not None:
            parts.append(parent.name)
            parent = index.get(parent.parent_id)
        path = " / ".join(reversed(parts))
        for tid in node.track_ids:
            out[tid].append(path)
    return out


def gig_sources(gig: Gig, membership: dict[str, list[str]]) -> list[Source]:
    """Which playlists this gig was pulled from, most-represented first.

    A gig rarely comes from one place — the spread is the point. Callers use the
    top entry as the default export destination and offer the rest as
    alternatives rather than guessing on the user's behalf.
    """
    counts: Counter[str] = Counter()
    for t in gig.tracks:
        for path in membership.get(t.track_id, []):
            counts[path] += 1
    n = max(gig.n, 1)
    return [Source(path=p, count=c, share=c / n) for p, c in counts.most_common()]


# ----------------------------------------------------------------------
# Transition mining
# ----------------------------------------------------------------------

@dataclass
class Transition:
    """An A→B pair actually played back to back, and how often."""
    a: PlayedTrack
    b: PlayedTrack
    plays: int
    nights: int          # distinct gig days — the signal that it's a habit

    @property
    def confident(self) -> bool:
        return self.nights >= 2


def transitions(gigs: list[Gig], min_nights: int = 1) -> list[Transition]:
    """Mine consecutive pairs across gigs, ranked by nights then plays.

    Counting *nights* rather than plays is what separates a habit from a quirk:
    a pair repeated inside one session is an accident of that night, a pair
    repeated across three nights is how you mix.
    """
    plays: Counter[tuple[str, str]] = Counter()
    nights: dict[tuple[str, str], set[str]] = defaultdict(set)
    seen: dict[str, PlayedTrack] = {}

    for gig in gigs:
        for a, b in _pairs(gig.tracks):
            if a.track_id == b.track_id:
                continue
            pair = (a.track_id, b.track_id)
            plays[pair] += 1
            nights[pair].add(gig.day)
            seen.setdefault(a.track_id, a)
            seen.setdefault(b.track_id, b)

    out = [Transition(a=seen[x], b=seen[y], plays=n, nights=len(nights[(x, y)]))
           for (x, y), n in plays.items() if len(nights[(x, y)]) >= min_nights]
    out.sort(key=lambda t: (t.nights, t.plays), reverse=True)
    return out


if __name__ == "__main__":
    sessions = load_sessions()
    gigs = build_gigs(sessions)
    verdicts = Counter(s.verdict for s in sessions)
    print(f"{len(sessions)} sessions since {DEFAULT_SINCE}: {dict(verdicts)}")
    print(f"{len(gigs)} gigs, {sum(g.n for g in gigs)} tracks played\n")
    for g in gigs[:10]:
        lo, hi = g.bpm_range or (0, 0)
        print(f"  {g.label:<18} {g.n:>3} tracks  {lo:.0f}-{hi:.0f} bpm  "
              f"harmonic {g.harmonic_rate:.0%}  ({len(g.sessions)} session(s))")
    tr = transitions(gigs, min_nights=2)
    print(f"\n{len(tr)} transitions played on 2+ nights:")
    for t in tr[:8]:
        print(f"  {t.nights} nights x{t.plays}  {t.a.display[:34]:34} -> {t.b.display[:34]}")
