#!/bin/bash
# Track Studio — one-shot installer for a fresh Mac.
#
# Sets up the Python environment, then builds and installs "Track Studio.app"
# into /Applications so it launches from Spotlight / Finder like a native app.
#
#   bash install.sh
#
# ("bash install.sh", not "./install.sh" — a downloaded copy is quarantined and
# macOS blocks direct execution; running it through bash always works.)
#
# Safe to re-run: the venv is reused and the app is rebuilt in place.
set -euo pipefail

PROJECT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT"

say()  { printf '\033[1;38;5;208m==>\033[0m %s\n' "$*"; }
fail() { printf '\033[1;31mError:\033[0m %s\n' "$*" >&2; exit 1; }

[[ "$(uname -s)" == "Darwin" ]] || fail "Track Studio is macOS-only."

# AirDropped / downloaded zips carry the quarantine xattr, and macOS refuses to
# execute quarantined scripts ("bad interpreter: Operation not permitted").
xattr -dr com.apple.quarantine "$PROJECT" 2>/dev/null || true

# python3 ships with the Command Line Tools; a bare Mac has only a stub that
# pops the CLT install dialog. Fail with the fix instead of hanging on it.
xcode-select -p >/dev/null 2>&1 \
    || fail 'Xcode Command Line Tools missing — run "xcode-select --install", then re-run this.'
command -v python3 >/dev/null 2>&1 || fail "python3 not found."

if [[ "$(uname -m)" != "arm64" ]]; then
    say "Note: only tested on Apple Silicon Macs — continuing anyway."
fi

if [[ ! -x venv/bin/python ]]; then
    say "Creating the Python environment (one time)"
    python3 -m venv venv
fi

say "Installing packages (first run downloads a few hundred MB — be patient)"
venv/bin/python -m pip install --quiet --upgrade pip
venv/bin/python -m pip install --quiet -r requirements.txt \
    || fail "Package install failed. Usually this means no essentia-tensorflow wheel exists for your Python ($(python3 --version 2>&1)) — the app is known-good on the macOS system Python 3.9."

# beatportdl (optional — powers the Beatport download feature): the vendored
# copy is not in the shared zip, so fetch the public release binary instead.
if [[ ! -x beatportdl/bpdl_mac ]]; then
    say "Fetching beatportdl (optional, for Beatport downloads)"
    case "$(uname -m)" in
        arm64) BPDL_ASSET=beatportdl-darwin-arm64 ;;
        *)     BPDL_ASSET=beatportdl-darwin-amd64 ;;
    esac
    mkdir -p beatportdl
    if curl -fsSL --retry 2 \
            "https://github.com/unspok3n/beatportdl/releases/latest/download/$BPDL_ASSET" \
            -o beatportdl/bpdl_mac; then
        chmod +x beatportdl/bpdl_mac
    else
        rm -f beatportdl/bpdl_mac
        say "Warning: beatportdl download failed — Beatport downloads disabled; everything else works."
    fi
fi

say "Building and installing Track Studio.app"
[[ -w /Applications ]] || fail "/Applications is not writable — re-run from an admin account."
bash ./scripts/build_app.sh --install

# Stop any running Track Studio server so the next launch runs this install.
# The launcher treats anything listening on :8080 as Track Studio, so if the
# port is held by something else, warn instead of killing it.
pids=$(lsof -i:8080 -sTCP:LISTEN -t 2>/dev/null | sort -u || true)
if [[ -n "$pids" ]]; then
    if ps -o command= -p $pids | grep -q "main\.py"; then
        say "Stopping the running Track Studio server — relaunch it to pick up this install"
        kill $pids 2>/dev/null || true
    else
        say "Warning: something else is using port 8080 — quit it before launching, or Track Studio will open that instead."
    fi
fi

echo
say 'Done — hit ⌘Space and type "Track Studio" to launch.'
say "First launch takes ~15s (analysis engine warm-up); the ML models download on your first analysis."
say "Spotify / Beatport credentials are optional — add them later in the app's Settings."
