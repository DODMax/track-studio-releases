"""Is this file's audio actually continuous? — the check behind "Check for problems".

A store-encoded file steps one frame per packet, from the first to the last. A
file stitched out of HLS segments carries a timestamp discontinuity at every
join: a gap that inserts time, or an overlap that swallows it. Measured across
this library, up to 777ms in one hit — over a beat and a half. Rekordbox grids
the intro, the audio wanders out from under it, and no amount of re-gridding
fixes a track whose beats genuinely aren't evenly spaced. The symptom is a
beatgrid you can't make fit and a BPM of 133.xx where the tag says a flat 133.

The cause is fetching audio over HLS (see `bpdl.BROKEN_QUALITIES`, now
withdrawn). The cure is re-downloading; nothing can repair a file whose audio is
already missing or duplicated.

Three signals. The first two are free and only decide what's worth probing:

1. **The encoder atom.** A direct store download carries no encoder tag at all;
   a remux is stamped by whatever wrote it (`Lavf…` for ffmpeg). Verified over
   1798 files here: of 443 with no encoder atom, *zero* were stitched. Absence
   is a sound negative test, which is what makes the pre-filter safe. Presence
   means "probe it", not "it's broken" — 93 remuxed files were fine.
2. **The BPM tell.** Both numbers are read, never recomputed: the file's own tag
   against what rekordbox measured. Kept for the explanation it gives, not its
   recall — alone it missed 2 of 19 stitched files in one folder, one gridded at
   exactly 137.00. Hence ORed with (1) rather than trusted.
3. **The packet check.** Proof, at the cost of one ffprobe.

Leaf module: no UI, no `runtime`. `analysis.IntegrityJob` drives it in the
background; `scripts/find_broken_audio.py` is the same thing on the command line.
"""
from __future__ import annotations

import json
import subprocess
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# A stitched file breaks every ~5s, so 90s catches ~18 of them — certain enough,
# at a fraction of the cost of reading six minutes.
DEFAULT_SAMPLE_SECONDS = 90
# Under this, a 133.04 is rounding rather than drift.
BPM_TOLERANCE = 0.05
# Segment joins recur on a period; damage doesn't. Bounds the "regular" window.
MIN_PERIOD_S, MAX_PERIOD_S = 3.0, 12.0
# Disposable: delete it and the next scan rebuilds it.
CACHE_NAME = ".integrity_cache.json"

STITCHED, BROKEN, CLEAN = "stitched", "broken", "clean"


@dataclass
class Finding:
    """What one file's packet stream says about itself."""
    path: Path
    breaks: int = 0
    events: int = 0
    worst_ms: float = 0.0
    period_s: Optional[float] = None     # spacing between breaks, when regular
    tag_bpm: Optional[float] = None
    grid_bpm: Optional[float] = None
    encoder: str = ""
    note: str = ""

    @property
    def verdict(self) -> str:
        if self.breaks and self.period_s and MIN_PERIOD_S <= self.period_s <= MAX_PERIOD_S:
            return STITCHED              # regular joins — the HLS signature
        if self.breaks:
            return BROKEN                # discontinuous, but not that pattern
        return CLEAN

    @property
    def summary(self) -> str:
        if self.verdict == CLEAN:
            return self.note or "clean"
        where = f", one every {self.period_s:.1f}s" if self.period_s else ""
        return (f"{self.events} jump(s){where}, worst {self.worst_ms:.0f}ms")

    @property
    def beats_off(self) -> Optional[float]:
        """The worst single jump as a fraction of a beat — what it costs you."""
        bpm = self.grid_bpm or self.tag_bpm
        return (self.worst_ms / 1000) * (bpm / 60) if bpm else None


def tag_bpm_and_encoder(path: Path) -> tuple[Optional[float], str]:
    """What the file claims about itself, without decoding a byte."""
    try:
        from mutagen import File as MutagenFile
        f = MutagenFile(path)
        if f is None or not f.tags:
            return None, ""
        if path.suffix.lower() == ".m4a":
            bpm = (f.tags.get("tmpo") or [None])[0]
            enc = (f.tags.get("\xa9too") or [""])[0]
        else:
            bpm = f.tags.get("TBPM").text[0] if f.tags.get("TBPM") else None
            enc = f.tags.get("TSSE").text[0] if f.tags.get("TSSE") else ""
        return (float(bpm) if bpm else None), str(enc)
    except Exception:
        return None, ""


def worth_probing(path: Path, grid_bpm: Optional[float] = None) -> tuple[bool, Optional[float], str]:
    """Free triage: should this file cost us an ffprobe? Returns (probe?, tag_bpm, encoder).

    Never clears a file it can't read — absence of evidence isn't evidence here.
    """
    tag_bpm, encoder = tag_bpm_and_encoder(path)
    if encoder:
        return True, tag_bpm, encoder            # remuxed by something
    if tag_bpm is None or grid_bpm is None:
        return True, tag_bpm, encoder            # can't rule it out
    return abs(grid_bpm - tag_bpm) > BPM_TOLERANCE, tag_bpm, encoder


def packet_check(path: Path, sample_seconds: int = DEFAULT_SAMPLE_SECONDS) -> Finding:
    """Count timestamp steps that aren't one frame. `sample_seconds=0` reads it all."""
    find = Finding(path=Path(path))
    # Packets, sample rate and timebase in ONE probe: asking separately doubled
    # the wall time of a library scan for two integers.
    cmd = ["ffprobe", "-v", "quiet", "-select_streams", "a:0",
           "-show_packets", "-show_streams",
           "-show_entries", "packet=pts:stream=sample_rate,time_base", "-of", "json"]
    if sample_seconds:
        cmd += ["-read_intervals", f"%+{sample_seconds}"]
    try:
        out = subprocess.run(cmd + [str(path)], capture_output=True, text=True,
                             timeout=120).stdout
        data = json.loads(out)
        pts = [int(p["pts"]) for p in data.get("packets", []) if p.get("pts") is not None]
    except (subprocess.SubprocessError, json.JSONDecodeError, ValueError, OSError):
        find.note = "unreadable"
        return find
    if len(pts) < 50:
        find.note = "too short to judge"
        return find

    # Derive the frame step from the file rather than assuming one. Hardcoding
    # AAC's 1024 reported every MP3 and FLAC in the library as thousands of
    # breaks: those use different frame sizes (1152, 4096) *and* a different
    # timebase. The modal delta is whatever this file calls a frame.
    deltas = [b - a for a, b in zip(pts, pts[1:])]
    step = Counter(deltas).most_common(1)[0][0]
    if step <= 0:
        find.note = "no regular frame spacing"
        return find
    # pts are in the stream's own timebase — 1/44100 for AAC in MP4, but
    # 1/14112000 for MP3. Read it; assuming it is what produced 28,000-second
    # drift reports for every MP3 in the library.
    try:
        num, den = (data["streams"][0].get("time_base") or "1/44100").split("/")
        tick_s = int(num) / int(den)
    except (KeyError, IndexError, ValueError, ZeroDivisionError):
        tick_s = 1 / 44100

    odd = [(i, d) for i, d in enumerate(deltas) if d != step]
    find.breaks = len(odd)
    if not odd:
        return find

    # One join can span several packets — group runs so "events" counts joins.
    events: list[list[tuple[int, int]]] = []
    for i, d in odd:
        if events and i == events[-1][-1][0] + 1:
            events[-1].append((i, d))
        else:
            events.append([(i, d)])
    find.events = len(events)
    find.worst_ms = max(
        abs(sum(d for _, d in ev) - step * len(ev)) * tick_s * 1000 for ev in events)

    # Regular spacing is what says "segment joins" rather than "damage".
    starts = [pts[ev[0][0]] * tick_s for ev in events]
    if len(starts) >= 3:
        gaps = [b - a for a, b in zip(starts, starts[1:])]
        median = sorted(gaps)[len(gaps) // 2]
        if median and all(abs(g - median) < median * 0.25 for g in gaps):
            find.period_s = round(median, 2)
    return find


def check_track(path: Path, grid_bpm: Optional[float] = None,
                sample_seconds: int = DEFAULT_SAMPLE_SECONDS) -> Optional[Finding]:
    """One file, triaged then probed. None when the free signals clear it."""
    path = Path(path)
    probe, tag_bpm, encoder = worth_probing(path, grid_bpm)
    if not probe:
        return None
    find = packet_check(path, sample_seconds)
    find.tag_bpm, find.grid_bpm, find.encoder = tag_bpm, grid_bpm, encoder
    return find


def _stamp(path: Path) -> Optional[str]:
    """A file's identity for cache purposes: when it changed, and how big it is."""
    try:
        st = path.stat()
    except OSError:
        return None
    return f"{int(st.st_mtime)}:{st.st_size}"


def scan_remuxed(paths) -> dict[str, bool]:
    """Which of these files carry an encoder atom — cached across runs.

    This is the free half of the triage, and "free" was doing a lot of work:
    reading the tag of every track meant opening every file, which measured at
    14s over 2377 tracks *on every launch*, to recompute an answer that changes
    only when a file does. So the answer is kept on disk against the file's
    mtime and size, and a second run costs one `stat` per track instead.

    The cache is disposable — delete the file and it rebuilds. It stores a
    boolean, never a verdict: whether a file is *stitched* still takes a probe.
    """
    cache = _load_cache()
    out: dict[str, bool] = {}
    dirty = False
    for p in paths:
        p = Path(p)
        key = str(p)
        stamp = _stamp(p)
        if stamp is None:
            continue
        hit = cache.get(key)
        if hit and hit[0] == stamp:
            out[key] = bool(hit[1])
            continue
        _bpm, encoder = tag_bpm_and_encoder(p)
        out[key] = bool(encoder)
        cache[key] = [stamp, bool(encoder)]
        dirty = True
    if dirty:
        # Drop entries for files that have gone, so the cache can't outgrow the
        # library it describes.
        for gone in set(cache) - {str(Path(p)) for p in paths}:
            del cache[gone]
        _save_cache(cache)
    return out


# Held for the process, not re-read per call: the file is a few hundred KB, and
# `scan_remuxed` is now called on every Library refresh to scope the warning to
# the selected playlist. Reading it once turns that into a dict lookup.
_CACHE: dict = {}
_CACHE_LOADED = False


def _load_cache() -> dict:
    global _CACHE_LOADED
    import json
    if _CACHE_LOADED:
        return _CACHE
    try:
        from config import ROOT
        path = ROOT / CACHE_NAME
        if path.exists():
            _CACHE.update(json.loads(path.read_text()))
    except (OSError, ValueError):
        pass
    _CACHE_LOADED = True
    return _CACHE


def _save_cache(cache: dict) -> None:
    import json
    try:
        from config import ROOT
        (ROOT / CACHE_NAME).write_text(json.dumps(cache))
    except (OSError, TypeError):
        pass                              # a cache that can't be written is just slow


def verify_downloads(paths, sample_seconds: int = DEFAULT_SAMPLE_SECONDS) -> list[Finding]:
    """Packet-check files that just arrived — a handful, so no triage, no mercy.

    The point of running it here is that a bad download can never enter the
    library silently: a few seconds now against a set that falls apart later.
    """
    out = []
    for p in paths:
        find = packet_check(Path(p), sample_seconds)
        if find.breaks:
            out.append(find)
    return out
