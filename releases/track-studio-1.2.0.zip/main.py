"""Track Studio — NiceGUI library manager (entry point).

Run:
    venv/bin/python main.py        (opens http://localhost:8080)

The app is split into focused modules: `widgets` (pure render helpers), `shell`
(theme/header/settings), `runtime` (shared state + helpers), `media` (the /media
audio endpoint), and `pages/` (the three @ui.page routes). Importing `media` and
`pages` registers their routes as an import-time side effect.
"""
from __future__ import annotations

from nicegui import ui

import media  # noqa: F401  — registers the /media FastAPI route
import pages  # noqa: F401  — registers the /, /sync, /build, ... routes
import updates
from runtime import _bootstrap


# Guard the server boot: the analysis pool uses multiprocessing "spawn", which
# re-imports this module in every worker. Without the guard each worker would run
# _bootstrap() and ui.run() and try to start a second server. Workers import this
# module (name != "__main__") only for its route side-effects, then go quiet.
if __name__ == "__main__":
    _bootstrap()
    # /api/version plus the twice-daily look for a new release. Registered here,
    # not on import, so the analysis workers don't each start a checker.
    updates.register()
    # reconnect_timeout: tolerate longer event-loop hiccups during heavy analysis
    # before the client gives up with "connection lost".
    ui.run(title="Track Studio", port=updates.PORT, reload=False, show=False,
           reconnect_timeout=30.0)
