"""The /media audio endpoint — a FastAPI route on NiceGUI's singleton `app`.

Named `media.py` (not `app.py`) to avoid colliding with the legacy Streamlit GUI's
`app.py` on import. Importing this module registers the route as a side effect.
"""
from __future__ import annotations

from pathlib import Path

from fastapi.responses import FileResponse, Response
from nicegui import app

import runtime


# Serve audio straight from disk — allowlist = any file the library knows about.
@app.get("/media")
def media(path: str):
    p = Path(path).resolve()
    allowed = {Path(t.local_path).resolve() for t in runtime.library.tracks if t.local_path}
    if p in allowed and p.is_file():
        return FileResponse(p)
    return Response(status_code=404)
