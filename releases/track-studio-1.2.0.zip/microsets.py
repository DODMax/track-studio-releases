"""The set-building domain: group tracks into blocks, score how they follow on.

A **block** is 3-10 tracks that sit close together in Energy, BPM and texture —
a programmed run within a longer set, ordered harmonically and given a place in
the arc ("Warm-up" … "Climax"). Blocks are deterministic and explainable: no
random clustering, no audio embeddings required.

Note the vocabulary, since the app leans on the distinction. A **crate** is a
source you dig through (a rekordbox playlist); a **block** is an ordered run you
play; **the set** (`SetEntry`) is what you assemble out of blocks and individual
picks. Blocks were called "micro-sets" once, which muddled the last two.

The compatibility score combines four dimensions: Energy continuity, BPM
continuity, Camelot key adjacency, and vibe (style/mood) similarity. It powers
the "next up" suggestions on the Build page.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from statistics import median
from typing import Optional

from tagging import parse_comment


# ----------------------------------------------------------------------
# Track + Block data classes
# ----------------------------------------------------------------------

@dataclass
class Track:
    """A track unified across rekordbox metadata + our energy/style/mood tags."""
    id: str
    name: str
    artist: str
    bpm: float
    key: str                        # Camelot tonality, e.g. "8A"
    energy: Optional[int] = None
    arousal: Optional[float] = None
    valence: Optional[float] = None
    danceability: Optional[float] = None
    style: Optional[str] = None
    moods: list[str] = field(default_factory=list)
    # texture (DSP descriptors; discriminate inside a tight genre cluster)
    brightness: Optional[float] = None          # spectral centroid, Hz (dark↔bright)
    dynamic_complexity: Optional[float] = None  # loudness deviation (flat↔punchy)
    spectral_complexity: Optional[float] = None # spectral peak density (clean↔busy)
    onset_rate: Optional[float] = None          # onsets per second (sparse↔busy)
    path: Optional[Path] = None     # local file path if resolvable

    @property
    def display(self) -> str:
        """'Artist — Title', or just the title when the file carries no artist
        tag (common on edits/bootlegs, where the artist sits in the filename)."""
        return f"{self.artist} — {self.name}" if self.artist else self.name

    @classmethod
    def from_rekordbox(cls, rb_track, path: Optional[Path]) -> "Track":
        # Prefer fresh tags read from the file itself (rekordbox's COLLECTION
        # Comments are only refreshed when the user clicks "Reload Tag", so the
        # XML can lag the actual file metadata by days).
        tags = parse_comment(rb_track.comments)
        if "energy" not in tags and path is not None and path.exists():
            tags = _read_file_tags(path) or tags
        return cls(
            id=rb_track.id,
            name=rb_track.name,
            artist=rb_track.artist,
            bpm=rb_track.bpm,
            key=rb_track.key,
            energy=tags.get("energy"),
            arousal=tags.get("arousal"),
            valence=tags.get("valence"),
            danceability=tags.get("danceability"),
            style=tags.get("style"),
            moods=tags.get("moods", []),
            brightness=tags.get("brightness"),
            dynamic_complexity=tags.get("dynamic_complexity"),
            spectral_complexity=tags.get("spectral_complexity"),
            onset_rate=tags.get("onset_rate"),
            path=path,
        )


def _read_file_tags(path: Path) -> dict:
    """Read the tagger's Comments string from the audio file directly."""
    try:
        from mutagen import File as MutagenFile
    except ImportError:
        return {}
    try:
        mf = MutagenFile(str(path))
    except Exception:
        return {}
    if mf is None or mf.tags is None:
        return {}
    text = ""
    suffix = path.suffix.lower()
    if suffix == ".mp3":
        for k, v in mf.tags.items():
            if k.startswith("COMM"):
                text = "".join(str(s) for s in v.text)
                if text:
                    break
    elif suffix == ".m4a":
        text = (mf.tags.get("\xa9cmt") or [""])[0]
    return parse_comment(text)


@dataclass
class Block:
    id: str                         # e.g. "610-03", or "B-03" with no prefix
    parent: str                     # parent playlist name
    tracks: list[Track]
    preset: "Optional[BlockPreset]" = None   # the recipe that built it (drives name lead)
    role: Optional[str] = None      # arc position, e.g. "Warm-up" / "Peak" (set by cluster)

    @property
    def dna(self) -> dict:
        return _dna(self.tracks)

    @property
    def name(self) -> str:
        d = self.dna
        e_lo, e_hi = d["energy_band"]
        e_label = f"E{e_lo:02d}" if e_lo == e_hi else f"E{e_lo:02d}-{e_hi:02d}"
        bpm_lo, bpm_hi = d["bpm_range"]
        bpm_label = f"{int(bpm_lo)}" if int(bpm_lo) == int(bpm_hi) else f"{int(bpm_lo)}-{int(bpm_hi)}"
        # Lead with whatever the preset treats as the block's identity: its top mood
        # (genre-agnostic presets) or its top genre. Falls back across the two.
        lead = d["top_style"] or "Unknown"
        if self.preset and self.preset.label_field == "mood":
            lead = (d["top_moods"][0] if d["top_moods"] else (d["top_style"] or "Unknown"))
        bits = [self.id, lead, e_label, bpm_label]
        return " · ".join(b for b in bits if b)

    @property
    def export_name(self) -> str:
        """Playlist name for the rekordbox export — leads with the arc role so the
        block's place in the journey reads at a glance in the rekordbox tree."""
        return f"{self.role} · {self.name}" if self.role else self.name


# ----------------------------------------------------------------------
# Camelot helpers
# ----------------------------------------------------------------------

_CAMELOT_RE = re.compile(r"^(\d{1,2})([AB])$")


def _camelot_parse(key: str) -> Optional[tuple[int, str]]:
    m = _CAMELOT_RE.match((key or "").upper().strip())
    if not m:
        return None
    return int(m.group(1)), m.group(2)


def _camelot_distance(a: str, b: str) -> int:
    """Adjacency score on the Camelot wheel: 100 (same) → 80 (±1 hour or A/B flip) → 50 (±2) → 20 (else).

    Returns 0 if either key is unparseable.
    """
    pa, pb = _camelot_parse(a), _camelot_parse(b)
    if pa is None or pb is None:
        return 0
    ha, ma = pa
    hb, mb = pb
    hour_diff = min((ha - hb) % 12, (hb - ha) % 12)  # circular
    mode_diff = 0 if ma == mb else 1
    if hour_diff == 0 and mode_diff == 0:
        return 100
    if (hour_diff == 1 and mode_diff == 0) or (hour_diff == 0 and mode_diff == 1):
        return 80
    if hour_diff == 2 and mode_diff == 0:
        return 50
    return 20


# ----------------------------------------------------------------------
# Presets — reusable grouping recipes
# ----------------------------------------------------------------------
#
# A preset is a named recipe for what "feels alike". Clustering grows blocks
# greedily over tracks sorted by arousal, joining a track to the current block
# while its weighted distance to the block centroid stays within `block_radius`
# and it breaks none of the hard `caps`. Which features matter — and how much —
# is entirely the preset's call: that's how one preset chases a dance-floor
# spine (danceability + a moving energy band, genre ignored) while another could
# prize harmonic key. Inside a block tracks are always ordered harmonically
# (greedy nearest Camelot), so key shapes *flow* even when it doesn't drive grouping.
#
# Features a preset can weight / cap (anything else is ignored):
#   energy        — arousal (continuous; reconstructed from the Energy bucket)
#   danceability  — 0..1 (only on --rich-tagged tracks; soft-skipped when absent)
#   valence       — DEAM valence
#   bpm           — tempo
#   key           — Camelot adjacency (weight only; never a cap)
# scales[f] is the delta in feature f that counts as one "full step" (0..1).
# caps[f] is the max |track − block-mean| in f for a track to still join a block.

@dataclass(frozen=True)
class BlockPreset:
    """A reusable recipe for grouping tracks into sets (see PRESETS)."""
    key: str
    name: str
    description: str
    weights: dict          # feature -> weight in the blend (needs a matching scale)
    scales: dict           # feature -> delta that counts as one full step
    caps: dict             # feature -> hard cap on |track - block-mean| to join
    block_radius: float    # max weighted distance (0..1) to join the current block
    min_block_size: int
    max_block_size: int
    label_field: str       # set-name lead: "mood" (top mood) or "style" (top genre)
    roles: tuple           # arc vocabulary low→high energy; blocks spread across it


HIGH_DANCE = BlockPreset(
    key="high-dance",
    name="High Dance",
    description=(
        "Dance-floor spine: tight danceability and a moving energy band, with a "
        "loose BPM window and mood cohesion. Genre and key are ignored when "
        "grouping (key still orders tracks within each set). Mirrors a hand-built "
        "peak-time set that freely mixes genres at a steady, danceable tempo."
    ),
    weights={"danceability": 0.40, "energy": 0.30, "bpm": 0.20, "valence": 0.10},
    scales={"danceability": 0.10, "energy": 0.8, "bpm": 6.0, "valence": 1.5},
    caps={"danceability": 0.12, "bpm": 7.0},
    block_radius=0.42,
    min_block_size=3,
    max_block_size=10,
    label_field="mood",
    roles=("Warm-up", "Groove", "Build", "Peak", "Climax"),
)

HIGH_DANCE_TEXTURE = BlockPreset(
    key="high-dance-texture",
    name="High Dance · Texture",
    description=(
        "Same dance-floor intent, but grouped on the audio's texture rather than "
        "its (near-saturated) danceability: brightness leads, with dynamics and a "
        "moving energy band. Separates dark/deep from bright/airy tracks inside the "
        "tight cluster where danceability and valence give up. Needs texture tags — "
        "re-analyze to populate them. Genre and key still ignored for grouping."
    ),
    weights={"brightness": 0.30, "energy": 0.28, "bpm": 0.16,
             "dynamic_complexity": 0.14, "danceability": 0.12},
    scales={"brightness": 350.0, "energy": 0.8, "bpm": 6.0,
            "dynamic_complexity": 1.2, "danceability": 0.10},
    caps={"bpm": 7.0},
    block_radius=0.42,
    min_block_size=3,
    max_block_size=10,
    label_field="mood",
    roles=("Warm-up", "Groove", "Build", "Peak", "Climax"),
)

HIGH_CHASE = BlockPreset(
    key="high-chase",
    name="High Chase",
    description=(
        "Driving, hypnotic peak-time builder. Groups on arrangement texture — "
        "spectral density (stripped roller ↔ layered builder) and dynamics "
        "(punchy ↔ relentless) — with energy driving the build arc. Danceability "
        "and valence are saturated in this kind of set, so they're dropped; BPM is "
        "loose cohesion, genre and key ignored for grouping. Tuned from a deep "
        "prog-house/techno set. Needs texture tags — re-analyze to populate them."
    ),
    weights={"energy": 0.30, "spectral_complexity": 0.22, "dynamic_complexity": 0.16,
             "bpm": 0.12, "brightness": 0.12, "onset_rate": 0.08},
    scales={"energy": 0.8, "spectral_complexity": 5.0, "dynamic_complexity": 1.2,
            "bpm": 6.0, "brightness": 350.0, "onset_rate": 1.2},
    caps={"bpm": 7.0},
    block_radius=0.42,
    min_block_size=3,
    max_block_size=10,
    label_field="mood",
    roles=("Roll-in", "Drive", "Build", "Surge", "Peak"),
)

# Registry order = selector order; DEFAULT_PRESET is the current/old grouping so
# behavior is unchanged until the user picks a texture-aware preset.
PRESETS: dict[str, BlockPreset] = {
    p.key: p for p in (HIGH_DANCE, HIGH_DANCE_TEXTURE, HIGH_CHASE)
}
DEFAULT_PRESET = HIGH_DANCE


def _feature(t: Track, feat: str) -> Optional[float]:
    """A track's continuous value for a preset feature (None if unavailable)."""
    if feat == "energy":
        return _arousal_of(t)
    if feat == "danceability":
        return t.danceability
    if feat == "valence":
        return t.valence
    if feat == "bpm":
        return t.bpm or None
    if feat == "brightness":
        return t.brightness
    if feat == "dynamic_complexity":
        return t.dynamic_complexity
    if feat == "spectral_complexity":
        return t.spectral_complexity
    if feat == "onset_rate":
        return t.onset_rate
    return None


def _arousal_of(t: Track) -> Optional[float]:
    """Continuous arousal; reconstruct from the energy bucket when absent.

    Energy is a quantization of arousal (DEAM 3..7 → 1..10); invert that so a
    track tagged only with Energy still has a usable continuous coordinate.
    """
    if t.arousal is not None:
        return t.arousal
    if t.energy is not None:
        return (t.energy - 1) / 9.0 * 4.0 + 3.0
    return None


def _distance(a: Track, b: Track, preset: BlockPreset = DEFAULT_PRESET) -> float:
    """Weighted, normalized 0..1 distance between two tracks (or centroids) under
    `preset`. Each weighted feature contributes its scaled, capped difference; the
    blend is normalized by the weight actually used, so a track missing a feature
    (e.g. danceability on a non-rich track) stays comparable on the rest.
    """
    acc = 0.0
    used = 0.0
    for feat, w in preset.weights.items():
        if feat == "key":
            cd = _camelot_distance(a.key, b.key)
            if cd > 0:  # 0 = unparseable on either side → skip the axis
                acc += w * ((100.0 - cd) / 100.0)
                used += w
            continue
        va, vb = _feature(a, feat), _feature(b, feat)
        if va is not None and vb is not None:
            acc += w * min(1.0, abs(va - vb) / preset.scales.get(feat, 1.0))
            used += w
    return acc / used if used else 1.0


def _within_caps(t: Track, centroid: Track, preset: BlockPreset) -> bool:
    """True if `t` is within every hard cap of the block `centroid`. A feature the
    track or centroid lacks (or that isn't capped) never blocks the join."""
    for feat, cap in preset.caps.items():
        if feat == "key":
            continue  # key is a weight axis, never a hard cap
        vt, vc = _feature(t, feat), _feature(centroid, feat)
        if vt is not None and vc is not None and abs(vt - vc) > cap:
            return False
    return True


def _centroid(block: list[Track]) -> Track:
    """A synthetic Track at the mean of the block (representative key = mode)."""
    def mean_of(attr):
        xs = [getattr(t, attr) for t in block if getattr(t, attr) is not None]
        return (sum(xs) / len(xs)) if xs else None
    aro = [x for x in (_arousal_of(t) for t in block) if x is not None]
    bpm = [t.bpm for t in block if t.bpm]
    eng = [t.energy for t in block if t.energy is not None]
    keyc = Counter(t.key for t in block if t.key)
    return Track(
        id="centroid", name="", artist="",
        bpm=(sum(bpm) / len(bpm)) if bpm else 0.0,
        key=keyc.most_common(1)[0][0] if keyc else "",
        energy=round(sum(eng) / len(eng)) if eng else None,
        arousal=(sum(aro) / len(aro)) if aro else None,
        valence=mean_of("valence"),
        danceability=mean_of("danceability"),
        brightness=mean_of("brightness"),
        dynamic_complexity=mean_of("dynamic_complexity"),
        spectral_complexity=mean_of("spectral_complexity"),
        onset_rate=mean_of("onset_rate"),
    )


def _merge_small(blocks: list[list[Track]],
                 preset: BlockPreset = DEFAULT_PRESET) -> list[list[Track]]:
    """Fold any block smaller than the preset's min size into its nearest neighbour."""
    blocks = [list(b) for b in blocks]
    changed = True
    while changed and len(blocks) > 1:
        changed = False
        for i, b in enumerate(blocks):
            if len(b) >= preset.min_block_size:
                continue
            ci = _centroid(b)
            j, _ = min(((k, _distance(ci, _centroid(blocks[k]), preset))
                        for k in range(len(blocks)) if k != i),
                       key=lambda kv: kv[1])
            blocks[j].extend(b)
            del blocks[i]
            changed = True
            break
    return blocks


def _harmonic_order(tracks: list[Track]) -> list[Track]:
    """Order a block by harmonic flow: start at the slowest track, then greedily
    step to the best Camelot match (closest BPM breaks ties)."""
    remaining = sorted(tracks, key=lambda t: (t.bpm or 0))
    if not remaining:
        return []
    ordered = [remaining.pop(0)]
    while remaining:
        last = ordered[-1]
        nxt = max(remaining, key=lambda t: (_camelot_distance(last.key, t.key),
                                            -abs((t.bpm or 0) - (last.bpm or 0))))
        ordered.append(nxt)
        remaining.remove(nxt)
    return ordered


_PLAYLIST_PREFIX_RE = re.compile(r"^\s*(\d{2,4})")


def _playlist_prefix(playlist_name: str) -> str:
    """Extract the leading numeric prefix from a playlist name.

    e.g. '610 - DeepRemixes' → '610'. Falls back to 'MS' if no prefix.
    """
    m = _PLAYLIST_PREFIX_RE.match(playlist_name or "")
    return m.group(1) if m else "B"


def _assign_roles(blocks: list[Block], preset: BlockPreset) -> None:
    """Label each block with its place in the arc, spreading the journey (blocks
    are already sorted low→high energy) across the preset's role vocabulary. With
    as many blocks as roles each gets a distinct word; fewer blocks stretch across
    the arc (e.g. 3 → first/middle/last), more repeat the middle bands."""
    n = len(blocks)
    last = len(preset.roles) - 1
    for i, ms in enumerate(blocks):
        idx = 0 if n <= 1 else round(i / (n - 1) * last)
        ms.role = preset.roles[idx]


def cluster(playlist_name: str, tracks: list[Track],
            preset: BlockPreset = DEFAULT_PRESET) -> list[Block]:
    """Group tracks into blocks by `preset`'s weighted feel-similarity.

    Pass over tracks ordered by arousal (then BPM), growing the current block
    while each track sits within `block_radius` of the block centroid and breaks
    none of the preset's hard caps; otherwise open a new block. Tiny blocks are
    merged into their nearest neighbour, blocks are ordered into a journey by
    rising arousal, sequenced harmonically, and tagged with an arc role.
    """
    if not tracks:
        return []

    ordered_in = sorted(
        tracks,
        key=lambda t: (_arousal_of(t) if _arousal_of(t) is not None else 0.0, t.bpm or 0),
    )

    blocks: list[list[Track]] = []
    for t in ordered_in:
        if not blocks or len(blocks[-1]) >= preset.max_block_size:
            blocks.append([t])
            continue
        cur = blocks[-1]
        cen = _centroid(cur)
        if _distance(cen, t, preset) <= preset.block_radius and _within_caps(t, cen, preset):
            cur.append(t)
        else:
            blocks.append([t])

    blocks = _merge_small(blocks, preset)

    def block_key(b: list[Track]):
        c = _centroid(b)
        return (c.arousal if c.arousal is not None else 0.0, c.bpm or 0)

    blocks.sort(key=block_key)

    prefix = _playlist_prefix(playlist_name)
    out = [
        Block(id=f"{prefix}-{i:02d}", parent=playlist_name,
                 tracks=_harmonic_order(b), preset=preset)
        for i, b in enumerate(blocks, start=1)
    ]
    _assign_roles(out, preset)
    return out


# ----------------------------------------------------------------------
# DNA + compatibility scoring
# ----------------------------------------------------------------------

def _dna(tracks: list[Track]) -> dict:
    """Compute the signature fields for a block."""
    energies = [t.energy for t in tracks if t.energy is not None]
    bpms = [t.bpm for t in tracks if t.bpm]
    keys = [t.key for t in tracks if t.key]
    styles = [t.style for t in tracks if t.style]
    moods_flat = [m for t in tracks for m in (t.moods or [])]
    valences = [t.valence for t in tracks if t.valence is not None]

    style_counter = Counter(styles)
    mood_counter = Counter(moods_flat)

    return {
        "count": len(tracks),
        "energy_band": (min(energies), max(energies)) if energies else (0, 0),
        "energy_median": median(energies) if energies else 0,
        "valence_center": (sum(valences) / len(valences)) if valences else None,
        "valence_band": (min(valences), max(valences)) if valences else None,
        "bpm_range": (min(bpms), max(bpms)) if bpms else (0, 0),
        "keys": sorted(set(keys), key=lambda k: (_camelot_parse(k) or (99, "Z"))),
        "top_style": style_counter.most_common(1)[0][0] if style_counter else None,
        "top_moods": [m for m, _ in mood_counter.most_common(3)],
        "all_styles": style_counter,
        "all_moods": mood_counter,
    }


def compatibility(a: Block, b: Block, valence_dir: int = 0,
                  model=None) -> int:
    """Score the transition A → B on a 0..100 scale.

    `valence_dir` shapes the mood term: 0 rewards staying at the same brightness
    (cohesion), +1 rewards getting brighter, -1 rewards getting darker — so the
    journey can be steered to climb or descend in valence across blocks.

    `model` (duck-typed `mixmodel.MixModel`, kept out of this module's imports
    so it stays leaf) adds a capped bonus when tracks of A and B were actually
    played together in past gigs — confirmed (2+ night) pairs weigh most.
    """
    if a is b:
        return 0
    da, db = a.dna, b.dna

    # Energy continuity (30%): penalize big arousal jumps between blocks.
    energy_jump = abs(db["energy_median"] - da["energy_median"])
    energy_score = max(0.0, 100.0 - 25.0 * energy_jump)

    # BPM continuity (20%): smooth transitions are best.
    a_bpm_max = da["bpm_range"][1] or 0
    b_bpm_min = db["bpm_range"][0] or 0
    bpm_gap = abs(b_bpm_min - a_bpm_max)
    bpm_score = max(0.0, 100.0 - 12.0 * bpm_gap)

    # Key adjacency (20%): use the dominant key of each set.
    a_keys = da["keys"] or [""]
    b_keys = db["keys"] or [""]
    key_score = max(_camelot_distance(ak, bk) for ak in a_keys for bk in b_keys)

    # Valence movement (20%): cohesion when neutral, directional otherwise.
    va, vb = da.get("valence_center"), db.get("valence_center")
    if va is None or vb is None:
        val_score = 50.0
    elif valence_dir == 0:
        val_score = max(0.0, 100.0 - 40.0 * abs(vb - va))
    else:
        val_score = max(0.0, min(100.0, 50.0 + 40.0 * (vb - va) * valence_dir))

    # Vibe similarity (10%): style match + mood overlap.
    vibe = 0
    if da["top_style"] and da["top_style"] == db["top_style"]:
        vibe += 50
    a_moods = set(da["top_moods"])
    b_moods = set(db["top_moods"])
    vibe += min(50, 25 * len(a_moods & b_moods))

    blended = (0.30 * energy_score + 0.20 * bpm_score + 0.20 * key_score
               + 0.20 * val_score + 0.10 * vibe)
    if model is not None:
        ev = model.set_evidence([t.id for t in a.tracks],
                                [t.id for t in b.tracks])
        blended = min(100.0, blended + ev.bonus)
    return int(round(blended))


def journey_direction(blocks: list[Block]) -> int:
    """Auto-detect whether the natural block order trends brighter (+1), darker
    (-1), or flat (0) in valence, comparing the first and last block centroids."""
    vals = [s.dna.get("valence_center") for s in blocks]
    vals = [v for v in vals if v is not None]
    if len(vals) < 2:
        return 0
    delta = vals[-1] - vals[0]
    if delta > 0.3:
        return 1
    if delta < -0.3:
        return -1
    return 0


def next_up(a: Block, all_blocks: list[Block], k: int = 3,
            valence_dir: int = 0, model=None) -> list[tuple[Block, int]]:
    """Top-k compatible blocks to play after `a`."""
    scored = [(s, compatibility(a, s, valence_dir, model=model))
              for s in all_blocks if s is not a]
    scored.sort(key=lambda x: -x[1])
    return scored[:k]


# ----------------------------------------------------------------------
# A set under construction
# ----------------------------------------------------------------------

@dataclass
class SetEntry:
    """One track in a set being built, and the block it arrived with.

    A set is always an ordered list of *tracks*, whether they were added a
    whole block at a time or picked one by one — that's what lets the two
    ways of building share one artifact. `block_id` remembers the provenance
    so the block structure survives: the timeline brackets consecutive
    same-block runs, and the export can still emit a playlist per block.
    `None` means the track was picked individually.
    """
    track: Track
    block_id: Optional[str] = None
    role: Optional[str] = None      # the block's arc role, for labels


def set_runs(entries: list[SetEntry]) -> list[tuple[Optional[str], list[SetEntry]]]:
    """Group consecutive entries into runs sharing a block.

    Consecutive, not by-block: adding a block, hand-picking two tracks, then
    returning to that block is three runs, which is what the set actually
    looks like. Loose picks (`block_id is None`) never merge with a block's
    run, but do run together with each other.
    """
    runs: list[tuple[Optional[str], list[SetEntry]]] = []
    for e in entries:
        if runs and runs[-1][0] == e.block_id and e.block_id is not None:
            runs[-1][1].append(e)
        elif runs and runs[-1][0] is None and e.block_id is None:
            runs[-1][1].append(e)
        else:
            runs.append((e.block_id, [e]))
    return runs


def run_label(block_id: Optional[str], run: list[SetEntry], index: int) -> str:
    """Playlist name for one run of the exported set.

    Prefixed "Set" because an export may carry both the played order and the
    pool's clustering into one rekordbox folder, where a bare "1 · Warm-up"
    would appear twice meaning two different things.
    """
    if block_id is None:
        return f"Set {index} · Picks"
    role = next((e.role for e in run if e.role), None)
    return f"Set {index} · {role}" if role else f"Set {index} · {block_id}"


@dataclass
class Sequence:
    """A pre-built walk through several blocks — the actual unit of play on a CDJ."""
    id: str                       # e.g. "610.A"
    label: str                    # "Warm-to-Peak (01→02→04→03)"
    blocks: list[Block]        # ordered

    @property
    def name(self) -> str:
        return f"{self.id} · {self.label}"

    @property
    def all_track_ids(self) -> list[str]:
        return [t.id for ms in self.blocks for t in ms.tracks]


def generate_sequences(blocks: list[Block],
                        max_count: int = 4,
                        length: int = 4,
                        min_score: int = 50,
                        valence_dir: int = 0,
                        model=None) -> list[Sequence]:
    """Build up to `max_count` greedy walks of length `length` through the next-up graph.

    Strategy:
      - Start from each set; greedily extend by the highest-scoring next that
        isn't already in the path.
      - Drop walks shorter than 2 blocks, or where the average transition score
        drops below `min_score`.
      - Dedupe walks that share their first two stops (similar enough).
      - Pick the highest-total-score walks until we hit `max_count`.

    Naming: "<prefix>.A", ".B", ... where prefix is taken from the parent
    playlist (e.g. "610"). Label encodes start→end energy direction.
    """
    if not blocks:
        return []

    # Map id → block for quick lookup.
    by_id = {ms.id: ms for ms in blocks}

    candidates: list[tuple[float, list[Block]]] = []
    for start in blocks:
        path = [start]
        total_score = 0.0
        used = {start.id}
        while len(path) < length:
            next_options = next_up(path[-1], blocks, k=len(blocks) - 1,
                                   valence_dir=valence_dir, model=model)
            picked = None
            for nb, sc in next_options:
                if nb.id in used:
                    continue
                if sc < min_score:
                    break
                picked = (nb, sc)
                break
            if picked is None:
                break
            nb, sc = picked
            path.append(nb)
            used.add(nb.id)
            total_score += sc
        if len(path) < 2:
            continue
        avg = total_score / max(1, len(path) - 1)
        if avg < min_score:
            continue
        candidates.append((avg, path))

    # Dedupe by first two stops, keep highest avg.
    seen_starts: dict[tuple[str, str], tuple[float, list[Block]]] = {}
    for avg, path in candidates:
        key = (path[0].id, path[1].id)
        if key not in seen_starts or seen_starts[key][0] < avg:
            seen_starts[key] = (avg, path)

    ranked = sorted(seen_starts.values(), key=lambda x: -x[0])[:max_count]

    # Build Sequence objects with letter-suffixed ids.
    prefix = _playlist_prefix(blocks[0].parent if blocks else "")
    out: list[Sequence] = []
    for i, (avg, path) in enumerate(ranked):
        letter = chr(ord("A") + i)
        # Label: route + energy direction.
        steps = "→".join(ms.id.split("-")[-1] for ms in path)
        e_start = path[0].dna["energy_median"]
        e_end = path[-1].dna["energy_median"]
        if e_end > e_start + 0.5:
            arc = "Warm-to-Peak"
        elif e_end < e_start - 0.5:
            arc = "Peak-to-Cool"
        else:
            arc = "Steady-Groove"
        label = f"{arc} ({steps})"
        out.append(Sequence(id=f"{prefix}.{letter}", label=label, blocks=path))
    return out


# Mapping Energy 1..10 → rekordbox Colour (Pioneer-canonical hex strings).
# Picked so the gradient reads at a glance on the CDJ track-list dot.
ENERGY_COLOR_HEX = {
    1: "0x0000FF", 2: "0x0000FF", 3: "0x0000FF",      # blue — chill
    4: "0x25FDE9", 5: "0x25FDE9",                       # aqua — mellow
    6: "0x00FF00",                                      # green — groove
    7: "0xFFFF00",                                      # yellow — build
    8: "0xFFA500",                                      # orange — push
    9: "0xFF0000", 10: "0xFF0000",                      # red — peak
}


def color_for_energy(energy: Optional[int]) -> Optional[str]:
    """Return the rekordbox Colour hex for an energy bucket, or None."""
    if energy is None:
        return None
    return ENERGY_COLOR_HEX.get(int(energy))


def transition_label(a: Block, b: Block) -> str:
    """Compact 'how does this transition' description for the UI."""
    da, db = a.dna, b.dna
    a_bpm_max = da["bpm_range"][1] or 0
    b_bpm_min = db["bpm_range"][0] or 0
    bpm_diff = b_bpm_min - a_bpm_max
    bpm_part = f"{bpm_diff:+.0f} BPM" if bpm_diff else "=BPM"

    # Pick the best key pairing for the description.
    best = (-1, "", "")
    for ak in da["keys"] or [""]:
        for bk in db["keys"] or [""]:
            d = _camelot_distance(ak, bk)
            if d > best[0]:
                best = (d, ak, bk)
    key_part = f"key {best[1]}→{best[2]}" if best[1] and best[2] else "key ?"

    return f"{bpm_part}, {key_part}"
