"""Route registration package.

Importing this package imports each page module, whose `@ui.page(...)` decorator
registers its route as an import-time side effect. `main.py` does `import pages`.

`/microsets` and `/builder` were merged into `/build`; both keep redirecting so
old bookmarks and links still land somewhere useful.
"""
from nicegui import ui

from . import (library_page, sync_page, build_page, download_page,  # noqa: F401
               history_page, settings_page)


def _query(batch: str, node: str, gig: str, crates: str = "") -> str:
    from urllib.parse import urlencode
    params = {k: v for k, v in
              (("batch", batch), ("node", node), ("gig", gig), ("crates", crates))
              if v}
    return f"/build?{urlencode(params)}" if params else "/build"


@ui.page("/microsets")
def _microsets_redirect(batch: str = "", node: str = "", gig: str = ""):
    ui.navigate.to(_query(batch, node, gig))


@ui.page("/builder")
def _builder_redirect(batch: str = "", node: str = "", gig: str = "",
                      crates: str = ""):
    ui.navigate.to(_query(batch, node, gig, crates))
