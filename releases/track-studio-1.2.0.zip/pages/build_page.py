"""Build page (`/build`) — assemble a set from a pool, at either zoom level.

This is one activity seen two ways. Clustering a crate into blocks and picking
tracks one at a time were separate pages once (`/microsets` and `/builder`), but
they share a pool, a model, an export target and a goal; the split only meant
that roughing out an arc in blocks and then fine-tuning a transition meant
leaving the page and starting from an empty set.

They join on the set itself. THE SET is always an ordered list of tracks
(`microsets.SetEntry`), each remembering the block it arrived with — so adding a
block appends its tracks, adding a suggestion appends one, undo and rewind work
uniformly over both, the timeline still brackets the blocks, and the export can
still emit a playlist per block. The `Track | Block` toggle only changes what
the three suggestion cards contain.

Clustering is lazy: a pool is only grouped into blocks when the Blocks panel is
opened or Block suggestions are asked for, so working track-by-track never pays
for it.
"""
from __future__ import annotations

from nicegui import run, ui

import drafts
import history
import microsets
import mixmodel
import rekordbox_io
import runtime
import setline_push
from analysis import AnalysisJob
from export_ui import export_handoff
from library import file_duration, read_comment_into_track
from shell import apply_theme, header
from store import load_studio_state
from widgets import (ENERGY_COLORS, _chip, audio_player, camelot_color,
                     energy_arc_svg, mood_color, render_track_row)

# Score tiers — one language for every transition score in the app.
GOOD, OK = 75, 50
TEAL = "#2dd4bf"        # confirmed play-history evidence, everywhere

# How the set should move in energy from here.
DIRECTIONS = ((1, "⬈ Build"), (0, "⟶ Hold"), (-1, "⬊ Cool"))

# Suggestion tiles per page, and how far "More" steps. Two ranks of three: the
# top candidate is rarely the one you take, and three was thin enough that
# "More" was a reflex rather than a choice.
CARDS = 6


def _score_color(score: int) -> str:
    return "#3fb950" if score >= GOOD else "#d29922" if score >= OK else "#f85149"


@ui.page("/build")
def build_page(batch: str = "", node: str = "", gig: str = "", crates: str = ""):
    apply_theme()
    header("Build")
    runtime.refresh_batches()
    # The working session outlives this page function (see runtime.build_state):
    # leaving the page and coming back re-renders what was there. Never rebind
    # `state` — mutate it.
    state = runtime.build_state
    if state["preset"] is None:
        state["preset"] = microsets.DEFAULT_PRESET
    # Per-visit only: `tree` is a UI element belonging to *this* client and must
    # not be reused by the next one, and the two caches are derived from a
    # library that may have been reloaded since.
    view = {"tree": None, "paths_map": None, "durations": {}, "n_drafts": None,
            "open_blocks": set(),
            # the player panel, kept alive across re-renders (see render_now)
            "now_track": None, "now_shell": None, "now_head": None}

    def model():
        """The learned mixing model, or None while it loads in the background."""
        return runtime.mix_state["model"]

    # ==================================================================
    # layout
    # ==================================================================

    with ui.left_drawer(value=True, bordered=True).props("width=280").style(
            "background:#121419; border-right:1px solid #23262d"):
        ui.label("POOL").classes("text-caption text-weight-bold q-mb-xs") \
            .style("color:#6b7280; letter-spacing:.08em")
        ui.label("Click a playlist, or tick several to pool them.") \
            .classes("text-caption q-mb-sm").style("color:#6b7280")
        tree_holder = ui.column().classes("w-full")
        comp_holder = ui.column().classes("w-full gap-1 q-mt-md")
        ui.separator().props("color=grey-9").classes("q-mt-sm")
        ui.label("SUGGEST FROM").classes("text-caption text-weight-bold q-mt-sm") \
            .style("color:#6b7280; letter-spacing:.08em")
        # Options read as one widening scale, and the middle one borrows the
        # wording of the chips right above it rather than inventing a synonym
        # ("companions" is the model's word, not the user's). The count keeps
        # the empty case honest — with no companions it would silently behave
        # exactly like "Pool only".
        scope_radio = ui.radio({"pool": "Pool only",
                                "companions": "+ often gigged with",
                                "library": "Whole library"},
                               value="pool", on_change=lambda e: set_scope(e.value)) \
            .props("dense").classes("w-full")

    with ui.column().classes("w-full p-4 gap-3"):
        title_lbl = ui.label("Pick a playlist to build from").classes("text-h6")
        pool_lbl = ui.label("").classes("text-caption").style("color:#6b7280")
        comp_row = ui.row().classes("items-center gap-2 wrap")
        dl_banner = ui.row().classes("items-center gap-2 q-px-md q-py-sm").style(
            "background:#16181d; border:1px solid #23262d; border-radius:8px")
        dl_banner.set_visibility(False)

        no_history = ui.row().classes("items-center gap-2 q-px-md q-py-sm").style(
            "background:#16181d; border:1px solid #23262d; border-radius:8px")
        no_history.set_visibility(False)
        with no_history:
            ui.icon("history_toggle_off").style("color:#6b7280")
            ui.label("No play history learned yet — suggestions use audio "
                     "compatibility only.").classes("text-caption text-grey")

        # --- THE SET ---
        with ui.column().classes("w-full surface q-pa-md gap-2"):
            with ui.row().classes("items-center justify-between w-full no-wrap"):
                with ui.column().classes("gap-0"):
                    ui.label("THE SET").classes("text-subtitle1 text-weight-bold") \
                        .style("letter-spacing:.08em")
                    stats_lbl = ui.label("Nothing in the set yet.") \
                        .classes("text-caption").style("color:#6b7280")
                with ui.row().classes("items-center gap-2"):
                    # "Auto-fill", not "Auto-draft": next to Save draft / Drafts,
                    # the old label read as "save this automatically", which is
                    # the one thing it doesn't do.
                    draft_btn = ui.button("Auto-fill", icon="auto_fix_high",
                                          on_click=lambda: auto_draft()) \
                        .props("outline dense no-caps size=sm color=secondary") \
                        .tooltip("fill the set with the best arc through the blocks, "
                                 "as a starting point to edit")
                    drafts_btn = ui.button("Drafts", icon="folder_open",
                                           on_click=lambda: open_drafts()) \
                        .props("flat dense no-caps size=sm color=grey") \
                        .tooltip("resume a set you saved for later")
                    save_btn = ui.button("Save draft", icon="bookmark_add",
                                         on_click=lambda: open_save()) \
                        .props("outline dense no-caps size=sm color=secondary") \
                        .tooltip("keep this set to finish another day")
                    with ui.button("Export", icon="ios_share") \
                            .props("unelevated dense no-caps size=sm color=primary") \
                            as export_btn:
                        with ui.menu():
                            ui.menu_item("The Set (ordered)",
                                         lambda: do_export("set"))
                            ui.menu_item("Blocks as playlists",
                                         lambda: do_export("blocks"))
                            ui.menu_item("Both", lambda: do_export("both"))
                    setline_btn = ui.button("Setline", icon="playlist_add",
                                            on_click=lambda: open_setline(
                                                [e.track for e in state["entries"]])) \
                        .props("outline dense no-caps size=sm color=secondary") \
                        .tooltip("send the set to a crate in Setline, to plan it with others")
                    undo_btn = ui.button("Undo", icon="undo", on_click=lambda: undo()) \
                        .props("flat dense no-caps size=sm color=grey")
                    clear_btn = ui.button("Clear", icon="clear", on_click=lambda: clear()) \
                        .props("flat dense no-caps size=sm color=grey")
            set_panel = ui.column().classes("w-full gap-2")

        now_panel = ui.column().classes("w-full")
        controls = ui.row().classes("items-center gap-3 wrap w-full")
        search_holder = ui.column().classes("w-full gap-0")
        # A grid, not a row: six tiles side by side would each be too narrow to
        # read the reason line, so they run three across and wrap to a second
        # rank. Ranking still reads left-to-right, top-to-bottom.
        cards = ui.element("div").classes("w-full").style(
            "display:grid; gap:12px; align-items:stretch; min-width:0;"
            "grid-template-columns:repeat(3, minmax(0, 1fr))")

        # --- BLOCKS (collapsed; clustering happens on first open) ---
        blocks_exp = ui.expansion("Blocks — how this pool groups", icon="view_agenda") \
            .classes("w-full surface q-mt-md").props("dense")
        with blocks_exp:
            with ui.row().classes("items-center gap-3 q-pt-sm wrap"):
                ui.select({k: p.name for k, p in microsets.PRESETS.items()},
                          value=state["preset"].key, label="Grouping",
                          on_change=lambda e: on_preset_change(e.value)) \
                    .props("dense outlined").style("min-width:210px")
                blocks_stats = ui.label("").classes("text-caption text-grey")
            preset_desc = ui.label(state["preset"].description) \
                .classes("text-caption text-grey")
            block_cards = ui.column().classes("w-full gap-3 q-pt-sm")
        blocks_exp.on_value_change(lambda e: e.value and ensure_clustered())

        # --- analyze the pool in place ---
        with ui.expansion("Analyze energy for this pool", icon="bolt") \
                .classes("w-full surface q-mt-md").props("dense"):
            with ui.row().classes("items-center gap-3 q-pt-sm"):
                force_cb = ui.checkbox("Force re-analyze")
                rich_cb = ui.checkbox("Rich (style/mood)", value=True)
                analyze_btn = ui.button("Analyze", icon="bolt",
                                        on_click=lambda: do_analyze()) \
                    .props("unelevated color=primary")
                cancel_btn = ui.button("Cancel", icon="stop",
                                       on_click=lambda: cancel_analyze()) \
                    .props("flat color=negative").classes("hidden")
            analyze_prog = ui.linear_progress(value=0, show_value=False) \
                .props("instant-feedback").classes("w-full hidden")
            analyze_lbl = ui.label("Tags the pool's local files, then reloads. "
                                   "Rich adds style/mood/danceability (~2× slower).") \
                .classes("text-caption text-grey")
            col_cb = ui.checkbox("Color exported tags by energy", value=True)
            ui.label("Energy color applies only to tracks not already in your "
                     "rekordbox collection; existing tracks keep their color.") \
                .classes("text-caption text-grey")

        # --- legend ---
        with ui.expansion("What do the colors mean?", icon="palette") \
                .classes("w-full surface q-mt-md").props("dense"):
            with ui.column().classes("gap-2 q-pt-sm"):
                with ui.row().classes("items-center gap-2 no-wrap"):
                    ui.label("Energy").classes("text-caption text-grey").style("width:104px")
                    for e in range(1, 11):
                        ui.element("div").style(
                            f"width:14px;height:14px;border-radius:3px;"
                            f"background:{ENERGY_COLORS[e]}").tooltip(str(e))
                    ui.label("1 chill → 10 peak").classes("text-caption text-grey")
                with ui.row().classes("items-center gap-2 no-wrap"):
                    ui.label("Key").classes("text-caption text-grey").style("width:104px")
                    for k in ("1A", "4A", "7A", "10A", "1B"):
                        _chip(k, camelot_color(k))
                    ui.label("Camelot wheel — adjacent hues mix harmonically") \
                        .classes("text-caption text-grey")
                with ui.row().classes("items-center gap-2 no-wrap"):
                    ui.label("Valence").classes("text-caption text-grey").style("width:104px")
                    ui.element("div").style(
                        "width:120px;height:10px;border-radius:5px;"
                        "background:linear-gradient(90deg, hsl(210,65%,55%), hsl(30,65%,55%))")
                    ui.label("sombre → bright (emotional positivity)") \
                        .classes("text-caption text-grey")
                with ui.row().classes("items-center gap-2 no-wrap"):
                    ui.label("Danceability").classes("text-caption text-grey").style("width:104px")
                    with ui.element("div").style(
                            "width:120px;height:10px;border-radius:5px;background:#2a2d35"):
                        ui.element("div").style(
                            "width:88px;height:10px;border-radius:5px;background:#2dd4bf")
                    ui.label("bar fill = how danceable").classes("text-caption text-grey")
                with ui.row().classes("items-center gap-2 wrap"):
                    ui.label("Evidence").classes("text-caption text-grey").style("width:104px")
                    _chip("♥ 2 nights", "#1d3a36", TEAL)
                    ui.label("you actually played this transition on 2+ separate "
                             "nights — anything less is shown as a weaker hint") \
                        .classes("text-caption text-grey")

    # ==================================================================
    # pool
    # ==================================================================

    def _matching_dl_tracks(node_name):
        """Pending download-batch tracks belonging to this playlist. Downloads land
        in a per-playlist subfolder named after the (paired) playlist, so the batch
        name matches the rekordbox playlist name — fold those in so a set can be
        built from rekordbox + freshly downloaded tracks without exporting first."""
        target = (node_name or "").replace("/", "-").strip().lower()
        for name, tracks in runtime.download_batches.items():
            if name.strip().lower() == target:
                return tracks
        return []

    def _node_source_tracks(node_id):
        """(node, included_tracks, dl_tracks) for a playlist node."""
        node = runtime.library.rekordbox_index.get(node_id)
        if not node:
            return None, [], []
        rb_tracks = runtime.library.tracks_in_playlist(node_id)
        dl_tracks = _matching_dl_tracks(node.name)
        if not state["include_dl"]:
            return node, rb_tracks, dl_tracks
        seen = {id(t) for t in rb_tracks}
        return node, rb_tracks + [t for t in dl_tracks if id(t) not in seen], dl_tracks

    def _load_pool(name, raw_tracks, *, names=None, node_id=None, batch_name=None,
                   title=None, n_dl=0):
        """Adopt a list of library Tracks as the working pool and re-render.

        The single funnel for every source — a click, a tick set, a download
        batch, a gig — so they all get the same tag hydration, BPM filtering and
        invalidation of whatever was clustered from the previous pool.

        **The set survives.** The pool is where you dig; the set is what you've
        built out of it. Changing crates mid-build is normal — you run out of
        ideas in one playlist and tick another — so a pool swap keeps the set
        and only changes what the suggestions and blocks are drawn from. Only
        Clear empties a set.
        """
        for t in raw_tracks:
            if t.local_path and t.energy is None:
                read_comment_into_track(t)
        tracks, excluded = runtime.library.mix_tracks_from(raw_tracks)
        # Re-point the set at the new pool's objects where the same track is in
        # it, so re-analysing a folder refreshes the energies shown in the set
        # instead of leaving it on the copies made before the tags were written.
        fresh = {t.id: t for t in tracks}
        for e in state["entries"]:
            if e.track.id in fresh:
                e.track = fresh[e.track.id]
        state.update(pool=tracks, excluded=excluded, pool_name=name,
                     pool_names=names or [name], node_id=node_id,
                     batch_name=batch_name, blocks=[], clustered=False,
                     offset=0, title=title or f"♬ {name}", n_dl=n_dl)
        title_lbl.set_text(state["title"])
        _render_dl_banner(n_dl)
        if blocks_exp.value:          # panel already open — recluster now
            ensure_clustered()
        render_all()

    def _pool_from_nodes(node_ids):
        """(tracks, names, pending_downloads) for a set of playlist nodes."""
        seen, out, names, n_dl = set(), [], [], 0
        index = runtime.library.rekordbox_index
        for nid in node_ids:
            pnode, tracks, dl = _node_source_tracks(nid)
            if pnode is None:
                continue
            names.append(mixmodel.node_label(index, nid))
            n_dl += len(dl)
            for t in tracks:
                if id(t) not in seen:
                    seen.add(id(t))
                    out.append(t)
        return out, names, n_dl

    def _sync_ticks():
        tree = view["tree"]
        if tree is not None:
            tree._props["ticked"] = list(state["pool_ids"])
            tree.update()

    def on_tick(ticked):
        state["pool_ids"] = list(ticked or [])
        if not state["pool_ids"]:
            if state["node_id"]:
                select_node(state["node_id"])
            return
        tracks, names, n_dl = _pool_from_nodes(state["pool_ids"])
        if not names:
            return
        name = " + ".join(names)
        _load_pool(name, tracks, names=names, n_dl=n_dl,
                   title=f"♬ {name}" if len(names) == 1
                   else f"♬ {name}  ·  pool of {len(names)} playlists")

    def select_node(node_id):
        """Click = single-playlist pool; any ticks are dropped."""
        node, tracks, dl = _node_source_tracks(node_id)
        if not node:
            return
        if state["pool_ids"]:
            state["pool_ids"] = []
            _sync_ticks()
        _load_pool(mixmodel.node_label(runtime.library.rekordbox_index, node_id),
                   tracks, node_id=node_id, n_dl=len(dl))

    def select_batch(name):
        raw = runtime.download_batches.get(name, [])
        if not raw:
            ui.notify(f"No pending batch “{name}”", type="warning")
            return
        _load_pool(name, raw, batch_name=name,
                   title=f"♬ ⬇ {name}  (download batch)")

    def add_to_pool(node_id):
        """Grow the pool — from a companion chip, or while already pooling."""
        if not state["pool_ids"] and state["node_id"]:
            state["pool_ids"] = [state["node_id"]]
        if node_id not in state["pool_ids"]:
            state["pool_ids"].append(node_id)
        _sync_ticks()
        on_tick(state["pool_ids"])

    def _render_dl_banner(n_dl):
        dl_banner.clear()
        dl_banner.set_visibility(bool(n_dl))
        if not n_dl:
            return
        with dl_banner:
            ui.icon("cloud_download").classes("text-secondary")
            ui.checkbox(f"Include {n_dl} downloaded track(s) not yet in rekordbox",
                        value=state["include_dl"],
                        on_change=lambda e: _toggle_dl(e.value)).props("dense")

    def _toggle_dl(value):
        state["include_dl"] = value
        if state["pool_ids"]:
            on_tick(state["pool_ids"])
        elif state["node_id"]:
            select_node(state["node_id"])

    def set_scope(value):
        state["scope"] = value
        state["offset"] = 0
        render_suggestions()
        _autosave()

    def _paths_map():
        if view["paths_map"] is None:
            view["paths_map"] = mixmodel.playlist_paths(
                runtime.library.rekordbox_index)
        return view["paths_map"]

    def _selected_ids():
        return state["pool_ids"] or ([state["node_id"]] if state["node_id"] else [])

    def _companions():
        """[(node_id, share, label)] of playlists historically gigged alongside
        the pool — the pool's own subtrees excluded on both sides."""
        m = model()
        current = _selected_ids()
        if m is None or not current:
            return []
        index = runtime.library.rekordbox_index
        by_path = _paths_map()
        by_id = {v: k for k, v in by_path.items()}
        mine = [p for nid in current
                for p in mixmodel.subtree_paths(index, nid, by_id)]
        ranked = []
        for cp, share in m.companions(mine, k=8):
            cid = by_path.get(cp)
            if cid is not None and cid not in current:
                ranked.append((cid, share, mixmodel.short_path(cp)))
        return mixmodel.drop_covered(index, current, ranked)[:4]

    def candidates():
        """Tracks the suggestions may draw from, per the scope radio."""
        if state["scope"] == "library":
            tracks, _ = runtime.library.mix_tracks_from(
                [t for t in runtime.library.tracks if t.bpm])
            return tracks
        if state["scope"] == "companions":
            ids = _selected_ids() + [cid for cid, _, _ in _companions()]
            if len(ids) > len(_selected_ids()):
                tracks, _, _ = _pool_from_nodes(ids)
                out, _ = runtime.library.mix_tracks_from(tracks)
                return out
        return state["pool"]

    # ==================================================================
    # blocks (lazy)
    # ==================================================================

    def ensure_clustered():
        """Cluster the pool if it hasn't been. Working track-by-track never
        triggers this, which is the point of doing it on demand."""
        if state["clustered"] or not state["pool"]:
            return
        state["blocks"] = microsets.cluster(state["pool_name"], state["pool"],
                                          preset=state["preset"])
        state["valence_dir"] = microsets.journey_direction(state["blocks"])
        state["clustered"] = True
        render_blocks()

    def on_preset_change(key):
        state["preset"] = microsets.PRESETS[key]
        preset_desc.set_text(state["preset"].description)
        state["clustered"] = False
        ensure_clustered()
        render_suggestions()
        _autosave()

    def _block_by_id(block_id):
        return next((b for b in state["blocks"] if b.id == block_id), None)

    def _toggle_block(block_id, opened):
        """Remember which blocks are unfolded, across the re-render a pick causes."""
        view["open_blocks"].discard(block_id)
        if opened:
            view["open_blocks"].add(block_id)

    # ==================================================================
    # the set
    # ==================================================================

    def _set_ids():
        return {e.track.id for e in state["entries"]}

    def _anchor():
        """The entry a new pick follows — the insertion point if one is set,
        otherwise the tail. This is what the suggestions are scored against."""
        entries = state["entries"]
        if not entries:
            return None
        at = state["insert_at"]
        return entries[at] if at is not None else entries[-1]

    def add_track(track, block=None):
        """Add a track after the anchor: the end of the set, or an insertion
        point you parked mid-set with "Pick next"."""
        entry = microsets.SetEntry(
            track=track,
            block_id=block.id if block else None,
            role=block.role if block else None)
        at = state["insert_at"]
        if at is None:
            state["entries"].append(entry)
            state["cursor"] = None
        else:
            state["entries"].insert(at + 1, entry)
            # Walk the insertion point along with what you just added, so a
            # second pick continues the run instead of stacking in reverse.
            state["insert_at"] = state["cursor"] = at + 1
        state["offset"] = 0

    def pick(track):
        add_track(track)
        render_all()

    def add_block(ms):
        """Append a whole block's tracks, skipping any already in the set."""
        have = _set_ids()
        added = 0
        for t in ms.tracks:
            if t.id not in have:
                add_track(t, ms)
                have.add(t.id)
                added += 1
        render_all()
        if not added:
            ui.notify(f"{ms.id} is already in the set", type="info")

    def undo():
        """Remove the last thing added — a whole block run if that's what it was.

        Undo is per *action*, not per track: a block arrived in one click and
        leaves in one. Ten tracks vanishing at once needs saying out loud,
        hence the notice.
        """
        entries = state["entries"]
        if not entries:
            return
        runs = microsets.set_runs(entries)
        last_id, last_run = runs[-1]
        drop = len(last_run) if last_id is not None else 1
        state["entries"] = entries[:len(entries) - drop]
        state["offset"] = 0
        state["cursor"] = state["insert_at"] = None
        render_all()
        if drop > 1:
            ui.notify(f"Removed {last_id} — {drop} tracks", type="info")

    def clear():
        state["entries"] = []
        state["offset"] = 0
        state["cursor"] = state["insert_at"] = None
        render_all()

    def set_insert(idx):
        """Park (or unpark) the point new picks land after. `None` = the end."""
        state["insert_at"] = None if state["insert_at"] == idx else idx
        state["offset"] = 0
        render_all()

    def audition(idx):
        """Put a step of the set under the player. Never changes the set.

        This is what clicking a step in the timeline does. It used to rewind,
        which made the one obvious gesture — "let me hear that again" — the
        destructive one; rewinding is now a button on the step you land on.
        Clicking the same step again returns to the live tail.
        """
        state["cursor"] = None if state["cursor"] == idx else idx
        render_set()
        render_now()

    def move(idx, delta):
        """Slide the selected step one place through the set.

        Order is the whole artifact — a set is the same tracks in a different
        order, and until now the only way to fix a run was to rewind past it
        and rebuild. The selection follows the track rather than the slot, so
        holding the button walks it along.
        """
        entries = state["entries"]
        j = idx + delta
        if not (0 <= j < len(entries)):
            return
        entries[idx], entries[j] = entries[j], entries[idx]
        state["cursor"] = j
        state["insert_at"] = None
        # Full re-render: moving the tail changes what comes next, so the
        # suggestions have to follow. The player survives it — `render_now`
        # only rebuilds its body when the track under the cursor changes.
        render_all()

    def drop(idx):
        """Take one track out and close the gap, leaving the rest in order.

        Undo can't bring it back — it works on the last *action*, and this
        isn't one — so the notice names what left, which is enough to find it
        again in the pool.
        """
        entries = state["entries"]
        if not (0 <= idx < len(entries)):
            return
        gone = entries.pop(idx)
        state["insert_at"] = None
        # Stay on the track that slid into the gap, so dropping a few in a row
        # doesn't mean re-selecting between each.
        state["cursor"] = min(idx, len(entries) - 1) if entries else None
        render_all()
        ui.notify(f"Removed {gone.track.display}", type="info")

    def rewind_to(idx):
        dropped = len(state["entries"]) - idx - 1
        if dropped <= 0:
            return
        state["entries"] = state["entries"][:idx + 1]
        state["offset"] = 0
        state["cursor"] = state["insert_at"] = None
        render_all()
        ui.notify(f"Rewound — dropped {dropped} track(s)", type="info")

    def auto_draft():
        """Fill the set with the best generated walk through the blocks.

        `generate_sequences` already computes exactly this; as a read-only list
        of names it was unusable, so it lands in the set as an editable draft.
        """
        ensure_clustered()
        if not state["blocks"]:
            ui.notify("Pick a pool first", type="warning")
            return
        seqs = microsets.generate_sequences(
            state["blocks"], max_count=1, length=4, min_score=60,
            valence_dir=state["valence_dir"], model=model())
        if not seqs:
            ui.notify("No arc scored well enough to draft — build it by hand",
                      type="warning")
            return
        seq = seqs[0]
        state["entries"] = []
        state["insert_at"] = None
        have = set()
        for ms in seq.blocks:
            for t in ms.tracks:
                if t.id not in have:
                    add_track(t, ms)
                    have.add(t.id)
        render_all()
        ui.notify(f"Drafted {seq.label} — {len(state['entries'])} tracks. Edit away.",
                  type="positive")

    # ==================================================================
    # drafts — finishing a set another day
    # ==================================================================

    def _snapshot(name: str) -> drafts.Draft:
        return drafts.Draft(
            name=name, pool_name=state["pool_name"],
            pool_ids=list(state["pool_ids"]), node_id=state["node_id"],
            batch_name=state["batch_name"], include_dl=state["include_dl"],
            pool_track_ids=[t.id for t in state["pool"]],
            preset=state["preset"].key, grain=state["grain"],
            energy_dir=state["energy_dir"], valence_dir=state["valence_dir"],
            scope=state["scope"],
            entries=drafts.entries_payload(state["entries"]))

    def open_save():
        """Name it and keep it. Re-saving a resumed draft offers its own name,
        so the common case (same set, later that night) is one extra click."""
        if not state["entries"]:
            ui.notify("Nothing to save yet", type="warning")
            return
        suggested = state["draft_name"] or drafts.unique_name(
            state["pool_name"] or "Untitled set")
        with ui.dialog() as dlg, ui.card().classes("surface q-pa-md gap-2") \
                .style("min-width:420px"):
            ui.label("Save this set as a draft").classes("text-subtitle1 text-weight-bold")
            ui.label(f"{len(state['entries'])} tracks from {state['pool_name']}") \
                .classes("text-caption").style("color:#6b7280")
            name_in = ui.input("Draft name", value=suggested) \
                .props("dense outlined autofocus").classes("w-full")
            warn = ui.label("").classes("text-caption").style("color:#d29922")

            def on_name(_=None):
                nm = (name_in.value or "").strip()
                clash = nm and nm != state["draft_name"] and drafts.exists(nm)
                warn.set_text(f"“{nm}” already exists — saving replaces it."
                              if clash else "")
            name_in.on_value_change(on_name)
            on_name()
            with ui.row().classes("justify-end gap-2 w-full q-mt-sm"):
                ui.button("Cancel", on_click=dlg.close) \
                    .props("flat dense no-caps color=grey")
                ui.button("Save", icon="bookmark_add",
                          on_click=lambda: _do_save(name_in.value, dlg)) \
                    .props("unelevated dense no-caps color=primary")
        dlg.open()

    def _do_save(name, dlg):
        name = (name or "").strip()
        if not name:
            ui.notify("Give the draft a name", type="warning")
            return
        drafts.save(_snapshot(name))
        state["draft_name"] = name
        dlg.close()
        render_drafts_btn(recount=True)
        render_set()
        ui.notify(f"Saved “{name}” — resume it any time from Drafts",
                  type="positive")

    # ==================================================================
    # send to Setline, the shared online planner
    # ==================================================================

    async def open_setline(tracks):
        """Send tracks to a crate in Setline: an existing one, or a new name.
        Setline matches each by Beatport id, ISRC, then artist and title, and
        types in what Beatport doesn't carry (see setline_push)."""
        tracks = list(tracks)
        if not tracks:
            ui.notify("Nothing to send yet", type="warning")
            return
        with ui.dialog() as dlg, ui.card().classes("surface q-pa-md gap-2") \
                .style("min-width:420px"):
            ui.label("Send to Setline").classes("text-subtitle1 text-weight-bold")
            ui.label(f"{len(tracks)} tracks, into a crate everyone planning the set "
                     "can dig through").classes("text-caption").style("color:#6b7280")
            if not setline_push.configured():
                ui.label("Add SETLINE_URL, SETLINE_TOKEN (the Setline service's "
                         "SETLINE_MCP_TOKEN) and SETLINE_NAME (your name in Setline) "
                         "to .env, then restart Track Studio.").classes("text-caption")
                with ui.row().classes("justify-end w-full q-mt-sm"):
                    ui.button("Close", on_click=dlg.close) \
                        .props("flat dense no-caps color=grey")
                dlg.open()
                return
            crate_in = ui.input("Crate", placeholder="Pick one, or type a new name") \
                .props("dense outlined autofocus").classes("w-full")
            hint = ui.label("Loading Setline's crates…").classes("text-caption") \
                .style("color:#6b7280")
            with ui.row().classes("justify-end gap-2 w-full q-mt-sm"):
                ui.button("Cancel", on_click=dlg.close) \
                    .props("flat dense no-caps color=grey")
                send_btn = ui.button("Send", icon="send") \
                    .props("unelevated dense no-caps color=primary")
        dlg.open()
        existing: dict[str, dict] = {}

        def on_name(_=None):
            name = (crate_in.value or "").strip()
            crate = existing.get(name.lower())
            hint.set_text(f"Adds to {crate['name']} ({crate['tracks']} tracks now)" if crate
                          else f"Starts a new crate “{name}”" if name
                          else f"{len(existing)} crates in Setline" if existing
                          else "No crates yet: type a name to start one")
            send_btn.set_enabled(bool(name))
        crate_in.on_value_change(on_name)
        send_btn.set_enabled(False)

        async def send():
            name = (crate_in.value or "").strip()
            if not name:
                return
            send_btn.props("loading")
            hint.set_text(f"Sending {len(tracks)} tracks: Setline checks each on Beatport…")
            try:
                result = await run.io_bound(setline_push.send, name, tracks,
                                            runtime.library.tracks)
            except setline_push.SetlineUnavailable as exc:
                runtime._safe_ui(lambda: (send_btn.props(remove="loading"),
                                          hint.set_text(str(exc))))
                return
            runtime._safe_ui(dlg.close)
            runtime._safe_ui(lambda: ui.notify(setline_push.describe(result),
                                               type="positive", multi_line=True))
        send_btn.on_click(send)

        try:
            crates = await run.io_bound(setline_push.crates)
        except setline_push.SetlineUnavailable as exc:
            runtime._safe_ui(lambda: hint.set_text(str(exc)))
            return
        existing.update({c["name"].lower(): c for c in crates})
        runtime._safe_ui(lambda: (crate_in.set_autocomplete([c["name"] for c in crates]),
                                  on_name()))

    def open_drafts():
        saved = drafts.all_drafts()
        with ui.dialog() as dlg, ui.card().classes("surface q-pa-md gap-2") \
                .style("min-width:560px"):
            ui.label("Saved drafts").classes("text-subtitle1 text-weight-bold")
            if not saved:
                ui.label("None yet — build a set and hit Save draft.") \
                    .classes("text-caption").style("color:#6b7280")
            for d in saved:
                with ui.row().classes("items-center gap-3 no-wrap w-full q-py-xs") \
                        .style("border-bottom:1px solid #1e2127"):
                    with ui.column().classes("gap-0 flex-grow").style("min-width:0"):
                        ui.label(d.name).classes("text-body2 ellipsis") \
                            .style("min-width:0")
                        ui.label(f"{d.n_tracks} tracks · {d.pool_name} · {d.when}") \
                            .classes("text-caption ellipsis") \
                            .style("color:#6b7280; min-width:0")
                    ui.button("Resume", icon="play_arrow",
                              on_click=lambda d=d: (dlg.close(), _resume_asking(d))) \
                        .props("outline dense no-caps size=sm color=primary")
                    ui.button(icon="delete_outline",
                              on_click=lambda d=d, g=dlg: (drafts.delete(d.name),
                                                           g.close(),
                                                           render_drafts_btn(True),
                                                           open_drafts())) \
                        .props("flat dense round size=sm color=grey") \
                        .tooltip(f"delete “{d.name}”")
            with ui.row().classes("justify-end w-full q-mt-sm"):
                ui.button("Close", on_click=dlg.close) \
                    .props("flat dense no-caps color=grey")
        dlg.open()

    def _resume_asking(d):
        """Resuming swaps the set on screen for the draft's.

        Worth a confirm now that everything else is non-destructive: switching
        crates keeps the set, Clear is the explicit way to empty it, and this is
        the one remaining click that can drop work you haven't named.
        """
        cur = state["entries"]
        if not cur or state["draft_name"] == d.name:
            resume_draft(d)
            return
        safe = state["draft_name"]
        with ui.dialog() as c, ui.card().classes("surface q-pa-md gap-2") \
                .style("min-width:420px"):
            ui.label(f"Replace the current {len(cur)}-track set?") \
                .classes("text-subtitle1 text-weight-bold")
            ui.label(f"It's saved as the draft “{safe}”, so you can bring it back."
                     if safe else
                     "It isn't saved as a draft — resuming will drop it. "
                     "Cancel and hit Save draft first if you want to keep it.") \
                .classes("text-caption").style("color:#9aa0a8")
            with ui.row().classes("justify-end gap-2 w-full q-mt-sm"):
                ui.button("Cancel", on_click=c.close) \
                    .props("flat dense no-caps color=grey")
                ui.button(f"Replace with “{d.name}”",
                          on_click=lambda: (c.close(), resume_draft(d))) \
                    .props("unelevated dense no-caps color=warning")
        c.open()

    def _pool_from_ids(d) -> bool:
        """Rebuild the draft's pool from its stored track ids. The fallback when
        the playlist it was dug from is gone, renamed, or never existed."""
        if not d.pool_track_ids:
            return False
        wanted = set(d.pool_track_ids)
        raw = [t for t in runtime.library.tracks
               if (t.rekordbox_id or t.isrc or t.display) in wanted]
        if not raw:
            return False
        _load_pool(d.pool_name, raw, title=f"♬ {d.pool_name}  ·  from a draft")
        return True

    def resume_draft(d, *, announce: bool = True) -> bool:
        """Rebuild the session a draft describes: its pool first, then the set.

        The pool has to come back first — the suggestions, the blocks and the
        scope all read from it — and loading a pool deliberately clears the set,
        so the entries are rehydrated *after*, from ids. Returns whether it
        worked; the autosave restore needs to know, so a library that hasn't
        loaded yet means "try again later" rather than "the work is gone".
        """
        state["include_dl"] = d.include_dl
        state["preset"] = microsets.PRESETS.get(d.preset, state["preset"])
        if d.batch_name:
            gone = d.batch_name not in runtime.download_batches
            if not gone:
                select_batch(d.batch_name)
        elif d.pool_ids:
            state["pool_ids"] = list(d.pool_ids)
            _sync_ticks()
            on_tick(d.pool_ids)
            gone = state["pool_name"] != d.pool_name
        elif d.node_id:
            select_node(d.node_id)
            gone = state["node_id"] != d.node_id
        else:
            gone = True                   # e.g. a pool seeded from a played gig
        if gone and not _pool_from_ids(d):
            # Refuse rather than half-resume: loading a pool clears the set, so
            # a draft restored against whatever pool happened to be loaded
            # would look right and then be wiped by the next playlist click.
            if announce:
                ui.notify(f"“{d.name}”: neither its pool ({d.pool_name}) nor its "
                          "tracks are in the loaded library — load rekordbox "
                          "first. The draft is untouched.", type="warning")
            return False
        wider, _ = runtime.library.mix_tracks_from(
            [t for t in runtime.library.tracks if t.bpm])
        entries, missing = drafts.rehydrate(d.entries, state["pool"], wider)
        state.update(entries=entries, draft_name=d.name or None, grain=d.grain,
                     energy_dir=d.energy_dir, valence_dir=d.valence_dir,
                     scope=d.scope, offset=0, cursor=None, insert_at=None)
        scope_radio.set_value(d.scope)
        render_all()
        if announce:
            ui.notify(f"Resumed “{d.name}” — {len(entries)} tracks"
                      + (f", {len(missing)} no longer in the library"
                         if missing else ""),
                      type="warning" if missing else "positive")
        return bool(entries)

    def _autosave():
        """Keep the working session on disk, so a restart resumes it.

        The guard is the whole subtlety: an empty set only *overwrites* the
        saved one once this process has taken ownership of it. Open the app
        before rekordbox has loaded and the restore can't run yet — writing
        "nothing here" at that moment would delete last night's work.
        """
        if state["entries"]:
            drafts.save_session(_snapshot(state["draft_name"] or ""))
        elif state["session_loaded"]:
            drafts.clear_session()

    def restore_autosave():
        """Pick the last session back up, once per process."""
        if state["session_loaded"] or state["entries"]:
            return
        d = drafts.load_session()
        if d is None:
            state["session_loaded"] = True      # nothing on disk to protect
            return
        if not resume_draft(d, announce=False):
            return              # library not ready — leave the file, retry later
        state["session_loaded"] = True
        n = len(state["entries"])
        ui.notify(f"Picked up where you left off — {n} tracks"
                  + (f" · draft “{state['draft_name']}”" if state["draft_name"]
                     else ""), type="info")

    def render_drafts_btn(recount: bool = False):
        """The count is cached: `render_set` runs on every add, and that is no
        reason to re-read the drafts file."""
        if recount or view["n_drafts"] is None:
            view["n_drafts"] = len(drafts.all_drafts())
        n = view["n_drafts"]
        drafts_btn.set_text(f"Drafts ({n})")
        drafts_btn.set_visibility(bool(n))

    def _duration(t) -> float:
        if not t.path:
            return 0.0
        key = str(t.path)
        if key not in view["durations"]:
            view["durations"][key] = file_duration(t.path) or 0.0
        return view["durations"][key]

    # ==================================================================
    # rendering
    # ==================================================================

    def render_all():
        render_pool_line()
        render_set()
        render_now()
        render_controls()
        render_suggestions()
        render_companion_chips()
        if state["clustered"]:
            render_blocks()
        _autosave()

    def render_pool_line():
        pool, excluded = state["pool"], state["excluded"]
        if not pool:
            pool_lbl.set_text("")
            return
        excl = f"  ·  {len(excluded)} excluded (no BPM)" if excluded else ""
        pool_lbl.set_text(f"{len(pool)} tracks in pool{excl}")

    def render_set():
        entries = state["entries"]
        for b in (export_btn, setline_btn, undo_btn, clear_btn, save_btn):
            b.set_visibility(bool(entries))
        draft_btn.set_visibility(bool(state["pool"]))
        render_drafts_btn()
        set_panel.clear()
        if not entries:
            stats_lbl.set_text("Nothing in the set yet — add a block, or pick a "
                               "track below." if state["pool"]
                               else "Pick a playlist on the left to start.")
            return

        mins = sum(_duration(e.track) for e in entries) / 60.0
        energies = [e.track.energy for e in entries if e.track.energy]
        bpms = [e.track.bpm for e in entries if e.track.bpm]
        bits = [f"{len(entries)} tracks"]
        if mins:
            bits.append(f"{mins:.0f} min")
        if energies:
            bits.append(f"E{min(energies)}→E{max(energies)}")
        if bpms:
            bits.append(f"{int(min(bpms))}–{int(max(bpms))} bpm")
        runs = microsets.set_runs(entries)
        bits.append(f"{len(runs)} section{'s' if len(runs) != 1 else ''}")
        if state["draft_name"]:
            bits.append(f"draft “{state['draft_name']}”")
        stats_lbl.set_text("  ·  ".join(bits))

        with set_panel:
            if len(energies) >= 2:
                ui.html(energy_arc_svg(energies, w=720, h=90, big=True),
                        sanitize=False).classes("w-full")
            # timeline: one bracket per run, chips inside it
            pos = 0
            with ui.row().classes("items-start gap-2 wrap w-full"):
                for block_id, run in runs:
                    with ui.column().classes("gap-0 q-pr-sm").style(
                            "border-left:2px solid "
                            + ("#ff7a1a" if block_id else "#3a3f47")
                            + "; padding-left:6px"):
                        role = next((e.role for e in run if e.role), None)
                        ui.label(f"{block_id} · {role}" if block_id and role
                                 else (block_id or "picks")) \
                            .classes("text-caption").style("color:#6b7280")
                        with ui.row().classes("items-center gap-1 wrap"):
                            for e in run:
                                t = e.track
                                col = ENERGY_COLORS.get(t.energy or 0, "#888")
                                i = pos
                                sel = state["cursor"] == i
                                with ui.row().classes("items-center gap-1 no-wrap").style(
                                        f"background:{col}{'55' if sel else '22'};"
                                        f"border:1px solid {col}; border-radius:8px;"
                                        "padding:2px 8px; cursor:pointer"
                                        + (f"; box-shadow:0 0 0 2px {col}66" if sel
                                           else "")) \
                                        .on("click", lambda i=i: audition(i)) \
                                        .tooltip(f"{t.display} — click to hear it"):
                                    ui.label(str(i + 1)).classes(
                                        "text-caption text-weight-bold")
                                    ui.label(f"{t.key or '?'} "
                                             f"{int(t.bpm) if t.bpm else '—'}") \
                                        .classes("text-caption").style("color:#9aa0a8")
                                if state["insert_at"] == i:
                                    ui.label("▸").classes("text-caption") \
                                        .style("color:#58a6ff; font-weight:700;"
                                               "margin:0 -2px") \
                                        .tooltip("new picks land here")
                                pos += 1
            ui.label("click a step to hear it and to move it — the set only "
                     "changes when you use the buttons below") \
                .classes("text-caption").style("color:#4b5563")

    def render_now():
        """The player panel: the set's tail, or the step being auditioned.

        One panel rather than two, because only one thing is ever playing — it
        just changes color and grows controls when you've stepped back into the
        set. Split in two on purpose: the body (name and transport) is rebuilt
        only when the *track* changes, so moving a step around, or anything
        else that re-renders the page, doesn't tear down the `<audio>` element
        and cut the sound you're arranging to.
        """
        entries = state["entries"]
        if not entries:
            now_panel.clear()
            view["now_track"] = None
            return
        cur = state["cursor"]
        if cur is not None and cur >= len(entries):
            cur = state["cursor"] = None
        idx = len(entries) - 1 if cur is None else cur
        t = entries[idx].track
        if view["now_track"] != t.id:
            now_panel.clear()
            with now_panel:
                shell = ui.column().classes("w-full q-pa-md gap-1")
                with shell:
                    head = ui.row().classes("items-center justify-between "
                                            "no-wrap w-full")
                    with ui.row().classes("items-center gap-3 no-wrap w-full"):
                        ui.badge(str(t.energy) if t.energy else "?").style(
                            f"background:{ENERGY_COLORS.get(t.energy or 0, '#888')}")
                        ui.label(t.display).classes("flex-grow ellipsis") \
                            .style("min-width:0")
                        if t.key:
                            _chip(t.key, camelot_color(t.key))
                        if t.bpm:
                            ui.label(f"{round(t.bpm)}") \
                                .classes("text-caption text-grey") \
                                .style("font-family:monospace")
                    if t.path:
                        audio_player(t.path)
            view.update(now_track=t.id, now_shell=shell, now_head=head)
        _render_now_head(idx, len(entries), cur is not None)

    def _render_now_head(idx, total, selected):
        """The panel's framing — which step this is, and what you can do to it.

        Redrawn on its own so the transport underneath keeps playing.
        """
        back = total - idx - 1              # steps between here and the tail
        view["now_shell"].style(
            "background:#16181d; border:1px solid #23262d; border-left:3px "
            f"solid {'#58a6ff' if back else '#ff7a1a'}; border-radius:0 8px 8px 0")
        head = view["now_head"]
        head.clear()
        with head:
            ui.label(f"REPLAYING · TRACK {idx + 1} OF {total}" if back
                     else f"NOW · TRACK {total}").classes("text-caption") \
                .style(f"color:{'#58a6ff' if back else '#6b7280'};"
                       "letter-spacing:.08em")
            if not selected:
                return
            with ui.row().classes("items-center gap-2 no-wrap"):
                # Reordering sits on the selected step, where auditioning and
                # rewinding already are — one click selects, everything you can
                # do to that track is then in one place.
                ui.button("Earlier", icon="arrow_back",
                          on_click=lambda i=idx: move(i, -1)) \
                    .props("flat dense no-caps size=sm color=grey"
                           + (" disable" if idx == 0 else "")) \
                    .tooltip("move this track one place earlier in the set")
                ui.button("Later", icon="arrow_forward",
                          on_click=lambda i=idx: move(i, 1)) \
                    .props("flat dense no-caps size=sm color=grey"
                           + (" disable" if back == 0 else "")) \
                    .tooltip("move this track one place later in the set")
                # "Remove" rather than "Drop": Rewind's own label already says
                # it drops the N after, and the two must not read alike — one
                # takes out a track, the other cuts off the rest of the set.
                ui.button("Remove", icon="close",
                          on_click=lambda i=idx: drop(i)) \
                    .props("flat dense no-caps size=sm color=negative") \
                    .tooltip("take this track out — the rest of the set stays")
                if back:
                    # Build forward from here instead of from the end: the
                    # alternative was rewinding past everything after this
                    # track just to change what follows it.
                    on = state["insert_at"] == idx
                    ui.button("Picking here" if on else "Pick next",
                              icon="playlist_add",
                              on_click=lambda i=idx: set_insert(i)) \
                        .props(("unelevated" if on else "outline")
                               + " dense no-caps size=sm color=info") \
                        .tooltip("point the suggestions at this track — picks "
                                 "land right after it instead of at the end")
                    ui.button(f"Rewind — drop the {back} after", icon="undo",
                              on_click=lambda i=idx: rewind_to(i)) \
                        .props("outline dense no-caps size=sm color=warning") \
                        .tooltip("cut the set back to this track")
                    ui.button("Back to the end", icon="last_page",
                              on_click=lambda: audition(None)) \
                        .props("flat dense no-caps size=sm color=grey")

    def render_controls():
        controls.clear()
        if not state["pool"]:
            return
        with controls:
            # Where the next pick lands has to be visible from up here: the
            # Pick buttons are in this row's cards, not down in the panel that
            # parked the insertion point.
            at = state["insert_at"]
            if at is not None:
                ui.label(f"NEXT AFTER TRACK {at + 1}") \
                    .classes("text-caption text-weight-bold") \
                    .style("color:#58a6ff; letter-spacing:.08em")
                ui.button("append at the end instead", icon="last_page",
                          on_click=lambda: set_insert(None)) \
                    .props("flat dense no-caps size=sm color=grey")
            else:
                ui.label("NEXT UP" if state["entries"] else "START WITH") \
                    .classes("text-caption text-weight-bold") \
                    .style("color:#6b7280; letter-spacing:.08em")
            ui.toggle({"track": "Track", "block": "Block"}, value=state["grain"],
                      on_change=lambda e: set_grain(e.value)) \
                .props("dense no-caps unelevated toggle-color=primary") \
                .tooltip("suggest the next single track, or a whole block")
            if state["entries"]:
                ui.toggle({d: label for d, label in DIRECTIONS},
                          value=state["energy_dir"],
                          on_change=lambda e: set_dir(e.value)) \
                    .props("dense no-caps unelevated toggle-color=primary") \
                    .tooltip("where the set should go from here")
                vlabel = {1: "valence brighter ↗", -1: "valence darker ↘",
                          0: "valence auto"}[state["valence_dir"]]
                ui.button(vlabel, on_click=lambda: cycle_valence()) \
                    .props("flat dense no-caps size=sm color=grey")
            ui.button("More", icon="refresh", on_click=lambda: more()) \
                .props("flat dense no-caps size=sm color=grey") \
                .tooltip("show the next candidates down the ranking")
            ui.space()
            ui.input(placeholder="or pick any track…",
                     on_change=lambda e: render_search(e.value)) \
                .props("dense outlined clearable").style("min-width:220px")
        search_holder.clear()

    def set_grain(value):
        state["grain"] = value
        state["offset"] = 0
        if value == "block":
            ensure_clustered()
        render_suggestions()
        _autosave()

    def set_dir(value):
        state["energy_dir"] = value
        state["offset"] = 0
        render_suggestions()
        _autosave()

    def cycle_valence():
        state["valence_dir"] = {0: 1, 1: -1, -1: 0}[state["valence_dir"]]
        state["offset"] = 0
        render_controls()
        render_suggestions()
        _autosave()

    def more():
        state["offset"] += CARDS
        render_suggestions()

    def render_search(query):
        """Manual override — the model advises, it never gates the choice."""
        search_holder.clear()
        q = (query or "").strip().lower()
        if len(q) < 2:
            return
        have = _set_ids()
        hits = [t for t in candidates()
                if t.id not in have
                and (q in t.name.lower() or q in (t.artist or "").lower())][:6]
        with search_holder:
            if not hits:
                ui.label("No match in the current scope.").classes("text-caption") \
                    .style("color:#6b7280")
            for t in hits:
                with ui.row().classes("items-center gap-2 no-wrap w-full q-py-xs") \
                        .style("border-bottom:1px solid #1e2127"):
                    ui.badge(str(t.energy) if t.energy else "?").style(
                        f"background:{ENERGY_COLORS.get(t.energy or 0, '#888')}")
                    ui.label(t.display).classes("flex-grow ellipsis") \
                        .style("min-width:0")
                    if t.key:
                        _chip(t.key, camelot_color(t.key))
                    ui.button("Pick", on_click=lambda t=t: pick(t)) \
                        .props("outline dense no-caps size=sm color=primary")

    # ----- suggestions -----

    def render_suggestions():
        cards.clear()
        if not state["pool"]:
            return
        m = model()
        no_history.set_visibility(m is not None and not m.gig_count)
        if m is None:
            with cards:
                ui.label("Learning from your play history…").classes("text-caption") \
                    .style("color:#6b7280")
            return
        items = (_block_suggestions() if state["grain"] == "block"
                 else _track_suggestions(m))
        if not items:
            with cards:
                with ui.column().classes("gap-1"):
                    ui.label("No candidates left in this scope.") \
                        .classes("text-caption").style("color:#9aa0a8")
                    ui.label("Widen “Suggest from” on the left, or use More / search.") \
                        .classes("text-caption").style("color:#6b7280")
            return
        with cards:
            for rank, item in enumerate(items):
                top = rank == 0 and state["offset"] == 0
                if state["grain"] == "block":
                    _render_block_card(*item, top=top)
                else:
                    _render_track_card(item, top=top)

    def _track_suggestions(m):
        entries, have = state["entries"], _set_ids()
        pool = candidates()
        if not entries:
            return m.openers([t for t in pool if t.id not in have],
                             k=CARDS, offset=state["offset"])
        return m.next_tracks(_anchor().track, pool, k=CARDS, offset=state["offset"],
                             exclude=have, energy_dir=state["energy_dir"],
                             valence_dir=state["valence_dir"])

    def _block_suggestions():
        """[(block, score, evidence)] — the next blocks to play.

        With an empty set the pool's own arc order is the suggestion (blocks are
        already sorted low→high energy). Otherwise score against where the set
        currently stands — or against the insertion point, when one is parked
        mid-set: the block that entry came from if it had one, else a one-track
        stand-in so a hand-picked anchor still has something to mix from.
        """
        ensure_clustered()
        sets, entries = state["blocks"], state["entries"]
        if not sets:
            return []
        have = _set_ids()
        fresh = [b for b in sets if not {t.id for t in b.tracks} <= have]
        if not entries:
            return [(b, None, None)
                    for b in fresh[state["offset"]:state["offset"] + CARDS]]
        m = model()
        last = _anchor()
        cur = _block_by_id(last.block_id) if last.block_id else None
        if cur is None:
            cur = microsets.Block(id="_cur", parent="", tracks=[last.track])
        scored = []
        for b in fresh:
            if b is cur:
                continue
            score = microsets.compatibility(cur, b, state["valence_dir"], model=m)
            ev = m.set_evidence([t.id for t in cur.tracks],
                                [t.id for t in b.tracks]) if m else None
            scored.append((b, score, ev))
        scored.sort(key=lambda x: -x[1])
        return scored[state["offset"]:state["offset"] + CARDS]

    def _card_shell(border):
        return ui.column().classes("surface q-pa-sm gap-1").style(
            f"flex:1 1 0; min-width:0; overflow:hidden; border-color:{border}")

    def _render_track_card(s, top: bool):
        played = s.pair is not None and s.pair.confirmed
        t = s.track
        with _card_shell(TEAL if played else "#23262d"):
            with ui.row().classes("items-center justify-between no-wrap w-full"):
                ui.label(str(s.score)).classes("text-h6 text-weight-bold") \
                    .style(f"color:{_score_color(s.score)}")
                if s.badge:
                    _chip(s.badge, "#1d3a36" if played else "#2a2d35",
                          TEAL if played else "#9aa0a8")
            ui.label(t.display).classes("text-body2 ellipsis") \
                .style("width:100%; min-width:0").tooltip(t.display)
            with ui.row().classes("items-center gap-2 no-wrap wrap"):
                ui.badge(str(t.energy) if t.energy else "?").style(
                    f"background:{ENERGY_COLORS.get(t.energy or 0, '#888')}")
                if t.key:
                    _chip(t.key, camelot_color(t.key))
                if t.bpm:
                    ui.label(f"{round(t.bpm)}").classes("text-caption text-grey") \
                        .style("font-family:monospace")
            ui.label(s.reason).classes("text-caption ellipsis") \
                .style("color:#6b7280; width:100%; min-width:0").tooltip(s.reason)
            if t.path:
                audio_player(t.path, compact=True)
            ui.button("Pick", on_click=lambda t=t: pick(t)) \
                .props(("unelevated" if top else "outline")
                       + " dense no-caps size=sm color=primary").classes("w-full")

    def _render_block_card(ms, score, ev, top: bool):
        played = ev is not None and ev.confirmed
        dna = ms.dna
        with _card_shell(TEAL if played else "#23262d"):
            with ui.row().classes("items-center justify-between no-wrap w-full"):
                if score is None:
                    ui.label(ms.role or ms.id).classes("text-subtitle2 text-weight-bold")
                else:
                    ui.label(str(score)).classes("text-h6 text-weight-bold") \
                        .style(f"color:{_score_color(score)}")
                if played:
                    _chip(f"♥ {ev.confirmed} nights", "#1d3a36", TEAL)
                elif ms.role and score is not None:
                    _chip(ms.role, "#2a2d35", "#9aa0a8")
            ui.label(ms.name).classes("text-body2 ellipsis") \
                .style("width:100%; min-width:0").tooltip(ms.name)
            with ui.row().classes("items-center gap-2 wrap"):
                if dna["top_style"]:
                    _chip(dna["top_style"], "#2a2d35", "#cbd2da")
                for mood in dna["top_moods"][:2]:
                    _chip(mood, mood_color(mood))
            arc = energy_arc_svg([t.energy for t in ms.tracks if t.energy])
            if arc:
                ui.html(arc, sanitize=False)
            ui.label(f"{dna['count']} tracks · "
                     + (microsets.transition_label(
                         _block_by_id(state["entries"][-1].block_id)
                         or microsets.Block(id="_cur", parent="",
                                               tracks=[state["entries"][-1].track]), ms)
                        if state["entries"] else
                        f"{int(dna['bpm_range'][0])}-{int(dna['bpm_range'][1])} bpm")) \
                .classes("text-caption").style("color:#6b7280")
            ui.button(f"Add {ms.id}", on_click=lambda m=ms: add_block(m)) \
                .props(("unelevated" if top else "outline")
                       + " dense no-caps size=sm color=primary").classes("w-full")

    def render_companion_chips():
        comp_row.clear()
        comp_holder.clear()
        comps = _companions()
        # Name the count in the scope option, so "+ often gigged with" can't
        # look like it would do something when there's nothing to add.
        scope_radio.options = {
            "pool": "Pool only",
            "companions": (f"+ often gigged with ({len(comps)})" if comps
                           else "+ often gigged with (none)"),
            "library": "Whole library"}
        scope_radio.update()
        if not comps:
            return
        with comp_row:
            ui.label("often gigged with").classes("text-caption") \
                .style("color:#6b7280")
            for cid, share, label in comps:
                ui.button(f"＋ {label} · {share:.0%}",
                          on_click=lambda c=cid: add_to_pool(c)) \
                    .props("outline dense no-caps size=sm color=secondary") \
                    .tooltip("sourced the same nights as this pool (2+ shared "
                             "gigs) — click to add it")
        with comp_holder:
            ui.label("OFTEN GIGGED WITH").classes("text-caption text-weight-bold") \
                .style("color:#6b7280; letter-spacing:.08em")
            for cid, share, label in comps:
                ui.button(f"＋ {label} · {share:.0%}",
                          on_click=lambda c=cid: add_to_pool(c)) \
                    .props("outline dense no-caps size=sm color=secondary") \
                    .classes("w-full")

    # ----- the Blocks panel -----

    def render_blocks():
        block_cards.clear()
        sets = state["blocks"]
        blocks_stats.set_text(f"{len(sets)} blocks from {len(state['pool'])} tracks"
                              if sets else "")
        if not sets:
            return
        m = model()
        have = _set_ids()
        with block_cards:
            for ms in sets:
                dna = ms.dna
                emed = round(dna["energy_median"]) if dna["energy_median"] else 0
                with ui.card().classes("w-full surface").style(
                        f"border-left:4px solid {ENERGY_COLORS.get(emed, '#888')}"):
                    with ui.row().classes("items-center justify-between no-wrap w-full"):
                        with ui.row().classes("items-center gap-2 no-wrap"):
                            if ms.role:
                                ui.badge(ms.role).props("color=primary") \
                                    .classes("text-weight-bold") \
                                    .style("letter-spacing:.04em")
                            ui.label(ms.name).classes("text-subtitle1 text-weight-bold")
                        with ui.row().classes("items-center gap-2 no-wrap"):
                            arc = energy_arc_svg([t.energy for t in ms.tracks if t.energy])
                            if arc:
                                ui.html(arc, sanitize=False)
                            ui.button(icon="playlist_add",
                                      on_click=lambda m=ms: open_setline(m.tracks)) \
                                .props("flat dense round size=sm color=grey") \
                                .tooltip("send this block to a crate in Setline")
                            ui.button("＋ Add to set",
                                      on_click=lambda m=ms: add_block(m)) \
                                .props("outline dense no-caps size=sm color=primary")
                    with ui.row().classes("items-center gap-2 wrap"):
                        if dna["top_style"]:
                            _chip(dna["top_style"], "#2a2d35", "#cbd2da")
                        for mood in dna["top_moods"]:
                            _chip(mood, mood_color(mood))
                        for k in dna["keys"]:
                            _chip(k, camelot_color(k))
                        blo, bhi = int(dna["bpm_range"][0]), int(dna["bpm_range"][1])
                        ui.label(f"{blo} bpm" if blo == bhi else f"{blo}-{bhi} bpm") \
                            .classes("text-caption text-grey")
                        _br = [x.brightness for x in ms.tracks if x.brightness is not None]
                        _dy = [x.dynamic_complexity for x in ms.tracks
                               if x.dynamic_complexity is not None]
                        if _br:
                            ui.label(f"◐ {int(sum(_br) / len(_br))}Hz") \
                                .classes("text-caption").style("color:#e2c044")
                        if _dy:
                            ui.label(f"⇅ {sum(_dy) / len(_dy):.1f}") \
                                .classes("text-caption").style("color:#a78bfa")
                    # Picking rebuilds this whole panel, so the open/closed state
                    # has to be remembered outside it — you dig through a block
                    # a few tracks at a time, and having it snap shut under you
                    # after every pick made that the one thing it couldn't do.
                    with ui.expansion(f"{dna['count']} tracks — pick them one by one",
                                      icon="queue_music",
                                      value=ms.id in view["open_blocks"],
                                      on_value_change=lambda e, b=ms.id:
                                          _toggle_block(b, e.value)).classes("w-full"):
                        for i, t in enumerate(ms.tracks):
                            picked = t.id in have
                            # A row is four lines tall (name, chips, scales,
                            # texture), so without a band behind every other one
                            # you can't see where one track stops and the next
                            # starts.
                            with ui.row().classes("items-center gap-2 no-wrap w-full "
                                                  "q-px-sm").style(
                                    "border-radius:6px" + ("; background:"
                                    "rgba(255,255,255,.03)" if i % 2 else "")):
                                with ui.column().classes("flex-grow") \
                                        .style("min-width:0"
                                               + ("; opacity:.4" if picked else "")):
                                    render_track_row(t)
                                # Same word and same button as the search rows and
                                # the suggestion cards: adding one track looks the
                                # same wherever you happen to be looking at one.
                                if picked:
                                    ui.button("In set", icon="check") \
                                        .props("flat dense no-caps size=sm color=grey "
                                               "disable").style("min-width:96px")
                                else:
                                    ui.button("Pick", on_click=lambda t=t, m=ms: (
                                        add_track(t, m), render_all())) \
                                        .props("outline dense no-caps size=sm "
                                               "color=primary").style("min-width:96px")
                    nxt = microsets.next_up(ms, sets, k=3,
                                            valence_dir=state["valence_dir"], model=m)
                    if nxt:
                        with ui.row().classes("items-center gap-2 wrap"):
                            ui.label("next →").classes("text-caption text-grey")
                            for nb, score in nxt:
                                ev = m.set_evidence([t.id for t in ms.tracks],
                                                    [t.id for t in nb.tracks]) if m else None
                                label = (f"{nb.id} · {microsets.transition_label(ms, nb)} "
                                         f"({score})")
                                if ev is not None and ev.confirmed:
                                    ui.badge(f"♥ {label}") \
                                        .props("outline color=secondary") \
                                        .tooltip("you played a transition between these "
                                                 f"blocks on {ev.confirmed} nights")
                                else:
                                    ui.badge(label).props("outline color=primary")

    # ==================================================================
    # export
    # ==================================================================

    def do_export(what: str):
        """`what` = set | blocks | both.

        The two deliverables are genuinely different: an ordered set to play,
        and the pool's clustering as a navigable crate to improvise from. Both
        go to the one rekordbox import file.
        """
        entries, pool = state["entries"], state["pool"]
        if what in ("blocks", "both"):
            ensure_clustered()
        playlists, pool_tracks = [], list(pool)

        if what in ("set", "both") and entries:
            ordered, seen = [], set()
            for e in entries:                      # unique tracks, play order
                if e.track.id not in seen:
                    seen.add(e.track.id)
                    ordered.append(e.track)
            playlists.append(("Set", [t.id for t in ordered]))
            for i, (block_id, run) in enumerate(microsets.set_runs(entries), 1):
                playlists.append((microsets.run_label(block_id, run, i),
                                  [e.track.id for e in run]))
            for t in ordered:                      # picks may sit outside the pool
                if all(p.id != t.id for p in pool_tracks):
                    pool_tracks.append(t)

        if what in ("blocks", "both") and state["blocks"]:
            playlists.append(("All", [t.id for t in pool]))
            for i, ms in enumerate(state["blocks"], 1):
                playlists.append((f"Block {i} · {ms.role}" if ms.role
                                  else f"Block {i}", [t.id for t in ms.tracks]))

        if not playlists:
            ui.notify("Nothing to export yet", type="warning")
            return
        # The collection carries only what the emitted playlists reference —
        # exporting a 40-track set out of an 80-track pool shouldn't drop 40
        # orphan entries into rekordbox's xml view.
        referenced = {tid for _, ids in playlists for tid in ids}
        pool_tracks = [t for t in pool_tracks if t.id in referenced]
        colors = None
        if col_cb.value:
            colors = {t.id: c for t in pool_tracks
                      if (c := microsets.color_for_energy(t.energy)) is not None}
        out = str(runtime.export_path())
        folder_name = state["pool_name"] or "Build"
        rekordbox_io.export_folder(out, folder_name,
                                      pool_tracks, playlists, track_colors=colors)
        with_files = sum(1 for t in pool_tracks if t.path)
        export_handoff(
            out,
            f"{len(playlists)} playlists · {with_files} tracks with files",
            f"the “{folder_name}” folder",
            re_export=lambda: do_export(what),
            on_reloaded=lambda: (build_tree(), _reload_pool()))

    # ==================================================================
    # analyze the pool in place
    # ==================================================================

    job_holder = {"job": None}

    def _tick():
        job = job_holder["job"]
        if not job:
            return

        def _update():
            analyze_prog.value = job.fraction
            analyze_lbl.set_text(
                f"{job.done}/{job.total}  ·  {job.current[:50]}"
                + (f"  ·  {len(job.errors)} errors" if job.errors else ""))
        runtime._safe_ui(_update)

    def _reload_pool():
        """Re-read the current source after tags changed."""
        if state["pool_ids"]:
            on_tick(state["pool_ids"])
        elif state["node_id"]:
            select_node(state["node_id"])
        elif state["batch_name"]:
            select_batch(state["batch_name"])

    async def do_analyze():
        ids = _selected_ids()
        if not ids and not state["batch_name"]:
            ui.notify("Pick a playlist or batch first", type="warning")
            return
        job = job_holder["job"]
        if job and job.running:
            ui.notify("Analysis already running", type="warning")
            return
        if ids:
            seen, tracks = set(), []
            for pid in ids:
                _, combined, _ = _node_source_tracks(pid)
                for t in combined:
                    if t.local_path and id(t) not in seen:
                        seen.add(id(t))
                        tracks.append(t)
        else:
            tracks = [t for t in runtime.download_batches.get(state["batch_name"], [])
                      if t.local_path]
        if not tracks:
            ui.notify("No local files in this pool to analyze", type="warning")
            return
        job = AnalysisJob(force=force_cb.value, rich=rich_cb.value)
        job_holder["job"] = job
        analyze_btn.props("loading")
        cancel_btn.classes(remove="hidden")
        analyze_prog.classes(remove="hidden")
        timer = ui.timer(0.4, _tick)
        ui.notify(f"Analyzing {len(tracks)} tracks in {state['pool_name']}…")
        try:
            await run.io_bound(job.run, tracks)
        finally:
            timer.deactivate()

        def _finish():
            analyze_btn.props(remove="loading")
            cancel_btn.classes("hidden")
            analyze_prog.classes("hidden")
            ui.notify(
                f"Tagged {job.tagged}"
                + (f", {len(job.errors)} errors" if job.errors else "")
                + (" (cancelled)" if job.cancelled else ""),
                type="positive" if not job.errors else "warning")
            _reload_pool()
        runtime._safe_ui(_finish)

    def cancel_analyze():
        job = job_holder["job"]
        if job:
            job.cancel()
            ui.notify("Cancelling after current track…")

    # ==================================================================
    # boot
    # ==================================================================

    def build_tree():
        tree_holder.clear()
        nodes = runtime.library.playlist_tree_nodes()
        if not nodes:
            with tree_holder:
                # Distinguish "never set up" from "not loaded this session" —
                # a first-timer needs Settings, not the Library reload button.
                if load_studio_state().get("rekordbox"):
                    ui.label("Load rekordbox first (Library tab)") \
                        .classes("text-caption text-grey")
                else:
                    ui.label("No rekordbox library yet.") \
                        .classes("text-caption text-grey")
                    ui.link("Set up rekordbox in Settings →", "/settings") \
                        .classes("text-caption")
            return
        with tree_holder:
            # "strict": each node ticks independently — a folder is one pool
            # entry, already expanded to its descendants by tracks_in_playlist.
            tree = ui.tree(nodes, label_key="label", node_key="id",
                           tick_strategy="strict",
                           on_select=lambda e: select_node(e.value),
                           on_tick=lambda e: on_tick(e.value)).classes("w-full")
            tree.props("dense no-connectors")
            view["tree"] = tree

    def select_gig(day, from_crates=False):
        """Seed from a played night — either the tracks it used, or the crates
        it drew them from (Histories offers both)."""
        st = runtime.load_history()
        g = next((x for x in st["gigs"] if x.day == day), None)
        if not g:
            ui.notify(f"No gig on {day}", type="warning")
            return
        if from_crates:
            by_path = _paths_map()
            ranked = [(nid, src.share)
                      for src in history.gig_sources(g, st["membership"])
                      if (nid := by_path.get(src.path))]
            ids = [nid for nid, _ in mixmodel.drop_covered(
                runtime.library.rekordbox_index, [], ranked)[:3]]
            if not ids:
                ui.notify("That gig's playlists aren't in the loaded tree",
                          type="warning")
                return
            state["pool_ids"] = ids
            _sync_ticks()
            on_tick(ids)
            return
        ids = {t.track_id for t in g.tracks}
        tracks = [t for t in runtime.library.tracks if t.rekordbox_id in ids]
        if not tracks:
            ui.notify("Those tracks aren't in the loaded library", type="warning")
            return
        _load_pool(g.label, tracks, title=f"♬ {g.label} — played set")

    async def load_model():
        """Learn from play history in the background, then re-render so the
        ♥ evidence and companion chips appear without delaying page open."""
        if runtime.mix_state["model"] is None:
            await run.io_bound(runtime.mix_model)
        runtime._safe_ui(render_all)

    def restore_session():
        """Redraw the session this page function just inherited.

        A query param is an explicit request for a different pool and wins;
        otherwise a revisit picks up exactly where the last one left off,
        ticks and all.
        """
        if state["title"]:
            title_lbl.set_text(state["title"])
        scope_radio.set_value(state["scope"])
        _sync_ticks()
        _render_dl_banner(state["n_dl"])
        render_all()

    build_tree()
    restore_autosave()
    restore_session()
    if batch:
        select_batch(batch)
    elif node:
        select_node(node)
    elif gig:
        select_gig(gig, from_crates=bool(crates))
    ui.timer(0.1, load_model, once=True)
