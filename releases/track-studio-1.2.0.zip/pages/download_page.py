"""Download page (`/download`) — get a track from anywhere into the library.

Three ways in, because tracks arrive three ways:

- **A link — or a name.** One field, source-detecting: a Beatport track/release
  URL goes through your beatportdl subscription, any other link through yt-dlp
  (YouTube, SoundCloud, ~1800 sites), and anything that isn't a link at all is
  searched on Beatport, whose catalog answers "that track I half-remember" far
  better than yt-dlp can. All three show what you're getting *before* the
  download — quality for streams, the tracklist for a release, the hits to pick
  from for a search, and for every one of them whether you already own it.
- **A set from Setline.** The shared planner's export: matched against the
  library, the missing tracks fetched from Beatport, then exported to rekordbox
  or saved as a Build draft — all of it, or the slice you filter it down to
  (some moments, someone's picks) (see `setline_import.py`).
- **Your Downloads folder.** Free-download gates, Bandcamp, promo mail and
  WeTransfer all end the same way: a file in `~/Downloads` with whatever name
  the artist gave it. The inbox lists those, guesses artist/title, and files
  them into the library in one click (see `inbox.py`).

Everything lands in the shared download root under a per-source subfolder, gets
ingested into the library, and is analyzed from Library → Downloads — the same
rails whichever way it arrived.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from nicegui import run, ui

import bpdl
import drafts
import dupes
import inbox
import rekordbox_io
import runtime
import setline_import
import ytdl
from export_ui import export_handoff
from shell import apply_theme, header, settings_dialog

# How many inbox files to show before "show all" — a Downloads folder is a
# midden, and the track you just grabbed is at the top.
INBOX_PREVIEW = 12

# A link has no spaces and carries either a scheme or a dotted host. Anything
# else in that field is a track someone typed from memory, and the one thing
# that must never happen to it is being handed to yt-dlp as a URL.
_URLISH = re.compile(r"^(?:[a-z][a-z0-9+.\-]*://|www\.)"
                     r"|^[\w\-]+(?:\.[\w\-]+)+(?:[/?#]|$)", re.IGNORECASE)


def _looks_like_url(text: str) -> bool:
    text = (text or "").strip()
    return " " not in text and bool(_URLISH.match(text))


def _fmt_duration(secs) -> str:
    if not secs:
        return "—"
    m, s = divmod(int(secs), 60)
    return f"{m}:{s:02d}"


def _filter_chip(text: str, on: bool, color: str, handler) -> None:
    """A clickable pill for the Setline filters, lit when it's in effect.

    The colour is passed as a hex, which `ui.chip` writes as an inline style —
    a Quasar colour name would land as a `bg-*` class, and those are `!important`,
    so the unlit half of the pair could never be hollowed out.
    """
    ui.chip(text, color=color if on else "transparent",
            text_color="#fff" if on else color, on_click=handler) \
        .props("dense size=sm") \
        .style("font-weight:600" if on else f"border:1px solid {color}66")


def _cover(url: Optional[str]) -> None:
    """A 48px sleeve — or a hole the same size, so a list of hits stays a column.

    A missing cover that renders as nothing shunts every badge on its row left,
    which is worse than the blank it was trying to avoid.
    """
    if url:
        ui.image(url).classes("rounded") \
            .style("width:48px; height:48px; object-fit:cover; flex:none")
    else:
        ui.element("div").classes("rounded") \
            .style("width:48px; height:48px; flex:none; background:#1e2127")


def _quality(mi: ytdl.MediaInfo) -> tuple[str, str]:
    """(label, quasar-color) for the audio-quality badge, colored by bitrate."""
    abr = mi.abr
    codec = (mi.acodec or "").split(".")[0] or "?"
    if not abr:
        return f"{codec} · ? kbps", "grey-7"
    label = f"{codec} · {abr:.0f} kbps"
    if abr >= 256:
        return label, "positive"
    if abr >= 128:
        return label, "warning"
    return label, "negative"


@ui.page("/download")
def download_page():
    apply_theme()
    header("Download")
    # rows: {kind: "media"|"beatport", mi|bt, title_in, artist_in, have}
    # have: dict path-string -> dupes.Existing, for the inbox listing
    # Per-visit only — the dropped Setline set outlives the visit and lives in
    # `runtime.setline_state` instead.
    # picked: row indexes ticked in a search — a menu you choose from, unlike a
    # link, which already said which tracks it meant.
    state = {"rows": [], "kind": None, "picked": set(), "inbox": [],
             "show_all": False, "filter": "", "checked": set(), "have": {}}

    with ui.column().classes("w-full p-4 gap-4") \
            .style("max-width:56rem; margin:auto") as page_col:
        ui.label("Download").classes("text-h6")
        ui.label("Paste a Beatport, YouTube or SoundCloud link — or just type a "
                 "track and search Beatport. Or pick up a file you already "
                 "downloaded in the browser, below.") \
            .classes("text-caption text-grey")

        with ui.row().classes("items-center gap-2 w-full"):
            url_in = ui.input("Paste a link, or type an artist and title",
                              on_change=lambda e: sync_fetch_btn(e.value)) \
                .props("outlined dense clearable").classes("flex-grow")
            url_in.on("keydown.enter", lambda: fetch())
            fetch_btn = ui.button("Fetch info", icon="search",
                                  on_click=lambda: fetch()) \
                .props("unelevated color=primary")

        with ui.row().classes("items-center gap-2 w-full"):
            ui.icon("download").classes("text-grey")
            dest_lbl = ui.label("").classes("text-caption text-grey")
            ui.button(icon="settings", on_click=lambda: settings_dialog()) \
                .props("flat dense round size=sm color=grey") \
                .tooltip("Settings (download root, inbox folder)")

        with ui.row().classes("items-center gap-2 w-full"):
            dl_btn = ui.button("Download", icon="cloud_download",
                               on_click=lambda: do_download()) \
                .props("unelevated color=primary")
            dl_btn.set_visibility(False)
            have_lbl = ui.label("").classes("text-caption") \
                .style("color:#d29922")
        results = ui.column().classes("w-full gap-2")

        # ---------------- a set from Setline ----------------
        ui.separator().props("color=grey-9").classes("q-mt-md")
        with ui.row().classes("items-center justify-between w-full no-wrap"):
            with ui.column().classes("gap-0"):
                ui.label("A SET FROM SETLINE") \
                    .classes("text-caption text-weight-bold") \
                    .style("color:#6b7280; letter-spacing:.08em")
                ui.label("In Setline: Export → Set file for Track Studio. Drop the file "
                         "here to see what you already have, fetch the rest from "
                         "Beatport, then send it to rekordbox or save it as a Build "
                         "draft — the whole set, or just the moments and the picks "
                         "you're preparing.") \
                    .classes("text-caption").style("color:#6b7280")
        ui.upload(label="Drop a .setline.json file", auto_upload=True, max_files=1,
                  on_upload=lambda e: load_setline(e)) \
            .props('accept=".json,application/json" flat bordered') \
            .classes("w-full")
        setline_col = ui.column().classes("w-full gap-1")

        # ---------------- inbox ----------------
        ui.separator().props("color=grey-9").classes("q-mt-md")
        with ui.row().classes("items-center justify-between w-full no-wrap"):
            with ui.column().classes("gap-0"):
                ui.label("FROM YOUR DOWNLOADS FOLDER") \
                    .classes("text-caption text-weight-bold") \
                    .style("color:#6b7280; letter-spacing:.08em")
                inbox_lbl = ui.label("").classes("text-caption") \
                    .style("color:#6b7280")
            with ui.row().classes("items-center gap-2"):
                inbox_filter = ui.input(placeholder="filter…",
                                        on_change=lambda e: set_filter(e.value)) \
                    .props("dense outlined clearable").style("width:170px")
                ui.button(icon="refresh", on_click=lambda: refresh_inbox()) \
                    .props("flat dense round size=sm color=grey") \
                    .tooltip("Re-scan the folder and re-check it against the library")
                import_btn = ui.button("Import", icon="library_add",
                                       on_click=lambda: do_import()) \
                    .props("unelevated dense no-caps size=sm color=primary")
                import_btn.set_visibility(False)
        inbox_col = ui.column().classes("w-full gap-0")

    # ==================================================================
    # notifications, anchored to the page
    # ==================================================================
    # A notification is an element like any other, and NiceGUI runs a handler in
    # the *sender's* parent slot — so a spinner started from a button inside a
    # list belongs to that list. The Setline handlers re-render their own list
    # mid-job, and `setline_col.clear()` was quietly taking the spinner with it:
    # the message vanished after a second and the result, created in a dead
    # slot, never reached the browser at all. Anchored to the page column, a
    # message outlives the thing that was clicked to produce it.

    def toast(*args, **kwargs):
        with page_col:
            return ui.notify(*args, **kwargs)

    def spinner(message: str):
        with page_col:
            return ui.notification(message, spinner=True, timeout=None)

    def later(fn) -> None:
        """Kick an async refresh from a sync callback, anchored the same way."""
        with page_col:
            ui.timer(0.05, fn, once=True)

    # ==================================================================
    # link downloads
    # ==================================================================

    def sync_fetch_btn(value=None) -> None:
        """Say which of the two things Enter will do, before it's pressed."""
        text = (value or "").strip()
        fetch_btn.text = ("Search Beatport" if text and not _looks_like_url(text)
                          else "Fetch info")

    def _dest() -> Path:
        """Where downloads land: <root>/<Beatport|YouTube|SoundCloud>."""
        if state["kind"] in ("beatport", "search"):
            return runtime._dl_root() / "Beatport"
        src = state["rows"][0]["mi"].source if state["rows"] else "web"
        sub = {"youtube": "YouTube", "soundcloud": "SoundCloud"}.get(src, "Downloads")
        return runtime._dl_root() / sub

    def update_dest() -> None:
        dest_lbl.set_text(f"Downloads → {_dest()}" if state["rows"]
                          else f"Download root → {runtime._dl_root()}")

    def _mark_have(rows) -> None:
        """Tag each fetched row with the library track it looks like, if any.

        Runs before anything is downloaded — the whole point is to say "you own
        this" while it's still a decision. Never blocks the download: replacing a
        128 kbps rip with lossless is a real reason to fetch a second copy.
        """
        idx = dupes.Index(runtime.library.tracks)
        for r in rows:
            if r["kind"] == "beatport":
                bt = r["bt"]
                # Beatport hands us the ISRC, so this is an identity check, not
                # a guess — the mix name rides along for the fuzzy fallback.
                r["have"] = idx.lookup(", ".join(bt.artists),
                                       f"{bt.name} {bt.mix_name}".strip(),
                                       isrc=bt.isrc)
            else:
                mi = r["mi"]
                r["have"] = idx.lookup(mi.artist, mi.title)

    def _have_badge(row) -> None:
        """The 'you already have this' chip, if the row matched something."""
        have = row.get("have")
        if not have:
            return
        ui.badge(have.chip) \
            .props("color=warning" if have.certain else "color=grey-7") \
            .tooltip(have.detail)

    def pick_row(idx: int, on: bool) -> None:
        state["picked"].add(idx) if on else state["picked"].discard(idx)
        sync_dl_btn()

    def sync_dl_btn() -> None:
        """The Download button. A search downloads what's ticked, a link its lot."""
        rows = state["rows"]
        if state["kind"] == "search":
            n = len(state["picked"])
            dl_btn.text = f"Download {n}" if n else "Download"
            dl_btn.set_enabled(bool(n))
            return
        dl_btn.text = f"Download {len(rows)}" if len(rows) > 1 else "Download"
        dl_btn.set_enabled(True)

    def render_results() -> None:
        results.clear()
        rows = state["rows"]
        dl_btn.set_visibility(bool(rows))
        sync_dl_btn()
        n_have = sum(1 for r in rows if r.get("have"))
        if state["kind"] == "search":
            have_lbl.set_text(
                f"{len(rows)} on Beatport — tick what you want"
                + (f"  ·  {n_have} already in your library" if n_have else ""))
        else:
            have_lbl.set_text(
                f"{n_have} of {len(rows)} already in your library"
                if n_have and len(rows) > 1
                else ("you already have this one" if n_have else ""))
        update_dest()
        with results:
            for i, row in enumerate(rows):
                if row["kind"] == "beatport":
                    _render_beatport_row(row, i)
                else:
                    _render_media_row(row)

    def _render_media_row(row) -> None:
        mi = row["mi"]
        qlabel, qcolor = _quality(mi)
        with ui.card().classes("w-full surface").props("flat"):
            with ui.row().classes("items-center w-full no-wrap gap-3"):
                _cover(mi.thumbnail)
                ui.badge(mi.source).props("color=grey-8")
                ui.badge(qlabel).props(f"color={qcolor}")
                _have_badge(row)
                ui.label(_fmt_duration(mi.duration)).classes("text-caption text-grey")
                ui.space()
                if mi.filesize:
                    ui.label(f"~{mi.filesize / 1e6:.1f} MB") \
                        .classes("text-caption text-grey")
                ui.link("open ↗", mi.url, new_tab=True).classes("text-caption")
            with ui.row().classes("items-center w-full no-wrap gap-2"):
                row["artist_in"] = ui.input("Artist", value=mi.artist) \
                    .props("outlined dense").classes("flex-grow")
                row["title_in"] = ui.input("Title", value=mi.title) \
                    .props("outlined dense").classes("flex-grow")
            if mi.raw_title and mi.raw_title != mi.title:
                ui.label(f"source: {mi.raw_title}").classes("text-caption text-grey")

    def _render_beatport_row(row, idx: int) -> None:
        """A Beatport hit. Artist/title aren't editable here: beatportdl writes
        the store's own tags, which are canonical — unlike a scraped video title.

        A search's rows tick and link out: twelve near-identical remixes is
        exactly the moment you want to hear one on Beatport before buying it.
        """
        bt, searching = row["bt"], state["kind"] == "search"
        with ui.card().classes("w-full surface").props("flat"):
            with ui.row().classes("items-center w-full no-wrap gap-3"):
                if searching:
                    ui.checkbox(value=idx in state["picked"],
                                on_change=lambda e, i=idx: pick_row(i, e.value)) \
                        .props("dense")
                _cover(bt.artwork())
                ui.badge("beatport").props("color=grey-8")
                _have_badge(row)
                ui.label(bt.display).classes("flex-grow ellipsis") \
                    .style("min-width:0")
                if bt.key:
                    ui.badge(bt.key).props("color=grey-8")
                if bt.bpm:
                    ui.label(f"{bt.bpm}").classes("text-caption text-grey") \
                        .style("font-family:monospace")
                ui.label(_fmt_duration((bt.length_ms or 0) / 1000)) \
                    .classes("text-caption text-grey")
                if searching:
                    ui.link("open ↗", bt.url, new_tab=True).classes("text-caption")

    async def fetch():
        query = (url_in.value or "").strip()
        if not query:
            toast("Paste a link, or type a track to search Beatport",
                  type="warning")
            return
        typed = not _looks_like_url(query)
        fetch_btn.props("loading")
        n = spinner(f"Searching Beatport for “{query}”…" if typed
                    else "Fetching info…")
        try:
            if bpdl.is_beatport_url(query):
                kind, tracks = await run.io_bound(bpdl.tracks_for_url, query)
                state["kind"] = "beatport"
                state["rows"] = [{"kind": "beatport", "bt": bt} for bt in tracks]
                if kind == "release":
                    toast(f"Release: {len(tracks)} tracks", type="info")
            elif typed:
                hits = await run.io_bound(bpdl.search_tracks, query)
                if not hits:
                    n.dismiss()
                    toast(f"Beatport has nothing for “{query}”. Try fewer words, "
                          "or paste a YouTube/SoundCloud link instead.",
                          type="warning", timeout=9000)
                    return
                state["kind"] = "search"
                state["rows"] = [{"kind": "beatport", "bt": bt} for bt in hits]
            else:
                infos = await run.io_bound(ytdl.probe, query)
                if not infos:
                    n.dismiss()
                    toast("No tracks found at that URL", type="warning")
                    return
                state["kind"] = "media"
                state["rows"] = [{"kind": "media", "mi": mi,
                                  "title_in": None, "artist_in": None}
                                 for mi in infos]
        except Exception as e:
            n.dismiss()
            toast(f"Couldn't search Beatport: {e}" if typed
                  else f"Couldn't read that URL: {e}",
                  type="negative", timeout=8000)
            return
        finally:
            fetch_btn.props(remove="loading")
        # Indexing the library is a pass over every track — off the event loop,
        # and never fatal: a failed check must not cost you the fetched result.
        try:
            await run.io_bound(_mark_have, state["rows"])
        except Exception as e:
            print(f"[download] duplicate check failed: {e!r}")
        state["picked"] = set()      # a new result set, none of it chosen yet
        n.dismiss()
        render_results()

    async def do_download():
        rows = state["rows"]
        if state["kind"] == "search":
            rows = [r for i, r in enumerate(rows) if i in state["picked"]]
            if not rows:
                toast("Tick the ones you want first", type="warning")
                return
        if not rows:
            return
        dest = _dest()
        dest.mkdir(parents=True, exist_ok=True)
        if state["kind"] == "media":
            await _download_media(rows, dest)
        else:
            await _download_beatport(rows, dest)

    async def _download_beatport(rows, dest: Path):
        ids = [r["bt"].id for r in rows]
        n = ui.notification(f"Downloading {len(ids)} from Beatport…",
                            spinner=True, timeout=None)
        try:
            new_files, log = await run.io_bound(bpdl.download, ids, dest)
        except Exception as e:
            n.dismiss()
            ui.notify(f"Beatport download failed: {e}", type="negative", timeout=9000)
            return
        _ingest(new_files)
        _verify_arrivals(new_files)

        def _finish():
            n.dismiss()
            if new_files:
                ui.notify(f"Downloaded {len(new_files)} → {dest}. Analyze them "
                          f"under Library → Downloads, then export.",
                          type="positive", timeout=12000)
            else:
                ui.notify(f"Nothing downloaded. {bpdl.failure_reason(log)}",
                          type="negative", timeout=15000)
        runtime._safe_ui(_finish)

    async def _download_media(rows, dest: Path):
        entries = [{"url": r["mi"].url,
                    "title": (r["title_in"].value or "").strip(),
                    "artist": (r["artist_in"].value or "").strip()} for r in rows]
        # Live progress: the worker (in run.io_bound) writes plain fields into
        # `prog`; this timer, on the main loop, renders them — the thread-safe
        # split the Sync/analysis jobs use.
        prog = {"done": 0, "total": len(entries), "frac": 0.0, "label": ""}
        n = ui.notification("Downloading…", spinner=True, timeout=None)

        def _render():
            pct = f"  ·  {prog['frac'] * 100:.0f}%" if prog["frac"] else ""
            cur = f"  ·  {prog['label'][:46]}" if prog["label"] else ""
            n.message = f"Downloading {prog['done']}/{prog['total']}{pct}{cur}"
        timer = ui.timer(0.3, _render)

        def _on_prog(done, total, frac, label):
            prog.update(done=done, total=total, frac=frac, label=label)

        try:
            new_files, log = await run.io_bound(ytdl.download, entries, dest, _on_prog)
        except Exception as e:
            timer.deactivate()
            n.dismiss()
            ui.notify(f"Download error: {e}", type="negative", timeout=8000)
            return
        timer.deactivate()
        _ingest(new_files)
        _verify_arrivals(new_files)      # yt-dlp remuxes too

        def _finish():
            n.dismiss()
            if new_files:
                ui.notify(
                    f"Downloaded {len(new_files)} → {dest}. Analyze them under "
                    f"Library → Downloads, then export."
                    + (f"  ({len(entries) - len(new_files)} failed)"
                       if len(new_files) < len(entries) else ""),
                    type="positive", timeout=12000)
            else:
                ui.notify(f"No files downloaded. {log[:200]}",
                          type="negative", timeout=10000)
        runtime._safe_ui(_finish)

    def _ingest(paths) -> None:
        """Fold freshly-arrived files into the in-memory library + batch list."""
        from library import track_from_file
        runtime.library.tracks.extend(track_from_file(p) for p in paths)
        runtime.refresh_batches()

    def _verify_arrivals(paths) -> None:
        """Packet-check what just landed, and say so if the audio isn't continuous.

        Seconds on a handful of files, against a set that falls apart on stage.
        A store download is always clean, so anything this finds means the file
        came down some other way — which is worth knowing at the moment it
        arrives, not the night you play it. Never fatal: the file is kept either
        way, because a false alarm must not cost you a download.
        """
        import integrity
        try:
            bad = integrity.verify_downloads(paths)
        except Exception as e:
            print(f"[download] integrity check failed: {e!r}")
            return
        if not bad:
            return
        worst = bad[0]
        toast(f"⚠ {len(bad)} of {len(paths)} downloaded file(s) have discontinuous "
              f"audio — “{worst.path.name}”: {worst.summary}. The beatgrid will "
              "drift; re-download or check Library → Check for problems.",
              type="warning", timeout=20000)

    # ==================================================================
    # a set from Setline — see setline_import.py
    # ==================================================================

    STATUS_BADGE = {
        setline_import.HAVE: ("in library", "positive"),
        setline_import.POSSIBLE: ("check match", "grey-7"),
        setline_import.FETCH: ("to download", "primary"),
        setline_import.MANUAL: ("not on Beatport", "warning"),
    }

    # The dropped set lives in `runtime.setline_state`, not here: see
    # `runtime.new_setline_session`. `sl` is a plain alias for the same dict —
    # it's mutated, never rebound, so it can't go stale.
    sl = runtime.setline_state

    async def load_setline(e) -> None:
        raw = await e.file.read()
        e.sender.reset()
        try:
            export = setline_import.read(raw)
        except setline_import.ImportError_ as err:
            toast(str(err), type="negative", timeout=9000)
            return
        sl.update(runtime.new_setline_session())   # a new set, not a second one
        sl["export"] = export
        await replan_setline()

    def clear_setline() -> None:
        sl.update(runtime.new_setline_session())
        render_setline()

    async def replan_setline() -> None:
        export = sl["export"]
        if not export:
            return
        try:
            p = await run.io_bound(
                setline_import.plan, export, runtime.library.tracks)
        except Exception as err:
            toast(f"Couldn't check the set against the library: {err}",
                  type="negative", timeout=9000)
            return
        # The filter survives a re-plan: downloading the slice re-matches the
        # whole set against a library that grew, and you're still on that slice.
        p.keep_moments, p.keep_added_by = sl["moments"], sl["added_by"]
        sl["plan"] = p
        render_setline()

    def pick_setline(key: str, value: Optional[str], every: list[str]) -> None:
        """A filter chip: from "all", narrow to the one clicked; then add/remove.

        Clicking the last one off — or ticking every one — is the same thing as
        no filter, so both land back on "all" rather than on an empty set.
        """
        kept = sl[key]
        if value is None:
            kept = None
        else:
            kept = {value} if kept is None else set(kept) ^ {value}
            if not kept or kept == set(every):
                kept = None
        sl[key] = kept
        if sl["plan"]:
            sl["plan"].keep_moments, sl["plan"].keep_added_by = sl["moments"], sl["added_by"]
        render_setline()

    def setline_filter_row(label: str, key: str, options: list[str],
                           colors: Optional[dict] = None) -> None:
        """One line of chips — the moments, or the people who planned the set."""
        kept = sl[key]
        with ui.row().classes("items-center gap-1 w-full").style("flex-wrap:wrap"):
            ui.label(label).classes("text-caption text-grey").style("width:5rem")
            _filter_chip("All", kept is None, "#6b7280",
                         lambda: pick_setline(key, None, options))
            for o in options:
                color = (colors or {}).get(o) or "#ff7a1a"
                _filter_chip(o, kept is not None and o in kept, color,
                             lambda o=o: pick_setline(key, o, options))

    def render_setline() -> None:
        setline_col.clear()
        p = sl["plan"]
        if not p:
            return
        n_fetch, n_manual = p.count(setline_import.FETCH), p.count(setline_import.MANUAL)
        n_have, n_possible = p.count(setline_import.HAVE), p.count(setline_import.POSSIBLE)
        rows = p.selected
        moments, people = p.moment_names, p.contributors
        with setline_col:
            with ui.row().classes("items-center justify-between w-full q-mt-sm"):
                with ui.column().classes("gap-0"):
                    ui.label(p.name).classes("text-subtitle1 text-weight-bold")
                    ui.label(
                        (f"{len(rows)} of {len(p.rows)} tracks" if p.filtered
                         else f"{len(p.rows)} tracks")
                        + f" · starts {p.starts_at}  ·  {n_have} in the library"
                        + (f" · {n_possible} to check" if n_possible else "")
                        + (f" · {n_fetch} to download" if n_fetch else "")
                        + (f" · {n_manual} not on Beatport" if n_manual else "")) \
                        .classes("text-caption text-grey")
                with ui.row().classes("items-center gap-2"):
                    if n_fetch:
                        ui.button(f"Download {n_fetch} from Beatport", icon="cloud_download",
                                  on_click=lambda: fetch_setline()) \
                            .props("unelevated dense no-caps color=primary")
                    # The set arrived already programmed, so rekordbox is one
                    # click away — Build is for *re*-programming it, not a toll
                    # gate on the way out.
                    ui.button("Export to rekordbox", icon="ios_share",
                              on_click=lambda: export_setline()) \
                        .props("unelevated dense no-caps color=primary") \
                        .tooltip(f"Write the set in order to {runtime.export_path()}")
                    ui.button("Save as Build draft", icon="playlist_add_check",
                              on_click=lambda: save_setline_draft()) \
                        .props("outline dense no-caps color=primary")
                    ui.button(icon="close", on_click=lambda: clear_setline()) \
                        .props("flat dense round size=sm color=grey") \
                        .tooltip("Put this set away — the only thing that does, "
                                 "now that it survives leaving the page")
            # Only worth a filter when there's something to choose between: a
            # one-moment set or a set you planned alone gets no chips.
            if len(moments) > 1:
                setline_filter_row("Moment", "moments", moments, p.moment_colors)
            if len(people) > 1:
                setline_filter_row("Added by", "added_by", people)
            if not rows:
                ui.label("Nothing in this slice of the set.") \
                    .classes("text-caption text-grey q-mt-sm")
            # Name who picked each track only while that still tells them apart.
            credit = len({r.added_by for r in rows if r.added_by}) > 1
            current = None
            for r in rows:
                if r.moment != current:
                    current = r.moment
                    ui.label(current.upper() or "—").classes("text-caption text-weight-bold q-mt-sm") \
                        .style("color:#9aa0a8; letter-spacing:.06em")
                label, color = STATUS_BADGE[r.status]
                # A fetch that Beatport refused leaves the row "to download",
                # which invites the same click and the same nothing. Say so.
                failed = (sl["failed"].get(r.beatport_id)
                          if r.status == setline_import.FETCH else None)
                if failed:
                    label, color = "wouldn't download", "negative"
                with ui.row().classes("items-center gap-2 no-wrap w-full q-py-xs"):
                    ui.label(r.clock).classes("text-caption text-grey") \
                        .style("font-family:monospace; width:3.2rem")
                    badge = ui.badge(label).props(f"color={color}")
                    if failed:
                        badge.tooltip(failed)
                    elif r.have and r.status == setline_import.POSSIBLE:
                        badge.tooltip(r.have.detail)
                    ui.label(r.display).classes("flex-grow ellipsis").style("min-width:0")
                    if r.added_by and credit:
                        ui.label(r.added_by).classes("text-caption text-grey no-wrap")
                    if r.key:
                        ui.badge(r.key).props("color=grey-8")
                    if r.bpm:
                        ui.label(f"{r.bpm}").classes("text-caption text-grey") \
                            .style("font-family:monospace")
                    if r.status == setline_import.MANUAL and r.link:
                        ui.button(icon="open_in_new", on_click=lambda link=r.link: ui.navigate.to(link, new_tab=True)) \
                            .props("flat dense round size=sm color=grey").tooltip(r.link)

    async def fetch_setline() -> None:
        p = sl["plan"]
        if not p or not p.to_fetch:
            return
        ids = p.to_fetch
        dest = runtime._dl_root() / setline_import.batch_name(p.name)
        dest.mkdir(parents=True, exist_ok=True)
        n = spinner(f"Downloading {len(ids)} from Beatport…")
        try:
            new_files, log = await run.io_bound(bpdl.download, ids, dest)
        except Exception as err:
            n.dismiss()
            toast(f"Beatport download failed: {err}", type="negative", timeout=9000)
            return
        _ingest(new_files)
        _verify_arrivals(new_files)
        sl["batch"] = dest.name
        # Remember what the log blamed each id for. Only ids still wanting a
        # download read it back, so a line about one that did arrive is inert.
        sl["failed"].update(bpdl.failures_by_id(log))
        await replan_setline()
        still = sl["plan"].count(setline_import.FETCH) if sl["plan"] else 0

        def _finish():
            n.dismiss()
            if not new_files:
                toast(f"Nothing downloaded. {bpdl.failure_reason(log)}",
                      type="negative", timeout=15000)
            elif still:
                toast(f"Downloaded {len(new_files)} → {dest}. {still} still "
                      f"missing: {bpdl.failure_reason(log)}",
                      type="warning", timeout=15000)
            else:
                toast(f"Downloaded {len(new_files)} → {dest}. Export to rekordbox "
                      "now, or analyze them under Library → Downloads first.",
                      type="positive", timeout=12000)
        runtime._safe_ui(_finish)

    def export_setline() -> None:
        """The set — or the slice — straight to rekordbox's import file.

        Everything in it that's in the library with a file goes, tagged or not:
        an Energy tag is what Build needs to *program* a set, and this one came
        programmed.
        """
        p = sl["plan"]
        if not p:
            return
        tracks, playlists = setline_import.to_playlists(p)
        if not playlists:
            toast(f"None of {'this slice' if p.filtered else 'the set'}’s tracks are "
                  "in the library with a file yet — download the missing ones first.",
                  type="warning", timeout=9000)
            return
        out = str(runtime.export_path())
        folder = setline_import.export_name(p)
        rekordbox_io.export_folder(out, folder, tracks, playlists)
        n_set = len(playlists[0][1])
        left_out = len(p.selected) - n_set
        export_handoff(
            out,
            f"{len(playlists)} playlist(s) · {n_set} tracks in set order"
            + (f"  ·  {p.selection_label}" if p.filtered else ""),
            f"the “{folder}” folder",
            re_export=export_setline,
            note=(f"{left_out} of the set’s tracks aren’t in the library yet and "
                  "were left out." if left_out else ""),
            # Reloading rekordbox is what turns the freshly-imported tracks into
            # matches, so re-plan against it: the rows go green.
            on_reloaded=lambda: later(replan_setline))

    def save_setline_draft() -> None:
        p = sl["plan"]
        if not p:
            return
        d = setline_import.to_draft(p)
        if not d.entries:
            toast(f"None of {'this slice of the set' if p.filtered else 'the set'}’s tracks "
                  "are in the library with a BPM yet. Download them first "
                  "(and analyze if needed).", type="warning", timeout=9000)
            return
        drafts.save(d)
        left_out = len(p.selected) - len(d.entries)
        toast(f"Saved the Build draft “{d.name}” with {len(d.entries)} tracks in set order"
              + (f" ({left_out} not in the library yet)" if left_out else "")
              + ". Open it from Build → Drafts.", type="positive", timeout=12000)

    # ==================================================================
    # inbox — files that arrived via the browser
    # ==================================================================

    def _known_paths() -> set:
        return {str(t.local_path).lower() for t in runtime.library.tracks
                if t.local_path}

    async def refresh_inbox() -> None:
        """Re-scan the inbox, and check each file against what you already own.

        The scan's own `known` filter is by path, which catches only a file
        already sitting in the library folder — an import *moves* the file, so
        the copy you own is somewhere else entirely under a different name. That
        case is what the library check below is for.

        Both halves read files and walk the whole library, so they run off the
        event loop together: the page paints before the folder is read.
        """
        def _work():
            files = inbox.scan(known=_known_paths())
            idx = dupes.Index(runtime.library.tracks)
            have = {str(f.path): e for f in files
                    if (e := idx.lookup(f.artist, f.title))}
            return files, have

        try:
            state["inbox"], state["have"] = await run.io_bound(_work)
            state["error"] = ""
        except Exception as e:
            state["inbox"], state["have"] = [], {}
            state["error"] = str(e)
            print(f"[inbox] scan failed: {e!r}")
        state["checked"] = set()
        render_inbox()

    def set_filter(value) -> None:
        state["filter"] = (value or "").strip().lower()
        render_inbox()

    def _visible() -> list:
        q = state["filter"]
        files = [f for f in state["inbox"]
                 if not q or q in f.path.name.lower() or q in f.display.lower()]
        return files if state["show_all"] else files[:INBOX_PREVIEW]

    def toggle_check(path_str: str, on: bool) -> None:
        state["checked"].discard(path_str) if not on else state["checked"].add(path_str)
        import_btn.set_visibility(bool(state["checked"]))
        import_btn.text = f"Import {len(state['checked'])}"

    def render_inbox() -> None:
        inbox_col.clear()
        files, total = _visible(), len(state["inbox"])
        folder = inbox.default_folder()
        n_have = len(state["have"])
        inbox_lbl.set_text(
            f"{total} file(s) in {folder} not yet in the library"
            + (f"  ·  {n_have} you may already have" if n_have else "")
            if total else f"Nothing new in {folder}")
        import_btn.set_visibility(bool(state["checked"]))
        import_btn.text = f"Import {len(state['checked'])}"
        if state.get("error"):
            with inbox_col:
                with ui.row().classes("items-center gap-2 q-py-sm"):
                    ui.icon("lock").style("color:#d29922")
                    ui.label(state["error"]).classes("text-caption") \
                        .style("color:#d29922")
            return
        if not files:
            return
        with inbox_col:
            for f in files:
                key = str(f.path)
                with ui.row().classes("items-center gap-2 no-wrap w-full q-py-xs") \
                        .style("border-bottom:1px solid #1e2127"):
                    ui.checkbox(value=key in state["checked"],
                                on_change=lambda e, k=key: toggle_check(k, e.value)) \
                        .props("dense")
                    f.artist_in = ui.input(placeholder="Artist", value=f.artist) \
                        .props("outlined dense").style("width:200px")
                    f.title_in = ui.input(placeholder="Title", value=f.title) \
                        .props("outlined dense").classes("flex-grow") \
                        .style("min-width:0")
                    have = state["have"].get(key)
                    if have:
                        ui.badge(have.chip) \
                            .props("color=warning" if have.certain
                                   else "color=grey-7") \
                            .tooltip(have.detail)
                    ui.label(f"{f.size / 1e6:.0f} MB").classes("text-caption") \
                        .style("color:#6b7280; width:52px; text-align:right")
                    badge = ui.badge(f.ext.lstrip("."))
                    badge.props("color=grey-8" if f.taggable else "color=warning")
                    if not f.taggable:
                        badge.tooltip("the analyzer writes .mp3/.m4a only — this "
                                      "will import but can't carry an Energy tag")
                    if f.from_tags:
                        ui.icon("sell").classes("text-caption") \
                            .style("color:#2dd4bf").tooltip("names read from the "
                                                            "file's own tags")
            if total > len(files) and not state["show_all"]:
                ui.button(f"Show all {total}",
                          on_click=lambda: (state.update(show_all=True),
                                            render_inbox())) \
                    .props("flat dense no-caps size=sm color=grey")

    async def do_import():
        picked = [f for f in state["inbox"] if str(f.path) in state["checked"]]
        if not picked:
            return
        root = runtime._dl_root()
        edits = [(f, (getattr(f, "artist_in", None).value if getattr(f, "artist_in", None) else f.artist),
                  (getattr(f, "title_in", None).value if getattr(f, "title_in", None) else f.title))
                 for f in picked]

        def _work():
            done, errors = [], []
            for f, artist, title in edits:
                try:
                    done.append(inbox.import_file(f, root, artist, title))
                except Exception as e:
                    errors.append(f"{f.path.name}: {e}")
            return done, errors

        n = ui.notification(f"Importing {len(picked)}…", spinner=True, timeout=None)
        moved, errors = await run.io_bound(_work)
        _ingest(moved)
        n.dismiss()
        await refresh_inbox()
        if moved:
            ui.notify(f"Imported {len(moved)} → {root / inbox.IMPORT_FOLDER}. "
                      f"Analyze them under Library → Downloads."
                      + (f"  ({len(errors)} failed)" if errors else ""),
                      type="positive" if not errors else "warning", timeout=12000)
        else:
            ui.notify(f"Nothing imported. {errors[0] if errors else ''}",
                      type="negative", timeout=9000)

    update_dest()
    # A set dropped on an earlier visit paints back immediately from its last
    # match, then re-matches: the trip this page sends you on — download here,
    # analyze under Library, come back — is exactly the one that grows the
    # library, so the statuses you left behind are the ones most likely stale.
    if sl["plan"]:
        render_setline()
    if sl["export"]:
        ui.timer(0.05, replan_setline, once=True)
    # The scan reads tags and indexes the library, so the page opens on a
    # placeholder rather than waiting on it.
    inbox_lbl.set_text("Scanning your downloads folder…")
    ui.timer(0.05, refresh_inbox, once=True)
