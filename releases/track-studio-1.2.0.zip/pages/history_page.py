"""Histories page (`/history`) — the sets you actually played.

Every other page in this app pushes tracks *towards* rekordbox. This one reads
back out of it: `history.py` reconstructs real performances from rekordbox's
play log, and this renders them — the BPM shape of the night, where the harmonic
mixing held, and which playlists the night was drawn from.

Three things a gig can then feed back into the rest of the app: export it as a
playlist (nested under the playlist it mostly came from, so it lands where it
belongs instead of at the root), analyze its energy, or build a new set from it.

The rejected sessions stay one click away on purpose. Classification is a
threshold on harmonic adjacency, and a threshold is only trustworthy if you can
see what it threw away.
"""
from __future__ import annotations

from pathlib import Path
from urllib.parse import quote

from nicegui import run, ui

import history
import rekordbox_io
import runtime
from analysis import AnalysisJob
from export_ui import export_handoff
from microsets import _camelot_distance
from shell import apply_theme, header
from widgets import ENERGY_COLORS, _chip, camelot_color, set_arc_svg

# Camelot score at or above which a join counts as harmonic (same key, ±1 hour,
# or the relative major/minor flip). Mirrors history.HARMONIC_COMPATIBLE.
JOINED = history.HARMONIC_COMPATIBLE


def _harmonics(tracks) -> list[int]:
    """Camelot score of each track's join from the one before it; -1 for the first."""
    out = [-1]
    for prev, cur in zip(tracks, tracks[1:]):
        out.append(_camelot_distance(prev.key or "", cur.key or ""))
    return out


@ui.page("/history")
def history_page():
    apply_theme()
    header("Histories")
    state = {"gig": None, "show_rejected": False}

    with ui.left_drawer(value=True, bordered=True).props("width=280").style(
            "background:#121419; border-right:1px solid #23262d"):
        with ui.row().classes("items-center gap-1 w-full no-wrap"):
            ui.button("Reload history", icon="history",
                      on_click=lambda: reload_history()) \
                .props("flat dense no-caps size=sm color=primary").classes("flex-grow")
        ui.separator().props("color=grey-9")
        gigs_lbl = ui.label("GIGS").classes("text-caption text-weight-bold q-mt-sm") \
            .style("color:#6b7280; letter-spacing:.08em")
        gigs_holder = ui.column().classes("w-full gap-0")
        ui.separator().props("color=grey-9").classes("q-mt-sm")
        rejected_btn = ui.button("Rejected sessions", icon="unfold_more",
                                 on_click=lambda: toggle_rejected()) \
            .props("flat dense no-caps size=sm color=grey").classes("w-full")
        rejected_holder = ui.column().classes("w-full gap-0")

    with ui.column().classes("w-full p-4 gap-3"):
        title_lbl = ui.label("Loading play history…").classes("text-h6")
        chips_row = ui.row().classes("items-center gap-2")
        source_lbl = ui.label("").classes("text-caption text-grey")

        with ui.row().classes("items-center gap-2"):
            export_btn = ui.button("Export as playlist", icon="ios_share",
                                   on_click=lambda: export_dialog()) \
                .props("unelevated color=primary")
            analyze_btn = ui.button("Analyze energy", icon="bolt",
                                    on_click=lambda: analyze_gig()) \
                .props("outline color=primary")
            seed_btn = ui.button("Build from these tracks", icon="auto_awesome_motion",
                                 on_click=lambda: build_from_tracks()) \
                .props("outline color=secondary") \
                .tooltip("open Build with exactly the tracks this night used")
            build_btn = ui.button("Build from its crates", icon="playlist_add",
                                  on_click=lambda: build_from_gig()) \
                .props("outline color=secondary") \
                .tooltip("open Build with the playlists this night drew from, "
                         "to make a new set from the same crates")
            for b in (export_btn, analyze_btn, seed_btn, build_btn):
                b.set_visibility(False)
        analyze_prog = ui.linear_progress(value=0, show_value=False) \
            .props("instant-feedback").classes("w-full hidden")
        analyze_lbl = ui.label("").classes("text-caption text-grey")

        arc_holder = ui.column().classes("w-full surface q-pa-md gap-1")
        arc_holder.set_visibility(False)
        tracks_holder = ui.column().classes("w-full gap-0")

    # ------------------------------------------------------------------
    # rendering
    # ------------------------------------------------------------------

    def render_rail():
        st = runtime.history_state
        gigs = st["gigs"]
        gigs_lbl.set_text(f"GIGS · {len(gigs)}")
        gigs_holder.clear()
        with gigs_holder:
            if not gigs:
                ui.label("No performances detected.").classes("text-caption text-grey q-pa-sm")
            for g in gigs:
                sel = state["gig"] is not None and state["gig"].day == g.day
                with ui.row().classes("items-center no-wrap w-full q-px-sm q-py-xs") \
                        .style("cursor:pointer;border-radius:6px;"
                               + ("background:rgba(255,122,26,.14);"
                                  "box-shadow:inset 2px 0 0 #ff7a1a" if sel else "")) \
                        .on("click", lambda g=g: select_gig(g)):
                    with ui.column().classes("gap-0 flex-grow").style("min-width:0"):
                        ui.label(g.label).classes(
                            "text-body2" + (" text-weight-bold" if sel else "")) \
                            .style("color:#ff7a1a" if sel else "")
                        lo, hi = g.bpm_range or (0, 0)
                        ui.label(f"{g.n} tracks · {lo:.0f}–{hi:.0f}") \
                            .classes("text-caption").style("color:#6b7280")
                    ui.label(f"{g.harmonic_rate:.0%}").classes("text-caption") \
                        .style(f"color:{'#2dd4bf' if g.harmonic_rate >= .55 else '#6b7280'}")

        rejected = [s for s in st["sessions"] if not s.is_performance]
        rejected_btn.set_text(f"Rejected sessions · {len(rejected)}")
        rejected_holder.clear()
        if not state["show_rejected"]:
            return
        with rejected_holder:
            ui.label("Sessions the classifier read as browsing rather than "
                     "performance. If one of these was a real gig, say so — the "
                     "threshold is tunable.").classes("text-caption q-pa-sm") \
                .style("color:#6b7280")
            for s in sorted(rejected, key=lambda x: x.started, reverse=True)[:60]:
                if s.n < 4:
                    continue
                with ui.row().classes("items-center no-wrap w-full q-px-sm q-py-xs gap-1"):
                    with ui.column().classes("gap-0 flex-grow").style("min-width:0"):
                        ui.label(f"{s.day} · {s.n} tracks").classes("text-caption") \
                            .style("color:#9aa0a8")
                        ui.label(f"{s.verdict} · {s.harmonic_rate:.0%} harmonic") \
                            .classes("text-caption").style("color:#6b7280")
                    ui.button(icon="visibility",
                              on_click=lambda s=s: preview_session(s)) \
                        .props("flat dense round size=sm color=grey") \
                        .tooltip("Look at it anyway")

    def render_gig():
        g = state["gig"]
        if g is None:
            return
        n_tagged = history.hydrate_energy(g, runtime.history_state["energy_cache"])
        title_lbl.set_text(g.label)
        lo, hi = g.bpm_range or (0, 0)
        repeats = g.n - len({t.track_id for t in g.tracks})

        chips_row.clear()
        with chips_row:
            _chip(f"{g.n} tracks", "#2a2d35")
            _chip(f"{lo:.0f}–{hi:.0f} bpm", "#2a2d35")
            _chip(f"{g.harmonic_rate:.0%} harmonic", "#2dd4bf", "#08302c")
            if len(g.sessions) > 1:
                _chip(f"{len(g.sessions)} sessions merged", "#2a2d35")
            if repeats:
                _chip(f"{repeats} replayed", "#3a2f18")
            _chip(f"energy {n_tagged}/{g.n}",
                  "#2a2d35" if n_tagged < g.n else "#1d3a1d")

        srcs = history.gig_sources(g, runtime.history_state["membership"])
        source_lbl.set_text(
            "Drawn from  " + " · ".join(f"{s.share:.0%} {s.path}" for s in srcs[:3])
            if srcs else "These tracks aren't in any rekordbox playlist.")

        for b in (export_btn, analyze_btn, seed_btn, build_btn):
            b.set_visibility(True)
        analyze_btn.set_text(f"Analyze energy ({g.n - n_tagged})"
                             if n_tagged < g.n else "Re-analyze energy")

        harm = _harmonics(g.tracks)
        arc_holder.set_visibility(True)
        arc_holder.clear()
        with arc_holder:
            with ui.row().classes("items-center justify-between w-full"):
                ui.label("BPM across the set").classes("text-caption") \
                    .style("color:#9aa0a8")
                with ui.row().classes("items-center gap-3"):
                    ui.html('<span style="color:#2dd4bf">●</span> '
                            '<span style="color:#6b7280">harmonic join</span>',
                            sanitize=False)
                    if n_tagged:
                        ui.html('<span style="color:#5fb454">┄</span> '
                                '<span style="color:#6b7280">energy</span>',
                                sanitize=False)
            ui.html(set_arc_svg([t.bpm for t in g.tracks], harm,
                                [t.energy for t in g.tracks]),
                    sanitize=False).classes("w-full")
            ui.label("position in the set — rekordbox logs a track number, "
                     "not a timestamp").classes("text-caption") \
                .style("color:#4b5563")

        render_tracks(g.tracks, harm)

    def render_tracks(tracks, harm):
        tracks_holder.clear()
        with tracks_holder:
            for i, t in enumerate(tracks):
                score = harm[i]
                mark, colour = ("·", "#4b5563") if score < 0 else (
                    ("✓", "#2dd4bf") if score >= JOINED else
                    ("~", "#6b7280") if score >= 50 else ("✕", "#e0705a"))
                with ui.row().classes("items-center no-wrap w-full gap-2 q-px-sm q-py-xs") \
                        .style("border-bottom:1px solid #1e2127"):
                    ui.label(str(i + 1)).classes("text-caption").style(
                        "color:#4b5563;width:22px;text-align:right")
                    ui.label(mark).classes("text-caption").style(
                        f"color:{colour};width:12px;text-align:center")
                    if t.energy:
                        ui.label(f"{t.energy}").classes("text-caption text-weight-bold") \
                            .style(f"width:20px;text-align:center;border-radius:4px;"
                                   f"color:#fff;background:"
                                   f"{ENERGY_COLORS.get(t.energy, '#888')}")
                    else:
                        ui.label("").style("width:20px")
                    with ui.column().classes("gap-0 flex-grow").style("min-width:0"):
                        ui.label(t.name).classes("text-body2 ellipsis")
                        ui.label(t.artist).classes("text-caption ellipsis") \
                            .style("color:#6b7280")
                    ui.label(f"{t.bpm:.0f}" if t.bpm else "—").classes("text-caption") \
                        .style("color:#9aa0a8;width:32px;text-align:right")
                    if t.key:
                        _chip(t.key, camelot_color(t.key))

    # ------------------------------------------------------------------
    # actions
    # ------------------------------------------------------------------

    def select_gig(g):
        state["gig"] = g
        render_rail()
        render_gig()

    def preview_session(s):
        """Render a rejected session using the same view, so it can be judged."""
        g = history.Gig(day=s.day, sessions=[s], tracks=list(s.tracks))
        state["gig"] = g
        render_rail()
        render_gig()
        ui.notify(f"Rejected as “{s.verdict}” — {s.harmonic_rate:.0%} harmonic",
                  type="info")

    def toggle_rejected():
        state["show_rejected"] = not state["show_rejected"]
        render_rail()

    def build_from_tracks():
        if state["gig"]:
            ui.navigate.to(f"/build?gig={quote(state['gig'].day)}")

    def build_from_gig():
        if state["gig"]:
            ui.navigate.to(f"/build?gig={quote(state['gig'].day)}&crates=1")

    def export_dialog():
        g = state["gig"]
        if not g:
            return
        srcs = history.gig_sources(g, runtime.history_state["membership"])[:4]
        options = {i: f"{s.share:.0%} — {s.path}" for i, s in enumerate(srcs)}
        options[-1] = "(top level of the export)"
        with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[34rem]"):
            ui.label(f"Export {g.label}").classes("text-subtitle1 text-weight-bold")
            ui.label("The set is written in play order. Pick where it should land — "
                     "the export mirrors that folder path, so it imports next to the "
                     "playlist it came from rather than at the root.") \
                .classes("text-caption text-grey")
            sel = ui.select(options, value=0 if srcs else -1) \
                .props("outlined dense").classes("w-full")

            def go():
                d.close()
                do_export(srcs[sel.value] if sel.value >= 0 else None)

            with ui.row().classes("justify-end w-full gap-2"):
                ui.button("Cancel", on_click=d.close).props("flat color=grey")
                ui.button("Export", on_click=go).props("unelevated color=primary")
        d.open()

    def do_export(source):
        g = state["gig"]
        items = [{"name": t.name, "artist": t.artist, "location": t.path,
                  "bpm": t.bpm, "key": t.key}
                 for t in g.tracks if t.path]
        if not items:
            ui.notify("No local files in this set to export", type="warning")
            return
        folders = (source.folders + [source.name]) if source else []
        out = str(runtime.export_path())
        n = rekordbox_io.export_nested(out, folders, f"▶ {g.label}", items)
        where = " / ".join(folders) if folders else "the top level"
        export_handoff(
            out, f"{n} tracks · “▶ {g.label}” at {where}", f"“▶ {g.label}”",
            re_export=lambda: do_export(source))

    async def analyze_gig():
        g = state["gig"]
        if not g:
            return
        paths = {str(t.path) for t in g.tracks if t.path and t.path.exists()}
        tracks = [t for t in runtime.library.tracks
                  if t.local_path and str(t.local_path) in paths]
        if not tracks:
            ui.notify("These files aren't in the loaded library — open the Library "
                      "tab and load rekordbox first", type="warning")
            return
        job = AnalysisJob(force=False, rich=True)
        analyze_btn.props("loading")
        analyze_prog.classes(remove="hidden")
        timer = ui.timer(0.4, lambda: (
            analyze_prog.set_value(job.fraction),
            analyze_lbl.set_text(f"Analyzing… {job.fraction:.0%}")))
        try:
            await run.io_bound(job.run, tracks)
        finally:
            timer.deactivate()
            analyze_btn.props(remove="loading")
            analyze_prog.classes("hidden")
            analyze_lbl.set_text("")
            runtime.history_state["energy_cache"].clear()
            render_gig()
            ui.notify("Analysis complete", type="positive")

    async def reload_history():
        await run.io_bound(runtime.mix_model, True)   # re-reads history, relearns
        state["gig"] = None
        render_rail()
        ui.notify(f"{len(runtime.history_state['gigs'])} gigs detected", type="positive")

    async def first_load():
        if not runtime.history_state["loaded"]:
            await run.io_bound(runtime.load_history, False)
        gigs = runtime.history_state["gigs"]
        state["gig"] = gigs[0] if gigs else None
        title_lbl.set_text("Select a gig" if not gigs else "")
        render_rail()
        render_gig()

    ui.timer(0.1, first_load, once=True)
