"""Settings page (`/settings`) — configure the app for a fresh machine.

Everything a new user must set up to use Track Studio lives here: file paths,
the three integrations (Spotify / Beatport / rekordbox) with their secrets and a
**Test** button each, and a System-health panel (ffmpeg / yt-dlp / models).

Secrets are written to the gitignored `.env` (this project keeps them local, not
in Infisical); paths go to `.studio_state.json`. Each Test button turns an opaque
mid-workflow failure into immediate green/red feedback during onboarding.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import time
from pathlib import Path

from nicegui import run, ui

import rbprefs
import runtime
import updates
from config import ENV_PATH, load_env, save_env
from export_ui import xml_setup_panel
from shell import apply_theme, header, update_dialog
from staging import STAGE_DIR
import inbox
from store import (default_export_file, load_studio_state,
                   save_download_root, save_export_file, save_inbox_folder,
                   save_rekordbox_db_path, save_update_channel)


def _section(title: str, subtitle: str = ""):
    """A titled settings card; returns the card's body column context manager."""
    card = ui.card().classes("w-full surface").props("flat")
    with card:
        ui.label(title).classes("text-subtitle1 text-weight-bold")
        if subtitle:
            ui.label(subtitle).classes("text-caption text-grey")
    return card


def _status(row, ok: bool | None, text: str) -> None:
    """Render a coloured status line into `row` (green ok / red fail / grey n/a)."""
    row.clear()
    color = {True: "positive", False: "negative", None: "grey"}[ok]
    icon = {True: "check_circle", False: "error", None: "help"}[ok]
    with row:
        ui.icon(icon).props(f"color={color}")
        ui.label(text).classes(f"text-caption text-{color}")


@ui.page("/settings")
def settings_page():
    apply_theme()
    header("Settings")
    load_env()  # so os.environ reflects any saved secrets for prefill
    import os
    st = load_studio_state()

    async def _pick_folder(target) -> None:
        """Native macOS folder picker (osascript) → write the choice into `target`.
        A non-zero exit is the user cancelling — stay quiet."""
        res = await run.io_bound(lambda: subprocess.run(
            ["osascript", "-e",
             'POSIX path of (choose folder with prompt "Choose folder")'],
            capture_output=True, text=True, timeout=300))
        path = (res.stdout or "").strip()
        if res.returncode == 0 and path:
            target.value = path

    with ui.column().classes("w-full p-4 gap-4").style("max-width:56rem; margin:auto"):
        ui.label("Settings").classes("text-h6")
        ui.label("Configure paths, integrations, and prerequisites. Secrets are "
                 f"saved locally to {ENV_PATH.name} (gitignored).") \
            .classes("text-caption text-grey")

        # ── Get set up ───────────────────────────────────────────────────────
        # The ordered spine for a fresh machine. Statuses are cheap proxies
        # (loaded state, saved creds, preference files) — the real probes are
        # the per-section Test buttons these rows link down to.
        with _section("Get set up", "The path from a fresh machine to a working "
                                    "round-trip, in order. Each row links to its "
                                    "section below."):
            checklist = ui.column().classes("w-full gap-1")

            def _checklist_rows():
                """[(ok, text, anchor)] — ok is True/False/None (n/a or partial),
                matching `_status`'s color language."""
                rows = []
                n_pl = len(runtime.library.rekordbox_index)
                rows.append((bool(n_pl) or False,
                             f"① rekordbox database — {n_pl} playlists loaded"
                             if n_pl else "① rekordbox database — not connected yet",
                             None if n_pl else "rekordbox"))
                v = rbprefs.evaluate(runtime.export_path())
                rows.append((v.ok, f"② rekordbox xml view — {v.detail}",
                             None if v.ok else "paths"))
                creds = bool(os.environ.get("SPOTIFY_CLIENT_ID")
                             and os.environ.get("SPOTIFY_CLIENT_SECRET"))
                from spotify import TOKEN_CACHE
                if creds and TOKEN_CACHE.exists():
                    rows.append((True, "③ Spotify — connected", None))
                elif creds:
                    rows.append((None, "③ Spotify — credentials saved, not yet "
                                       "connected", "spotify"))
                else:
                    rows.append((False, "③ Spotify — not set up (needed for Sync)",
                                 "spotify"))
                import bpdl
                bp_user = bool(os.environ.get("BEATPORT_USERNAME"))
                bp_bin = bpdl.BPDL_BIN.exists()
                if bp_user and bp_bin:
                    rows.append((True, "④ Beatport — ready", None))
                elif bp_user or bp_bin:
                    rows.append((None, "④ Beatport — "
                                 + ("binary present, no login saved" if bp_bin
                                    else "login saved, downloader binary missing"),
                                 "beatport"))
                else:
                    rows.append((None, "④ Beatport — optional, only needed to "
                                       "auto-download from Beatport", "beatport"))
                return rows

            def render_checklist():
                checklist.clear()
                with checklist:
                    for ok, text, anchor in _checklist_rows():
                        color = {True: "positive", False: "negative",
                                 None: "grey"}[ok]
                        icon = {True: "check_circle", False: "error",
                                None: "help"}[ok]
                        with ui.row().classes("items-center gap-2 no-wrap"):
                            ui.icon(icon).props(f"color={color}")
                            ui.label(text).classes(f"text-caption text-{color}")
                            if anchor and ok is not True:
                                ui.link("set up ↓", f"#{anchor}") \
                                    .classes("text-caption")

            render_checklist()
            ui.button("Re-check", icon="refresh", on_click=render_checklist) \
                .props("flat dense no-caps size=sm color=grey")

        # ── Paths ────────────────────────────────────────────────────────────
        ui.link_target("paths")
        with _section("Paths", "Where downloads land, where browser downloads are "
                               "picked up, and the single rekordbox export file "
                               "every export overwrites."):
            dl = st.get("download_root") or str(STAGE_DIR)
            ex = st.get("export_file") or str(default_export_file(dl))
            with ui.row().classes("w-full items-center gap-2 no-wrap"):
                dl_in = ui.input("Download root folder", value=dl) \
                    .props("outlined dense").classes("grow")
                ui.button("Browse…", icon="folder_open",
                          on_click=lambda: _pick_folder(dl_in)).props("outline dense")
            ib = st.get("inbox_folder") or str(inbox.default_folder())
            with ui.row().classes("w-full items-center gap-2 no-wrap"):
                ib_in = ui.input("Downloads inbox folder", value=ib) \
                    .props("outlined dense").classes("grow")
                ui.button("Browse…", icon="folder_open",
                          on_click=lambda: _pick_folder(ib_in)).props("outline dense")
            inbox_hint = ui.label("").classes("text-caption text-grey")
            ui.button("Test access", icon="lock_open",
                      on_click=lambda: test_inbox()) \
                .props("flat dense no-caps size=sm color=grey")
            ex_in = ui.input("Rekordbox export file", value=ex) \
                .props("outlined dense").classes("w-full")

            def _adopt_watched(watched):
                """Fix a mismatch in the direction that needs no rekordbox visit:
                make rekordbox's already-watched file *our* export file."""
                save_export_file(str(watched))
                ex_in.value = str(watched)
                panel_refresh()
                render_checklist()
                ui.notify(f"Export file switched to {watched}", type="positive")

            # Live check against rekordbox's own preferences — replaces the old
            # paragraph of one-time instructions (they only appear when a step
            # is actually missing).
            panel_refresh = xml_setup_panel(runtime.export_path,
                                            on_adopt=_adopt_watched)

            def test_inbox():
                """Read the folder for real. macOS only reveals a TCC block when
                something actually tries to list the directory, so a live read is
                the only honest check — and it names the app to grant."""
                folder = Path(ib_in.value).expanduser() if ib_in.value.strip() \
                    else inbox.default_folder()
                try:
                    n = len(inbox.scan(folder))
                except PermissionError as e:
                    inbox_hint.set_text(str(e))
                    inbox_hint.style("color:#d29922")
                    return
                except Exception as e:
                    inbox_hint.set_text(str(e))
                    inbox_hint.style("color:#f85149")
                    return
                inbox_hint.set_text(f"Readable — {n} importable file(s) right now.")
                inbox_hint.style("color:#3fb950")

            def save_paths():
                # Order matters: save_download_root may relocate a not-yet-written
                # export file into the new root. Writing the export field
                # unconditionally afterwards would put the stale path straight
                # back, so it's only persisted when actually edited — an explicit
                # choice beats the automatic one, an untouched field doesn't.
                if dl_in.value.strip():
                    save_download_root(str(Path(dl_in.value).expanduser()))
                edited = ex_in.value.strip() and ex_in.value.strip() != ex
                if edited:
                    save_export_file(str(Path(ex_in.value).expanduser()))
                save_inbox_folder(str(Path(ib_in.value).expanduser())
                                  if ib_in.value.strip() else None)
                now = load_studio_state().get("export_file") or ""
                moved = not edited and now and now != ex
                if moved:
                    ex_in.value = now          # show where it actually went
                panel_refresh()                # the wiring check follows the path
                render_checklist()
                ui.notify(f"Paths saved — export file moved to {now}" if moved
                          else "Paths saved", type="positive",
                          timeout=9000 if moved else 3000)
            ui.button("Save paths", on_click=save_paths).props("unelevated color=primary")

        # ── Spotify ──────────────────────────────────────────────────────────
        ui.link_target("spotify")
        with _section("Spotify", "Create an app on the Spotify Developer Dashboard, "
                                 "then paste its Client ID/Secret and add the exact "
                                 "Redirect URI below to the app's settings."):
            with ui.row().classes("items-center gap-1"):
                ui.link("Open the Spotify Developer Dashboard",
                        "https://developer.spotify.com/dashboard", new_tab=True) \
                    .classes("text-caption")
                ui.label('— when creating the app, tick "Web API" under '
                         '"Which API/SDKs are you planning to use?".') \
                    .classes("text-caption text-grey")
            sp_status = ui.row().classes("items-center gap-1")
            _status(sp_status, None, "Not tested")
            sp_id = ui.input("Client ID", value=os.environ.get("SPOTIFY_CLIENT_ID", "")) \
                .props("outlined dense").classes("w-full")
            sp_secret = ui.input("Client Secret",
                                 value=os.environ.get("SPOTIFY_CLIENT_SECRET", "")) \
                .props("outlined dense type=password").classes("w-full")
            sp_uri = ui.input("Redirect URI",
                              value=os.environ.get("SPOTIFY_REDIRECT_URI",
                                                   "http://127.0.0.1:8888/callback")) \
                .props("outlined dense").classes("w-full")
            ui.label("Register this exact Redirect URI in the Spotify app, then "
                     "Connect. Its port (8888) is a temporary login-only server "
                     "spotipy runs just during consent — intentionally different "
                     "from the app's port (8080), so don't set it to 8080. Any free "
                     "port works; keep it matching what you register on Spotify.") \
                .classes("text-caption text-grey")

            async def connect_spotify():
                save_env({"SPOTIFY_CLIENT_ID": sp_id.value.strip(),
                          "SPOTIFY_CLIENT_SECRET": sp_secret.value.strip(),
                          "SPOTIFY_REDIRECT_URI": sp_uri.value.strip()})
                runtime._spotify["client"] = None   # force rebuild with new creds
                _status(sp_status, None, "Connecting… (check your browser)")
                try:
                    from spotify import Spotify
                    name = await run.io_bound(lambda: Spotify().me())
                    _status(sp_status, True, f"Connected as {name}")
                    ui.notify("Spotify connected", type="positive")
                except Exception as e:
                    _status(sp_status, False, f"Failed: {e}")
            ui.button("Save & Connect", icon="link",
                      on_click=connect_spotify).props("unelevated color=primary")

        # ── Beatport ─────────────────────────────────────────────────────────
        ui.link_target("beatport")
        with _section("Beatport", "Needs an active Beatport LINK subscription and the "
                                  "beatportdl binary (platform-specific, not bundled)."):
            bp_status = ui.row().classes("items-center gap-1")
            import bpdl
            if bpdl.BPDL_BIN.exists():
                _status(bp_status, None, "Binary present · not tested")
            else:
                _status(bp_status, False, f"beatportdl binary missing at {bpdl.BPDL_BIN}")
            bp_user = ui.input("Username", value=os.environ.get("BEATPORT_USERNAME", "")) \
                .props("outlined dense").classes("w-full")
            bp_pw = ui.input("Password", value=os.environ.get("BEATPORT_PASSWORD", "")) \
                .props("outlined dense type=password").classes("w-full")

            # --- download quality ---
            # The options include the current quality even when it's one we've
            # withdrawn, so a config already on it renders (loudly) instead of
            # blank. `save_quality` still refuses to put it back.
            bp_q = ui.select(bpdl.quality_options(bpdl.get_quality()),
                             value=bpdl.get_quality(),
                             label="Download quality",
                             on_change=lambda e: save_quality(e.value)) \
                .props("outlined dense").classes("w-full")
            q_status = ui.row().classes("items-center gap-1")
            _status(q_status, None, "Not tested")
            ui.label("Which tiers you can actually download is set by your Beatport "
                     "subscription. beatportdl does NOT fall back: if the tier isn't "
                     "on your plan the whole batch fails with “Requested quality is "
                     "not available” and nothing downloads — so test before a big sync.") \
                .classes("text-caption text-grey")
            q_warn = ui.label("").classes("text-caption").style("color:#f0a830")
            # Offers the one-click switch back to Medium once we've proven Medium
            # works — hidden until a test establishes that.
            switch_btn = ui.button("", icon="arrow_upward",
                                   on_click=lambda: pick_quality(
                                       bpdl.FALLBACK_FOR.get(bp_q.value, bpdl.RECOMMENDED_QUALITY))) \
                .props("flat dense no-caps color=primary")
            switch_btn.set_visibility(False)

            def pick_quality(q):
                bp_q.set_value(q)          # on_change → save_quality

            def show_broken(q) -> bool:
                """Flag a withdrawn quality, and offer the way off it. True if shown.

                No test gates this one, unlike the fallback nudge below: HLS is
                never the right answer, so there's nothing to establish first.
                """
                why = bpdl.BROKEN_QUALITIES.get(q)
                if not why:
                    return False
                q_warn.set_text(f"⚠ “{q}” is withdrawn — {why}")
                switch_btn.set_text(f"Switch to {bpdl.FALLBACK_FOR.get(q, bpdl.RECOMMENDED_QUALITY)}")
                switch_btn.set_visibility(True)
                _status(q_status, False, f"{q} — anything downloaded this way is suspect")
                return True

            def save_quality(q):
                if not q:
                    return
                if show_broken(q):
                    return                 # never written back; set_quality refuses it
                try:
                    bpdl.set_quality(q)
                except ValueError as e:
                    _status(q_status, False, str(e))
                    return
                q_warn.set_text(bpdl.QUALITY_NOTES.get(q, ""))
                switch_btn.set_visibility(False)
                _status(q_status, None, "Saved · not tested")

            async def test_quality():
                q = bp_q.value
                _status(q_status, None, f"Asking Beatport about “{q}”…")
                try:
                    ok, msg = await run.io_bound(bpdl.probe_quality, q)
                except Exception as e:
                    _status(q_status, False, f"Couldn't test: {e}")
                    return
                _status(q_status, ok, f"{q}: {msg}")

                # If they're on a fallback tier (HLS), check whether the tier it
                # stands in for is actually available — if it is, there's no reason
                # to be on the fallback, so offer the switch.
                better = bpdl.FALLBACK_FOR.get(q)
                if not (ok and better):
                    return
                try:
                    better_ok, better_msg = await run.io_bound(bpdl.probe_quality, better)
                except Exception:
                    return
                if better_ok:
                    _status(q_status, True,
                            f"{q}: {msg} — but “{better}” is available too, and it's "
                            f"the same 128 kbps audio without the segment fetch + remux.")
                    switch_btn.set_text(f"Switch to {better} (recommended)")
                    switch_btn.set_visibility(True)

            save_quality(bp_q.value)   # surface the selected option's caveat on load

            async def test_beatport():
                save_env({"BEATPORT_USERNAME": bp_user.value.strip(),
                          "BEATPORT_PASSWORD": bp_pw.value.strip()})
                _status(bp_status, None, "Logging in…")
                try:
                    import beatport
                    await run.io_bound(beatport.connect)
                    extra = "" if bpdl.BPDL_BIN.exists() else " (⚠ downloader binary missing)"
                    _status(bp_status, True, f"Login OK{extra}")
                except Exception as e:
                    _status(bp_status, False, f"Failed: {e}")
            with ui.row().classes("items-center gap-2"):
                ui.button("Save & Test login", icon="login",
                          on_click=test_beatport).props("unelevated color=primary")
                ui.button("Test quality", icon="high_quality",
                          on_click=test_quality).props("outline color=primary") \
                    .tooltip("Checks whether your plan can download at the selected "
                             "quality (no audio is fetched)")

        # ── rekordbox ────────────────────────────────────────────────────────
        ui.link_target("rekordbox")
        with _section("rekordbox", "Reads the live rekordbox 6/7 database. On 6.6.5+/7 "
                                   "the DB is encrypted — fetch the decryption key once."):
            rb_status = ui.row().classes("items-center gap-1")
            _status(rb_status, None, "Not tested")
            rb_db = ui.input("Database folder override (optional)",
                             value=st.get("rekordbox_db_path") or "") \
                .props("outlined dense clearable").classes("w-full")
            ui.label("Leave blank to auto-detect. Set only if the test below fails to "
                     "find your database.").classes("text-caption text-grey")
            ui.label('Database on an external drive? If the test fails with '
                     '"Operation not permitted", macOS is blocking access: open '
                     "System Settings → Privacy & Security → Full Disk Access, add "
                     "Track Studio from /Applications, then use Restart server in "
                     "the System section below.").classes("text-caption text-grey")

            async def test_rekordbox():
                save_rekordbox_db_path(rb_db.value.strip() or None)
                _status(rb_status, None, "Reading database…")
                try:
                    import rekordbox
                    col = await run.io_bound(rekordbox.from_live)
                    _status(rb_status, True,
                            f"Connected · {len(col.playlist_index)} playlists")
                except Exception as e:
                    _status(rb_status, False, f"Failed: {e}")

            async def download_key():
                _status(rb_status, None, "Downloading decryption key…")
                try:
                    out = await run.io_bound(lambda: subprocess.run(
                        [sys.executable, "-m", "pyrekordbox", "download-key"],
                        capture_output=True, text=True, timeout=120))
                    ok = out.returncode == 0
                    _status(rb_status, ok or None,
                            "Key installed — now Test connection" if ok
                            else f"Key download failed: {(out.stderr or out.stdout)[:120]}")
                except Exception as e:
                    _status(rb_status, False, f"Failed: {e}")

            with ui.row().classes("gap-2"):
                ui.button("Test connection", icon="cable",
                          on_click=test_rekordbox).props("unelevated color=primary")
                ui.button("Download decryption key", icon="vpn_key",
                          on_click=download_key).props("outline color=grey")
                ui.button("Open Full Disk Access settings", icon="privacy_tip",
                          on_click=lambda: subprocess.Popen(
                              ["open", "x-apple.systempreferences:"
                                       "com.apple.preference.security?Privacy_AllFiles"])) \
                    .props("outline color=grey")

        # ── Version & updates ────────────────────────────────────────────────
        with _section("Version", "Track Studio looks for a new release at launch and "
                                 "twice a day, and never installs one on its own."):
            with ui.row().classes("items-center gap-3 w-full"):
                ui.label(f"You're on {updates.current_version()}") \
                    .classes("text-body2 text-weight-medium")
                seen = ui.label("").classes("text-caption text-grey")

                def _say_checked() -> None:
                    when = updates.last_checked()
                    rec = updates.available()
                    if rec:
                        seen.text = f"{rec['version']} is waiting"
                    elif when:
                        ago = max(0, int((time.time() - when) / 60))
                        seen.text = ("checked just now" if ago < 2 else
                                     f"checked {ago} min ago" if ago < 90 else
                                     f"checked {round(ago / 60)} h ago")
                    else:
                        seen.text = "not looked yet"
                    err = updates._read_state().get("last_error")
                    if err and not rec:
                        seen.text += f" · {err}"

                _say_checked()
                ui.space()
                found = ui.row().classes("items-center gap-2")

                def _offer() -> None:
                    found.clear()
                    rec = updates.available()
                    if rec:
                        with found:
                            ui.button(f"Install {rec['version']}", icon="arrow_circle_up",
                                      on_click=lambda r=rec: update_dialog(r)) \
                                .props("unelevated color=primary")

                _offer()

                async def _check() -> None:
                    seen.text = "looking…"
                    await run.io_bound(updates.check)
                    _say_checked()
                    _offer()
                    if not updates.available():
                        ui.notify(f"{updates.current_version()} is the latest", type="positive")

                ui.button("Check now", icon="refresh", on_click=_check).props("outline color=grey")

            with ui.row().classes("items-center gap-2 w-full"):
                ui.label("Releases").classes("text-caption text-grey")
                ui.toggle({"stable": "Stable", "beta": "Beta"},
                          value=updates.channel(),
                          on_change=lambda e: (save_update_channel(e.value),
                                               ui.notify(f"Following {e.value} releases"))) \
                    .props("dense no-caps")
                ui.label("Beta gets them first, and gets the odd broken one.") \
                    .classes("text-caption text-grey")
            ui.label(f"From {updates.feed_url()}").classes("text-caption") \
                .style("color:#6b7280; word-break:break-all")

        # ── System health ────────────────────────────────────────────────────
        with _section("System", "Prerequisites for analysis and downloads."):
            # ffmpeg
            with ui.row().classes("items-center gap-2 w-full"):
                ff = shutil.which("ffmpeg")
                r = ui.row().classes("items-center gap-1")
                _status(r, bool(ff), f"ffmpeg: {ff}" if ff
                        else "ffmpeg not found — install with `brew install ffmpeg`")
            # yt-dlp
            ytdlp_row = ui.row().classes("items-center gap-2 w-full")
            with ytdlp_row:
                yr = ui.row().classes("items-center gap-1")
                try:
                    import yt_dlp
                    _status(yr, True, f"yt-dlp {yt_dlp.version.__version__}")
                except Exception:
                    _status(yr, False, "yt-dlp not installed")
                ui.space()

                async def update_ytdlp():
                    _status(yr, None, "Updating yt-dlp…")
                    try:
                        await run.io_bound(lambda: subprocess.run(
                            [sys.executable, "-m", "pip", "install", "-U", "yt-dlp"],
                            capture_output=True, text=True, timeout=180))
                        import importlib
                        import yt_dlp as _y
                        importlib.reload(_y.version)
                        _status(yr, True, f"yt-dlp {_y.version.__version__}")
                        ui.notify("yt-dlp updated", type="positive")
                    except Exception as e:
                        _status(yr, False, f"Update failed: {e}")
                ui.button("Update", icon="update",
                          on_click=update_ytdlp).props("flat dense color=primary")
            # essentia models
            models_dir = Path(__file__).resolve().parent.parent / "models"
            n_pb = len(list(models_dir.glob("*.pb"))) if models_dir.is_dir() else 0
            mr = ui.row().classes("items-center gap-1")
            _status(mr, n_pb > 0 or None,
                    f"Essentia models: {n_pb} present (auto-download on first Analyze)"
                    if n_pb else "Essentia models: none yet (download on first Analyze)")

            def restart_server() -> None:
                """Hand off to a detached child that waits for :8080 to free up,
                then relaunches main.py (with Homebrew on PATH so brew-installed
                tools like ffmpeg are visible), and exit this process."""
                env = dict(os.environ)
                env["PATH"] = "/opt/homebrew/bin:/usr/local/bin:" + env.get("PATH", "")
                root = Path(__file__).resolve().parent.parent
                (root / "data").mkdir(exist_ok=True)
                with open(root / "data" / "app.log", "ab") as log:
                    subprocess.Popen(
                        ["/bin/bash", "-c",
                         "for _ in $(seq 1 40); do "
                         "lsof -i:8080 -sTCP:LISTEN -t >/dev/null 2>&1 || break; "
                         "sleep 0.25; done; "
                         f'exec "{sys.executable}" main.py'],
                        cwd=str(root), env=env, stdout=log, stderr=log,
                        start_new_session=True)
                ui.notify("Restarting — the page comes back by itself…")
                ui.run_javascript(
                    "setTimeout(function retry() {"
                    " fetch('/', {cache: 'no-store'})"
                    "   .then(() => location.reload())"
                    "   .catch(() => setTimeout(retry, 1500));"
                    "}, 3000)")
                ui.timer(1.0, lambda: os._exit(0), once=True)

            with ui.row().classes("items-center gap-2"):
                ui.button("Restart server", icon="restart_alt",
                          on_click=restart_server).props("outline color=primary")
                ui.label("Picks up newly installed tools (e.g. ffmpeg) and macOS "
                         "permission changes.").classes("text-caption text-grey")
