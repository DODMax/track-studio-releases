"""Replace a stitched file with a clean one — the action behind "Check for problems".

`integrity` says a file's audio isn't continuous. Nothing can repair that: the
audio is already duplicated or missing. The only fix is fetching the track again
from the store and swapping it in **at the same path**, because rekordbox keys
its collection on file location — a clean copy at a *new* path imports as a
second entry and splits the play evidence `history`/`mixmodel` run on, which is
the whole reason `dupes` exists.

Identity is the hard part. Beatport's own downloads carry no ISRC, so there's
nothing to match on but text and numbers, and getting it wrong is worse than the
glitch: it silently swaps the record under a track rekordbox still thinks it
knows. So three signals have to agree, and anything short of that is left for a
human:

- **name**, via `match.match_track` — title and artist scored independently, so
  a remix never collapses into the original it's named after;
- **duration**, the strongest one. A stitched file's length is off by only tens
  of milliseconds, so ±2s cleanly separates a rendition from a different record;
- **BPM**, to break ties between otherwise equal candidates.

Every replacement is backed up first, then packet-checked, and rolled back if the
"clean" copy isn't actually clean. Leaf module: no UI, no `runtime`.
"""
from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

BACKUP_DIRNAME = ".broken_backup"
DURATION_TOLERANCE_S = 2.0
LOOSE_TOLERANCE_S = 4.0
SEARCH_LIMIT = 15
NAME_CONFIDENT = 88.0
NAME_POSSIBLE = 78.0

CONFIDENT, REVIEW, NOT_FOUND = "confident", "review", "not found"


@dataclass
class Candidate:
    """A Beatport track that might be the clean version of a local file."""
    path: Path                      # the local file to replace
    artist: str
    title: str
    local_s: float
    beatport_id: Optional[int] = None
    display: str = ""
    beatport_s: float = 0.0
    bpm: Optional[int] = None
    score: float = 0.0
    worst_ms: float = 0.0           # carried from the finding, for ordering

    @property
    def delta_s(self) -> float:
        return self.beatport_s - self.local_s

    @property
    def verdict(self) -> str:
        """Safe to replace without a human looking at it?"""
        if self.beatport_id is None:
            return NOT_FOUND
        if self.score >= NAME_CONFIDENT and abs(self.delta_s) <= DURATION_TOLERANCE_S:
            return CONFIDENT
        return REVIEW

    @property
    def detail(self) -> str:
        if self.beatport_id is None:
            return "no Beatport match"
        return f"{self.display} · {self.delta_s:+.1f}s · name {self.score:.0f}"


def read_local(path: Path) -> tuple[str, str, float, Optional[int]]:
    """(artist, title, duration, bpm) off the file's own tags."""
    from mutagen import File as MutagenFile
    f = MutagenFile(path)
    if f is None:
        return "", "", 0.0, None
    tags = f.tags or {}
    if path.suffix.lower() == ".m4a":
        artist = (tags.get("\xa9ART") or [""])[0]
        title = (tags.get("\xa9nam") or [""])[0]
        bpm = (tags.get("tmpo") or [None])[0]
    else:
        artist = tags.get("TPE1").text[0] if tags.get("TPE1") else ""
        title = tags.get("TIT2").text[0] if tags.get("TIT2") else ""
        bpm = tags.get("TBPM").text[0] if tags.get("TBPM") else None
    return str(artist), str(title), float(f.info.length), (int(bpm) if bpm else None)


def find_on_beatport(path: Path) -> Candidate:
    """The best Beatport candidate for one local file. Never raises."""
    import bpdl
    from match import match_track, prep_choices

    artist, title, duration, bpm = read_local(Path(path))
    cand = Candidate(path=Path(path), artist=artist, title=title, local_s=duration)
    if not (artist and title):
        return cand
    try:
        hits = bpdl.search_tracks(f"{artist} {title}", limit=SEARCH_LIMIT)
    except Exception:
        return cand
    if not hits:
        return cand

    choices = prep_choices([(", ".join(h.artists), f"{h.name} {h.mix_name}".strip())
                            for h in hits])
    overall = match_track(artist, title, choices)
    if not overall.hit:
        return cand

    # The name match picks a *rendition*; length picks which pressing of it.
    # Among hits scoring about as well as the best, take the closest length.
    best_key = None
    for i, h in enumerate(hits):
        one = match_track(artist, title, [choices[i]])
        if not one.hit or one.score < overall.score - 6:
            continue
        delta = abs((h.length_ms or 0) / 1000 - duration)
        bpm_off = abs((h.bpm or 0) - bpm) if (bpm and h.bpm) else 99
        key = (delta > DURATION_TOLERANCE_S, bpm_off > 1, delta)
        if best_key is None or key < best_key:
            best_key = key
            cand.beatport_id, cand.display = h.id, h.display
            cand.beatport_s = (h.length_ms or 0) / 1000
            cand.bpm, cand.score = h.bpm, one.score
    return cand


def plan(findings) -> list[Candidate]:
    """A Candidate per finding, worst damage first. One Beatport search each."""
    out = []
    for f in findings:
        c = find_on_beatport(f.path)
        c.worst_ms = getattr(f, "worst_ms", 0.0)
        out.append(c)
    out.sort(key=lambda c: -c.worst_ms)
    return out


def replace_in_place(new_file: Path, target: Path) -> tuple[bool, str]:
    """Swap `new_file` in at `target`. Returns (ok, message).

    The original is moved aside, never deleted — a wrong match has to be
    undoable. The Comments payload is carried across because that tag *is* the
    database (see CLAUDE.md) and a fresh download has none; it was computed on
    the broken audio, so re-analysing is worth it, but dropping it silently
    would be worse. Finally the replacement is packet-checked, and rolled back
    if it isn't actually clean — "downloaded again" is not the same as "fixed".
    """
    import integrity

    new_file, target = Path(new_file), Path(target)
    backup_dir = target.parent / BACKUP_DIRNAME
    backup_dir.mkdir(exist_ok=True)
    backup = backup_dir / target.name

    comment = None
    if target.suffix.lower() == ".m4a":
        try:
            from mutagen.mp4 import MP4
            comment = (MP4(target).tags or {}).get("\xa9cmt")
        except Exception:
            comment = None
    try:
        shutil.move(str(target), str(backup))
        shutil.copy2(str(new_file), str(target))
    except OSError as e:
        return False, f"could not swap: {e}"

    if comment:
        try:
            from mutagen.mp4 import MP4
            t = MP4(target)
            t["\xa9cmt"] = comment
            t.save()
        except Exception:
            pass                      # the audio is what mattered

    check = integrity.packet_check(target, sample_seconds=0)
    if check.breaks:
        shutil.move(str(backup), str(target))
        return False, f"replacement still broken ({check.breaks} breaks) — rolled back"
    return True, "replaced"


def pair_downloads(files: list[Path], candidates: list[Candidate]) -> dict:
    """Map each downloaded file to the candidate it satisfies.

    beatportdl names by its own template, not by track id, so the download has
    to be recognised rather than looked up. Length does it: these are the exact
    tracks we asked for, and two of them being within 2s of each other *and*
    confusable by name is not a case worth engineering for.
    """
    from mutagen import File as MutagenFile

    lengths = {}
    for f in files:
        try:
            lengths[f] = MutagenFile(f).info.length
        except Exception:
            continue
    out, taken = {}, set()
    for c in candidates:
        best, best_delta = None, None
        for f, length in lengths.items():
            if f in taken:
                continue
            delta = abs(length - c.beatport_s)
            if best_delta is None or delta < best_delta:
                best, best_delta = f, delta
        if best is not None and best_delta is not None and best_delta <= DURATION_TOLERANCE_S:
            out[c.path] = best
            taken.add(best)
    return out
