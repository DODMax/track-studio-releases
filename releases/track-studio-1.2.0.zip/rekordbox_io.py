"""Write a rekordbox-importable collection.xml (DJ_PLAYLISTS format).

Rekordbox is read-only for us via pyrekordbox, so the way to create playlists /
sub-sets is to emit an XML the user imports (Preferences → View → rekordbox xml,
then drag the sub-playlists into the main library). On import rekordbox matches
each TRACK to the existing collection by its `Location` file path, so no
duplicates are created for tracks already present.

This is the inverse of rekordbox.parse_collection: `encode_location` round-trips
with `rekordbox._decode_location`.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote


def encode_location(path: Path) -> str:
    """Path -> `file://localhost/...` URL (inverse of rekordbox._decode_location)."""
    return "file://localhost" + quote(str(path), safe="/")


@dataclass
class NodeSpec:
    """A playlist-tree node to emit: a folder (children) or a playlist (track_ids)."""
    name: str
    is_folder: bool = False
    track_ids: list[str] = field(default_factory=list)
    children: list["NodeSpec"] = field(default_factory=list)


def _rating_attr(stars: int) -> str:
    return str(int(stars) * 51)  # inverse of rekordbox._norm_rating


def build_collection_xml(tracks: dict[str, dict], roots: list[NodeSpec]) -> ET.ElementTree:
    """Build a DJ_PLAYLISTS tree. `tracks` maps TrackID -> attr dict
    (name, artist, location:Path, bpm, key, genre, colour, rating)."""
    root = ET.Element("DJ_PLAYLISTS", {"Version": "1.0.0"})
    ET.SubElement(root, "PRODUCT", {"Name": "rekordbox", "Version": "track-studio",
                                    "Company": "track-energy"})

    coll = ET.SubElement(root, "COLLECTION", {"Entries": str(len(tracks))})
    for tid, t in tracks.items():
        attrs = {"TrackID": str(tid), "Name": t.get("name", ""),
                 "Artist": t.get("artist", "")}
        if t.get("location"):
            attrs["Location"] = encode_location(t["location"])
        if t.get("bpm"):
            attrs["AverageBpm"] = f"{float(t['bpm']):.2f}"
        if t.get("key"):
            attrs["Tonality"] = t["key"]
        if t.get("genre"):
            attrs["Genre"] = t["genre"]
        if t.get("rating"):
            attrs["Rating"] = _rating_attr(t["rating"])
        if t.get("colour"):
            attrs["Colour"] = t["colour"]
        ET.SubElement(coll, "TRACK", attrs)

    playlists = ET.SubElement(root, "PLAYLISTS")
    rootnode = ET.SubElement(playlists, "NODE", {"Type": "0", "Name": "ROOT",
                                                 "Count": str(len(roots))})
    for spec in roots:
        _emit_node(rootnode, spec)
    return ET.ElementTree(root)


def _emit_node(parent: ET.Element, spec: NodeSpec) -> None:
    if spec.is_folder:
        node = ET.SubElement(parent, "NODE", {"Type": "0", "Name": spec.name,
                                              "Count": str(len(spec.children))})
        for child in spec.children:
            _emit_node(node, child)
    else:
        node = ET.SubElement(parent, "NODE", {"Type": "1", "Name": spec.name,
                                              "KeyType": "0",
                                              "Entries": str(len(spec.track_ids))})
        for tid in spec.track_ids:
            ET.SubElement(node, "TRACK", {"Key": str(tid)})


def export_playlist(out_xml: str, playlist_name: str, items: list[dict]) -> int:
    """Write a DJ_PLAYLISTS xml with a single playlist `playlist_name` listing
    every item that has a local file. `items` are dicts:
    {name, artist, location:Path, bpm, key, genre}. TrackIDs are synthesized
    (rekordbox re-matches by Location on import). Returns the track count written.
    """
    return export_nested(out_xml, [], playlist_name, items)


def export_nested(out_xml: str, folders: list[str], playlist_name: str,
                  items: list[dict]) -> int:
    """`export_playlist`, optionally nested under a mirrored chain of `folders`.

    A played set exported at the root of the xml view is one more orphan to file
    by hand. Re-creating the folder chain it came from ("Max 2025" → "860 -
    Techno Peak Time" → the set) means the import lands next to its source, so
    filing it is a single drag rather than a hunt. `folders=[]` writes at root,
    which is what `export_playlist` is.
    """
    collection: dict[str, dict] = {}
    ids: list[str] = []
    for i, it in enumerate(items, 1):
        if not it.get("location"):
            continue  # rekordbox can't import a track without a Location
        tid = str(i)
        collection[tid] = {
            "name": it.get("name", ""),
            "artist": it.get("artist", ""),
            "location": it["location"],
            "bpm": it.get("bpm"),
            "key": it.get("key"),
            "genre": it.get("genre", ""),
        }
        ids.append(tid)

    node = NodeSpec(playlist_name, track_ids=ids)
    for name in reversed(folders):
        node = NodeSpec(name, is_folder=True, children=[node])

    tree = build_collection_xml(collection, [node])
    ET.indent(tree, space="  ")
    tree.write(out_xml, encoding="UTF-8", xml_declaration=True)
    return len(ids)


def export_folder(out_xml: str, folder_name: str, tracks, playlists,
                  track_colors=None) -> str:
    """Write a collection.xml: ONE folder named `folder_name` holding `playlists`
    (an ordered list of `(name, [track_id,...])`) as flat leaves — no sub-folders, so
    it browses as a simple ordered list on a CDJ/XDJ. The caller owns naming/order
    (e.g. "All", "Set 1 · Warm-up", "Block 1 · Warm-up"); this owns structure.
    `tracks` is the `microsets.Track` pool the ids refer to. Returns out_xml.
    """
    # Synthesize integer TrackIDs. rekordbox's XML import requires numeric TrackIDs;
    # a track's logical id can be an ISRC or title (e.g. freshly downloaded tracks not
    # yet in rekordbox), which rekordbox fails to import — every such track then aliases
    # onto a single COLLECTION entry. Map each logical id to a sequential integer, used
    # consistently across the COLLECTION and every playlist node. (export_playlist does
    # the same; this brings the block/set export in line.)
    collection: dict[str, dict] = {}
    tid_of: dict = {}                 # logical t.id -> integer TrackID (str)
    for t in tracks:
        if not t.path:
            continue                  # rekordbox can't import a track without a Location
        if t.id in tid_of:
            continue                  # referenced twice → a single COLLECTION entry
        tid = str(len(tid_of) + 1)
        tid_of[t.id] = tid
        collection[tid] = {
            "name": t.name,
            "artist": t.artist,
            "location": t.path,
            "bpm": t.bpm,
            "key": t.key,
            "genre": t.style or "",
            "colour": (track_colors or {}).get(t.id),
        }

    def _ids(ids):
        return [tid_of[i] for i in ids if i in tid_of]

    # One flat folder, playlists in caller order. rekordbox folders can't hold tracks
    # directly, so the playlists live as leaves under it — no nested folders to dive
    # into on the XDJ, just a scrollable ordered list.
    folder = NodeSpec(folder_name, is_folder=True,
                      children=[NodeSpec(name, track_ids=_ids(ids))
                                for name, ids in playlists])

    tree = build_collection_xml(collection, [folder])
    ET.indent(tree, space="  ")
    tree.write(out_xml, encoding="UTF-8", xml_declaration=True)
    return out_xml
