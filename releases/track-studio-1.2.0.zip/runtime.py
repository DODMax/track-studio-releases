"""Shared runtime state for the Track Studio app + the helpers that operate on it.

Owns the three process-wide singletons every page reads — the in-memory `library`,
the pending `download_batches`, and a lazy Spotify client — plus export/scan helpers
and the startup `_bootstrap`. These are only ever *mutated*, never rebound: import
this module (`import runtime`) and reference `runtime.library` / `runtime.download_batches`
so a later rebinding can't strand a stale alias.

Leaf relative to the UI: imports domain modules only, never `widgets` / `shell` / `pages`.
"""
from __future__ import annotations

from pathlib import Path

import rekordbox
import rekordbox_io
from library import Library
from spotify import Spotify
from staging import STAGE_DIR
from store import RekordboxSnapshot, default_export_file, load_studio_state

library = Library()

# pending download batches (on disk, not-yet-in-rekordbox), keyed by playlist name
download_batches: dict[str, list] = {}

# a shared Spotify client (lazy — token is cached, so this is headless)
_spotify = {"client": None}


# play history — lazily read and cached for the process. Walking the history tree
# means resolving every logged track against the collection, so it's a page-open
# cost we pay once rather than on every render.
history_state: dict = {"sessions": [], "gigs": [], "membership": {},
                       "energy_cache": {}, "loaded": False}

# the learned mixing model (mixmodel.MixModel), derived from history_state.
# Cached separately so pages can hold a reference; reset whenever history is
# (re)read so the two can't drift apart.
mix_state: dict = {"model": None}


def new_build_session() -> dict:
    """A fresh Build working session — the pool, its blocks, and the set."""
    return {
        # --- pool ---
        "pool_ids": [],          # ticked playlist nodes (multi-select)
        "node_id": None,         # single-click selection
        "batch_name": None,      # a pending download batch
        "pool_name": "",
        "pool_names": [],
        "pool": [],              # microsets.Track list, deduped
        "excluded": [],          # dropped for having no BPM
        "include_dl": True,
        "title": "",
        "n_dl": 0,
        # --- blocks (clustered lazily) ---
        "blocks": [],
        "clustered": False,
        "preset": None,          # microsets.BlockPreset; the page fills the default
        # --- the set ---
        "entries": [],           # list[microsets.SetEntry]
        "cursor": None,          # step being auditioned; None = the live tail
        "insert_at": None,       # picks land after this step; None = append
        "grain": "track",        # track | block
        "energy_dir": 1,
        "valence_dir": 0,
        "offset": 0,
        "scope": "pool",         # pool | companions | library
        "draft_name": None,      # the draft this session was resumed from/saved as
        # Has this process taken ownership of the autosaved session on disk?
        # Until it has, an empty set must not overwrite it (see `_autosave`).
        "session_loaded": False,
    }


# The Build page's working session. It lives here rather than in the page
# function because a NiceGUI page body re-runs from scratch on every visit:
# held there, an hour of set-building evaporated the moment you clicked another
# tab. Only ever mutated (`import runtime; runtime.build_state[...]`), and it
# holds no UI elements — those die with their client. `drafts` is the on-disk
# half, for picking a set back up after a restart.
build_state: dict = new_build_session()


def new_setline_session() -> dict:
    """The Download page's Setline import — the dropped set and where it stands."""
    return {
        "export": None,      # the parsed .setline.json
        "plan": None,        # setline_import.Plan, matched against the library
        "moments": None,     # the slice: kept moment names; None = all of them
        "added_by": None,    # the slice: kept contributors; None = all of them
        "failed": {},        # beatport id -> what beatportdl said it couldn't do
        "batch": None,       # the download batch folder a fetch landed in
    }


# The Setline import, for the same reason `build_state` exists: the Download
# page re-runs from scratch on every visit, so the dropped set, its match
# against the library and the slice you'd narrowed it to all evaporated the
# moment you clicked Library to analyze what you'd just fetched — which is
# exactly the trip the workflow asks you to make. Mutated, never rebound.
setline_state: dict = new_setline_session()


def _sp() -> Spotify:
    if _spotify["client"] is None:
        _spotify["client"] = Spotify()
    return _spotify["client"]


def load_history(force: bool = False) -> dict:
    """Read + classify rekordbox's play history into gigs. Cached; `force` re-reads.

    Playlist attribution reuses `library.rekordbox_index` when the library has
    already merged rekordbox (the usual case after `_bootstrap`), so opening the
    page costs one history read rather than a second full collection read.
    """
    if history_state["loaded"] and not force:
        return history_state

    import history

    sessions = history.load_sessions()
    index = library.rekordbox_index
    if not index:
        try:
            index = rekordbox.from_live().playlist_index
        except Exception as e:
            print(f"[history] playlist attribution unavailable: {e}")
            index = {}
    history_state.update(
        sessions=sessions,
        gigs=history.build_gigs(sessions),
        membership=history.build_membership(index) if index else {},
        energy_cache={},
        loaded=True,
    )
    mix_state["model"] = None          # derived from history — rebuild lazily
    return history_state


def mix_model(force: bool = False):
    """The learned mixing model (see `mixmodel`), built lazily and cached.

    Slow on first call (history read + one file-tag read per played track for
    the Δenergy profile) — call from a background thread like `load_history`.
    `force` re-reads history and rebuilds.
    """
    st = load_history(force)
    if mix_state["model"] is None:
        import mixmodel
        mix_state["model"] = mixmodel.build(
            st["gigs"], st["membership"], energy_cache=st["energy_cache"])
    return mix_state["model"]


def _dl_root() -> Path:
    return Path(load_studio_state().get("download_root") or str(STAGE_DIR)).expanduser()


def refresh_batches() -> None:
    """Re-scan the download root for per-playlist batches of pending tracks."""
    download_batches.clear()
    for name, tracks in library.scan_download_batches(_dl_root()):
        download_batches[name] = tracks


# How many tracks look like they might have stitched audio, from the free
# signals alone (see `integrity.worth_probing`). A count, never a verdict: it
# reads tags and compares them to the BPM rekordbox measured, and decodes
# nothing. Proving it needs `Library → Check for problems`.
integrity_hint: dict = {"suspect": 0, "checked": 0, "scanned": False}


def scan_integrity_hint() -> dict:
    """Count the suspect files, for free, so the app can mention them unprompted.

    The whole point is that this costs nothing: no ffprobe, no decoding, just a
    tag read per track. A library of stitched downloads currently announces
    itself only once you notice a beatgrid won't sit still — which took months.
    """
    import integrity

    # Only the encoder signal is counted here: a BPM that merely disagrees is
    # often an honest live edit, and a headline number that cries wolf is one
    # nobody reads twice. `scan_remuxed` caches against mtime+size, so the first
    # run pays the tag read and later ones pay a stat.
    remuxed = integrity.scan_remuxed([t.local_path for t in library.tracks
                                      if t.local_path])
    integrity_hint.update(suspect=sum(1 for v in remuxed.values() if v),
                          checked=len(remuxed), scanned=True)
    return integrity_hint


def start_integrity_hint() -> None:
    """Kick the hint off on a daemon thread, because it isn't as free as it looks.

    "Tags only, no decoding" still means opening every file in the library:
    measured at 14s over 2377 tracks, which is not something to add to a launch
    that already takes 16s. Nobody is waiting on this number — it only has to
    arrive before someone looks at it — so it runs behind the app and the header
    renders whatever `integrity_hint` holds at the time (0 until it lands).
    """
    import threading

    def _work():
        try:
            hint = scan_integrity_hint()
            if hint["suspect"]:
                print(f"[integrity] {hint['suspect']} of {hint['checked']} tracks may "
                      f"have stitched audio (Library → Check for problems)")
        except Exception as e:
            print(f"[integrity] hint failed: {e}")

    threading.Thread(target=_work, name="integrity-hint", daemon=True).start()


def _safe_ui(fn) -> None:
    """Run a UI update, swallowing the error if the client (browser tab) is gone.

    Long background jobs (download + analysis) can outlive the websocket; once a
    client is deleted, touching its elements raises RuntimeError. Callers use this
    so a disconnected tab never crashes the task or skips later cleanup."""
    try:
        fn()
    except RuntimeError:
        pass


def export_path() -> Path:
    """The single, stable rekordbox-import file. Every export (sync / batch /
    build) overwrites this one file, so rekordbox's xml view can be pointed
    at it once and just refreshed to see the latest export. Configurable globally
    (Settings); defaults to <download root>/track-studio.xml."""
    cfg = load_studio_state().get("export_file")
    p = Path(cfg).expanduser() if cfg else default_export_file(_dl_root())
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def export_batch_xml(name: str, tracks: list) -> tuple[str, int]:
    """Write a one-playlist rekordbox XML for a batch to the fixed export file."""
    items = [{"name": t.title, "artist": t.artist, "location": Path(t.local_path),
              "bpm": t.bpm, "key": t.key, "genre": t.style or ""}
             for t in tracks if t.local_path]
    out = str(export_path())
    n = rekordbox_io.export_playlist(out, name, items)
    return out, n


def _bootstrap() -> None:
    """Restore the last-loaded library once at process start, so the app opens
    ready instead of needing the Load buttons clicked every launch."""
    st = load_studio_state()
    if st.get("rekordbox"):
        try:
            library.merge_rekordbox(rekordbox.from_live(), snapshot=RekordboxSnapshot())
            print(f"[bootstrap] merged rekordbox ({len(library.rekordbox_index)} playlists)")
        except Exception as e:
            print(f"[bootstrap] rekordbox load failed: {e}")
    folder = st.get("folder")
    if folder and Path(folder).is_dir():
        try:
            n = library.add_folder(Path(folder))
            print(f"[bootstrap] added folder: {folder} (+{n} tracks)")
        except Exception as e:
            print(f"[bootstrap] folder load failed: {e}")
    # Load previously-downloaded files so the Sync gap sees them as "downloaded"
    # (not "missing") on a fresh start, even before visiting the Library page.
    try:
        refresh_batches()
        if download_batches:
            print(f"[bootstrap] download batches: "
                  f"{ {n: len(t) for n, t in download_batches.items()} }")
    except Exception as e:
        print(f"[bootstrap] batch scan failed: {e}")
    start_integrity_hint()
