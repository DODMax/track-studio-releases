"""Bring a set planned in Setline into Track Studio.

Setline (the shared, online set planner) exports a `.setline.json`: the set in
order, its moments, each track's mix points, Beatport id and ISRC. This turns
that file into Track Studio's own terms:

1. **Match** every track against the library — Beatport id, then ISRC, then
   `dupes.Index` (the same "do I already have this?" check the Download page
   runs, remix-credit guard included).
2. **Fetch** what's missing from Beatport through beatportdl, into one download
   batch named after the set, so it analyses and exports like any other batch.
3. **Export it to rekordbox** (`to_playlists`) — the set in order, one playlist
   per moment, straight out to `runtime.export_path()`. A set that arrived
   already programmed is playable tonight without a detour through Build; going
   through Build is for *re*-programming it.
4. Or **save a Build draft**: the set's tracks in order, each carrying its moment
   as the entry's role, pooled with everything matched or fetched. Build needs a
   BPM to place a track, so a match without one waits for analysis. Opening the
   draft in Build is where it meets the mixing model.

Tracks Setline has that Beatport doesn't (typed in by hand) can't be fetched;
they're listed with their link and left out of the draft until they're in the
library.

A whole set is rarely what you want at once: `Plan.keep_moments` /
`Plan.keep_added_by` narrow it to some moments, some of the people who planned
it, or both — `Plan.selected` is what every count, download and draft then works
on. A b2b's export carries the other DJ's picks too, and the hour you're
actually preparing is one moment of five; both are a filter, not a second file.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Optional

import dupes

FORMAT = "setline-set"
HAVE, POSSIBLE, FETCH, MANUAL = "have", "possible", "fetch", "manual"


class ImportError_(ValueError):
    """The file isn't a Setline set this version understands; the message says why."""


@dataclass
class Row:
    """One track of the set, and where Track Studio stands with it."""
    position: int
    moment: str
    clock: str
    title: str
    artists: list[str]
    bpm: Optional[int]
    key: Optional[str]
    isrc: Optional[str]
    beatport_id: Optional[int]
    source: str
    link: Optional[str]
    added_by: str = ""
    have: Optional[dupes.Existing] = None
    by_beatport_id: Optional[object] = None  # library.Track with the same Beatport id

    @property
    def track(self):
        """The library track this row resolves to, or None."""
        if self.by_beatport_id is not None:
            return self.by_beatport_id
        return self.have.track if self.have else None

    @property
    def status(self) -> str:
        if self.by_beatport_id is not None or (self.have and self.have.certain):
            return HAVE
        if self.have:
            return POSSIBLE  # a name match worth confirming, not a fact
        return FETCH if self.beatport_id else MANUAL

    @property
    def display(self) -> str:
        return f"{', '.join(self.artists)} - {self.title}"


def _distinct(values) -> list[str]:
    """The non-empty values, deduped, in the order they first turn up."""
    out: list[str] = []
    for v in values:
        if v and v not in out:
            out.append(v)
    return out


@dataclass
class Plan:
    """The set against the library, and the slice of it you're taking.

    `rows` is always the whole set — the filter lives in `keep_moments` /
    `keep_added_by` (`None` meaning "all of them") so that narrowing costs
    nothing and widening again doesn't need a re-match against the library.
    Everything downstream reads `selected`.
    """
    name: str
    starts_at: str
    rows: list[Row] = field(default_factory=list)
    moment_colors: dict[str, str] = field(default_factory=dict)
    keep_moments: Optional[set[str]] = None
    keep_added_by: Optional[set[str]] = None

    @property
    def moment_names(self) -> list[str]:
        """The moments that actually carry a track, in set order."""
        return _distinct(r.moment for r in self.rows)

    @property
    def contributors(self) -> list[str]:
        """Who put tracks in the set, in the order they first appear."""
        return _distinct(r.added_by for r in self.rows)

    def keeps(self, row: Row) -> bool:
        return ((self.keep_moments is None or row.moment in self.keep_moments)
                and (self.keep_added_by is None or row.added_by in self.keep_added_by))

    @property
    def selected(self) -> list[Row]:
        return [r for r in self.rows if self.keeps(r)]

    @property
    def filtered(self) -> bool:
        return self.keep_moments is not None or self.keep_added_by is not None

    @property
    def selection_label(self) -> str:
        """The slice in a few words, for a draft's name: 'Peak Time · Max'."""
        parts = []
        for kept, every, plural in ((self.keep_moments, self.moment_names, "moments"),
                                    (self.keep_added_by, self.contributors, "DJs")):
            if kept is None:
                continue
            names = [n for n in every if n in kept]
            parts.append(" + ".join(names) if len(names) <= 2 else f"{len(names)} {plural}")
        return " · ".join(p for p in parts if p)

    def count(self, status: str) -> int:
        return sum(1 for r in self.selected if r.status == status)

    @property
    def to_fetch(self) -> list[int]:
        return [r.beatport_id for r in self.selected if r.status == FETCH]


def read(raw: bytes | str) -> dict:
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise ImportError_(f"That isn't a Setline set file (not JSON: {e.msg}).") from e
    if not isinstance(data, dict) or data.get("format") != FORMAT:
        raise ImportError_("That isn't a Setline set file. In Setline, use Export → Set file for Track Studio.")
    if data.get("version") != 1:
        raise ImportError_(f"This Setline file is version {data.get('version')}; Track Studio reads version 1. Update Track Studio.")
    return data


def plan(export: dict, library_tracks: list) -> Plan:
    """Where every track of the set stands against the library."""
    by_bp = {t.beatport_id: t for t in library_tracks if t.beatport_id and (t.local_path or t.in_rekordbox)}
    idx = dupes.Index(library_tracks)
    out = Plan(name=export.get("name") or "Setline set", starts_at=export.get("starts_at") or "",
               moment_colors={m.get("name", ""): m.get("color") or ""
                              for m in export.get("moments") or []})
    for t in export.get("tracks") or []:
        row = Row(
            position=t.get("position", len(out.rows) + 1), moment=t.get("moment") or "", clock=t.get("clock") or "",
            title=t.get("display_title") or t.get("title") or "", artists=t.get("artists") or [],
            bpm=t.get("bpm"), key=t.get("key"), isrc=t.get("isrc"), beatport_id=t.get("beatport_id"),
            source=t.get("source") or "beatport", link=t.get("link"),
            added_by=t.get("added_by") or "",
        )
        row.by_beatport_id = by_bp.get(row.beatport_id) if row.beatport_id else None
        if row.by_beatport_id is None:
            row.have = idx.lookup(", ".join(row.artists), row.title, isrc=row.isrc)
        out.rows.append(row)
    return out


def batch_name(set_name: str) -> str:
    """The download batch folder for a set's missing tracks: 'Setline - Sunday b2b'."""
    clean = re.sub(r'[\\/:*?"<>|]+', " ", set_name).strip() or "set"
    return f"Setline - {clean}"[:80]


def export_name(p: Plan) -> str:
    """The rekordbox folder a set exports into — the set's name, and nothing else.

    Deliberately *not* narrowed by the slice, unlike a draft's name. The folder
    is the handle you grab in rekordbox to delete the last import before
    dragging in the next one, and that only works if re-exporting lands on the
    same name. A slice that renamed the folder would leave the previous one
    sitting there beside it, and you'd be merging two half-sets by hand.

    Which slice it was still shows in the export dialog's summary; it just
    doesn't reach rekordbox.
    """
    return p.name


def set_track_id(track) -> str:
    """How Build identifies a track in drafts and pools (see library `_to_mix_track`)."""
    return track.rekordbox_id or track.isrc or track.display


def to_playlists(p: Plan) -> tuple[list, list[tuple[str, list[str]]]]:
    """The selected tracks in `rekordbox_io.export_folder`'s terms: (tracks, playlists).

    One playlist is the set in order; a slice spanning several moments gets one
    leaf per moment as well, so the sections are browsable on the CDJ.

    Only rows with a local file, because rekordbox matches an imported TRACK by
    its Location and one without a path is an entry it could never place. A BPM
    is *not* required, unlike a Build draft: an un-analyzed track still plays.
    """
    from library import Library

    pool, by_id = [], {}
    per_moment: dict[str, list[str]] = {}
    for r in p.selected:
        t = r.track
        if t is None or not t.local_path:
            continue
        tid = set_track_id(t)
        if tid not in by_id:
            by_id[tid] = Library._to_mix_track(t)
            pool.append(by_id[tid])
        ids = per_moment.setdefault(r.moment or "—", [])
        if tid not in ids:                  # a track played twice is one entry
            ids.append(tid)
    if not pool:
        return [], []
    playlists = [("Set", [t.id for t in pool])]
    if len(per_moment) > 1:
        playlists += [(f"{i} · {name}", ids)
                      for i, (name, ids) in enumerate(per_moment.items(), 1)]
    return pool, playlists


def to_draft(p: Plan, *, include_possible: bool = True):
    """The selected tracks as a Build draft: in order, moment as each entry's role.

    No batch name on purpose: a draft resumed from a batch pools only that batch,
    and most of a set is usually tracks you already own. The id list brings back
    all of them, downloaded or not.

    A filtered plan makes a draft of its own — the slice is in the name and the
    pool, so "the Peak Time hour" and "everything Max picked" can sit side by
    side in Build → Drafts without either being the other's leftovers.
    """
    import drafts

    slice_ = p.selection_label
    usable = [r for r in p.selected
              if r.track is not None and r.track.bpm and (include_possible or r.status == HAVE)]
    ids: list[str] = []
    for r in usable:
        if set_track_id(r.track) not in ids:
            ids.append(set_track_id(r.track))
    return drafts.Draft(
        name=drafts.unique_name(f"{p.name}{' · ' + slice_ if slice_ else ''} (Setline)"),
        pool_name=f"Setline · {p.name}" + (f" · {slice_}" if slice_ else ""),
        pool_track_ids=ids,
        entries=[{"track_id": set_track_id(r.track), "block_id": None, "role": r.moment or None} for r in usable],
    )


if __name__ == "__main__":
    # Dry run against the live library, optionally on one slice of the set:
    #   python setline_import.py set.setline.json [--moment "Peak Time"] [--by Max]
    # Both repeat, and the counts are the ones the Download page would show.
    import sys

    import runtime

    args = sys.argv[1:]
    path = args[0]
    moments = {args[i + 1] for i, a in enumerate(args) if a == "--moment"} or None
    people = {args[i + 1] for i, a in enumerate(args) if a == "--by"} or None

    runtime._bootstrap()
    with open(path, "rb") as f:
        pl = plan(read(f.read()), runtime.library.tracks)
    pl.keep_moments, pl.keep_added_by = moments, people
    print(f"moments: {', '.join(pl.moment_names)}")
    print(f"added by: {', '.join(pl.contributors)}")
    print(f"{pl.name}: {len(pl.selected)} of {len(pl.rows)} tracks"
          + (f" ({pl.selection_label})" if pl.filtered else "")
          + f" — have {pl.count(HAVE)}, possible {pl.count(POSSIBLE)}, "
          f"fetch {pl.count(FETCH)}, not on Beatport {pl.count(MANUAL)}")
    for r in pl.selected:
        print(f"  {r.clock}  [{r.status:>8}]  {r.moment:<12} {r.added_by:<10} {r.display}")
