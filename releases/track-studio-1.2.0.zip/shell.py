"""App shell — theme, header/nav, and the global Settings dialog.

Independent of `runtime` (no shared mutable state): `settings_dialog` computes its
defaults inline from `load_studio_state()` / `STAGE_DIR`. Both `header` and the Sync
page import `settings_dialog` from here, so keeping this module runtime-free avoids
an import cycle.
"""
from __future__ import annotations

from pathlib import Path

from nicegui import run, ui

import rbprefs
import updates
from staging import STAGE_DIR
from store import (default_export_file, load_studio_state,
                   save_download_root, save_inbox_folder)


# The skin + behaviour behind `widgets.audio_player`. The stock <audio> control
# bar is a fixed light-grey slab that can't be themed, so we hide it and drive a
# plain `<audio>` element ourselves. All of it is delegated off `document`: one
# set of listeners covers every player on the page, including ones added later
# by a re-render, and playback state never crosses the websocket.
PLAYER_ASSETS = """
<style>
  /* Seek bar on its own full-width line, transport underneath — auditioning
     is mostly scrubbing, so the bar gets the width and the button tucks under. */
  /* Fills its container, but capped: past ~560px the extra width buys no
     seeking precision and the bar starts to look like a progress meter. */
  .ts-player {
    display:flex; flex-direction:column; gap:5px;
    width:100%; max-width:560px; min-width:0;
  }
  .ts-player audio { display:none; }
  .ts-under { display:flex; align-items:center; gap:8px; min-width:0; }
  .ts-play {
    flex:0 0 auto; width:26px; height:26px; padding:0; border-radius:50%;
    border:1px solid #3a3f47; background:#1b1e24; color:#ff7a1a; cursor:pointer;
    display:flex; align-items:center; justify-content:center; transition:.12s;
  }
  .ts-play:hover { background:#24272f; border-color:#ff7a1a; }
  .ts-i-pause, .ts-player.is-playing .ts-i-play { display:none; }
  .ts-player.is-playing .ts-i-pause { display:block; }
  /* Playing: the button inverts to a solid orange disc and breathes, so one
     glance down twenty identical rows finds the one making noise. Only one
     player runs at a time (see the `play` listener below), so exactly one of
     these is ever lit. */
  .ts-player.is-playing .ts-play {
    background:#ff7a1a; border-color:#ff7a1a; color:#0e0f13;
    animation:ts-pulse 1.9s ease-out infinite;
  }
  .ts-player.is-playing .ts-play:hover { background:#ff8f3d; border-color:#ff8f3d; }
  @keyframes ts-pulse {
    0%   { box-shadow:0 0 0 0 rgba(255,122,26,.5); }
    70%  { box-shadow:0 0 0 8px rgba(255,122,26,0); }
    100% { box-shadow:0 0 0 0 rgba(255,122,26,0); }
  }
  /* The clock and the bar wake up with it — the row reads as live, not just
     the button. */
  .ts-player.is-playing .ts-time { color:#e6e8ea; }
  .ts-player.is-playing .ts-bar { background:#343841; }
  .ts-player.is-playing .ts-fill::after {
    box-shadow:0 0 0 2px #16181d, 0 0 9px rgba(255,122,26,.85);
  }
  /* A halo that doesn't move, for anyone who'd rather it didn't. */
  @media (prefers-reduced-motion: reduce) {
    .ts-player.is-playing .ts-play {
      animation:none; box-shadow:0 0 0 3px rgba(255,122,26,.35);
    }
  }
  .ts-bar {
    position:relative; width:100%; height:8px; border-radius:4px;
    background:#2a2d35; cursor:pointer; touch-action:none;
  }
  /* invisible padding so the 8px bar is a forgiving scrub target */
  .ts-bar::after { content:''; position:absolute; left:0; right:0; top:-7px; bottom:-7px; }
  .ts-buf, .ts-fill { position:absolute; left:0; top:0; height:100%; border-radius:4px; }
  .ts-buf { background:#3a3f47; width:0; }
  .ts-fill { background:#ff7a1a; width:0; }
  /* playhead knob — rides the fill's right edge so the position is legible
     even when the elapsed portion is a sliver */
  .ts-fill::after {
    content:''; position:absolute; right:-5px; top:50%; width:10px; height:10px;
    margin-top:-5px; border-radius:50%; background:#ff7a1a;
    box-shadow:0 0 0 2px #16181d; transition:transform .12s;
  }
  .ts-bar:hover .ts-fill::after { transform:scale(1.25); }
  .ts-time {
    font-family:monospace; font-size:11px; color:#9aa0a8;
    font-variant-numeric:tabular-nums;
  }
  .ts-compact .ts-time { font-size:10px; }
  .ts-compact .ts-play { width:22px; height:22px; }
  .ts-compact .ts-bar { height:6px; }
</style>
<script>
(function () {
  const clock = s => (!isFinite(s) || s < 0) ? '–:––'
    : Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');

  function paint(a) {
    const p = a.closest('.ts-player'); if (!p) return;
    const d = a.duration;
    p.querySelector('.ts-fill').style.width =
      (isFinite(d) && d ? (a.currentTime / d * 100) : 0) + '%';
    if (a.buffered.length && isFinite(d) && d) {
      p.querySelector('.ts-buf').style.width =
        (a.buffered.end(a.buffered.length - 1) / d * 100) + '%';
    }
    p.querySelector('.ts-time').textContent = clock(a.currentTime) + ' / ' + clock(d);
  }

  // Grabbing the bar on a stopped player starts it: you scrub to hear that part
  // of the track, so a seek that leaves it silent is never what was meant.
  function seek(bar, clientX) {
    const p = bar.closest('.ts-player'); if (!p) return;
    const a = p.querySelector('audio');
    const r = bar.getBoundingClientRect();
    const frac = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
    if (isFinite(a.duration) && a.duration) {
      a.currentTime = frac * a.duration;
      paint(a);
    } else {
      // `preload=none` (the table rows): no duration yet, so the seek has
      // nothing to land on. Park it, paint the intent, and let the play below
      // pull the metadata in — `loadedmetadata` applies it.
      a.dataset.tsSeek = frac;
      p.querySelector('.ts-fill').style.width = (frac * 100) + '%';
    }
    if (a.paused) a.play().catch(() => {});
  }

  // A seek asked for before the duration was known lands here. Registered
  // ahead of the paint listeners so they see the corrected currentTime.
  document.addEventListener('loadedmetadata', e => {
    const a = e.target;
    if (!(a instanceof HTMLAudioElement) || a.dataset.tsSeek === undefined) return;
    const frac = parseFloat(a.dataset.tsSeek);
    delete a.dataset.tsSeek;
    if (isFinite(frac) && isFinite(a.duration)) a.currentTime = frac * a.duration;
  }, true);

  document.addEventListener('click', e => {
    const btn = e.target.closest('.ts-play');
    if (!btn) return;
    const a = btn.closest('.ts-player').querySelector('audio');
    a.paused ? a.play() : a.pause();
  });

  // Scrub: grab the bar, keep tracking on the document so the pointer may
  // wander off the 6px strip mid-drag.
  let dragging = null;
  document.addEventListener('pointerdown', e => {
    const bar = e.target.closest('.ts-bar');
    if (!bar) return;
    dragging = bar; seek(bar, e.clientX); e.preventDefault();
  });
  document.addEventListener('pointermove', e => { if (dragging) seek(dragging, e.clientX); });
  document.addEventListener('pointerup', () => { dragging = null; });

  // Media events don't bubble — listen on the capture phase instead.
  for (const ev of ['timeupdate', 'loadedmetadata', 'durationchange', 'progress', 'seeked']) {
    document.addEventListener(ev, e => {
      if (e.target instanceof HTMLAudioElement) paint(e.target);
    }, true);
  }
  for (const [ev, on] of [['play', true], ['playing', true], ['pause', false], ['ended', false]]) {
    document.addEventListener(ev, e => {
      if (!(e.target instanceof HTMLAudioElement)) return;
      const p = e.target.closest('.ts-player');
      if (p) p.classList.toggle('is-playing', on);
    }, true);
  }

  // Only one preview at a time: starting any player pauses the rest.
  document.addEventListener('play', e => {
    if (!(e.target instanceof HTMLMediaElement)) return;
    document.querySelectorAll('audio, video').forEach(m => { if (m !== e.target) m.pause(); });
  }, true);
})();
</script>
"""


def apply_theme() -> None:
    """Dark theme with orange accent — applied on every page."""
    ui.dark_mode().enable()
    ui.colors(
        primary="#ff7a1a",      # orange accent
        secondary="#2dd4bf",    # teal (rekordbox "in")
        accent="#ff7a1a",
        dark="#16181d",         # surfaces (header, drawer, cards)
        dark_page="#0e0f13",    # page background
        positive="#3fb950",
        negative="#f85149",
        warning="#d29922",
        info="#58a6ff",
    )
    ui.add_head_html("""
    <style>
      /* The page's own colour, on the document itself and before anything else.
         Quasar paints `dark_page` once its stylesheet is in, and a nav between
         pages is a full load — so between the two there's a moment with no
         stylesheet at all, which the webview fills with white. A rule on `html`
         lands in the first paint, so the gap is the app's colour instead. */
      html, body, #q-app { background: #0e0f13; color-scheme: dark; }
      .q-table tbody tr { cursor: pointer; }
      .q-table { background: transparent; }
      .q-table thead th { color:#9aa0a8; font-weight:600; letter-spacing:.03em; }
      .q-table tbody tr:hover { background: rgba(255,122,26,.08) !important; }
      .q-tree__node-header:hover { background: rgba(255,122,26,.10); border-radius:6px; }
      .q-tree__node-header.q-tree__node--selected {
        color:#ff7a1a; font-weight:600;
        background: rgba(255,122,26,.16); border-radius:6px;
      }
      .surface { background:#16181d; border:1px solid #23262d; border-radius:12px; }
      ::-webkit-scrollbar { width:10px; height:10px; }
      ::-webkit-scrollbar-thumb { background:#2a2d35; border-radius:6px; }
    </style>
    """)
    ui.add_head_html(PLAYER_ASSETS)


def settings_dialog() -> None:
    """Quick settings — the two folders. The export file is deliberately absent:
    the user never needs to *know* that path except during the one-time rekordbox
    wiring, which the Settings page verifies and hands over with a copy button."""
    import inbox
    st = load_studio_state()
    dl = st.get("download_root") or str(STAGE_DIR)
    ex = st.get("export_file") or str(default_export_file(dl))
    ib = st.get("inbox_folder") or str(inbox.default_folder())
    with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[34rem]"):
        ui.label("Settings").classes("text-subtitle1 text-weight-bold")
        dl_in = ui.input("Download root folder", value=dl) \
            .props("outlined dense").classes("w-full")
        ui.label("Beatport downloads land here, in a per-playlist subfolder.") \
            .classes("text-caption text-grey")
        ib_in = ui.input("Downloads inbox folder", value=ib) \
            .props("outlined dense").classes("w-full")
        ui.label("Where the Download page looks for files you grabbed in the "
                 "browser (free-download gates, Bandcamp, promo mail).") \
            .classes("text-caption text-grey")
        with ui.row().classes("items-center gap-1 no-wrap w-full"):
            ui.label(f"Exports write to {ex}").classes("text-caption ellipsis") \
                .style("color:#6b7280; min-width:0").tooltip(ex)
            ui.link("manage", "/settings").classes("text-caption")

        def _save():
            # The root save may relocate a not-yet-written export file (see
            # store.save_download_root) — read it back to report the move.
            if dl_in.value.strip():
                save_download_root(str(Path(dl_in.value).expanduser()))
            # Blank restores the ~/Downloads default rather than saving "".
            save_inbox_folder(str(Path(ib_in.value).expanduser())
                              if ib_in.value.strip() else None)
            now = load_studio_state().get("export_file") or ""
            moved = now and now != ex
            d.close()
            ui.notify(f"Settings saved — export file moved to {now}" if moved
                      else "Settings saved", type="positive",
                      timeout=9000 if moved else 3000)

        with ui.row().classes("justify-end w-full gap-2"):
            ui.button("Cancel", on_click=d.close).props("flat color=grey")
            ui.button("Save", on_click=_save).props("unelevated color=primary")
    d.open()


def update_dialog(rec: dict) -> None:
    """What's in the new version, and the one button that installs it.

    The install outlives this dialog and this server: `apply_update.py` stops the
    app to replace its files, so the page can't be told when it's done — it waits
    for `/api/version` to answer with the new number instead, and reloads itself.
    That waiting is plain JavaScript on purpose: NiceGUI's socket dies with the
    server it belongs to, and this has to survive that.
    """
    with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[34rem]"):
        with ui.row().classes("items-center gap-2 w-full no-wrap"):
            ui.label(f"Track Studio {rec['version']}").classes("text-subtitle1 text-weight-bold")
            ui.label(f"you're on {updates.current_version()}").classes("text-caption text-grey")
        if rec.get("notes"):
            ui.markdown(rec["notes"]).classes("text-body2").style("max-height:14rem; overflow:auto")
        ui.label("Your library, settings, downloads and drafts are untouched — only the app's own "
                 "files are replaced, and the old ones come back if the new version doesn't start.") \
            .classes("text-caption text-grey")
        status = ui.label().classes("text-caption")
        row = ui.row().classes("justify-end w-full gap-2 items-center")

        async def _install() -> None:
            row.clear()
            with row:
                ui.spinner(size="sm")
            status.text = "Downloading…"
            try:
                staged = await run.io_bound(updates.prepare, rec)
            except Exception as e:                       # noqa: BLE001 — the message is the point
                status.text = str(e)
                status.classes(replace="text-caption text-negative")
                with row:
                    ui.button("Close", on_click=d.close).props("flat color=grey")
                return
            status.text = "Installing — Track Studio will restart in a moment."
            updates.launch_apply(staged, rec)
            ui.run_javascript(_WAITING_JS.replace("__VERSION__", rec["version"]))

        with row:
            ui.button("Skip this version", on_click=lambda: (updates.skip(rec["version"]), d.close())) \
                .props("flat color=grey")
            ui.button("Later", on_click=d.close).props("flat color=grey")
            ui.button("Install and restart", on_click=_install).props("unelevated color=primary")
    d.open()


# Shown while the server is being replaced under us: the page is on its own from
# here, so this is deliberately dependency-free and survives the socket dropping.
_WAITING_JS = """
(() => {
  const want = "__VERSION__";
  const el = document.createElement('div');
  el.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0e0f13;color:#e6e8ea;'
    + 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;'
    + 'font:15px -apple-system,system-ui,sans-serif';
  el.innerHTML = '<div style="font-size:17px;font-weight:600">Installing Track Studio ' + want + '</div>'
    + '<div id="ts-up-note" style="color:#9aa0a8">Stopping the server…</div>';
  document.body.appendChild(el);
  const note = el.querySelector('#ts-up-note');
  const started = Date.now();
  const tick = async () => {
    const waited = Math.round((Date.now() - started) / 1000);
    try {
      const r = await fetch('/api/version', { cache: 'no-store' });
      const j = await r.json();
      if (j.version === want) { note.textContent = 'Done — reloading'; location.reload(); return; }
      note.textContent = 'Waiting for the new version to start… (' + waited + 's)';
    } catch (e) {
      note.textContent = 'Restarting… (' + waited + 's)';
    }
    if (waited > 180) {
      note.innerHTML = 'This is taking longer than it should. Open Track Studio again from '
        + 'Spotlight — the old version comes back on its own if the new one fails to start.';
      return;
    }
    setTimeout(tick, 1500);
  };
  setTimeout(tick, 2500);
})();
"""


def _setup_alert() -> bool:
    """Whether required first-run setup is incomplete — the red dot on the ⚙.

    Runs on every page render, so file reads only (no DB, no network): has the
    rekordbox DB ever been read, and is rekordbox watching the export file?
    Spotify/Beatport are feature-gated, not required, so they don't gate here.
    """
    try:
        st = load_studio_state()
        if not st.get("rekordbox"):
            return True
        dl = st.get("download_root") or str(STAGE_DIR)
        ex = st.get("export_file") or str(default_export_file(dl))
        return not rbprefs.evaluate(ex).ok
    except Exception:
        return False    # never let the badge break the header


def header(active: str) -> None:
    """Shared app header with nav + global settings."""
    with ui.header().classes("items-center justify-between").style(
            "background:#16181d; border-bottom:1px solid #23262d"):
        with ui.row().classes("items-center gap-2"):
            ui.label("🎚️").classes("text-h6")
            ui.label("Track Studio").classes("text-h6 text-weight-bold") \
                .style("color:#ff7a1a")
        with ui.row().classes("items-center gap-1"):
            for label, path in (("Download", "/download"), ("Sync", "/sync"),
                                ("Library", "/"), ("Build", "/build"),
                                ("Histories", "/history")):
                btn = ui.button(label, on_click=lambda p=path: ui.navigate.to(p)) \
                    .props("flat no-caps" + (" color=primary" if active == label else " color=white"))
                if active == label:
                    btn.classes("text-weight-bold")
            # A release waiting, if one is. Reads the last check's answer off disk —
            # no network on a page render — and looks again every minute so a find
            # by the background check shows up without navigating anywhere.
            waiting = ui.row().classes("items-center")

            def _paint_update() -> None:
                rec = updates.available()
                waiting.clear()
                if not rec:
                    return
                with waiting:
                    ui.button(f"Update {rec['version']}", icon="arrow_circle_up",
                              on_click=lambda r=rec: update_dialog(r)) \
                        .props("flat dense no-caps color=primary") \
                        .tooltip(f"Track Studio {rec['version']} is out — see what changed")

            _paint_update()
            ui.timer(60.0, _paint_update)

            alert = _setup_alert()
            with ui.button(icon="settings",
                           on_click=lambda: ui.navigate.to("/settings")) \
                    .props("flat round color=white") as gear:
                if alert:
                    ui.badge().props("floating rounded color=negative") \
                        .style("width:10px; height:10px; padding:0")
            gear.tooltip("Finish setup in Settings" if alert else "Settings")
