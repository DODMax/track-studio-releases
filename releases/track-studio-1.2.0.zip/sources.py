"""Synced sources — durable bindings to Spotify playlists we sync from.

A source is bound by Spotify playlist ID (survives renames on either side); the
display name is refreshed on each pull. Optionally paired to a rekordbox playlist
so the Sync page can show the "in the set" signal alongside "in the collection".

Persisted as a small JSON list, same pattern as the rekordbox snapshot.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

from config import ROOT

SOURCES_PATH = ROOT / ".synced_sources.json"


@dataclass
class SyncedSource:
    spotify_playlist_id: str
    last_name: str = ""
    paired_rb_id: Optional[str] = None      # rekordbox playlist node id, or None
    paired_rb_name: Optional[str] = None
    last_synced: Optional[str] = None

    @property
    def rb_name(self) -> str:
        """The rekordbox-facing name of this source: the paired playlist's name,
        falling back to the Spotify name when unpaired. The download folder, the
        Library batch and the export are all keyed on this — keying them on
        `last_name` forks a second playlist whenever the pairing has a different
        name."""
        return self.paired_rb_name or self.last_name


class SourceStore:
    def __init__(self, path: Path = SOURCES_PATH) -> None:
        self.path = path

    def list(self) -> list[SyncedSource]:
        if not self.path.exists():
            return []
        try:
            data = json.loads(self.path.read_text())
        except (json.JSONDecodeError, OSError):
            return []
        return [SyncedSource(**d) for d in data]

    def _write(self, sources: list[SyncedSource]) -> None:
        self.path.write_text(json.dumps([asdict(s) for s in sources], indent=2,
                                        ensure_ascii=False))

    def get(self, spotify_playlist_id: str) -> Optional[SyncedSource]:
        return next((s for s in self.list()
                     if s.spotify_playlist_id == spotify_playlist_id), None)

    def upsert(self, source: SyncedSource) -> None:
        sources = [s for s in self.list()
                   if s.spotify_playlist_id != source.spotify_playlist_id]
        sources.append(source)
        self._write(sources)

    def rb_name_for_folder(self, folder: str) -> str:
        """The rekordbox playlist a download folder belongs to.

        Folders created before the source was paired (or before pairing was
        honoured) carry the *Spotify* name; exporting them under that name forks
        a new playlist instead of updating the paired set. Map those back onto
        the pairing. Unknown folders keep their own name.
        """
        key = folder.strip().lower()
        srcs = self.list()
        if any(s.rb_name.strip().lower() == key for s in srcs):
            return folder                       # already rekordbox-named
        for s in srcs:
            if s.last_name.strip().lower() == key:
                return s.rb_name                # legacy Spotify-named folder
        return folder

    def remove(self, spotify_playlist_id: str) -> None:
        self._write([s for s in self.list()
                     if s.spotify_playlist_id != spotify_playlist_id])
