"""Default download location.

Beatport downloads land in a per-playlist subfolder under a configurable root
(set on the Sync page; persisted as `download_root` in `.studio_state.json`).
`STAGE_DIR` is just the fallback root when none has been chosen. There is no
separate "staging" copy step — the download folder *is* the staging folder.
"""
from __future__ import annotations

from config import ROOT

STAGE_DIR = ROOT / "_stage"
