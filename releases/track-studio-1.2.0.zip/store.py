"""Local persistence — durable snapshot of rekordbox state.

The "removed from rekordbox" signal is temporal: the live DB only reports what is
present *now*. To know what *left*, we remember every rekordbox track we've ever
seen and diff against the current read.

This is a small JSON store (not SQLite yet — the live read of ~3k tracks is fast
enough that we don't need a query cache). It records, per rekordbox track id:
name, artist, source kind, path, and whether it was `present` in the latest read.
Entries are kept even after a track leaves rekordbox, so the removed list is
durable across sessions rather than a one-shot.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from config import ROOT

if TYPE_CHECKING:
    from rekordbox import RekordboxCollection

SNAPSHOT_PATH = ROOT / ".rekordbox_snapshot.json"
STATE_PATH = ROOT / ".studio_state.json"

# The one file every export overwrites, by default beside the downloads.
DEFAULT_EXPORT_NAME = "track-studio.xml"


def default_export_file(download_root) -> Path:
    return Path(download_root).expanduser() / DEFAULT_EXPORT_NAME


def _read_state() -> dict:
    if not STATE_PATH.exists():
        return {}
    try:
        return json.loads(STATE_PATH.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def save_studio_state(folder, rekordbox_loaded: bool) -> None:
    """Remember what was loaded so the app can restore it on next startup.
    Merges into the existing state so other keys (e.g. download_root) survive."""
    st = _read_state()
    st["folder"] = str(folder) if folder else None
    st["rekordbox"] = bool(rekordbox_loaded)
    STATE_PATH.write_text(json.dumps(st))


def save_download_root(path) -> None:
    """Persist the chosen download root, taking the export file with it when the
    export file doesn't exist yet.

    Pointing rekordbox's xml view at a path is a one-time manual setup, so an
    export file that exists is one the user may have already wired up — moving
    it would silently break that. A file that has never been written can't have
    been wired up, so it follows the downloads rather than being stranded in the
    old folder. Returns nothing; read `export_file` back if you need the result.
    """
    st = _read_state()
    st["download_root"] = str(path) if path else None
    if path:
        ex = st.get("export_file")
        if not ex or not Path(ex).expanduser().exists():
            st["export_file"] = str(default_export_file(path))
    STATE_PATH.write_text(json.dumps(st))


def save_export_file(path) -> None:
    """Persist the single rekordbox-import xml file path (used by all exports)."""
    st = _read_state()
    st["export_file"] = str(path) if path else None
    STATE_PATH.write_text(json.dumps(st))


def save_inbox_folder(path) -> None:
    """Persist where the Download page looks for browser-downloaded files.
    None/empty restores the default (`~/Downloads`)."""
    st = _read_state()
    st["inbox_folder"] = str(path) if path else None
    STATE_PATH.write_text(json.dumps(st))


def save_update_channel(channel: str) -> None:
    """Which releases this machine is offered: "stable", or "beta" to get them first."""
    st = _read_state()
    st["update_channel"] = channel
    STATE_PATH.write_text(json.dumps(st))


def save_rekordbox_db_path(path) -> None:
    """Persist an optional override for the rekordbox database directory
    (pyrekordbox auto-detects by default; set this only if detection fails)."""
    st = _read_state()
    st["rekordbox_db_path"] = str(path) if path else None
    STATE_PATH.write_text(json.dumps(st))


def load_studio_state() -> dict:
    return _read_state()


@dataclass
class RemovedEntry:
    track_id: str
    name: str
    artist: str
    source_kind: str
    path: str


class RekordboxSnapshot:
    """Durable last-seen state of the rekordbox collection."""

    def __init__(self, path: Path = SNAPSHOT_PATH) -> None:
        self.path = path

    def _load(self) -> dict[str, dict]:
        if not self.path.exists():
            return {}
        try:
            return json.loads(self.path.read_text())
        except (json.JSONDecodeError, OSError):
            return {}

    def _save(self, data: dict[str, dict]) -> None:
        self.path.write_text(json.dumps(data, indent=0, ensure_ascii=False))

    def update(self, collection: "RekordboxCollection") -> list[RemovedEntry]:
        """Diff the current collection against the snapshot, persist, and return
        the full durable list of tracks that are absent now but were seen before.

        On the very first run the snapshot is empty, so nothing is reported as
        removed (we have no prior state to compare to) — correct behaviour.
        """
        prev = self._load()
        current_ids = set(collection.tracks.keys())

        merged: dict[str, dict] = {}
        # carry forward everything previously seen, updating presence
        for tid, entry in prev.items():
            merged[tid] = {**entry, "present": tid in current_ids}
        # overwrite/add current tracks with fresh fields
        for tid, rb in collection.tracks.items():
            merged[tid] = {
                "name": rb.name,
                "artist": rb.artist,
                "source_kind": rb.source_kind,
                "path": rb.raw_path,
                "present": True,
            }
        self._save(merged)

        return [
            RemovedEntry(
                track_id=tid,
                name=e.get("name", ""),
                artist=e.get("artist", ""),
                source_kind=e.get("source_kind", ""),
                path=e.get("path", ""),
            )
            for tid, e in merged.items()
            if not e.get("present")
        ]
