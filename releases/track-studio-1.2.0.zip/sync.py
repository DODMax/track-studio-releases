"""Sync service — compute the Spotify→rekordbox gap for a bound source.

For each track in a Spotify playlist, two independent signals:
  - Collection: is it anywhere in the rekordbox library?  have / review / missing
  - Set:        is it in the paired rekordbox playlist?     in / out / n_a

Both are fuzzy artist+title matches (rekordbox has no ISRC). `high` confidence is
trusted as a hit; `medium`/`low` is a hit flagged for review; `none` is a true
miss. The "missing from collection" rows are the download worklist.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from dupes import isrc_index as _isrc_index
from library import Library, Track
from match import Match, match_track, prep_choices
from spotify import SpotifyTrack


@dataclass
class SyncRow:
    spotify: Optional[SpotifyTrack]
    collection: str               # have / review / missing
    collection_match: Optional[Track]
    collection_score: float
    in_set: str                   # in / out / n_a
    set_match: Optional[Track]
    downloaded: bool = False      # have a local file (not yet in rekordbox)
    local_match: Optional[Track] = None   # the downloaded local Track, if any
    in_spotify: bool = True       # False = in the rekordbox set but not the Spotify source

    @property
    def needs_source(self) -> bool:
        # Truly missing = not in rekordbox AND not already downloaded locally.
        return self.collection == "missing" and not self.downloaded

    @property
    def needs_add_to_set(self) -> bool:
        # Have it in the library, but it's not in the paired set.
        return self.in_set == "out" and self.collection in ("have", "review")

    @property
    def pipeline(self) -> str:
        """Sourcing pipeline: missing -> downloaded -> in_rekordbox."""
        if self.collection in ("have", "review"):
            return "in_rekordbox"
        return "downloaded" if self.downloaded else "missing"


def _state_from(match: Match) -> str:
    if not match.hit:
        return "miss"
    return "ok" if match.confidence == "high" else "review"


def compute_sync(spotify_tracks: list[SpotifyTrack], library: Library,
                 paired_rb_id: Optional[str] = None,
                 cutoff: float = 78.0) -> list[SyncRow]:
    """Match each Spotify track against the rekordbox collection and paired set.

    Matching scores title and artist separately (see match.match_track) so a
    shared artist or a single common title word can't manufacture a match —
    genuinely different tracks fall through to 'missing' and are sourced from
    Beatport instead of being wrongly treated as already in the collection.
    """
    rb_tracks = [t for t in library.tracks if t.in_rekordbox]
    coll_choices = prep_choices((t.artist, t.title) for t in rb_tracks)
    coll_isrc = _isrc_index(rb_tracks)

    paired_tracks = library.tracks_in_playlist(paired_rb_id) if paired_rb_id else []
    set_choices = prep_choices((t.artist, t.title) for t in paired_tracks)
    set_isrc = _isrc_index(paired_tracks)

    # Local files we have but rekordbox doesn't (e.g. freshly downloaded).
    local_tracks = [t for t in library.tracks if t.local_path and not t.in_rekordbox]
    local_choices = prep_choices((t.artist, t.title) for t in local_tracks)
    local_isrc = _isrc_index(local_tracks)

    rows: list[SyncRow] = []
    matched_set_idx: set[int] = set()   # paired-set tracks covered by a Spotify row
    for sp in spotify_tracks:
        qa, qt = ", ".join(sp.artists), sp.name
        isrc = (sp.isrc or "").upper() or None   # exact id when both sides have it

        # --- collection: ISRC exact first, then fuzzy title/artist ---
        ci = coll_isrc.get(isrc) if isrc else None
        if ci is not None:
            collection, coll_match, coll_score = "have", rb_tracks[ci], 100.0
        else:
            cm = match_track(qa, qt, coll_choices, cutoff=cutoff)
            collection = {"miss": "missing", "review": "review",
                          "ok": "have"}[_state_from(cm)]
            coll_match = rb_tracks[cm.target_index] if cm.hit else None
            coll_score = cm.score

        # --- local downloaded files (only matters when not in rekordbox) ---
        downloaded, local_match = False, None
        if coll_match is None:
            li = local_isrc.get(isrc) if isrc else None
            if li is not None:
                downloaded, local_match = True, local_tracks[li]
            elif local_choices:
                lm = match_track(qa, qt, local_choices, cutoff=cutoff)
                downloaded = lm.hit
                local_match = local_tracks[lm.target_index] if lm.hit else None

        # --- paired set membership ---
        if not paired_rb_id:
            in_set, set_match = "n_a", None
        else:
            si = set_isrc.get(isrc) if isrc else None
            if si is None:
                sm = match_track(qa, qt, set_choices, cutoff=cutoff)
                si = sm.target_index if sm.hit else None
            if si is not None:
                in_set, set_match = "in", paired_tracks[si]
                matched_set_idx.add(si)
            else:
                in_set, set_match = "out", None

        rows.append(SyncRow(
            spotify=sp,
            collection=collection,
            collection_match=coll_match,
            collection_score=coll_score,
            in_set=in_set,
            set_match=set_match,
            downloaded=downloaded,
            local_match=local_match,
        ))

    # Tracks in the rekordbox set that no Spotify track matched: they were taken
    # out of the Spotify source but still live in the playlist. Surface them so
    # they aren't silently clipped from the export (default: keep them).
    for idx, pt in enumerate(paired_tracks):
        if idx in matched_set_idx:
            continue
        rows.append(SyncRow(
            spotify=None,
            collection="have",
            collection_match=pt,
            collection_score=100.0,
            in_set="in",
            set_match=pt,
            in_spotify=False,
        ))
    return rows


def summarize(rows: list[SyncRow]) -> dict[str, int]:
    return {
        "total": len(rows),
        "have": sum(1 for r in rows if r.collection == "have"),
        "review": sum(1 for r in rows if r.collection == "review"),
        "missing": sum(1 for r in rows if r.needs_source),
        "downloaded": sum(1 for r in rows if r.pipeline == "downloaded"),
        "to_add": sum(1 for r in rows if r.needs_add_to_set),
        "only_rb": sum(1 for r in rows if not r.in_spotify),
    }
