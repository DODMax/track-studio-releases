"""Pure visual helpers + color constants — the DJ-tool render language.

Leaf module: no app state, imports only stdlib, `microsets` (for `_camelot_parse`),
and NiceGUI's `ui`. Both the Library and Micro-sets pages render through these.
"""
from __future__ import annotations

import hashlib
from html import escape
from urllib.parse import quote

from nicegui import ui

import microsets

ENERGY_COLORS = {
    1: "#3b6ea5", 2: "#3b6ea5", 3: "#3b6ea5",
    4: "#4a90e2", 5: "#4a90e2", 6: "#5fb454",
    7: "#f0a830", 8: "#e8731c", 9: "#d83a3a", 10: "#a02020",
}
STATUS_COLORS = {"ready": "positive", "untagged": "warning", "missing": "grey"}

TRACK_BG = "#394150"   # empty-bar track — lighter than the surface for contrast


# ----------------------------------------------------------------------
# Visual language helpers (energy / harmonic key / vibe) — DJ-tool render
# ----------------------------------------------------------------------

def camelot_color(key: str | None) -> str:
    """Camelot-wheel color for a harmonic key pill (the DJ-tool signature).

    Hue follows the wheel hour (1..12); minor (A) reads deeper/saturated,
    major (B) lighter. Unknown / non-Camelot keys fall back to grey.
    """
    parsed = microsets._camelot_parse(key or "")
    if not parsed:
        return "#555"
    hour, mode = parsed
    hue = (hour - 1) / 12.0 * 360.0
    return f"hsl({hue:.0f}, 62%, 42%)" if mode == "A" else f"hsl({hue:.0f}, 72%, 58%)"


def valence_color(v: float | None) -> str:
    """DEAM valence (~3..7) → cold-blue (sombre) to warm-amber (bright)."""
    if v is None:
        return "#555"
    frac = max(0.0, min(1.0, (v - 3.0) / 4.0))
    hue = 210 - frac * 180.0          # 210° blue → 30° amber
    return f"hsl({hue:.0f}, 65%, 55%)"


def mood_color(s: str) -> str:
    """Deterministic muted color for a mood/theme word (stable across renders)."""
    h = int(hashlib.md5(s.encode()).hexdigest()[:6], 16)
    return f"hsl({h % 360}, 38%, 46%)"


_arc_seq = [0]


def energy_arc_svg(energies: list[int], w: int = 160, h: int = 34, big: bool = False) -> str:
    """Area chart of an energy progression (1..10 → height). '' if no data."""
    pts = [e for e in energies if e]
    if not pts:
        return ""
    _arc_seq[0] += 1
    gid = f"eg{_arc_seq[0]}"
    n = len(pts)
    pad = 4
    uw, uh = w - pad * 2, h - pad * 2

    def x(i: int) -> float:
        return pad + (uw * (i / (n - 1)) if n > 1 else uw / 2)

    def y(e: int) -> float:
        return pad + uh * (1 - (e - 1) / 9.0)

    line = " ".join(f"{x(i):.1f},{y(e):.1f}" for i, e in enumerate(pts))
    area = f"{x(0):.1f},{h - pad:.1f} {line} {x(n - 1):.1f},{h - pad:.1f}"
    dots = ""
    if big:
        dots = "".join(
            f'<circle cx="{x(i):.1f}" cy="{y(e):.1f}" r="3" '
            f'fill="{ENERGY_COLORS.get(e, "#888")}"/>'
            for i, e in enumerate(pts)
        )
    sw = 2.5 if big else 1.5
    return (
        f'<svg viewBox="0 0 {w} {h}" width="{w}" height="{h}" '
        f'xmlns="http://www.w3.org/2000/svg" style="display:block;max-width:100%">'
        f'<defs><linearGradient id="{gid}" x1="0" y1="0" x2="0" y2="1">'
        f'<stop offset="0%" stop-color="#ff7a1a" stop-opacity="0.45"/>'
        f'<stop offset="100%" stop-color="#ff7a1a" stop-opacity="0.02"/>'
        f'</linearGradient></defs>'
        f'<polygon points="{area}" fill="url(#{gid})"/>'
        f'<polyline points="{line}" fill="none" stroke="#ff7a1a" '
        f'stroke-width="{sw}" stroke-linejoin="round" stroke-linecap="round"/>'
        f'{dots}</svg>'
    )


def set_arc_svg(bpms: list, harmonics: list, energies: list | None = None,
                w: int = 900, h: int = 150) -> str:
    """The shape of a played set: BPM against position, harmonic joins marked.

    Sibling of `energy_arc_svg`, but for real performances rather than planned
    planned blocks — so the spine is BPM (rekordbox has it for every track) and
    energy is an optional overlay that only appears once the set is tagged.

    The x axis is *position in the set*, not time: rekordbox's history log stores
    a track number and no timestamps, so a time axis would be fabricated.

    `harmonics[i]` is the Camelot distance score from track i-1 to i (see
    `microsets._camelot_distance`); -1 for the first track, which has no join.
    """
    pts = [(i, b) for i, b in enumerate(bpms) if b]
    if len(pts) < 2:
        return ""
    _arc_seq[0] += 1
    gid = f"sg{_arc_seq[0]}"
    padl, padr, padt, padb = 34, 8, 10, 18
    uw, uh = w - padl - padr, h - padt - padb
    n = len(bpms)
    vals = [b for _, b in pts]
    lo, hi = min(vals), max(vals)
    if hi - lo < 4:                       # a tight set still deserves a readable band
        mid = (hi + lo) / 2
        lo, hi = mid - 2, mid + 2

    def x(i: int) -> float:
        return padl + (uw * (i / (n - 1)) if n > 1 else uw / 2)

    def y(b: float) -> float:
        return padt + uh * (1 - (b - lo) / (hi - lo))

    # horizontal BPM guides, rounded to whole values
    grid = ""
    step = max(1, round((hi - lo) / 4))
    tick = int(lo // step * step)
    while tick <= hi:
        if tick >= lo:
            gy = y(tick)
            grid += (f'<line x1="{padl}" y1="{gy:.1f}" x2="{w - padr}" y2="{gy:.1f}" '
                     f'stroke="#23262d" stroke-width="1"/>'
                     f'<text x="{padl - 6}" y="{gy + 3:.1f}" text-anchor="end" '
                     f'font-size="9" fill="#6b7280">{tick}</text>')
        tick += step

    line = " ".join(f"{x(i):.1f},{y(b):.1f}" for i, b in pts)
    area = f"{x(pts[0][0]):.1f},{h - padb:.1f} {line} {x(pts[-1][0]):.1f},{h - padb:.1f}"

    # energy overlay: a second, fainter spine on its own 1..10 scale
    overlay = ""
    if energies and any(e for e in energies):
        epts = [(i, e) for i, e in enumerate(energies) if e]
        if len(epts) >= 2:
            ey = lambda e: padt + uh * (1 - (e - 1) / 9.0)  # noqa: E731
            epath = " ".join(f"{x(i):.1f},{ey(e):.1f}" for i, e in epts)
            overlay = (f'<polyline points="{epath}" fill="none" stroke="#5fb454" '
                       f'stroke-width="1.6" stroke-dasharray="4 3" opacity="0.85"/>')

    dots = ""
    for i, b in pts:
        joined = harmonics[i] >= 80 if i < len(harmonics) else False
        dots += (f'<circle cx="{x(i):.1f}" cy="{y(b):.1f}" r="{3.2 if joined else 2.6}" '
                 f'fill="{"#2dd4bf" if joined else "#16181d"}" '
                 f'stroke="{"#2dd4bf" if joined else "#6b7280"}" stroke-width="1.4"/>')

    return (
        f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" '
        f'style="display:block;width:100%;height:auto">'
        f'<defs><linearGradient id="{gid}" x1="0" y1="0" x2="0" y2="1">'
        f'<stop offset="0%" stop-color="#ff7a1a" stop-opacity="0.30"/>'
        f'<stop offset="100%" stop-color="#ff7a1a" stop-opacity="0.02"/>'
        f'</linearGradient></defs>{grid}'
        f'<polygon points="{area}" fill="url(#{gid})"/>'
        f'<polyline points="{line}" fill="none" stroke="#ff7a1a" stroke-width="2" '
        f'stroke-linejoin="round" stroke-linecap="round"/>{overlay}{dots}</svg>'
    )


def _chip(text: str, bg: str, fg: str = "#fff") -> None:
    """A small pill label."""
    ui.label(text).classes("text-caption text-weight-medium").style(
        f"background:{bg}; color:{fg}; padding:1px 8px; border-radius:6px")


def metric_bar(label: str, frac: float, color: str, value_str: str) -> None:
    """A labeled 0..1 bar with a trailing value — for valence/danceability etc."""
    with ui.row().classes("items-center gap-2 no-wrap"):
        ui.label(label).classes("text-caption text-grey").style("width:92px")
        with ui.element("div").style(
                f"width:120px;height:8px;border-radius:4px;background:{TRACK_BG}"):
            ui.element("div").style(
                f"width:{int(max(0.0, min(1.0, frac)) * 120)}px;height:8px;"
                f"border-radius:4px;background:{color}")
        ui.label(value_str).classes("text-caption").style("color:#cbd2da")


def mini_metric(label: str, frac: float, color: str, value_str: str) -> None:
    """Compact inline labeled scale for track rows (valence / dance / arousal)."""
    with ui.row().classes("items-center gap-1 no-wrap"):
        ui.label(label).classes("text-caption text-grey")
        with ui.element("div").style(
                f"width:72px;height:7px;border-radius:4px;background:{TRACK_BG}"):
            ui.element("div").style(
                f"width:{int(max(0.0, min(1.0, frac)) * 72)}px;height:7px;"
                f"border-radius:4px;background:{color}")
        ui.label(value_str).classes("text-caption").style("color:#cbd2da")


# Texture (DSP) metrics — display normalization: attr -> (lo, hi, label, color, fmt).
# lo/hi map the raw value onto a 0..1 bar; ranges chosen to spread real tracks.
TEXTURE_SPECS = {
    "brightness":          (400.0, 2400.0, "bright",   "#e2c044", lambda v: f"{v:.0f}Hz"),
    "dynamic_complexity":  (2.0,   6.0,    "dynamics", "#a78bfa", lambda v: f"{v:.1f}"),
    "spectral_complexity": (5.0,   22.0,   "density",  "#34d399", lambda v: f"{v:.0f}"),
    "onset_rate":          (2.0,   8.0,    "onsets",   "#f472b6", lambda v: f"{v:.1f}"),
}


def render_texture_metrics(t, bar_fn) -> bool:
    """Draw whichever texture metrics the track has, using `bar_fn` (mini_metric
    or metric_bar). Returns True if anything was drawn."""
    drawn = False
    for attr, (lo, hi, label, color, fmt) in TEXTURE_SPECS.items():
        v = getattr(t, attr, None)
        if v is None:
            continue
        bar_fn(label, (v - lo) / (hi - lo), color, fmt(v))
        drawn = True
    return drawn


def _kv(label: str, value: str) -> None:
    """A 'label: value' row for the track detail panel."""
    with ui.row().classes("items-center gap-2 no-wrap"):
        ui.label(label).classes("text-caption text-grey").style("width:92px")
        ui.label(value).classes("text-caption").style("color:#cbd2da; word-break:break-all")


# ----------------------------------------------------------------------
# Audio transport
# ----------------------------------------------------------------------

# Play / pause glyphs. Two paths in one button, swapped by CSS on the
# `.is-playing` class the delegated script toggles (see shell.PLAYER_ASSETS).
_PLAY_SVG = ('<svg class="ts-i ts-i-play" viewBox="0 0 24 24" width="11" height="11" '
             'fill="currentColor"><path d="M8 5v14l11-7z"/></svg>')
_PAUSE_SVG = ('<svg class="ts-i ts-i-pause" viewBox="0 0 24 24" width="11" height="11" '
              'fill="currentColor"><path d="M6 5h4v14H6zm8 0h4v14h-4z"/></svg>')


def _player_markup(audio_tag: str, compact: bool) -> str:
    """The transport's markup wrapped around a given `<audio>` tag.

    Split out from `audio_player` because the Sync page renders its players
    inside a Quasar table slot — a Vue template compiled in the browser — where
    the source is a row binding rather than a path we know server-side. Both
    callers must emit the same DOM or `shell.PLAYER_ASSETS` won't drive it.
    """
    return (
        f'<div class="ts-player{" ts-compact" if compact else ""}">'
        f'{audio_tag}'
        f'<div class="ts-bar"><div class="ts-buf"></div><div class="ts-fill"></div></div>'
        f'<div class="ts-under">'
        f'<button class="ts-play" type="button" aria-label="Play">'
        f'{_PLAY_SVG}{_PAUSE_SVG}</button>'
        f'<span class="ts-time">–:–– / –:––</span>'
        f'</div>'
        f'</div>'
    )


def player_vue(src_expr: str, compact: bool = True) -> str:
    """The same transport as a Vue template fragment, for use inside a Quasar
    table slot. `src_expr` is a template expression (e.g. `props.row.audio`),
    bound rather than baked in.

    `preload=none` where `audio_player` uses `metadata`: a table paints 50 rows
    at once and shouldn't fire 50 range requests to fill in durations. The clock
    stays at `–:––` until the first play — the delegated `loadedmetadata`
    listener paints it then.
    """
    return _player_markup(f'<audio preload="none" :src="{src_expr}"></audio>', compact)


def audio_player(path, compact: bool = False) -> None:
    """A themed transport for one local file.

    The browser still owns the audio: this is a plain `<audio>` element with its
    default chrome hidden (no `controls`), plus our own scrub bar, play button
    and clock driven by a single delegated listener (`shell.PLAYER_ASSETS`).
    Nothing about decoding, buffering or seeking is reimplemented — only the
    skin, because the stock control bar is a light-grey slab in a dark app.

    Layout puts the seek bar full-width on its own line with the transport
    underneath: auditioning a track is mostly scrubbing to the drop, so the bar
    gets the whole width rather than whatever the button and clock leave over.

    Markup only, no per-player Python callbacks: scrubbing at 60fps over the
    websocket would be absurd, so playback state never leaves the client.
    """
    src = escape(f"/media?path={quote(str(path))}", quote=True)
    # w-full on the wrapper: ui.html's div is inline-sized by default and would
    # shrink the bar to its content instead of filling the card.
    ui.html(
        _player_markup(f'<audio preload="metadata" src="{src}"></audio>', compact),
        sanitize=False,
    ).classes("w-full")


def render_track_row(t) -> None:
    """Rich per-track row: energy badge · name · Camelot key pill · BPM · wide ▶,
    then a chips line (style / mood) and a scales line (valence / dance / arousal).
    Degrades gracefully for tracks without Rich data."""
    with ui.column().classes("w-full gap-1 q-py-xs"):
        with ui.row().classes("items-center gap-3 no-wrap w-full"):
            ui.badge(str(t.energy) if t.energy else "?").style(
                f"background:{ENERGY_COLORS.get(t.energy or 0, '#888')}")
            ui.label(t.display).classes("flex-grow ellipsis") \
                .style("min-width:0")
            if t.key:
                _chip(t.key, camelot_color(t.key))
            if t.bpm:
                ui.label(f"{round(t.bpm)}").classes("text-caption text-grey") \
                    .style("font-family:monospace")
            if t.path:
                with ui.element("div").style("width:300px; max-width:42%; flex:0 0 auto"):
                    audio_player(t.path, compact=True)
        if t.style or t.moods:
            with ui.row().classes("items-center gap-2 wrap").style("padding-left:34px"):
                if t.style:
                    _chip(t.style, "#2a2d35", "#cbd2da")
                for m in (t.moods or [])[:3]:
                    _chip(m, mood_color(m))
        if t.valence is not None or t.danceability is not None or t.arousal is not None:
            with ui.row().classes("items-center gap-4 wrap").style("padding-left:34px"):
                if t.valence is not None:
                    mini_metric("valence", (t.valence - 3.0) / 4.0,
                                valence_color(t.valence), f"{t.valence:.1f}")
                if t.danceability is not None:
                    mini_metric("dance", t.danceability, "#2dd4bf", f"{t.danceability:.2f}")
                if t.arousal is not None:
                    mini_metric("arousal", (t.arousal - 3.0) / 4.0, "#f0a830",
                                f"{t.arousal:.1f}")
        # texture (DSP) line — brightness / dynamics / density / onsets
        if any(getattr(t, a, None) is not None for a in TEXTURE_SPECS):
            with ui.row().classes("items-center gap-4 wrap").style("padding-left:34px"):
                render_texture_metrics(t, mini_metric)
