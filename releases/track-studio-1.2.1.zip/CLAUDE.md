# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Setup & commands

Always work inside the local venv:

```bash
source venv/bin/activate
pip install -r requirements.txt   # one-time
```

Run the app (the primary interface — NiceGUI, opens on :8080):

```bash
venv/bin/python main.py
```

Run the tagger directly on a folder:

```bash
venv/bin/python energy.py /path/to/folder [--dry-run] [--force] [--rich]
```

**`--rich` is not optional if you care about the suggestions.** Only a rich pass
loads the Discogs-EffNet model, and therefore only a rich pass produces the
embedding, the genre/mood distributions and the voice probability that
`mixmodel.fill`'s sound axis runs on (`vectors`). A plain pass writes an energy
and leaves the ranking exactly as blind as it was. Same for the UI: Library →
**Analyze energy** with "Rich" on.

Several domain modules have a `__main__` self-test that prints real numbers off
the live library — the fastest way to sanity-check a change:

```bash
venv/bin/python history.py     # gigs reconstructed from the play log
venv/bin/python mixmodel.py    # move profile + a real next-track ranking
venv/bin/python genres.py      # the genre kinship table, pair by pair
venv/bin/python db.py          # what the cache holds (also: vectors.py)
```

There is no test suite, linter, or build step configured. `app.py` is the
superseded Streamlit GUI, kept only as a reference; `main.py` is the live app.

## Where the docs live

| Plane | Role |
|---|---|
| **This file** | **Decided** architecture, conventions and footguns — how the app *is*. Start here. |
| [`docs/proposals/`](docs/proposals/README.md) | Investigations and proposed changes — how it *might be* — status-tagged, with the measurements behind each argument. A built proposal is marked `Implemented` and its truths move here; a rejected one stays, so the same idea is not re-proposed every six months. |

Current proposals: **[0001](docs/proposals/0001-crate-matching-and-the-sound-axis.md)**
— what makes two tracks belong together (the sound axis; partly built, with the
open items and one rejection ledgered at the end) · **[0002](docs/proposals/0002-setline-becomes-the-set-builder.md)**
— Setline becomes the set builder, replacing the Build page and the whole
import/push bridge (Draft) · **[0003](docs/proposals/0003-solo-setline-and-the-shared-one.md)**
— the shared online Setline keeps existing, so the local board is a *second
instance* that has to sync with it; holds the decisions that are brutal to
retrofit and so have to be taken before it is built (Draft).

## Where data lives — and the one thing that isn't a tag

`vectors.py` (the audio embeddings) is the one thing that does **not** live in a
tag, and the reason is the rule below rather than an escape from it: the Comments
string exists so a human *and rekordbox* can read it, and 1 280 floats are
readable to neither. The line that keeps this from sprawling:

- **One SQLite file** (`.cache.sqlite`, stdlib `sqlite3`, gitignored, handle in
  `db.py`) for data that is *machine-derived, per-file and rebuildable*, keyed on
  the file path and invalidated on `(size, mtime)` — every way this app changes a
  file moves at least one of the two (`write_energy` rewrites the Comments tag,
  `refetch.replace_in_place` swaps the audio, `normalize_loudness` re-encodes),
  so a stale row cannot be served rather than merely being unlikely to be.
  Connections are **thread-local**: this app is threads all the way down
  (NiceGUI's loop, `run.io_bound`, the analysis thread), a `sqlite3` connection
  belongs to the thread that opened it, and reopening one per call would cost
  more than the read some of these caches exist to avoid. Two tables today —
  `vectors` (`vectors.py`) and `file_tags` (`tagcache.py`).
- **A small JSON dotfile at `ROOT`** for everything hand-made and small
  (`.crates.json`, `.set_drafts.json`, `.build_session.json`,
  `.studio_state.json`, `.synced_sources.json`). These stay JSON on purpose: for
  data a person made by hand, a file you can open and repair in a text editor is
  a better failure mode than a binary DB.
- **Deleting the DB must never lose a fact.** It costs compute. Anything that
  reads it copes with it being empty.

Do not key a per-file cache on `library.track_key`: that is
`rekordbox_id or isrc or display`, which *changes* when a downloaded track is
imported into rekordbox, orphaning every row exactly when the library grows.

## The Comments tag is the database

Everything the analyzer learns is encoded as one human-readable string in the
audio file's **Comments** tag. There is no sidecar DB and no write to the
rekordbox DB:

```
Energy 07 | A 5.67 | Dance 0.95 | Valence 5.81 | Style House | Mood summer,deep
       | Bright 1450 | Dyn 3.21 | Spec 12.4 | Onset 4.10
LUFS -8.20 | LRA 4.10 | TP -0.30
```

Rekordbox's Intelligent Playlists then filter on `Comments contains "Energy 0[1-3]"`.

**If you add a field, change all three sides or re-runs will corrupt it:**
`energy.write_energy` (write), `tagging.parse_comment` (read), and the
`_merge_comment` regex (strips the prior payload so re-runs don't accumulate).
Loudness has its own pair (`write_loudness` / `_merge_loudness_comment`).

## Vocabulary

Four distinct words, and keeping them straight is most of understanding how a
set gets built:

- **pool** — a source you dig *through*: a rekordbox playlist, or several
  pooled. **This used to be called a crate**, and the rename is deliberate —
  see below.
- **crate** — a preselection you dig *out*: tracks you gathered for a genre, a
  mood, a "maybe for Friday". Yours, hand-picked, and a track can be in
  several at once (`crates.py`). Setline's meaning, and now the app's.
- **the set** — the ordered list of tracks you assemble and actually play.
- **block** — 3–10 tracks grouped by feel, ordered harmonically and given an
  arc role ("Warm-up" … "Climax"). A programmed run *within* a set.
  **Being retired**: blocks were *generated* clusters, crates are *curated*
  piles, and the curation is the part worth keeping — crates replace them when
  the board arrives and the Build page goes. That move is now costed and written
  down: [`docs/proposals/0002`](docs/proposals/0002-setline-becomes-the-set-builder.md).

**Why "crate" moved.** It meant "a source you dig through", which is a *pool*
by any other name, and Setline — which is becoming the set-building half of
this app — has always used the word for the preselection. Two meanings for one
word across two halves of the same product is the kind of thing that is cheap
to fix now and tangled later, so the app took Setline's meaning and the old
sense became "pool".

The set outlives the pool: swapping or widening it mid-build keeps the set and
only changes what the suggestions and blocks are drawn from — running dry in one
playlist and ticking another is how a set actually gets built. `Clear` is the
only thing that empties a set, and `_load_pool` re-points surviving entries at
the new pool's objects so a re-analysis refreshes them in place.

## Architecture

### Analysis pipeline

- **`energy.py`** — the core. Lazy-downloads Essentia `.pb` models into `models/`,
  loads them once via `build_predictors(rich=…)`, runs `analyze(path, predictors)`,
  then `write_energy` merges the payload into the existing Comments. MP3 uses
  mutagen `ID3/COMM`; M4A uses `MP4` `\xa9cmt`. Energy 1–10 comes from
  `_arousal_to_energy`, which maps DEAM arousal **3.0..7.0 → 1..10** (not the full
  1..9 range) because real tracks cluster in the middle. Also owns EBU R128
  loudness (`extract_loudness` / `normalize_loudness`).
- **`tagging.py`** — the read side: `parse_comment(text) → dict`.
- **`analysis.py`** — `AnalysisJob` / `LoudnessJob` / `NormalizeJob`: cancellable
  background jobs with progress, driven from the UI.

### Domain

- **`tagcache.py`** — one row per file holding what its tags said, so the same
  file is not opened twice. `library._read_file_fields` and `library.file_duration`
  go through it, which is most of the disk reading this app does: the Library and
  Build tables ask for a duration **per rendered row**, `mixmodel`'s build asks
  for a Comments string per played track, `hydrate_genres` / `hydrate_local_energy`
  walk the library, the inbox scan reads every download. **Measured: 5.5 ms → 0.01 ms
  a file (≈400x), 13 s → 0.03 s for the library's 2 377 local files, and the
  mixmodel build 1.93 s → 0.03 s** — so the first Fill or Build of a session now
  pays 0.4 s instead of 2.3 s. Both readers fall back to the file on any cache
  failure; a cache that raises would be worse than no cache. Note the file read is
  ~1.4 ms warm and ~18 ms cold, so the win is largest exactly where it is felt
  most: the first pass after a launch, and anything on the shared drive.
- **`library.py`** — `Library` + the `Track` aggregate, the single source of truth
  the UI renders, merged across local files / rekordbox / Spotify / Beatport.
  `mix_tracks_from` maps these to the set-building `microsets.Track` (BPM required).
  **`Track.genre`** is the *vendor's* genre (distinct from `style`, which is the
  analyzer's own reading): rekordbox's `Genre` where it has one, else the file's
  tag — Beatport writes its store genre into every download. Wiring both took
  genre coverage from 0.3% to **70%** of this library, and it is the only style
  fact the app has about most tracks. Note rekordbox is the *poorer* source: its
  XML carries no Genre for 42% of the collection, and a track that arrives
  through the rekordbox merge never has its file read — so a Beatport download
  the user has since imported ends up with the genre in the file and nothing in
  the app. `hydrate_genres(tracks)` reads it back on demand (~18 ms/file cold,
  ~1.4 ms warm; targeted, because a blanket pass is 5–17 s to gain ~5%).
- **`microsets.py`** — the set-building domain (despite the legacy filename):
  `Track`, `Block`, `BlockPreset`, `SetEntry`, Camelot helpers, `cluster()`,
  `compatibility()`, `generate_sequences()`. Leaf: it takes the learned model
  duck-typed rather than importing it.
- **`history.py`** — reconstructs real gigs from rekordbox's play log. Most
  sessions aren't performances; the discriminator is *harmonic adjacency* (real
  sets run 60-72% vs a ~17% random baseline), with an alphabetical-order check to
  reject sorted playlists clicked through. Read-only.
- **`mixmodel.py`** — turns that history into advice. One rule throughout: **a
  one-off can be a practice miss; only repetition across nights is proof.** Pair
  evidence (2+ nights = "confirmed", teal ♥ in the UI), a night-weighted move
  profile that generalizes to pairs never played, and playlist affinity ("often
  gigged with").
  Two questions, not one, **and two scorings**. `next_tracks` asks *what plays
  after this* — a sequence, scored by `_base_score` (bpm 25 / key 25 / energy 20
  / …). **`fill` asks what belongs with a crate** — a pile, no direction, scored
  by `_kinship`: **sound 45** (cosine between the audio embeddings, `vectors`) /
  genre 22 / tempo-as-a-band 12 / energy 8 / vibe 5 / texture 3 / **key 5, a
  tie-break only**. An axis with no data is skipped and the rest renormalize, so
  an unanalyzed library still ranks exactly as it did before, genre-led.
  **One asymmetry, and it was found by testing rather than reasoning:**
  `genres.UNKNOWN` penalizes a missing genre so a blank tag can't outrank a
  known match on tempo alone — but when `sound` is known that penalty is
  *skipped*, not scored, because ignorance about a shop's label is not ignorance
  about the music. Without it the ranking put Justice at 0.86 similarity below a
  track at 0.76 that merely shared a Beatport label: the tag deciding over the
  audio, exactly backwards. Key and tempo are *mixability, not kinship*:
  they say two records can be beatmatched, not that they belong together, and
  ranking a crate on key is what produced twelve proposals reading "same key ·
  steady bpm" with nothing else in common. Coverage bites harder here
  (`0.6 + 0.4*coverage`) so a track we know nothing about cannot win on tempo
  alone, and `genres.UNKNOWN` (22) puts a blank genre *below* a neighbouring one.
  The move typicality is taken both ways and nothing is scored against "the
  current track" at all. Each candidate is scored against every crate member
  and the score is the mean of the best `FILL_COUNTED` (3): averaging over all
  of them punishes a crate that deliberately holds two moods, and taking the
  single best rewards an accidental twin. Play evidence with *several* members
  beats a strong link to one (`seeds_played`), because then the evidence is
  about the crate rather than a pair. Duplicates are filtered on
  `match.record_key` at both ends — without it the first thing a crate of
  "Quem Sou Eu" gets offered is "Quem Sou Eu (Original Mix)", which is not a
  suggestion, it is the same track back.
  **What it is worth:** holding out one gig at a time and rebuilding the model
  without it, the track actually played next landed in the top 5 of 3 493
  candidates 4.9% of the time against 0.1% by chance (~34x), top-100 23.5% vs
  2.9%, median rank 536. Good enough to rank with, nowhere near good enough to
  add anything to a crate by itself — which is why `pages/crate_fill.py` is a
  screen you press Add on.
- **`db.py`** — the shared handle on `.cache.sqlite` plus the three rules that
  keep it a cache and not a second source of truth (deleting it must lose no
  fact; every table keyed on the path and invalidated on `(size, mtime)`; never
  keyed on `track_key`, which changes when a download is imported). Each cache
  passes its own `CREATE TABLE IF NOT EXISTS` — `db` doesn't know their schemas.
  **A gigs/transitions cache was considered here and rejected on measurement:**
  the 2.9 s the first Fill used to pay was tag reads, `tagcache` took it to
  0.4 s, and the 0.37 s left is reading rekordbox's play history — which changes
  every time you DJ. Caching that to save a third of a second would buy a
  staleness bug.
- **`vectors.py`** — one row per analysis: the Discogs-EffNet embedding
  (mean-pooled, L2-normalized, float16 — 2.6 KB a track), plus the **full** 400
  genre probabilities and 56 mood probabilities rather than only the label the
  tag records, plus `voice` (P(vocal), from the `voice_instrumental` head that
  shipped in `models/` and was never run until now). The rule: **the pass is
  ~3.4 hours, so write everything it produces** — anything skipped costs another
  3.4 hours to obtain. `energy.analyze` was already computing the embedding to
  feed the genre and mood heads and letting it go out of scope; keeping it is
  what makes "belongs with this crate" a dot product instead of a genre-string
  comparison. `SoundSpace` is the read side: every seed-to-candidate similarity
  in one matrix multiply, looked up per pair by `mixmodel._fit`.
  **Why the label alone was not enough to keep:** measured on real tracks the
  top genre probability is often ~0.25 — Justice/Boys Noize comes back "Electro
  .25 / Electro House .25 / House .20" where Beatport says "Mainstage". The
  distribution is both the better signal and the only way to change our mind
  about the label later without re-running the library. **Measured on
  the real library:** embed *Illmerica* plus its "1 · FrenchTouch" playlist mates,
  the tracks the genre ranking proposed, and 18 random tracks, then rank by
  cosine — the six nearest are six of the playlist mates (Justice .863, Boys
  Noize .843, deadmau5/Gartner .829, Brodinski, Digitalism ×2), the first genre
  pick is 7th, random averages 26th of 37. It reconstructed a hand-made playlist
  from audio alone. Written **parent-side only** (`analysis._store_vector`): the
  pool is N spawned processes and one SQLite file, so the vector rides home in
  the result dict and the parent is the single writer. `AnalysisJob._partition`
  also treats "tagged but no vector" as work in a rich pass, or tracks analyzed
  before this existed would never get one.
- **`genres.py`** — genre *kinship*, because string equality is useless here:
  Beatport splits what DJs treat as one crate ("Techno (Peak Time / Driving)" vs
  "Hard Techno") and lumps what they don't ("Melodic House & Techno" is 405
  tracks of this library). Families are swap groups, not a store's menu; unknown
  strings fall back to a keyword scan so a genre added after this was written
  still lands somewhere sensible.
  **Its ceiling is known and documented.** A vendor's one-word genre is the
  weakest form of style matching — Beatport files Wolfgang Gartner's *Illmerica*
  under "Mainstage", so a French-touch crate seeded on it gets David Guetta,
  while the genre model already sitting in `models/` hears Justice/Boys Noize as
  "Electro". See **[`docs/proposals/0001`](docs/proposals/0001-crate-matching-and-the-sound-axis.md)** for what DJs actually
  match on, what the field computes, and the measured plan for fixing it (short
  version: the user's own 117 playlists are free signal today; a ~3.4-hour
  one-time analysis pass makes every axis real; and `energy.analyze` already
  computes the EffNet embedding per track and throws it away — keeping it is what
  turns `fill` into real similarity search).
- **`rekordbox.py`** (read the live DB / an XML export) and **`rekordbox_io.py`**
  (write an importable `collection.xml`; `export_folder` is the one used by Build).
- **`rbprefs.py`** — read-only view of rekordbox's *own* preferences
  (`rekordbox3.settings`): is rekordbox's xml view pointed at our export file,
  and is the sidebar tree enabled? Turns the one-time setup into a verifiable
  check (Settings checklist, header badge, post-export dialog). Never writes.
- **`sync.py`**, **`sources.py`**, **`spotify.py`**, **`beatport.py`**, **`bpdl.py`**,
  **`ytdl.py`**, **`inbox.py`**, **`match.py`** — the Spotify→Beatport→local
  sourcing pipeline. ISRC is the identity key.
  `SyncRow.other_edit` is the same length guard as `dupes`, pointed the other
  way: a name-only match called the collection's 3½-minute radio edit "have",
  so the 6-minute version the playlist wanted was **never offered for
  download**. Spotify gives a duration and the matched file has one, so
  `dupes.different_edit` settles it and the row goes back on the worklist.
  Keyed on *how* it matched (`by_isrc`), never on the score — a perfect name
  match scores 100 too, and those are exactly the rows that matter.
  `match.record_key(artist, title)` is the cheap, exact half of the same idea:
  "is this the same record?" as a dict key, with generic mix qualifiers
  stripped but a remixer's name kept. Used wherever a list must not show you
  the copy you already have (`mixmodel.fill`).
- **`destinations.py`** — where an arriving track is going, which is the question
  the old flow never asked. A destination is a rekordbox playlist name, and a
  track carries it by **sitting in a folder of that name** under the download
  root — not a new representation, but the one the sync path already used
  (downloads land in `<root>/<paired playlist>/`, and the export names the
  playlist after the folder), extended to tracks that arrived by another door.
  So *filing a track is a file move*, and the export machinery learns nothing
  new. Only not-yet-imported tracks are ever moved; moving one rekordbox knows
  about would break its link. `DOORS` are folders named after where a track came
  *from* (Beatport, SoundCloud, Imported…) and are never destinations however
  long something sits in them. `assign` refuses to overwrite a same-named file
  rather than renaming to "… (2)" — that would manufacture exactly the second
  copy at a second path that `dupes` exists to warn about. `known_names` reads
  rekordbox nodes **including folders** (a built set lands as a folder named for
  the bucket), synced source names, and locally declared ones.
  `discard` is the opposite verb, for a download the collection already has: it
  **moves, never deletes**, into `<root>/.duplicates/` — a dotfolder the batch
  scan skips, so the row leaves the lane while the audio stays recoverable in
  Finder. The judgement behind it is a fuzzy name match *plus* an agreeing
  duration — strong, but still inference, and inference is not grounds for
  destroying someone's audio (`refetch` takes the same line with
  `.broken_backup`). Unlike `assign` it *does* number a clash, because there a
  second copy is the whole point and nothing will ever import it.
- **`incoming.py`** — the arrival vocabulary. A track crosses three thresholds,
  and this is the only place that says which it still owes:

      want it  →  get it  →  know where it goes  →  rekordbox has it

  Two rules that aren't obvious: **rekordbox holding a track settles
  everything** (whatever we can't see, it has been through, and it is not
  arriving), and a destination is owed *before* the file exists — a wanted track
  from an unpaired source should say so before it is downloaded into another
  anonymous pile.
  **Energy analysis is deliberately not a step**, and used to be. Only the Build
  page consumes it, that page is on its way out, and it had reached ~16% of the
  library when this was written — so making it a step put the biggest button on
  screen in front of the job people are actually there for. It lives in the ⋮
  menu over a selection. Loudness never was one, for a similar reason: it asks
  about a playlist's mastering, not about one track being unfinished.
  An `Item` is one row whichever side it came from: a download folder
  (`from_folders`) or a source's computed gap (`from_gap`), the latter keeping
  the whole `sync.SyncRow` because the set-membership decision and the match
  score only mean something for a source and the export still needs them.
  `merge` dedupes by file path and **drops whatever owes nothing** — that is
  what makes a row leave the lane — and sorts by *step*, so the list is a
  worklist rather than a history.
  `scan_duplicates` / `apply_duplicates` answer a different kind of question:
  not what a row *owes* but whether the collection already holds it. That is an
  answer **about** a row, never a step, so `needs` knows nothing about it and
  `Item.duplicate` / `Item.heals` / `Item.better_edit` are what the page slices
  on. The scan is a fuzzy pass over the whole collection per row (~2s for a
  thousand) plus two duration reads per *match* (see `dupes.EDIT_DIFFERENCE_S`),
  so it runs off the event loop and is cached in `runtime.duplicate_scan`;
  `apply` re-attaches it by key on every render, because the lane is rebuilt
  from scratch each time.
  `Item.duplicate` additionally requires that the length was *measured*, not
  merely that it didn't disagree — `different_edit` is false both when the two
  agree and when neither could be read, and those are opposite situations.
  `Existing.certain` can't draw that line because it is also asked before a
  download exists, where there is no file to measure; here both are on disk, so
  a row we have only a name for stays out of the pile that gets bulk-discarded.
  Fed by `runtime.incoming_batches` (whole folders, imported ones included)
  while `runtime.download_batches` keeps its old meaning (not-yet-imported
  only), which is what the Build pool means by a batch — **don't merge them**.
- **`crates.py`** — the preselection you gather while digging, before a set is
  programmed. Not a destination and not a playlist, and the difference is the
  module: a track has **exactly one** destination and carries it by sitting in
  a folder of that name (nothing to store), but sits in **several** crates and
  nothing moves (so crates need real storage, `.crates.json`).
  Membership is **evidence**, not just convenience: the play history records
  only what you played, a crate records what you *considered*, and the
  crate→set step records what you considered and left out — negative examples
  from a controlled context, which rekordbox cannot give at all. So the store
  is written to be read by the suggester later, not only by the UI.
  Multiplayer is coming back as local instances syncing, so four things are
  decided now because they cost nothing and are brutal to retrofit: **UUIDs**
  (two instances minting "crate 7" is unmergeable), **`created_at`/`updated_at`**,
  **tombstones** (a row that is simply gone is indistinguishable from one the
  other side hasn't seen), and **an author** on every row. They pick no sync
  strategy; they avoid foreclosing one. Nothing else in there is
  multiplayer-shaped.
- **`library.track_key`** — `rekordbox_id or isrc or display`, how anything
  storing a *reference* to a track names it. Rekordbox id first because it
  survives `refetch.replace_in_place`, so a crate still holds the track after
  an upgrade swaps the audio underneath. Build's drafts have used this from the
  start as `setline_import.set_track_id`, which now defers here.
- **`dupes.py`** — "do I already have this?", asked *before* a download commits.
  Rekordbox dedups on file location alone, so a second copy at a second path
  imports as a second entry however identical the tags — and since `history` and
  `mixmodel` key on the rekordbox track id, that splits a track's play evidence
  across both copies. Reuses `match.match_track` (never a fresh comparison) plus
  a remix-credit guard, and only ever *warns*: replacing a 128 kbps rip with
  lossless is a real reason to fetch a second copy.
  **`lookup(..., where=REKORDBOX)` is mandatory when the candidate is itself in
  the library**, and the bug it fixes is the kind that reports success. A
  downloaded file carries the ISRC it was fetched with; the ISRC branch returns
  on the first exact hit; the `DOWNLOADED` pool contains the very file being
  asked about — so the answer was always "yes, here it is", pointing at itself,
  and the fuzzy pass against rekordbox never ran (the DB stores no ISRCs, so
  that pool could never answer first). The module's own self-test printed `0`
  for every library it was ever run on while ~1000 redundant files accumulated.
  A pending download cannot be in the rekordbox pool by definition, so pinning
  the pool is both the question and the fix.
  Two things invert the advice, and both have to be checked before "you already
  have this" is allowed to mean "so get rid of it":
  - `Existing.missing_file` — the matched track's file is gone from disk, so
    the candidate is not a redundant copy but the replacement for one rekordbox
    has lost. Discarding it leaves a dead entry with no audio.
  - `Existing.different_edit` — the two files are more than `EDIT_DIFFERENCE_S`
    (20s) apart in length. `match._norm_part` strips "Extended Mix" and "Radio
    Edit" as generic qualifiers *by design*, so a 7-minute extended and a
    3½-minute radio edit score 100 against each other on name alone. Measured
    on the real library: 35 of 966 name matches were a different edit and **34
    of those were the extended against a radio edit already in the collection**
    — so the unguarded advice would have binned the better file every time.
    Duration is measured off the audio and settles what the tags are sloppy
    about; `refetch.EDIT_DIFFERENCE_S` is the same number for the same reason.
    Whoever has both files fills in `delta_s` (`incoming.scan_duplicates`);
    `lookup` only ever sees one side.
- **`drives.py`** — which external drives the library lives on, and whether
  they're plugged in. A path under `/Volumes/<name>/` that doesn't exist means
  *not connected*, never *gone*, and the app used to answer both the same way.
  It **created folders there**: `runtime.export_path()` made the export folder on
  every call, Settings calls it while drawing, and with a friend's library drive
  unplugged the page died on "Permission denied: '/Volumes/<name>'" (`/Volumes`
  is root's; on a Mac where it isn't, the folder squats the mount point and the
  drive mounts beside it as "<name> 1"). And it **called files lost**:
  `merge_rekordbox` drops the path of a file it can't see, and `dupes` reads a
  rekordbox track with no file as one rekordbox has lost — so every download
  matching a track on the drive wore "replaces a lost file". Hence the rules:
  folders under a user-chosen root go through `drives.ensure_dir`, which raises
  `DriveOffline` (a sentence saying to plug it in) instead of creating;
  `export_path()` only says where and `export_target()` is the one that writes;
  `Track.offline_path` keeps where an unreachable file is (never alongside
  `local_path`, which keeps meaning "a file we can read"), so its row says
  "offline" rather than "missing" and `missing_file` says unknown, not lost.
  `runtime.note_drives` counts what each drive holds; the header chip names a
  missing drive that holds something the app depends on (rekordbox DB, download
  folder, export file) or a tenth of the library — not 9 strays on an old drive
  — and `runtime.watch_drives` re-reads the library when one comes back, so
  plugging it in is the whole fix.
- **`setline_import.py`** — brings in a set planned in Setline (the shared online
  planner in `~/Code/setline`): reads its `.setline.json` export (format
  `setline-set` v1), matches each track by Beatport id, then ISRC, then
  `dupes.Index`; the Download page fetches the missing ones from Beatport into a
  "Setline - <set>" batch, then either exports the set to rekordbox
  (`to_playlists`: a leaf per moment, led by the whole set in order — except a
  slice down to one moment, which is just that moment's leaf under its own name;
  all under a folder named for the set and *only* the set — `export_name`
  deliberately drops the slice so a re-export lands on the same folder you delete
  to replace it) or saves it as a
  Build draft (`to_draft`: moment → entry `role`, ids as Build keys them:
  rekordbox id, else ISRC, else display). **Build is not on the way out.** A set
  that arrived already programmed is playable as it stands; going through Build
  is for *re*-programming it, and the export needs no Energy tag (a BPM is a
  Build requirement, not rekordbox's).
  `Plan.keep_moments` / `keep_added_by` narrow it to a slice — the hour you're
  preparing, or your own picks out of a b2b — and `Plan.selected` is what the
  counts, the download, the export and the draft all read, so a slice is never a
  second file. The filter lives on `runtime.setline_state`, not the plan, so a
  re-plan after downloading lands you back on the same slice. The
  draft carries no `batch_name` on purpose, so resuming pools every matched
  track, not just the downloaded ones.
- **`setline_push.py`** — the other direction: the Build page's "Setline"
  button (the set) and each block's send icon post tracks to a Setline crate,
  new or existing, with the Beatport id and ISRC the library knows so Setline
  can match exactly. Needs `SETLINE_URL`, `SETLINE_TOKEN` (Setline's
  `SETLINE_MCP_TOKEN`) and `SETLINE_NAME` (who gets the credit) in `.env`.
- **`drafts.py`** — a set-in-progress on disk, so one can be finished another day.
  Stores what it takes to *rebuild* the session, never a copy of it: the pool's
  source (playlist nodes / download batch, with the pool's track ids as the
  fallback when that source is gone), the knobs, and the set as ordered track
  ids. The library stays the source of truth for what a track is. Two slots,
  same shape: **named drafts** (`.set_drafts.json`, deliberate, kept until
  deleted) and **the session** (`.build_session.json`, one slot rewritten as you
  work and restored on the next launch). The autosave's one rule: an empty set
  only overwrites the saved one once the process has *restored* it — open the
  app before rekordbox has loaded and writing "nothing here" would delete last
  night's work (`build_page._autosave` / `restore_autosave`).
- **`store.py`**, **`config.py`**, **`staging.py`** — local persistence and config.

### App

- **`main.py`** — entry point. The `if __name__ == "__main__"` guard matters: the
  analysis pool uses multiprocessing "spawn", which re-imports this module in
  every worker.
- **`runtime.py`** — the process-wide singletons every page reads (`library`,
  `download_batches`, `history_state`, `mix_state`, `build_state`,
  `setline_state`, `job_state`). Only ever *mutated*, never rebound — `import
  runtime` and reference `runtime.library`, so a rebinding can't strand a stale
  alias.
  **A NiceGUI page body re-runs from scratch on every visit**, so anything a page
  function holds is lost the moment you click another tab — which is why a
  page's working session lives here: `build_state` (pool + blocks + the set) and
  `setline_state` (the dropped `.setline.json`, its match against the library,
  and the slice you narrowed it to). None of them hold UI elements — those die
  with their client, and the pages keep them in a per-visit dict instead.
  `job_state` + `start_job` are the same idea for the Library page's long jobs
  (analyze / loudness / normalize / integrity / refetch): the job runs on its
  own thread rather than inside `run.io_bound`, because awaiting that makes the
  *page's* coroutine the owner of the result and that page is gone as soon as
  you click another tab. The thread only writes into `job_state`; whichever
  Library page is open when it lands shows the result (`library_page._tick` →
  `_deliver`), and if none is, the result waits until one opens. A page being
  left behind must not claim it, hence the `client.has_socket_connection` check
  either side of delivery.
- **`shell.py`** — theme, header/nav (with the setup-needed badge on the ⚙),
  quick settings dialog, and `PLAYER_ASSETS` (the CSS+JS behind the custom audio
  transport). Deliberately free of `runtime`.
- **`export_ui.py`** — `export_handoff`, the persistent dialog every "Export to
  rekordbox" ends in (setup check → refresh/drag steps → "Done — reload
  library"), plus the reusable xml-wiring panel Settings shows. UI layer: unlike
  `widgets` it imports `runtime`; imported by pages only.
- **`widgets.py`** — pure render helpers: `render_track_row`, `audio_player`,
  `energy_arc_svg`, `set_arc_svg`, `_chip`, the energy/Camelot color language.
- **`media.py`** — `/media` (audio) and `/artwork` (the sleeve out of a file's
  own tags), both served only for files the library knows about. `/artwork`
  **downscales to `ART_PX` and caches**: stores embed sleeves at full size
  (measured 278 KB average here), a card shows one at ~48px, and a shelf of
  forty would otherwise push 11 MB to draw forty thumbnails — 220 KB after.
  Cached on path **+ mtime**, so a file replaced in place stops serving the
  old record's sleeve.
- **`pages/`** — one module per route, registered by import side effect:
  `/incoming`, `/` (library), `/build`, `/download`, `/history`, `/settings`.
  `/microsets` and `/builder` redirect to `/build`, which merged them; `/sync`
  redirects to `/incoming`, which did the same to it.
  **`pages/crate_bar.py` is Setline's UI living inside Track Studio's.** The
  crate dock mounts on any page that lists tracks, because crating happens
  wherever you notice a track — you are on a playlist, you see one, it goes in
  "Friday", you carry on. It is deliberately **not** Track Studio's look: the
  card with its sleeve, the sideways-scrolling shelf and the tab strip are
  lifted from Setline's `.dock` / `.shelf` / `.card` CSS (prefixed `ts-`),
  because that look is 628 lines of hand-written CSS with no component library
  behind it — the only honest way to have it here is to bring the CSS. The two
  palettes turned out to be *the same language typed twice* (Setline's
  `--accent` and `--smooth` are Track Studio's exact hexes, and both derive the
  Camelot pill from the wheel hour with the same formula), so
  `widgets.camelot_color` is used unchanged.
  **The drag never touches the server.** A drag is events at pointer rate and a
  NiceGUI round trip is tens of milliseconds, so it is plain HTML5
  drag-and-drop handled in the browser and only the *drop* crosses the wire —
  one `emitEvent` carrying a track key. Same rule that fixed the table: keep
  the interaction local, send the decision. Listeners are delegated from
  `document` because the dock's markup is replaced wholesale on every change.
  `ui.html(..., sanitize=False)` is required (the `draggable` and
  `data-crate-act` attributes are what it is wired through), so everything
  interpolated is escaped at the point of use — this library really does
  contain filenames carrying raw `&#39;`.
  `grab_cell()` is the table side: the drag handle **plus a chip saying which
  crates already hold the row**, because without it the dock is write-only from
  the table and the only way to answer "have I crated this?" is to open each
  crate and look. One crate reads as its name, more than one as a count, the
  full list is the tooltip. Both the chip and the `+` open a picker, which is
  the path for anyone not dragging — a trackpad, or a row near the top of three
  thousand with the dock at the bottom of the screen. Pages pass
  `mount(on_change=…)` so the chips repaint when the dock changes.
  **Setline's CSS assumes content-sized containers**, which is worth knowing as
  more of it comes across: pinning the header to a fixed height turned its
  `margin-bottom:-1px` tab idiom into a one-pixel overflow, and `overflow-x:auto`
  turned that into a vertical scrollbar (the spec won't leave one axis
  `visible` when the other isn't). Anything given a fixed height here needs its
  borders and negative margins re-checked.
  **A fixed dock has to be paid for by the pages under it.** It is
  `position:fixed; bottom:0`, so anything at the bottom of a page's scroll area
  lives *under* it — the sidebar's last playlist was unreachable. `crate_bar`
  therefore reserves the room from outside itself: `--ts-dock-room` on `body`
  (38px closed, 200px while open or dragging, via `body:has(.ts-dock.open)`)
  padding the bottom of `.q-drawer__content` and `.q-page-container`. The
  property lives on `body` so a browser without `:has()` still gets the closed
  reserve, and the fill screen — a dialog *over* the dock, not a page under it —
  opts back out.
  **`pages/crate_fill.py` — "Fill this crate", and why it is a screen.** The
  dock's ✨ Fill opens a full-screen dialog of proposals from `mixmodel.fill`,
  each with its artwork, the crate track it sits closest to, the reason, a
  player, and an **Add button — nothing enters a crate unless you press it.**
  That is the whole design: a crate is a hand-made thing, so a suggester that
  wrote into it would be quietly un-making it, and a ×34-over-chance ranking
  (see `mixmodel`) is exactly the accuracy that has to be *offered* rather than
  applied. Adding leaves the list where it is (dimmed row, teal border) instead
  of re-sorting under the pointer; **Re-rank** is a separate button, because
  re-scoring is a thing you ask for once you've made your picks. A dialog and
  not a route: filling happens in the middle of digging, and closing it puts
  you back on the same page at the same scroll position.
  **The way out is a back arrow at the top left**, not only the "Done" in the
  far corner: on a screen that commits nothing, a lone Done reads as a commit
  gesture rather than an exit, and it was reported as *no way back*. Escape works
  too (Quasar's own dismiss).
  It also **says what it had to go on** — each row carries its genre, the header
  reports what share of the library has one, and a crate whose own tracks have
  none is told, in words, that it is being ranked on tempo and key. That is the
  same honesty rule as the Add button: an answer you can't judge is one you
  can't use, and this ranking's inputs are thin enough that hiding it would
  mislead (see [`docs/proposals/0001`](docs/proposals/0001-crate-matching-and-the-sound-axis.md)).
  **`pages/acquire.py` is the other non-route:** It builds the
  link box, the Beatport search and the Downloads inbox into whatever container
  it is handed and returns a `refresh()`; Incoming owns the container, the
  drawer entry and the notifications, so a download's result outlives the list
  that started it. Built on first use, because its inbox scan reads tags and
  walks the library and no visit that never opens it should pay for that.
  It is in Setline's language too, over the shared tokens in
  **`pages/kit.py`** — three surfaces speak that palette now (dock, acquire,
  fill), and one drifting copy is how two of them stop looking like one app.
  Each scopes the tokens to its own class rather than to `:root`: these mount
  inside pages full of Quasar, and a global variable named `--line` is the kind
  of thing a component library helps itself to.

### Incoming owns the arrival pipeline

The job the page exists for, in one sentence: *sync a playlist or acquire a
track, make sure it ends up in the right playlist, and send it to rekordbox so
the actual playlist updates.* Everything on it is built from that sentence.

**Build it from the job, not from the code that's already on screen.** This page
was got wrong twice by doing the opposite — first as a sidebar list bolted onto
Library, then as a rewrite that kept the old steps (analyze, export) as its main
controls. Both reorganised what existed instead of asking what the user came to
do. The symptom each time was the same: the biggest button on screen served a
feature (Build) that is being deleted.

The spine is therefore **where a track is going**, and the views that lead are
the things you can act on:

- **Needs a home** — acquired, nobody said which playlist. The dead end the old
  flow created: a thousand files sat in `Beatport/` (936 on one day) because
  nothing ever asked. Ticks + a playlist picker; filing moves the files.
- **Already have it** — the collection *already holds* this, under another path,
  **at the same length**. Filing one of these is not a smaller version of the
  right action, it is the wrong one, so they are lifted out of the filing
  worklist rather than listed among it. Discard (move to `.duplicates`) is the
  expected answer and filing is the dissenting one, which is why both verbs are
  on the bar. Measured on the real library the first time it ran, of 999
  homeless files: **931 were already in rekordbox** at the same length (5.9 GB
  of re-downloaded collection), 37 were a *longer* edit than what rekordbox
  had, 21 replaced a rekordbox entry whose file was gone, and 10 were new. The
  "backlog" was a re-download of the collection, not a filing job.
  **Only the 931 may be discarded**; everything the match argues *for* keeping
  stays in Needs a home wearing a chip that says why (green "longer edit", blue
  "replaces a lost file"), because a pile labelled "you already have these" is
  the one label that would invite binning them all. The view only appears once
  the scan has an answer; an "Already have it (0)" sitting there beforehand is a
  claim we haven't earned.
  The **evidence is reachable per row**, because a playlist name can't settle
  "is this really the same file?": the "Show paths" switch puts the last two
  components of both files inline, and hovering gives the two full paths and
  both lengths. Two collapsed states rather than columns — 931 rows of full
  paths would bury the thing you came to read.
- **Longer than rekordbox's** — the mirror of the above: the collection has this
  record, but what just arrived is the longer cut (37 of them here, the
  extended mix against a radio edit). Its verb is its own, which is why it is
  its own view: **Replace** puts the new file at the path rekordbox already
  points at (`refetch.replace_in_place`, backup + packet check + rollback), so
  the entry keeps its playlists, rating and **play history** — the thing
  `history`/`mixmodel` are built on — and only the audio changes. Filing
  instead would leave the worse file holding all of that. Two costs the dialog
  states rather than discovers: the cue points and beatgrid were set for the
  shorter edit and will be wrong, and the Energy tag carries over stale. The
  displaced file lands in `.replaced/`, not refetch's `.broken_backup/` — same
  mechanism, but calling a perfectly good radio edit "broken" would be a claim
  that isn't true.
- **Ready to send** — destination known, rekordbox hasn't got it. One import per
  destination.
- **Acquire a track** — the link box, the Beatport search and the Downloads
  inbox (`pages/acquire.py`), as a *view* rather than a page. It asks where the
  track is going **before** fetching it: the destination is in the Download
  button's own label, and leaving it blank says out loud that the file will land
  in a door folder and join "Needs a home". That is the door the pile came
  through, so closing it is the other half of clearing the pile.

Below those, the synced playlists and the download folders, for drilling in.
Four things worth knowing:

- **A synced source shows *all* its rows, finished ones included** — that is what
  the export would carry, and hiding a track already in the set is how one gets
  silently clipped out of it. Everything else is a worklist.
- **A source's download goes straight into its destination folder**, so a synced
  track never passes through the unfiled state at all.
- **Export is per destination, never merged.** One import carries one name, so
  several destinations means a list to pick from, not a guess.
- **A pulled gap is cached in `runtime.source_rows`** — a pull costs a Spotify
  round trip plus a fuzzy match against the whole collection. A rekordbox reload
  clears it, because every "have it / missing" answer was computed against the
  collection that just changed.

`/download` is **not in the nav**, and now holds only the Setline set import.
Acquiring is a step of this job, not a place, so it lives on Incoming; the route
survives for the bridge and keeps "Incoming" lit, with a button back to where
acquiring went so an old bookmark doesn't read as a dropped feature.

**What is deliberately not there:** the Setline set import itself. It is a
bridge between two libraries, and it goes away entirely once the board runs
locally against this one — `setline_import.py`, `setline_push.py` and the
`.setline.json` format with it. Porting it would be work spent on something
already condemned. The plan, with what it deletes and what it must not lose:
[`docs/proposals/0002`](docs/proposals/0002-setline-becomes-the-set-builder.md).

### The window

`window.py` is the app as macOS sees it: a WKWebView (pywebview) on
`127.0.0.1:8080`, run by the bundle's launcher in the **foreground**, which is
what gives Track Studio a Dock icon, ⌘Tab and a menu bar instead of a browser
tab. It is a **separate process from the server** on purpose — closing the window
leaves a four-hour analysis running, reopening is instant, and an update can
restart the server underneath it while the page just reloads. (pywebview also
insists on the main thread, which the analysis pool's parent already owns.)

- **`claim_identity`** overrides `CFBundleName` and the Dock icon at runtime: the
  process is the framework's `Python.app`, so without it the app is called
  "Python". Cosmetic failure only — never fatal.
- **`raise_existing_window`** makes a second launch bring the first window
  forward (`NSRunningApplication`, no accessibility permission needed) instead of
  stacking windows, because the launcher runs on every ⌘Space.
- ⌘R / ⌘0 / ⌘+ / ⌘− are wired in JS; the rest is Cocoa's.

### Self-update

The whole endpoint is a **static JSON file** — Tauri's updater pattern, with
Sparkle's signing habit; there is no update server. A release is two files in a
public repo (`stable.json` + `releases/track-studio-<v>.zip`), so publishing is a
commit in GitHub Desktop.

- **`VERSION`** — one line, the only place the number lives. `build_app.sh` stamps
  it into the bundle's plist, so Get Info and the app can't disagree.
- **`updates.py`** — check (twice a day and at launch), download, verify, and the
  `/api/version` route. Registered from `main.py`'s `__main__` guard, so the
  analysis workers don't each start a checker. `available()` reads the last
  answer off disk, which is what the header chip renders on every page.
- **`signing.py`** — ed25519, the RFC 8032 reference code, no dependency: the one
  component that must keep working mid-upgrade can't be broken by a package
  install. Private key in `~/.config/track-studio/release_key`, public half baked
  into `updates.RELEASE_PUBLIC_KEY`.
- **`scripts/apply_update.py`** — the swap, detached, because it stops the server
  whose files it replaces. Stdlib only and no project imports.
- **`scripts/release.py`** — build + sign + write the manifest. `keygen` once.

Four things it is easy to get wrong, each of which was got wrong first:

1. **What the signature covers is `version\ntheir sha256`**, not the zip alone.
   The manifest and the payload sit in the same public repo, so signing the file
   by itself would leave the manifest free to point a version number at some
   other validly-signed zip.
2. **Nothing is swapped until the port is actually free.** The pid the helper is
   handed is only a hint (it's whoever asked); `stop_server` falls back to
   whatever `lsof` says is listening and *returns whether it worked*.
3. **"It answers" is not proof the new version is running.** `current_version()`
   reads `VERSION` from disk, so a server that never stopped happily reports the
   number it was just handed — the `/api/version` **pid** is what tells the two
   apart. (This is the bug that made a failed install look successful.)
4. **The payload is what git tracks *or would track*** (`release.payload_files`).
   Tracked-only is the obvious rule and the wrong one: a release cut before the
   commit ships without its newest modules and then refuses to install. Ignored
   paths stay out, which is what keeps the venv, models, `.env` and local state
   out of a zip that gets unpacked over someone's install.

A failed start rolls back: the previous files are restored from
`data/updates/rollback/`, the old version is started again, and an alert says so.
A version that dies on import is noticed the moment the child process exits, not
at the end of the 120s wait. `data/update.log` has every step of every attempt.

Testing a release without publishing one: `TRACK_STUDIO_FEED=file:///…` in `.env`
— `urllib` reads `file://` URLs, so the whole flow runs with no server anywhere.

### Two model families

`build_predictors` loads two backbones depending on `rich`:

- Always: **MusiCNN** backbone → DEAM head (arousal+valence). This alone gives Energy.
- `--rich` only: additionally **MusiCNN→danceability**, and the **Discogs-EffNet**
  backbone → genre (400 classes) + moodtheme (56 classes, sigmoid, top-2 ≥ 0.10).

Texture descriptors (brightness / dynamic / spectral complexity / onset rate) come
from plain DSP in `_extract_texture`, not a model — they discriminate inside a
tight genre cluster where danceability and valence saturate.

Model files and URLs live in `MODEL_FILES` at the top of `energy.py`;
`ensure_models()` downloads any missing ones on first use.

### File handling conventions

- Supported: `.mp3`, `.m4a`. WAV/AIFF/FLAC/AAC are listed in `find_skipped_files`
  and reported but not tagged (rekordbox WAV tagging is non-standard).
- `find_audio_files` is non-recursive (single folder) and ignores dotfiles.
- The pre-analysis partition in `main()` calls `read_existing_energy` *before*
  importing Essentia, so a fully-tagged folder exits without paying the TF import.

## Conventions worth respecting

- **Defer heavy imports** (`essentia`, `mutagen.id3`, `mutagen.mp4`, `pyrekordbox`)
  into function bodies so `--help` / `--dry-run` and page opens stay fast.
- **Long jobs outlive the browser tab.** Wrap UI updates from a background job in
  `runtime._safe_ui` — touching a dead client's elements raises `RuntimeError`.
- **A notification is an element, and NiceGUI runs a handler in the *sender's*
  parent slot.** So a spinner started from a button inside a list belongs to that
  list: a handler that re-renders its own list (`col.clear()`) deletes its own
  message mid-job, and the result it notifies afterwards is created in a dead
  slot and never reaches the browser — a download that silently reported nothing,
  not even its error. Anchor both to a container the handler doesn't clear
  (`download_page.toast` / `spinner`).
- **A `ui.table` row dict is paid for once per row *and again on every selection
  change*.** NiceGUI keeps `selected` as a list of **whole row dicts** in
  `_props`, so it is pushed to the browser as a Quasar prop every time the
  selection changes — tick the 900th box and all 900 dicts go over the wire
  again. Adding four path-ish fields to the Incoming rows took 931 rows from
  458 KB to 1130 KB and made "Select all shown" visibly lag. Three rules follow:
  derive in the template what the browser can (`props.row.path.split('/')`,
  not a second pre-computed field); send a field only on the view that draws it
  (a chip's tooltip is dead weight where the chip is hidden); and put *view
  state* in a class on the table rather than a boolean copied onto every row —
  `.ts-show-paths` toggles with CSS and never rebuilds a row. Above a few
  hundred rows, give the bulk action its own button over the server-side item
  list instead of routing it through a selection at all.
- **Read tags from the file, not from rekordbox's `Commnt`**, which only refreshes
  when the user clicks "Reload Tag" and can lag by days.
- **Everything exports to one file** (`runtime.export_path()`), so rekordbox's XML
  view is pointed at it once and just refreshed.
- Rekordbox's XML import requires **numeric TrackIDs**; the exporters synthesize
  them because a logical id may be an ISRC or a title.
- **Never fetch audio over HLS** (`bpdl.BROKEN_QUALITIES`). beatportdl's
  `medium-hls` stitches a track out of ~5s encrypted segments and remuxes them
  with ffmpeg; every join carries a timestamp discontinuity. Measured here: 91
  and 98 breaks in two tracks, one every ~5s, up to 93ms each — a fifth of a beat
  at 133 BPM, audible as a jump, and a beatgrid that can't be made to fit. It was
  never an upgrade: identical 128 kbps AAC to `medium`. Two free tells that a
  file came down this way — an encoder atom (a store download has *none*; a
  remux is stamped `Lavf…`), and rekordbox gridding it at 133.xx where the
  Beatport tag says a flat 133. `scripts/find_broken_audio.py` uses both to
  decide what to ffprobe, and the packet check to decide. Withdrawn from the
  Settings picker but still recognised there, so a config already set to it is
  shouted about rather than silently honoured.
