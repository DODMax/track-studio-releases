"""Beatport API client — authenticate as a user and search the catalog.

Replicates the OAuth dance that beatportdl (github.com/unspok3n/beatportdl)
uses: a Beatport account's username/password are exchanged for a short-lived
session, then an authorization code, then a Bearer access token. The same
public client_id that Beatport's own web app uses is reused here.

No credentials are stored in this module. Pass them in (the app injects them
from Infisical / the bpdl config), e.g.:

    bp = Beatport(username, password)
    bp.login()
    track = bp.search_by_isrc("GBARL0600677")

This is a thin, read-only client: login + catalog search/lookup. Downloads
stay the job of the bpdl binary.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Optional

import requests

API_BASE = "https://api.beatport.com/v4"
CLIENT_ID = "ryZ8LuyQVPqbK2mBX2Hwt4qSMtnWuTYSqBPO92yQ"

LOGIN_URL = f"{API_BASE}/auth/login/"
AUTHORIZE_URL = f"{API_BASE}/auth/o/authorize/"
TOKEN_URL = f"{API_BASE}/auth/o/token/"

# A browser-ish UA; the API rejects some default client UAs.
USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) track-energy/0.1"


class BeatportAuthError(RuntimeError):
    """Login or token exchange failed."""


@dataclass
class BeatportTrack:
    """The subset of a Beatport catalog track we care about for matching."""
    id: int
    name: str
    mix_name: str
    artists: list[str]
    isrc: Optional[str]
    bpm: Optional[int]
    key: Optional[str]
    length_ms: Optional[int]
    url: str
    raw: dict[str, Any]

    @property
    def display(self) -> str:
        artists = ", ".join(self.artists)
        mix = f" ({self.mix_name})" if self.mix_name else ""
        return f"{artists} - {self.name}{mix}"

    def artwork(self, size: int = 96) -> Optional[str]:
        """The release sleeve at `size` px square, or None.

        The sleeve hangs off the *release* — a track's own `image` is a
        1500x250 banner, which is not what anyone means by cover art. The CDN
        resizes on demand through `dynamic_uri`, so a thumbnail costs a
        thumbnail (~2 KB at 96px) instead of a 500px jpeg squeezed down in the
        browser. Ask for twice the drawn size; these are retina screens.
        """
        img = (self.raw.get("release") or {}).get("image") or {}
        dynamic = img.get("dynamic_uri")
        if dynamic:
            return dynamic.replace("{w}", str(size)).replace("{h}", str(size))
        return img.get("uri") or None

    @property
    def sample_url(self) -> Optional[str]:
        """The store's own two-minute preview clip, or None.

        A plain mp3 on a public CDN: no auth, no subscription, and emphatically
        no HLS — the one transport this project refuses (`bpdl.BROKEN_QUALITIES`)
        would have been defensible for a preview, and isn't needed even there.
        Beatport cuts the clip from the middle of the track (`sample_start_ms`,
        usually near the two-minute mark), which is the part you would audition
        anyway, and it rides along in `raw` on every search hit — so hearing a
        track before buying it costs nothing we haven't already fetched.
        """
        return self.raw.get("sample_url") or None

    @property
    def sample_window(self) -> Optional[tuple[float, float]]:
        """Where in the track the clip was taken from, in seconds, if stated."""
        start, end = self.raw.get("sample_start_ms"), self.raw.get("sample_end_ms")
        if start is None or end is None:
            return None
        return start / 1000, end / 1000


def _store_url(d: dict[str, Any]) -> str:
    """The track's page in the *store* — which is not what the API calls `url`.

    A catalog response's `url` is its own self-link,
    `api.beatport.com/v4/catalog/tracks/<id>/`, so trusting it sent "open ↗"
    to a JSON document instead of the page you buy from. The store's canonical
    form is `/track/<slug>/<id>`, and it resolves `x` in place of a slug it can
    look up from the id — the same shape `bpdl` hands the downloader.
    """
    return f"https://www.beatport.com/track/{d.get('slug') or 'x'}/{d.get('id')}"


def _parse_track(d: dict[str, Any]) -> BeatportTrack:
    """Map a raw Beatport track JSON object into a BeatportTrack."""
    key = None
    if isinstance(d.get("key"), dict):
        # Prefer Camelot when present, else the spelled-out name.
        key = d["key"].get("camelot_number") and (
            f"{d['key'].get('camelot_number')}{d['key'].get('camelot_letter', '')}"
        ) or d["key"].get("name")
    return BeatportTrack(
        id=d["id"],
        name=d.get("name", ""),
        mix_name=d.get("mix_name") or "",
        artists=[a.get("name", "") for a in d.get("artists", [])],
        isrc=d.get("isrc"),
        bpm=d.get("bpm"),
        key=key,
        length_ms=d.get("length_ms"),
        url=_store_url(d),
        raw=d,
    )


class Beatport:
    def __init__(self, username: str, password: str):
        self._username = username
        self._password = password
        self._session = requests.Session()
        self._session.headers.update({"User-Agent": USER_AGENT})
        self._access_token: Optional[str] = None
        self._token_expires_at: float = 0.0

    # -- auth ----------------------------------------------------------------

    def login(self) -> None:
        """Run the full login -> authorize -> token flow. Raises on failure."""
        self._password_login()
        code = self._authorize_code()
        self._exchange_code(code)

    def _password_login(self) -> None:
        # Seed cookies (csrftoken) by touching the API root first.
        self._session.get(f"{API_BASE}/auth/login/", timeout=30)
        csrf = self._session.cookies.get("csrftoken")
        headers = {"Referer": LOGIN_URL}
        if csrf:
            headers["X-CSRFToken"] = csrf
        r = self._session.post(
            LOGIN_URL,
            json={"username": self._username, "password": self._password},
            headers=headers,
            timeout=30,
        )
        if r.status_code != 200:
            raise BeatportAuthError(f"login failed: {r.status_code} {r.text[:300]}")
        if not self._session.cookies.get("sessionid"):
            raise BeatportAuthError("login returned 200 but no sessionid cookie")

    def _authorize_code(self) -> str:
        r = self._session.get(
            AUTHORIZE_URL,
            params={"client_id": CLIENT_ID, "response_type": "code"},
            allow_redirects=False,
            timeout=30,
        )
        loc = r.headers.get("Location", "")
        if "code=" not in loc:
            raise BeatportAuthError(
                f"authorize did not return a code (status {r.status_code}, loc={loc!r})"
            )
        # code is the value of the `code` query param in the redirect URL.
        from urllib.parse import urlparse, parse_qs

        code = parse_qs(urlparse(loc).query).get("code", [None])[0]
        if not code:
            raise BeatportAuthError(f"could not parse code from redirect: {loc!r}")
        return code

    def _exchange_code(self, code: str) -> None:
        r = self._session.post(
            TOKEN_URL,
            data={
                "grant_type": "authorization_code",
                "code": code,
                "client_id": CLIENT_ID,
            },
            timeout=30,
        )
        if r.status_code != 200:
            raise BeatportAuthError(f"token exchange failed: {r.status_code} {r.text[:300]}")
        tok = r.json()
        self._access_token = tok["access_token"]
        self._token_expires_at = time.time() + int(tok.get("expires_in", 3600)) - 60
        self._session.headers["Authorization"] = f"Bearer {self._access_token}"

    def _ensure_token(self) -> None:
        if not self._access_token or time.time() >= self._token_expires_at:
            self.login()

    # -- catalog -------------------------------------------------------------

    def _get(self, path: str, **params) -> dict[str, Any]:
        self._ensure_token()
        r = self._session.get(f"{API_BASE}{path}", params=params, timeout=30)
        r.raise_for_status()
        return r.json()

    def search_by_isrc(self, isrc: str) -> Optional[BeatportTrack]:
        """Exact ISRC lookup. Returns the first matching track or None."""
        data = self._get("/catalog/tracks/", isrc=isrc)
        results = data.get("results") or []
        return _parse_track(results[0]) if results else None

    def search(self, query: str, per_page: int = 10) -> list[BeatportTrack]:
        """Free-text catalog search; returns track results (artist/title query)."""
        data = self._get("/catalog/search/", q=query, per_page=per_page, type="tracks")
        tracks = data.get("tracks") or data.get("results") or []
        return [_parse_track(t) for t in tracks]

    def get_track(self, track_id: int) -> BeatportTrack:
        return _parse_track(self._get(f"/catalog/tracks/{track_id}/"))

    def get_release_tracks(self, release_id: int,
                           per_page: int = 100) -> list[BeatportTrack]:
        """Every track on a release — so a pasted release URL can be previewed
        (and priced in tracks) before anything is downloaded."""
        data = self._get(f"/catalog/releases/{release_id}/tracks/",
                         per_page=per_page)
        return [_parse_track(d) for d in data.get("results", [])]


def _load_bpdl_config(path: str) -> tuple[str, str]:
    """Read username/password from a beatportdl config yml (fallback creds source)."""
    import yaml

    with open(path) as f:
        cfg = yaml.safe_load(f)
    return cfg["username"], cfg["password"]


def credentials() -> tuple[str, str]:
    """Beatport creds: prefer .env, fall back to the bpdl config yml if present."""
    from config import load_env
    import os

    load_env()
    user = os.environ.get("BEATPORT_USERNAME")
    pw = os.environ.get("BEATPORT_PASSWORD")
    if user and pw:
        return user, pw
    for candidate in ("beatportdl/beatportdl-config.yml", "bpdl/beatportdl-config.yml"):
        if Path(candidate).exists():
            return _load_bpdl_config(candidate)
    raise BeatportAuthError("no Beatport credentials (set BEATPORT_USERNAME/PASSWORD in .env)")


def connect() -> "Beatport":
    """Convenience: build a logged-in client from configured credentials."""
    user, pw = credentials()
    bp = Beatport(user, pw)
    bp.login()
    return bp


if __name__ == "__main__":
    # Smoke test: log in using configured creds and run one ISRC lookup.
    import sys

    user, pw = credentials()
    bp = Beatport(user, pw)
    print("logging in...", flush=True)
    bp.login()
    print(f"  ok, token acquired (expires ~{int(bp._token_expires_at - time.time())}s)")

    test_isrc = sys.argv[2] if len(sys.argv) > 2 else "GB28K1500096"
    print(f"ISRC lookup {test_isrc}...", flush=True)
    t = bp.search_by_isrc(test_isrc)
    print(f"  -> {t.display} | bpm={t.bpm} key={t.key} url={t.url}" if t else "  -> no match")

    print("free-text search 'daft punk one more time'...", flush=True)
    for t in bp.search("daft punk one more time", per_page=3):
        print(f"  - [{t.id}] {t.display} (isrc={t.isrc})")
