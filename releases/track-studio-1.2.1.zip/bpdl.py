"""Beatport download — resolve Spotify tracks to Beatport, then fetch via bpdl_mac.

Resolution reuses beatport.py (ISRC exact → fuzzy artist+title via match.py) with
the same confidence tiers as the gap view. Download shells out to the beatportdl
binary, run from a dedicated working dir holding our own config (so output goes to
the staging folder and the user's beatportdl setup is left untouched — bpdl checks
the working dir for its config before the executable dir).
"""
from __future__ import annotations

import re
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

import yaml

import beatport
import drives
from config import ROOT
from match import best_match, normalize
from spotify import SpotifyTrack
from staging import STAGE_DIR

BPDL_DIR = (ROOT / "beatportdl").resolve()
BPDL_BIN = BPDL_DIR / "bpdl_mac"
BPDL_CONFIG = BPDL_DIR / "beatportdl-config.yml"
AUDIO_EXTS = {".m4a", ".mp3", ".flac", ".aac"}

DEFAULT_QUALITY = "medium"
RECOMMENDED_QUALITY = "medium"
# HLS is the *fallback* for Medium, not a step up: identical 128 kbps AAC, just
# fetched a slower way. Keyed here so the UI can steer people back to Medium.
FALLBACK_FOR = {"medium-hls": "medium"}

# Qualities we refuse to offer, and why — not deleted, because a config already
# set to one has to be recognised and flagged rather than silently accepted.
#
# medium-hls stitches a track out of ~5s encrypted segments and remuxes them
# with ffmpeg, and every join carries a timestamp discontinuity. Measured on two
# tracks in this library: 91 and 98 breaks, one every ~5s, each shifting the
# audio by up to 93ms — a fifth of a beat at 133 BPM, audible as a jump. The
# giveaway downstream is rekordbox gridding the track at 133.xx where the
# Beatport tag says a flat 133, and a beatgrid that can't be made to fit. It was
# never an upgrade — identical 128 kbps AAC to `medium` — so there is nothing to
# weigh against that. See `scripts/find_broken_audio.py` to find affected files.
BROKEN_QUALITIES = {
    "medium-hls": "stitched from ~5s segments; every join shifts the audio by up "
                  "to a fifth of a beat, so the beatgrid drifts and can't be "
                  "fixed. Identical 128 kbps audio to Medium — nothing is gained.",
}

# What Beatport grants depends on the *subscription tier*, and beatportdl does not
# degrade: an unavailable tier fails the whole batch with
# "400 - Requested quality is not available" and downloads nothing. So the setting
# is worth probing (probe_quality) before a real run.
#
# Ordered best → fallback: ui.select renders in dict order, so the list reads as a
# quality ladder with HLS at the bottom, where it belongs.
QUALITY_OPTIONS = {
    "lossless":   "FLAC 44.1 kHz  (.flac)  — highest · needs a top LINK tier",
    "high":       "AAC 256 kbps  (.m4a)  — needs a higher LINK tier",
    "medium":     "AAC 128 kbps  (.m4a)  — recommended",
}

# Shown under the picker for the selected option — the "why" behind the ordering.
QUALITY_NOTES = {
    "lossless": "FLAC isn't tagged by Track Studio (it writes .mp3/.m4a only), so "
                "these downloads land in the library without an Energy tag.",
}


def quality_options(current: Optional[str] = None) -> dict[str, str]:
    """What the quality picker may show.

    The offerable qualities — plus `current`, if the config is already set to one
    we've withdrawn. A select whose value isn't among its options renders blank,
    which would read as "no quality set" for precisely the setting that most
    needs to be shouted about.
    """
    opts = dict(QUALITY_OPTIONS)
    if current in BROKEN_QUALITIES:
        opts[current] = f"{current}  —  ⚠ DO NOT USE, see below"
    return opts
# The tagger only writes .mp3/.m4a (see energy.SUPPORTED_EXTS), so FLAC downloads
# land in the library untaggable — flagged in the UI rather than blocked.
UNTAGGABLE_QUALITIES = {"lossless"}


# A Beatport web URL ends in /<kind>/<slug>/<id>, with an optional locale
# segment ("/en/track/…") and any query string. The slug is decorative — the
# trailing id is the only part that identifies anything.
_URL_RE = re.compile(
    r"beatport\.com/(?:[a-z]{2}(?:-[a-z]{2})?/)?(track|release|chart)/[^/]+/(\d+)",
    re.IGNORECASE,
)


def parse_url(url: str) -> Optional[tuple[str, int]]:
    """(kind, id) for a Beatport track/release/chart URL, else None."""
    m = _URL_RE.search(url or "")
    return (m.group(1).lower(), int(m.group(2))) if m else None


# beatportdl has no quit flag: after the batch it prompts for another url and
# hits our closed stdin, so its last two lines are the same noise whatever
# happened. A failing line, by contrast, is prefixed with the url it was given.
_LOG_NOISE = ("enter url or search query", "error reading input string")
_LOG_URL = re.compile(r"^\[https?://\S*?/(\d+)\]\s*")


def failure_reason(log: str) -> str:
    """Why a batch came back empty, in the words that matter.

    Showing the raw log buried the one line that explains anything under the
    binary's own EOF chatter. "403 - Territory Restricted" is the common one and
    the most opaque: Beatport won't sell that track in your country, so neither
    a retry nor another quality will ever fetch it.
    """
    lines: list[str] = []
    for raw in (log or "").splitlines():
        line = _LOG_URL.sub("", raw.strip())
        if not line or line in lines:
            continue
        if any(n in line.lower() for n in _LOG_NOISE):
            continue
        lines.append(line)
    text = " · ".join(lines) or "beatportdl said nothing."
    if "territory restricted" in text.lower():
        text += ("  Beatport doesn't sell it in your country — retrying or "
                 "changing quality won't help. Try a YouTube/SoundCloud link, "
                 "or drop the file in your Downloads folder.")
    return text


def failures_by_id(log: str) -> dict[int, str]:
    """What the log says about each track id it names.

    Only meaningful for ids that produced no file — beatportdl prefixes lines
    with the url, not with whether they went well.
    """
    out: dict[int, str] = {}
    for raw in (log or "").splitlines():
        line = raw.strip()
        m = _LOG_URL.match(line)
        if m:
            out[int(m.group(1))] = _LOG_URL.sub("", line)
    return out


def is_beatport_url(url: str) -> bool:
    return parse_url(url) is not None


def tracks_for_url(url: str, bp=None) -> tuple[str, list["beatport.BeatportTrack"]]:
    """(kind, tracks) behind a pasted Beatport URL — one for a track link, the
    whole tracklist for a release. Metadata only; nothing is downloaded."""
    parsed = parse_url(url)
    if not parsed:
        raise ValueError("not a Beatport track or release URL")
    kind, bp_id = parsed
    if kind == "chart":
        raise ValueError("chart links aren't supported yet — paste a track or "
                         "release URL")
    bp = bp or beatport.connect()
    if kind == "track":
        return kind, [bp.get_track(bp_id)]
    return kind, bp.get_release_tracks(bp_id)


def search_tracks(query: str, limit: int = 12, bp=None) -> list["beatport.BeatportTrack"]:
    """The catalog's best guesses for a typed query — what `tracks_for_url` is
    to a pasted link.

    Same search `resolve` uses to match a Spotify track, minus the picking: here
    a person reads the list, so the ranking is Beatport's and the choice is
    theirs.
    """
    if not (query or "").strip():
        return []
    bp = bp or beatport.connect()
    return bp.search(query.strip(), per_page=limit)


def read_config() -> dict:
    if not BPDL_CONFIG.exists():
        return {}
    return yaml.safe_load(BPDL_CONFIG.read_text()) or {}


def get_quality() -> str:
    return read_config().get("quality") or DEFAULT_QUALITY


def set_quality(quality: str) -> None:
    """Persist the download quality into the beatportdl config, leaving the rest
    (credentials, templates) untouched.

    Refuses a withdrawn quality outright — you can only ever move *off* one.
    """
    if quality in BROKEN_QUALITIES:
        raise ValueError(f"{quality} produces broken files: {BROKEN_QUALITIES[quality]}")
    if quality not in QUALITY_OPTIONS:
        raise ValueError(f"unknown quality: {quality}")
    cfg = read_config()
    cfg["quality"] = quality
    BPDL_CONFIG.write_text(yaml.safe_dump(cfg, sort_keys=False))


def probe_quality(quality: str, bp=None) -> tuple[bool, str]:
    """Ask Beatport whether this subscription can actually download at `quality`.

    Hits the same endpoint beatportdl would for that quality, for one arbitrary
    catalog track, and reports what came back. Returns (ok, message). No audio is
    fetched — only the signed-URL metadata response is read.

    Note the endpoint differs by quality: medium-hls comes off the *stream* endpoint
    (streaming rights), everything else off *download* (download rights). Probing
    HLS against /download/ would report on the wrong entitlement entirely.
    """
    import requests

    bp = bp or beatport.connect()
    hits = bp.search("techno", per_page=1)
    if not hits:
        return False, "couldn't reach the Beatport catalog to test"
    tid = hits[0].id
    try:
        if quality == "medium-hls":
            data = bp._get(f"/catalog/tracks/{tid}/stream/")
        else:
            data = bp._get(f"/catalog/tracks/{tid}/download/", quality=quality)
    except requests.HTTPError as e:
        detail = ""
        try:
            detail = (e.response.json() or {}).get("detail", "")
        except Exception:
            detail = (e.response.text or "")[:120] if e.response is not None else ""
        code = e.response.status_code if e.response is not None else "?"
        return False, f"{code} — {detail or 'not available on this plan'}"
    if quality == "medium-hls":
        return bool(data.get("url") or data.get("Url")), "available (128 kbps HLS stream)"
    got = data.get("stream_quality") or data.get("StreamQuality") or "?"
    return True, f"available (stream {got})"


@dataclass
class Resolution:
    spotify: SpotifyTrack
    beatport: Optional["beatport.BeatportTrack"]
    confidence: str           # high / medium / low / none
    via: str                  # isrc / fuzzy / none

    @property
    def hit(self) -> bool:
        return self.beatport is not None


def resolve(spotify_tracks: list[SpotifyTrack], bp=None, progress=None) -> list[Resolution]:
    """Resolve each Spotify track to a Beatport track (ISRC first, then fuzzy).

    `progress`, if given, is called after each track as
    `progress(done, total, found, label)` — for live UI feedback during the loop.
    """
    bp = bp or beatport.connect()
    out: list[Resolution] = []
    total, found = len(spotify_tracks), 0
    for i, sp in enumerate(spotify_tracks, 1):
        bt = None
        via = conf = "none"
        if sp.isrc:
            try:
                bt = bp.search_by_isrc(sp.isrc)
            except Exception:
                bt = None
            if bt:
                via, conf = "isrc", "high"
        if not bt:
            try:
                cands = bp.search(f"{' '.join(sp.artists)} {sp.name}", per_page=10)
            except Exception:
                cands = []
            if cands:
                q = normalize(", ".join(sp.artists), sp.name)
                choices = [normalize(", ".join(c.artists), f"{c.name} {c.mix_name}")
                           for c in cands]
                m = best_match(q, choices, cutoff=72)
                if m.hit:
                    bt, via, conf = cands[m.target_index], "fuzzy", m.confidence
        out.append(Resolution(sp, bt, conf, via))
        if bt:
            found += 1
        if progress:
            progress(i, total, found, f"{', '.join(sp.artists)} — {sp.name}")
    return out


def _ensure_config(dest: Path) -> None:
    """Patch the bpdl config the binary uses: output → dest, flat (no context dirs),
    m4a-friendly quality. Preserves the user's credentials and other settings."""
    cfg = {}
    if BPDL_CONFIG.exists():
        cfg = yaml.safe_load(BPDL_CONFIG.read_text()) or {}
    if not cfg.get("username") or not cfg.get("password"):
        cfg["username"], cfg["password"] = beatport.credentials()
    cfg["downloads_directory"] = str(Path(dest).resolve())
    cfg["sort_by_context"] = False      # keep tracks flat so we can locate them
    # setdefault, not assignment: the Settings page owns this choice.
    cfg.setdefault("quality", DEFAULT_QUALITY)
    BPDL_CONFIG.write_text(yaml.safe_dump(cfg, sort_keys=False))


def download(beatport_ids: list[int], dest: Path = STAGE_DIR,
             timeout: int = 1800,
             progress: Optional[Callable[[int, int, float, str], None]] = None
             ) -> tuple[list[Path], str]:
    """Download the given Beatport track ids into `dest`. Returns (new_files, log).

    `progress`, if given, is called about once a second as
    `progress(done, total, frac, label)` — `done` being how many new audio files
    have landed in `dest` so far and `label` the newest of them.

    Counting arrivals is the only honest progress there is here: the whole batch
    goes to beatportdl in *one* invocation, and it prints nothing machine-readable
    while it works, so a 247-track re-download sat at 0/247 for minutes and read
    as frozen. It's the same count this returns at the end, one second stale. A
    file counts the moment it appears, which can be slightly ahead of it being
    finished — fine for a bar, and never what the result is built from.
    """
    dest = drives.ensure_dir(dest)
    if not beatport_ids:
        return [], ""
    if not BPDL_BIN.exists():
        raise FileNotFoundError(f"bpdl binary not found at {BPDL_BIN}")
    _ensure_config(dest)

    urls = [f"https://www.beatport.com/track/x/{i}" for i in beatport_ids]
    total = len(urls)
    start = time.time()

    def _landed() -> tuple[list[Path], str]:
        """Audio files in `dest` newer than this call, and the newest one's name."""
        found: list[tuple[float, Path]] = []
        for p in dest.rglob("*"):
            if p.suffix.lower() not in AUDIO_EXTS:
                continue
            try:
                mtime = p.stat().st_mtime
            except OSError:
                continue            # vanished mid-scan — a rename in flight
            if mtime >= start - 2:
                found.append((mtime, p))
        return sorted(p for _, p in found), (max(found)[1].name if found else "")

    # This binary has no quit flag: it downloads the positional URLs then enters
    # an interactive prompt. Closing stdin (EOF) makes it exit after the batch.
    proc = subprocess.Popen(
        [str(BPDL_BIN), *urls],
        cwd=str(BPDL_DIR), stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    # Drained on a thread rather than read here, because polling the folder must
    # not leave the child blocked on a full pipe: it is chatty, and a few hundred
    # tracks of output is well past the 64K buffer.
    out: dict = {}

    def _drain() -> None:
        out["log"] = proc.communicate()

    drain = threading.Thread(target=_drain, name="bpdl-drain", daemon=True)
    drain.start()
    while drain.is_alive():
        drain.join(1.0)
        if progress:
            files, newest = _landed()
            done = min(len(files), total)
            progress(done, total, done / total if total else 0.0, newest)
        if time.time() - start > timeout:
            proc.kill()
            drain.join(5)
            raise subprocess.TimeoutExpired(BPDL_BIN.name, timeout)

    stdout, stderr = out.get("log", ("", ""))
    return _landed()[0], (stdout or "") + (stderr or "")
