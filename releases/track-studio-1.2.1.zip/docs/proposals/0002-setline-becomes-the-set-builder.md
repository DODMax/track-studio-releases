# 0002 — Setline becomes the set builder

**Status:** Draft · 2026-09-22
**Written for:** you, and whoever picks up the Build page next.
**Read with:** [0003](0003-solo-setline-and-the-shared-one.md). This proposal
assumed the board simply moves here; the shared Setline keeps existing, so what
is built is a *second instance* that has to sync with it. 0003 holds the
decisions that have to be taken before the solo board is written.

## In one sentence

Track Studio stops having a set builder of its own: it serves **Setline's board
locally**, against Track Studio's own library and crate store, and the Build page
plus the whole import/push bridge are deleted.

## Why this is on the table

**The two halves disagree about what a set is.** `pages/build_page.py` (1 763
lines) assembles an ordered list of `microsets.SetEntry` out of *generated*
blocks. Setline has a horizontal timeline split into **moments**, with mix points
per track and a set that plays through following them — which is how a night
actually gets planned, and it is finished (its README lists six built steps).

**The bridge exists only because they are two programs.** `setline_import.py`
(312 lines) + `setline_push.py` (119) + the `.setline.json` format + three `.env`
keys are all machinery for moving data between two stores that could be one:
export, match against the library, fetch the missing from Beatport, push a block
back, re-import. Every one of those steps is a round trip that disappears if the
board reads the library directly.

**Blocks were already sentenced.** `CLAUDE.md`'s vocabulary note says it
outright: blocks were *generated* clusters, crates are *curated* piles, the
curation is the part worth keeping, and "crates replace them when the board
arrives and the Build page goes". This proposal is that sentence, costed.

**Both sides do the same work twice.** Beatport search, library matching
(`dupes.Index` here, `matching.py` + rapidfuzz there), a player, crates, and a
track model. Setline's `tools.py` alone is 1 500 lines of surface that overlaps
this app.

**The look already moved.** The dock, the acquire panel and the fill screen are
Setline's CSS living inside Track Studio (`pages/kit.py` holds the shared
tokens). The app has been migrating toward Setline's design for months; this is
the same move for the part that matters most.

## Why it is more plausible than it sounds

Measured by reading both repos today:

| Fact | Consequence |
|---|---|
| Setline's server is **FastAPI + SQLAlchemy + uvicorn** (`server/pyproject.toml`) | NiceGUI *is* FastAPI underneath — Setline's API can be mounted into Track Studio's own app. One process, one port, one window. |
| Setline's web is a **Svelte 5 + Vite SPA** that builds to `web/dist` | Served as static files from the same app. No second dev server in production. |
| **No Postgres-only types in `server/setline/models.py`** — plain `String`, `Integer`, `BigInteger`, `Text`, `DateTime(timezone=True)`, and `JSON` (*not* `JSONB`); no `ARRAY`, no `UUID`, no `tsvector` | SQLite is a live option, which removes the "run a database daemon inside a personal Mac app" objection. |
| No Postgres-only DDL found across its **12 alembic migrations** | The migration chain may port as-is. Verify before trusting it. |
| Both already share an export contract (`setline-set` v1) | The data shapes are known to each other; this is not an integration from zero. |
| **But:** Track Studio's venv is **Python 3.9.6** and Setline requires **≥3.13** (`str \| None` annotations SQLAlchemy resolves at mapper configuration) | "One process" is blocked until Track Studio moves interpreter. Measured since: the installed `essentia-tensorflow 2.1b6.dev1389` is the release that ships cp313 arm64 wheels, and essentia asks only for `numpy>=1.25` — so the blocker is our own `numpy<2` pin (1.26.4 has no cp313 wheel), not the analysis stack. A pin to lift and a pass to re-verify. |

## What each side brings

| Setline has | Track Studio has |
|---|---|
| The board: timeline, moments, drag-and-drop, Row/Grid/List views | The library: rekordbox merge, ~3 500 tracks, the analysis pipeline |
| Mix points, and a set that plays through them | The learned model (`mixmodel`): `next_tracks`, `fill`, ×34 over chance |
| Full-track Beatport streams (hls.js) | **The local files** — nothing to stream for tracks you already own |
| Live editing, invite links, presence, per-change credit | rekordbox export (`rekordbox_io.to_playlists`) — the set you can play tonight |
| Crates (the word came from here) | Crates (the store — `crates.py`) |

Two crate stores is the one collision that has to be resolved rather than
merged. `CLAUDE.md` already says which *meaning* won; this decides which
*implementation* does.

## The three real questions

**1. Where does the data live?** Three options, cheapest first:

- **Point Setline's SQLAlchemy at SQLite.** Plausible because the models are
  portable (above). Risks to check: `DateTime(timezone=True)` degrades on SQLite
  (naive datetimes), `server_default=func.now()` behaves differently, and the
  alembic chain needs a dry run. Could share `.cache.sqlite`'s file or take its
  own — **its own**, because `.cache.sqlite` is declared deletable and a set is
  not.
- **Keep Setline's API, re-point its persistence** at `crates.py` + a new sets
  store. Most work, least new infrastructure, and it keeps one crate store.
- **Run Postgres locally.** A daemon, a migration story and a backup story for a
  single-user Mac app. Only if the first two fail.

**2. Does multiplayer come along?** **Answered since this was written, and it
changes the shape of the whole proposal:** the shared online Setline *keeps
existing* — not everyone has Track Studio — so what gets built here is a second
live instance of it, and the two have to replicate. That is
[0003](0003-solo-setline-and-the-shared-one.md), and it has decisions in it that
must be taken before the solo board is written rather than after.

What remains of the original question is the local end of it: invite links,
presence and cursors (`live.py` 156 lines, `auth.py` 102) are meaningless for one
person at one desk — **except** that they are exactly what would let you plan on
an iPad on the couch against the library on the Mac. Per-change credit is no
longer optional, though: 0003 §6 needs an author on every op.

**3. What happens to the assistant?** `server/setline/assistant.py` (594 lines)
plus an `anthropic` dependency and an MCP endpoint. Inside a local app that is
already driven from Claude Code, it may be redundant — or it may be the thing
that makes the board usable without a terminal. Not free either way: it needs a
key and it costs tokens per set.

## What gets deleted

| | lines |
|---|---|
| `pages/build_page.py` | 1 763 |
| `setline_import.py` | 312 |
| `setline_push.py` | 119 |
| the set/block half of `microsets.py` | ~400 of 800 |
| `drafts.py` + `.set_drafts.json` + `.build_session.json` | 214 + state |
| `.setline.json` as a format, `SETLINE_URL` / `SETLINE_TOKEN` / `SETLINE_NAME` | — |

Roughly **2 800 lines and one data format**, against whatever the mount and the
storage decision cost.

**`microsets.py` does not go away.** `Track`, `_camelot_distance`,
`_camelot_parse`, `_arousal_of` and `compatibility()` are load-bearing for
`mixmodel` and for `library.mix_tracks_from` — the fill screen would break
instantly. Only `Block`, `BlockPreset`, `SetEntry`, `cluster()` and
`generate_sequences()` are in scope. Split the module before deleting anything.

## What must survive the move

1. **The learned model has to reach the board.** `fill` and `next_tracks` are
   the reason this app is more than a library browser, and a board that cannot
   ask "what goes next" is a worse Build page with nicer CSS. The pattern is
   already built and proven: proposals with a reason, a player and an **Add**
   button, never an autofill (see [0001](0001-crate-matching-and-the-sound-axis.md)).
2. **rekordbox export.** A set that cannot be played tonight is a plan, not a
   set. `rekordbox_io.to_playlists` must hang off the board.
3. **The analysis.** Energy, key, BPM, genre and the sound axis are what the
   ranking runs on; the board should show them, not just titles.
4. **Local files over streams.** Setline streams from Beatport because it is
   online and shared. Here the file is on disk and `/media` already serves it.

## The smallest first step

*Now phase 1 of the sequenced plan in
[0003 → The road to done](0003-solo-setline-and-the-shared-one.md#the-road-to-done),
which adds two more spikes (Setline's suite on SQLite, and Track Studio on
Python 3.13) and puts the shared-side schema changes before any solo code.*

A spike, not a migration. Two evenings, and it answers the storage question with
a result instead of an argument:

1. `cd ~/Code/setline/web && npm run build`, then serve `web/dist` from Track
   Studio at `/board` (one `app.mount`), with Setline's FastAPI app mounted under
   `/api/setline` against a SQLite file.
2. One vertical slice only: **a crate from `crates.py` appears on the board.**
3. Judge it there. If the seam holds, the rest is porting. If it fights — the
   SQLite port bites, or the Svelte app assumes a server Track Studio cannot be —
   the fallback is to port the *board* into NiceGUI instead: worse-looking,
   cheaper, and it keeps one stack.

Do not start by deleting the Build page. It is the only working set builder, and
it stays until the board can export a set to rekordbox.

## Open questions

- Does the alembic chain actually apply on SQLite? (12 migrations; nothing
  Postgres-specific found, not yet run)
- Who owns the set — Setline's tables, or a Track Studio store?
- One crate store or two, and which implementation survives?
- Is a Beatport streaming session viable from a local app, or does the board fall
  back to local files plus `beatportdl` for everything not owned?
- Setline's `uploads/` (9.5 MB today) holds hand-added audio. Does that merge
  into the download root, or stay separate?
- Does the in-app assistant stay?

## What this is not

Not a rewrite of Setline, and not Track Studio absorbing a product. It is one
program serving the UI the other already built, over the library only this side
has.
