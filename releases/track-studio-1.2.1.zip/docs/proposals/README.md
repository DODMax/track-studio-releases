# Proposals

Written for: whoever picks this up next — you, or an agent reading the repo cold.

Research and proposed changes, one file each, numbered and **status-tagged**.
The point of the folder is that a half-finished idea has somewhere to live that
is neither a commit message nor a conversation that scrolled away.

## The contract

| Plane | What belongs there |
|---|---|
| `CLAUDE.md` | **Decided** architecture, conventions and footguns — how the app *is*. The canonical brief; start there. |
| `docs/proposals/` | Investigations and proposed changes — how the app *might be*, plus the measurements behind the argument. |

A proposal that gets built does **not** get deleted: it is marked
`Implemented` and the parts that became true migrate into `CLAUDE.md`. The
proposal keeps the reasoning and the numbers, which is the half a commit message
never carries.

## Status values

- **Draft** — proposed, not decided. Argument and measurements, no commitment.
- **Accepted** — decided, not built.
- **Implemented** — built; `CLAUDE.md` now describes it. Open sub-items are
  listed at the end of the file.
- **Rejected** — decided against, with the reason. **These are the valuable
  ones**: they stop the same idea being re-proposed every six months. (See
  0001's rejected gigs cache for the pattern: the cost it would have fixed
  turned out to be something else entirely.)

## Rules that made this folder necessary

1. **Measure before you argue.** Every claim in here that matters carries a
   number taken off the real library — 3 507 tracks, 28 gigs, this machine. The
   one time a weighting was reasoned about instead of measured, it ranked a
   0.86 match below a 0.76 one (0001 §5b).
2. **Say what you don't know.** An open question written down is worth more
   than a confident guess, and both cost the same to type.
3. **Number the file, never renumber it.** Links from `CLAUDE.md` and from
   commit messages point at these names.

## Index

| # | Title | Status |
|---|---|---|
| [0001](0001-crate-matching-and-the-sound-axis.md) | What makes two tracks belong together | Implemented (partly) |
| [0002](0002-setline-becomes-the-set-builder.md) | Setline becomes the set builder | Draft |
| [0003](0003-solo-setline-and-the-shared-one.md) | Solo Setline and the shared one | Draft |
