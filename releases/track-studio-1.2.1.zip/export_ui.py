"""Post-export handoff — the dialog every "Export to rekordbox" ends in, plus
the reusable "is rekordbox watching our file?" panel (also shown in Settings).

An export used to end in a `ui.notify` carrying multi-step instructions that
vanished after a few seconds — and nothing ever verified the one-time rekordbox
xml setup, or closed the loop afterwards. This dialog does all three:

1. verifies the setup live via `rbprefs` (and can adopt rekordbox's own file
   on a mismatch, re-running the export against it);
2. shows the two-step rekordbox side (refresh the xml tree, drag the playlist);
3. offers "Done — reload library", which re-reads the rekordbox DB so the teal
   "in set" states light up immediately — the proof the round-trip worked.

UI layer: imports `runtime` (unlike `widgets`/`shell`); imported by pages only.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

from nicegui import run, ui

import rbprefs
import runtime
from store import (RekordboxSnapshot, load_studio_state, save_export_file,
                   save_skip_export_dialog, save_studio_state)

# The one-time rekordbox side of the wiring, referenced wherever the check
# isn't green. Kept as data so Settings and the dialog can't drift apart.
SETUP_STEPS = (
    'In rekordbox: Preferences → Advanced → Database — under "rekordbox xml", '
    "set Imported Library to the file below.",
    'Preferences → View → Layout — tick "rekordbox xml". A «rekordbox xml» '
    "tree appears in the sidebar.",
)

_STATE_STYLE = {  # icon, color per rbprefs state
    "ok": ("check_circle", "#3fb950"),
    "tree_hidden": ("visibility_off", "#d29922"),
    "mismatch": ("sync_problem", "#d29922"),
    "unconfigured": ("build_circle", "#f85149"),
    "unknown": ("help", "#6b7280"),
}


def xml_setup_panel(export_file: Path | Callable[[], Path], *,
                    on_adopt: Callable[[Path], None] | None = None) -> Callable[[], None]:
    """Render the live rekordbox-xml wiring status into the current container.

    Green collapses to a single reassuring line; anything else shows the exact
    steps that are missing, the path with a copy button, and "Check again"
    (rekordbox may not flush a just-changed preference to disk immediately).
    `on_adopt(watched)` adds the one-click fix on a mismatch: adopt the file
    rekordbox already watches instead of re-configuring rekordbox.
    Returns the re-render function so callers can refresh after saving paths.
    """
    holder = ui.column().classes("w-full gap-1")

    def render() -> None:
        ef = export_file() if callable(export_file) else export_file
        v = rbprefs.evaluate(ef)
        icon, color = _STATE_STYLE[v.state]
        holder.clear()
        with holder:
            with ui.row().classes("items-center gap-2 no-wrap"):
                ui.icon(icon).style(f"color:{color}")
                ui.label(v.detail).classes("text-caption").style(f"color:{color}")
            if v.ok:
                return
            if v.state == "mismatch" and on_adopt:
                ui.button("Use the file rekordbox already watches",
                          icon="swap_horiz",
                          on_click=lambda: on_adopt(v.watched)) \
                    .props("outline dense no-caps size=sm color=primary") \
                    .tooltip(f"Switch this app's export file to {v.watched} — "
                             "no rekordbox visit needed")
            # Which steps are actually missing: a mismatch only needs step ①
            # re-pointed; a hidden tree only needs step ②.
            steps = (SETUP_STEPS[1:] if v.state == "tree_hidden"
                     else SETUP_STEPS[:1] if v.state == "mismatch"
                     else SETUP_STEPS)
            for i, s in enumerate(steps, 1):
                ui.label(f"{i}.  {s}").classes("text-caption text-grey")
            with ui.row().classes("items-center gap-1 no-wrap w-full"):
                ui.label(str(ef)).classes("text-caption ellipsis") \
                    .style("font-family:monospace; color:#cbd2da; min-width:0") \
                    .tooltip(str(ef))
                ui.button(icon="content_copy",
                          on_click=lambda: (ui.clipboard.write(str(ef)),
                                            ui.notify("Path copied"))) \
                    .props("flat dense round size=sm color=grey") \
                    .tooltip("Copy the exact path to paste into rekordbox")
                ui.button("Check again", icon="refresh", on_click=render) \
                    .props("flat dense no-caps size=sm color=grey")

    render()
    return render


def export_handoff(out: str, summary: str, drag_label: str, *,
                   on_reloaded: Callable[[], None] | None = None,
                   re_export: Callable[[], None] | None = None,
                   note: str = "") -> None:
    """Open the persistent post-export dialog.

    `drag_label` names what to drag inside rekordbox ("“Peak Time”", "the
    “Warehouse” folder"). `re_export` re-runs the caller's export — used when
    the user adopts rekordbox's watched file mid-dialog, so the export lands in
    the newly adopted file (the write to the old path is stale the moment the
    path changes). `on_reloaded` lets the page re-render after the DB reload.

    Silenced by "Don't show this again" (Settings turns it back on), in which
    case the export still happens and says so — it just leaves the reload to
    Library → Reload rekordbox. The wiring check is *not* skipped when it is
    failing: a dialog you dismissed once shouldn't hide an export landing in a
    file rekordbox isn't watching, which is the one failure that looks exactly
    like success.
    """
    if load_studio_state().get("skip_export_dialog") and rbprefs.evaluate(Path(out)).state == "ok":
        ui.notify(f"Exported {summary} → {out}. Refresh «rekordbox xml» and drag "
                  f"{drag_label} in; Library → Reload rekordbox picks it up.",
                  type="positive", timeout=12000)
        return

    with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[36rem]"):
        ui.label("Exported — now import in rekordbox") \
            .classes("text-subtitle1 text-weight-bold")
        ui.label(f"{summary}  →  {out}").classes("text-caption text-grey")
        if note:
            ui.label(note).classes("text-caption").style("color:#d29922")

        def adopt(watched: Path) -> None:
            save_export_file(str(watched))
            d.close()
            if re_export:
                re_export()   # rewrite into the adopted file; opens a fresh dialog
            else:
                ui.notify("Export file switched — run the export again to write "
                          "it there", type="info")

        xml_setup_panel(Path(out), on_adopt=adopt)

        ui.separator().props("color=grey-9")
        for i, step in enumerate((
                "In rekordbox's sidebar, click the refresh icon on «rekordbox xml».",
                f"Drag {drag_label} into your Playlists.",
                "Come back and reload, so the app sees what landed."), 1):
            ui.label(f"{i}.  {step}").classes("text-caption text-grey")

        async def do_reload() -> None:
            reload_btn.props("loading")
            try:
                import rekordbox
                col = await run.io_bound(rekordbox.from_live)
            except Exception as e:
                reload_btn.props(remove="loading")
                ui.notify(f"Couldn't read rekordbox DB: {e}",
                          type="negative", timeout=8000)
                return
            stats = runtime.library.merge_rekordbox(col, snapshot=RekordboxSnapshot())
            save_studio_state(runtime.library.folder, True)
            runtime.refresh_batches()
            reload_btn.props(remove="loading")
            d.close()
            ui.notify(f"Rekordbox reloaded — {stats['matched']} matched, "
                      f"{stats['added']} added"
                      + (f", {stats['removed']} removed" if stats["removed"] else ""),
                      type="positive")
            if on_reloaded:
                on_reloaded()

        with ui.row().classes("items-center w-full gap-2"):
            ui.checkbox("Don't show this again",
                        on_change=lambda e: _silence(e.value)) \
                .props("dense").classes("text-caption") \
                .tooltip("Exports will just say so in a notification. "
                         "Turn it back on in Settings.")
            ui.space()
            ui.button("Later", on_click=d.close).props("flat color=grey")
            reload_btn = ui.button("Done — reload library", icon="album",
                                   on_click=do_reload).props("unelevated color=primary")
    d.open()


def _silence(on: bool) -> None:
    save_skip_export_dialog(on)
    if on:
        ui.notify("Exports will be a notification from now on. Reload the library "
                  "from the Library tab when you've dragged them in.", type="info")
