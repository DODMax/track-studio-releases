"""Shared runtime state for the Track Studio app + the helpers that operate on it.

Owns the process-wide singletons every page reads — the in-memory `library`, the
download folders (`download_batches` / `incoming_batches`), each page's working
session, and a lazy Spotify client — plus export/scan helpers and the startup
`_bootstrap`. These are only ever *mutated*, never rebound: import
this module (`import runtime`) and reference `runtime.library` / `runtime.download_batches`
so a later rebinding can't strand a stale alias.

Leaf relative to the UI: imports domain modules only, never `widgets` / `shell` / `pages`.
"""
from __future__ import annotations

from collections import Counter
from pathlib import Path

import drives
import rekordbox
import rekordbox_io
from library import Library
from spotify import Spotify
from staging import STAGE_DIR
from store import RekordboxSnapshot, default_export_file, load_studio_state

library = Library()

# pending download batches (on disk, not-yet-in-rekordbox), keyed by playlist name
download_batches: dict[str, list] = {}

# Every track in the download folders, imported or not — the Incoming lane's
# feed (see `incoming`). Kept beside `download_batches` rather than replacing it
# because "a batch" means the *pending* tracks to the Build pool and the Sync
# gap, and would be wrong for either if it suddenly included imported ones.
incoming_batches: dict[str, list] = {}

# a shared Spotify client (lazy — token is cached, so this is headless)
_spotify = {"client": None}


# play history — lazily read and cached for the process. Walking the history tree
# means resolving every logged track against the collection, so it's a page-open
# cost we pay once rather than on every render.
history_state: dict = {"sessions": [], "gigs": [], "membership": {},
                       "energy_cache": {}, "loaded": False}

# the learned mixing model (mixmodel.MixModel), derived from history_state.
# Cached separately so pages can hold a reference; reset whenever history is
# (re)read so the two can't drift apart.
mix_state: dict = {"model": None}


def new_build_session() -> dict:
    """A fresh Build working session — the pool, its blocks, and the set."""
    return {
        # --- pool ---
        "pool_ids": [],          # ticked playlist nodes (multi-select)
        "node_id": None,         # single-click selection
        "batch_name": None,      # a pending download batch
        "pool_name": "",
        "pool_names": [],
        "pool": [],              # microsets.Track list, deduped
        "excluded": [],          # dropped for having no BPM
        "include_dl": True,
        "title": "",
        "n_dl": 0,
        # --- blocks (clustered lazily) ---
        "blocks": [],
        "clustered": False,
        "preset": None,          # microsets.BlockPreset; the page fills the default
        # --- the set ---
        "entries": [],           # list[microsets.SetEntry]
        "cursor": None,          # step being auditioned; None = the live tail
        "insert_at": None,       # picks land after this step; None = append
        "grain": "track",        # track | block
        "energy_dir": 1,
        "valence_dir": 0,
        "offset": 0,
        "scope": "pool",         # pool | companions | library
        "draft_name": None,      # the draft this session was resumed from/saved as
        # Has this process taken ownership of the autosaved session on disk?
        # Until it has, an empty set must not overwrite it (see `_autosave`).
        "session_loaded": False,
    }


# The Build page's working session. It lives here rather than in the page
# function because a NiceGUI page body re-runs from scratch on every visit:
# held there, an hour of set-building evaporated the moment you clicked another
# tab. Only ever mutated (`import runtime; runtime.build_state[...]`), and it
# holds no UI elements — those die with their client. `drafts` is the on-disk
# half, for picking a set back up after a restart.
build_state: dict = new_build_session()


# A source's computed gap (`sync.SyncRow` list), keyed by Spotify playlist id,
# for every source pulled this session. Pulling costs a Spotify round trip plus
# a fuzzy match of the playlist against the whole rekordbox collection, so it is
# not something to redo on every render — and "Everything" in the Incoming lane
# is the union of these with the download folders, which means it can only show
# a source that has actually been pulled. Cleared by a rekordbox reload, since
# every row's "have it / missing" answer was computed against the old collection.
source_rows: dict[str, list] = {}


# The duplicate scan (`incoming.scan_duplicates`): which arriving tracks the
# collection already holds, keyed by `incoming.Item.key`. Cached for the same
# reason `source_rows` is — it is a fuzzy pass over the whole collection per
# row, ~2s for a thousand, so it belongs nowhere near a render.
#
# `gen` stamps what the answer depended on. Both halves matter: the collection
# is what a row is compared *against*, and the arriving files are what is being
# asked about, so either changing makes the cached answer a claim about a
# library that no longer exists.
duplicate_scan: dict = {"gen": None, "found": {}}


def _dupe_gen() -> tuple:
    return (len(library.tracks),
            sum(1 for t in library.tracks if t.in_rekordbox))


def duplicates_stale() -> bool:
    """Has anything changed under the cached scan? True before the first one."""
    return duplicate_scan["gen"] != _dupe_gen()


def save_duplicates(found: dict) -> None:
    duplicate_scan.update(gen=_dupe_gen(), found=found)


def clear_duplicates() -> None:
    duplicate_scan.update(gen=None, found={})


def forget_tracks(paths) -> None:
    """Drop library tracks for files that have just been moved away.

    `refresh_batches` rebuilds the *folders*, but the `Track` objects live in
    `library.tracks` and are keyed by the path they were read from — so a moved
    file leaves a ghost behind pointing at a location nothing is at any more.
    Harmless in the lane (which is rebuilt from the folders) and not harmless
    anywhere that walks the library: `dupes.Index` pools it, the Library page
    lists it, and `/media` would serve a 404 for it.

    Only the named paths, never a sweep for missing files — a download root on
    a volume that happens to be unmounted must not quietly empty the library.
    """
    gone = {str(Path(p)).lower() for p in paths}
    if not gone:
        return
    library.tracks[:] = [t for t in library.tracks
                         if not (t.local_path and not t.in_rekordbox
                                 and str(t.local_path).lower() in gone)]


# The crate dock's own state — which crate is on top, and whether the shelf is
# up. Here rather than in a page because the dock mounts on *several* pages and
# the whole point of it is that it follows you: opening Library after crating
# something on Incoming should find the same crate open, not a closed bar.
crate_state: dict = {"open": False, "active": None}


def new_incoming_session() -> dict:
    """The Incoming page's selection — which source, and which filter."""
    return {
        # "!needs-a-home" / "!already-have" / "!ready-to-send" (the three job
        # views), "sp:<playlist id>" for a synced source, or a folder's name.
        "sel": "!needs-a-home",
        "set_override": {},    # per-track export decisions, source-specific
        "previewing": set(),   # rows with a Beatport lookup in flight
    }


# Lives here for the same reason `build_state` does: a NiceGUI page body re-runs
# from scratch on every visit, so the source you were working through would be
# lost the moment you clicked Library to look something up.
incoming_state: dict = new_incoming_session()


def new_setline_session() -> dict:
    """The Download page's Setline import — the dropped set and where it stands."""
    return {
        "export": None,      # the parsed .setline.json
        "plan": None,        # setline_import.Plan, matched against the library
        "moments": None,     # the slice: kept moment names; None = all of them
        "added_by": None,    # the slice: kept contributors; None = all of them
        "failed": {},        # beatport id -> what beatportdl said it couldn't do
        "batch": None,       # the download batch folder a fetch landed in
    }


# The Setline import, for the same reason `build_state` exists: the Download
# page re-runs from scratch on every visit, so the dropped set, its match
# against the library and the slice you'd narrowed it to all evaporated the
# moment you clicked Library to analyze what you'd just fetched — which is
# exactly the trip the workflow asks you to make. Mutated, never rebound.
setline_state: dict = new_setline_session()


def _sp() -> Spotify:
    if _spotify["client"] is None:
        _spotify["client"] = Spotify()
    return _spotify["client"]


def load_history(force: bool = False) -> dict:
    """Read + classify rekordbox's play history into gigs. Cached; `force` re-reads.

    Playlist attribution reuses `library.rekordbox_index` when the library has
    already merged rekordbox (the usual case after `_bootstrap`), so opening the
    page costs one history read rather than a second full collection read.
    """
    if history_state["loaded"] and not force:
        return history_state

    import history

    sessions = history.load_sessions()
    index = library.rekordbox_index
    if not index:
        try:
            index = rekordbox.from_live().playlist_index
        except Exception as e:
            print(f"[history] playlist attribution unavailable: {e}")
            index = {}
    history_state.update(
        sessions=sessions,
        gigs=history.build_gigs(sessions),
        membership=history.build_membership(index) if index else {},
        energy_cache={},
        loaded=True,
    )
    mix_state["model"] = None          # derived from history — rebuild lazily
    return history_state


def mix_model(force: bool = False):
    """The learned mixing model (see `mixmodel`), built lazily and cached.

    Slow on first call (history read + one file-tag read per played track for
    the Δenergy profile) — call from a background thread like `load_history`.
    `force` re-reads history and rebuilds.
    """
    st = load_history(force)
    if mix_state["model"] is None:
        import mixmodel
        mix_state["model"] = mixmodel.build(
            st["gigs"], st["membership"], energy_cache=st["energy_cache"])
    return mix_state["model"]


def _dl_root() -> Path:
    return Path(load_studio_state().get("download_root") or str(STAGE_DIR)).expanduser()


def refresh_batches() -> None:
    """Re-scan the download root for per-playlist batches.

    One pass over the filesystem fills both views of it: `incoming_batches` gets
    every folder whole, and `download_batches` the not-yet-imported tracks that
    the Build pool and the Sync gap mean by a batch.
    """
    incoming_batches.clear()
    download_batches.clear()
    for name, tracks in library.scan_download_batches(_dl_root(), pending_only=False):
        incoming_batches[name] = tracks
        pending = [t for t in tracks if not t.in_rekordbox]
        if pending:
            download_batches[name] = pending
    note_drives()


def note_drives() -> None:
    """Count what the library keeps on each external drive, for `drives.missing`.

    Here because this is where the library is known: it runs at the end of
    `refresh_batches`, which follows every rekordbox merge, so the header can
    name what an unplugged drive takes with it ("2 341 tracks, the download
    folder") without walking the library on every page. Never raises: it runs
    inside every page that refreshes the batches, and a chip is not worth one.
    """
    uses: dict[str, list[str]] = {}

    def add(path, what: str) -> None:
        name = drives.volume(path)
        if name:
            uses.setdefault(name, []).append(what)

    try:
        st = load_studio_state()
        if st.get("rekordbox"):
            add(rekordbox.db_file(), "your rekordbox database")
        add(_dl_root(), "the download folder")
        add(export_path(), "the rekordbox export file")
        add(st.get("folder"), "the extra folder")
        on = Counter(drives.volume(t.local_path or t.offline_path) for t in library.tracks)
        for name, n in on.items():
            # A drive holding only a few strays doesn't make the app look empty,
            # and their rows already say "offline". Measured here: 9 of 2 509
            # tracks still point at an old "Lexar" drive, and a chip on every
            # page for those would be one more warning to learn to ignore.
            if name and (name in uses or n >= len(library.tracks) / 10):
                uses.setdefault(name, []).insert(
                    0, f"{n:,} track{'' if n == 1 else 's'}".replace(",", " "))
    except Exception as e:  # noqa: BLE001
        print(f"[drives] couldn't count what's on each drive: {e}")
        return
    drives.state["uses"] = uses


async def _drives_back(names: set) -> None:
    """A drive the library lives on is plugged back in: read again what was
    read without it.

    The rekordbox merge is the part that matters — run while the drive was out,
    it left every track on it without a file (`Track.offline_path`) — and
    everything computed from that answer goes with it: each source's gap, the
    duplicate scan, and the play-history model, whose energies come from tags
    it couldn't read.
    """
    import asyncio

    st = load_studio_state()
    if st.get("rekordbox"):
        try:
            col = await asyncio.get_event_loop().run_in_executor(None, rekordbox.from_live)
            library.merge_rekordbox(col, snapshot=RekordboxSnapshot())
        except Exception as e:
            print(f"[drives] rekordbox reload failed: {e}")
    folder = st.get("folder")
    if folder and Path(folder).is_dir():
        library.add_folder(Path(folder))     # dedupes by path, so a re-add is a no-op
    refresh_batches()
    source_rows.clear()
    clear_duplicates()
    history_state["loaded"] = False
    mix_state["model"] = None
    drives.state["reloads"] += 1
    print(f"[drives] {', '.join(sorted(names))} connected — library re-read")


def watch_drives() -> None:
    """Notice a drive coming back, and re-read the library when one does.

    A stat per drive the library uses, every few seconds, rather than asking
    anyone to press Reload: someone who opened the app before plugging the
    drive in has already been told what's missing (the header chip), and the
    obvious next move — plugging it in — should be the whole fix. Registered
    from `main.py`'s `__main__` guard, so the analysis workers don't each run one.
    """
    import asyncio

    from nicegui import app

    async def _loop() -> None:
        away = set(drives.missing())
        while True:
            await asyncio.sleep(3)
            now = set(drives.missing())
            back, away = away - now, now
            if back:
                try:
                    await _drives_back(back)
                except Exception as e:  # noqa: BLE001 — a watcher that dies stops watching
                    print(f"[drives] re-read after {', '.join(back)} came back failed: {e}")

    @app.on_startup
    async def _start() -> None:
        asyncio.create_task(_loop())


# Stitched audio is not scanned for unprompted, deliberately. The library-wide
# hint that used to live here counted files carrying an encoder atom, which is a
# sound *negative* test and a coin flip as a positive one: measured over this
# library, 250 flagged files split 125 stitched / 125 not, because ffmpeg stamps
# that atom for every honest reason too — our own `normalize_loudness`, yt-dlp,
# and beatportdl tagging a perfectly good store download. A banner that is wrong
# half the time, and was wrong 57 times out of 57 on the playlist that finally
# killed it, is one you learn to scroll past — and then it is worth less than
# nothing, because a real warning lands in the same blind spot.
#
# What replaced it is not a better guess but a closed door: HLS is withdrawn
# (`bpdl.BROKEN_QUALITIES`, refused by `set_quality`), and every path a file
# takes into the library packet-checks it on arrival — the downloaders via
# `integrity.verify_downloads`, and `refetch.replace_in_place`, which reads the
# whole file and rolls the swap back if the fresh copy is stitched too. The
# backlog is a one-time job for `Library → Check for problems`, which at ~4ms a
# file is over before you have read the dialog title.


# The Library page's long job (energy analysis / loudness / normalize /
# integrity / refetch), if one is in flight. It lives here for the same reason
# `build_state` does: a NiceGUI page body re-runs from scratch on every visit,
# so a job held in the page function lost its progress bar, its Cancel button
# and — worse — the report it was about to produce, the moment you clicked
# another tab. The work itself carried on in a thread nobody was watching, and
# an energy analysis over a big playlist — hours, not minutes — is exactly the
# job you'd walk away from. (The integrity check used to be the example here,
# from before it sampled packet headers instead of reading whole files; at ~4ms
# a track it now finishes before you could leave the page.) Mutated, never
# rebound, and holds no UI elements.
job_state: dict = {
    "job": None,      # the analysis.*Job — running, or finished and unread
    "kind": None,     # analyze | loudness | normalize | problems |
                      # refetch_plan | refetch_apply — which button owns it
    "msg": "",        # the progress line ("Checking audio · Club nights")
    "scope": "",      # the playlist it was started on, for the report's header
    "tracks": [],     # and the tracks it covered (domain Tracks, never UI)
    "report": False,  # finished, and nobody has seen the result yet
}


def job_running() -> bool:
    """Is a Library job in flight?

    Not `job.running`, which is False for the moment between handing the work
    to a thread and that thread reaching the job's own `run()` — long enough
    for a double-click to start a second one.
    """
    return job_state["job"] is not None and not job_state["report"]


def start_job(job, kind: str, msg: str, run, *, scope: str = "", tracks=None) -> None:
    """Run a long Library job on a thread of its own, detached from the page.

    Deliberately not `nicegui.run.io_bound`: awaiting that makes the *page's*
    coroutine the owner of the result, and that page is gone as soon as you
    click another tab. Here the thread only writes into `job_state`, and
    whichever Library page is open when it lands picks the result up from
    there — if none is, the result waits until one opens.
    """
    import threading

    job_state.update(job=job, kind=kind, msg=msg, scope=scope,
                     tracks=list(tracks or []), report=False)

    def _work() -> None:
        try:
            run()
        except Exception as e:  # noqa: BLE001 — the jobs catch their own; this is the net
            print(f"[job] {kind} failed: {e}")
        finally:
            job_state["report"] = True

    threading.Thread(target=_work, name=f"job-{kind}", daemon=True).start()


def clear_job() -> None:
    """Hand the job slot back, once the result has actually been shown."""
    job_state.update(job=None, kind=None, msg="", scope="", tracks=[], report=False)


def _safe_ui(fn) -> None:
    """Run a UI update, swallowing the error if the client (browser tab) is gone.

    Long background jobs (download + analysis) can outlive the websocket; once a
    client is deleted, touching its elements raises RuntimeError. Callers use this
    so a disconnected tab never crashes the task or skips later cleanup."""
    try:
        fn()
    except RuntimeError:
        pass


def export_path() -> Path:
    """The single, stable rekordbox-import file. Every export (sync / batch /
    build) overwrites this one file, so rekordbox's xml view can be pointed
    at it once and just refreshed to see the latest export. Configurable globally
    (Settings); defaults to <download root>/track-studio.xml.

    Only says where. Writing goes through `export_target`, because asking must
    never create anything: Settings asks while it draws, and creating the folder
    from here is what took that page down when the drive was unplugged."""
    cfg = load_studio_state().get("export_file")
    return Path(cfg).expanduser() if cfg else default_export_file(_dl_root())


def export_target() -> Path:
    """`export_path()` with its folder made, for writing to it. Raises
    `drives.DriveOffline` when that folder is on a drive that isn't plugged in."""
    p = export_path()
    drives.ensure_dir(p.parent)
    return p


def export_batch_xml(name: str, tracks: list) -> tuple[str, int]:
    """Write a one-playlist rekordbox XML for a batch to the fixed export file."""
    items = [{"name": t.title, "artist": t.artist, "location": Path(t.local_path),
              "bpm": t.bpm, "key": t.key, "genre": t.style or ""}
             for t in tracks if t.local_path]
    out = str(export_target())
    n = rekordbox_io.export_playlist(out, name, items)
    return out, n


def _bootstrap() -> None:
    """Restore the last-loaded library once at process start, so the app opens
    ready instead of needing the Load buttons clicked every launch."""
    st = load_studio_state()
    if st.get("rekordbox"):
        try:
            library.merge_rekordbox(rekordbox.from_live(), snapshot=RekordboxSnapshot())
            print(f"[bootstrap] merged rekordbox ({len(library.rekordbox_index)} playlists)")
        except Exception as e:
            print(f"[bootstrap] rekordbox load failed: {e}")
    folder = st.get("folder")
    if folder and Path(folder).is_dir():
        try:
            n = library.add_folder(Path(folder))
            print(f"[bootstrap] added folder: {folder} (+{n} tracks)")
        except Exception as e:
            print(f"[bootstrap] folder load failed: {e}")
    # Load previously-downloaded files so the Sync gap sees them as "downloaded"
    # (not "missing") on a fresh start, even before visiting the Library page.
    try:
        refresh_batches()
        if download_batches:
            print(f"[bootstrap] download batches: "
                  f"{ {n: len(t) for n, t in download_batches.items()} }")
    except Exception as e:
        print(f"[bootstrap] batch scan failed: {e}")
