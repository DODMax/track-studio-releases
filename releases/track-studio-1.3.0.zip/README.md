# Track Energy Tagger

Tag MP3 and M4A files with an AI-derived **Energy 1–10** score that rekordbox can read and filter on.

The score is written into the file's **Comments** tag (`Energy 07`), zero-padded so rekordbox Intelligent Playlists can match `Energy 0[1-3]` (chill), `Energy 0[4-6]` (mid), `Energy 0[7-9]` (peak), `Energy 10` cleanly. The format is compatible with the Mixed In Key convention.

Powered by [Essentia](https://essentia.upf.edu/) (MTG, UPF) — DEAM arousal regression on top of MusiCNN audio embeddings. Arousal is the standard MIR-equivalent of "perceived energy".

## Install

```bash
cd track-energy
bash install.sh
```

One shot: sets up the Python environment, then builds and installs
**Track Studio.app** into /Applications — launch it from Spotlight
(⌘Space → "Track Studio"). Needs the Xcode Command Line Tools
(`xcode-select --install`); the script checks and tells you. Safe to re-run.
The optional Beatport download engine ([beatportdl](https://github.com/unspok3n/beatportdl))
is fetched automatically from its public GitHub releases.

### Updating

**Track Studio updates itself.** It looks for a new release when it launches and
twice a day after that, and never installs one on its own: a new version shows as
a quiet **Update 1.2.0** button in the header, which opens what changed and an
*Install and restart*. It takes a few seconds.

Only the app's own files are replaced — your venv, credentials, downloads,
analysis, drafts and rekordbox snapshot are never touched, because the release is
a code-only zip and everything else is on the ignore list. If the new version
fails to start, the old one is put back and started again automatically, and you
get an alert saying so.

Settings → **Version** shows what you're on, when it last looked, and a *Check
now*; it's also where you switch to the **beta** channel to get releases first.

<details><summary>Cutting a release (maintainer)</summary>

```bash
venv/bin/python scripts/release.py 1.2.0 --notes "- what changed"
```

That writes `VERSION`, builds a signed zip and a `stable.json` manifest into
`../track-studio-releases`, which is an ordinary public repo — publishing is a
commit in GitHub Desktop, there is no update server. The release is signed with
the ed25519 key in `~/.config/track-studio/release_key` (made once by
`scripts/release.py keygen`); the app refuses anything that key didn't sign.

To try a release on your own machine before publishing it, put the folder in
`.env` and restart: `TRACK_STUDIO_FEED=file:///Users/you/Code/track-studio-releases`

</details>

### Manual setup

```bash
cd track-energy
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

`essentia-tensorflow` ships its own TensorFlow runtime (~115 MB wheel). The three model `.pb` files (~3.5 MB total) are downloaded on first run into `models/`.

## Use

### Track Studio app (recommended)

```bash
open "/Applications/Track Studio.app"    # installed by ./install.sh
```

Opens the app window — library, sync, build, download and history. It's a real
window with its own Dock icon, not a browser tab; ⌘R reloads, ⌘+/− size the page.

The window and the server are separate: **closing the window leaves an analysis
running**, and opening the app again brings the window back instantly instead of
starting a second one. If you'd rather use a browser (or want it on a phone on
the same network), the server is still at http://localhost:8080.

### Streamlit tagger GUI

```bash
streamlit run app.py
```

Browser opens with a folder input on the left. Type/paste a folder path, click **Analyze N tracks** to tag the untagged ones, then browse tracks grouped by energy bucket with inline audio playback. Filter buckets via the multi-select. Force re-analyze in the *advanced* expander.

### CLI

```bash
# Analyze all .mp3/.m4a in a folder and write Energy NN to each file's Comments tag
python energy.py /path/to/folder

# Preview without writing
python energy.py /path/to/folder --dry-run

# Re-analyze tracks that already have an Energy tag
python energy.py /path/to/folder --force

# Also write Dance score + Valence: "Energy 07 | Dance 0.72 | Valence 5.30"
python energy.py /path/to/folder --rich
```

WAV files are deliberately skipped (rekordbox WAV tagging is non-standard; convert to AIFF or M4A first if you want them analyzed).

## In rekordbox

1. **Reload tags** on the affected tracks: select them in Collection → right-click → *Reload Tag*. The Comments column should now show `Energy NN`.
2. **Create Intelligent Playlists** to slice by energy:

| Sub-playlist  | Rule                              |
|---------------|-----------------------------------|
| Chill (1-3)   | `Comments contains "Energy 0[1-3]"` (or three rules joined OR) |
| Groove (4-5)  | `Comments contains "Energy 04"` OR `Energy 05` |
| Build (6-7)   | `Comments contains "Energy 06"` OR `Energy 07` |
| Peak (8-10)   | `Comments contains "Energy 08"` OR `Energy 09` OR `Energy 10` |

(rekordbox's UI doesn't accept regex in the rule, so OR-chain individual `contains "Energy NN"` rules.)

## Troubleshooting

- **Settings shows ffmpeg/yt-dlp red even though it's installed** — the server
  keeps running in the background between app launches, so it never sees newly
  installed tools. Restart it: `kill $(lsof -ti:8080)`, then reopen Track
  Studio.
- **"Operation not permitted" reading a rekordbox DB on an external drive** —
  macOS privacy protection. System Settings → Privacy & Security → **Full Disk
  Access** → add **Track Studio** (from /Applications), then restart the server
  as above. (If it still fails, also grant Full Disk Access to the Python
  listed by `ls -l venv/bin/python`.)

## Re-runs are safe

The script reads the existing Comments tag first; if `Energy NN` is already present it skips that file. Use `--force` to re-analyze.

## Why this design

- **No external DB**: state lives on the file. Move the file, the energy moves with it.
- **No rekordbox database writes**: works on any rekordbox version, survives library rebuilds.
- **Compatible with Mixed In Key**: same Comments-field convention; if you later subscribe to MIK, both tools coexist.
