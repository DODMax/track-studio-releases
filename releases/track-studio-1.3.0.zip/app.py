"""Streamlit UI for the Track Energy Tagger.

Run with:
    streamlit run app.py
"""
from __future__ import annotations

import re
from pathlib import Path

import pandas as pd
import streamlit as st
from mutagen import File as MutagenFile

from energy import (
    SUPPORTED_EXTS,
    analyze,
    build_predictors,
    ensure_models,
    find_audio_files,
    find_skipped_files,
    read_existing_energy,
    write_energy,
)
from tagging import parse_comment

st.set_page_config(page_title="Track Energy Tagger", page_icon="🎚️", layout="wide")

ENERGY_LABELS = {
    1: "Ambient", 2: "Sleep", 3: "Slow",
    4: "Mellow", 5: "Steady", 6: "Chill",
    7: "Groove", 8: "Build", 9: "Peak", 10: "Max",
}
ENERGY_COLORS = {
    1: "#3b6ea5", 2: "#3b6ea5", 3: "#3b6ea5",
    4: "#4a90e2", 5: "#4a90e2", 6: "#5fb454",
    7: "#f0a830", 8: "#e8731c", 9: "#d83a3a", 10: "#a02020",
}


@st.cache_resource(show_spinner="Loading Essentia models...")
def load_predictors(rich: bool):
    """Load Essentia models once per session. Cache key includes `rich` so the
    danceability head is loaded only when needed."""
    paths = ensure_models()
    return build_predictors(paths, rich=rich)


def _read_full_comment(path: Path) -> str:
    f = MutagenFile(path)
    if f is None or f.tags is None:
        return ""
    if path.suffix.lower() == ".mp3":
        comm = next((v for k, v in f.tags.items() if k.startswith("COMM")), None)
        return "".join(comm.text) if comm else ""
    if path.suffix.lower() == ".m4a":
        return (f.tags.get("\xa9cmt") or [""])[0]
    return ""


def _chip(label: str, value: str, color: str, tooltip: str) -> str:
    """Render a small badge with a label, value, and tooltip on hover."""
    return (
        f"<span title='{tooltip}' "
        f"style='display:inline-block;font-family:monospace;font-size:0.78em;"
        f"background:#f3f4f6;border-left:3px solid {color};border-radius:3px;"
        f"padding:1px 6px;color:#374151;'>"
        f"<span style='color:#9ca3af;'>{label}</span> {value}"
        f"</span>"
    )


def scan_folder(folder: Path) -> pd.DataFrame:
    """Build a dataframe summarising every supported file in `folder`."""
    rows = []
    for p in find_audio_files(folder):
        comment = _read_full_comment(p)
        tags = parse_comment(comment)
        rows.append({
            "name": p.name,
            "format": p.suffix[1:].upper(),
            "energy": tags.get("energy"),
            "arousal": tags.get("arousal"),
            "danceability": tags.get("danceability"),
            "valence": tags.get("valence"),
            "style": tags.get("style"),
            "moods": ",".join(tags.get("moods", [])) or None,
            "comment": comment,
            "path": str(p),
        })
    return pd.DataFrame(rows)


# ------------------------------ sidebar ------------------------------
with st.sidebar:
    st.header("🎚️ Track Energy")
    mode = st.radio(
        "Mode",
        options=["Folder", "Library"],
        index=0,
        horizontal=True,
        key="ui_mode",
        help="Folder mode = analyze + browse a single folder of files. Library mode = browse rekordbox playlists as auto-generated blocks.",
    )
    st.divider()
    folder_str = st.text_input(
        "Folder",
        value=st.session_state.get("folder", str(Path.home() / "Downloads" / "Tracks")),
        help="Path to a folder of MP3/M4A files.",
        disabled=(mode != "Folder"),
    )
    st.session_state["folder"] = folder_str
    folder = Path(folder_str).expanduser()

    if mode == "Folder" and not folder.is_dir():
        st.error(f"Not a directory: {folder}")
        st.stop()

    xml_str = st.text_input(
        "rekordbox.xml",
        value=st.session_state.get("xml_path", str(Path.home() / "Downloads" / "rekordbox.xml")),
        help="Path to the rekordbox XML export.",
        disabled=(mode != "Library"),
    )
    st.session_state["xml_path"] = xml_str

    if st.button("🔄 Rescan", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

    rich = st.checkbox(
        "Rich analysis",
        value=False,
        help=(
            "Also score danceability, emotional valence, top genre/style "
            "(Discogs-400), and top mood/theme tags (MTG-Jamendo-56). "
            "Roughly 2× slower per track because of the extra Discogs-EffNet "
            "embedding pass. All extras are written into the Comments tag."
        ),
    )

    st.divider()

    with st.expander("ℹ️ what do the numbers mean?"):
        st.markdown(
            """
            **Energy 01–10** — DJ-style energy bucket. Computed from the model's
            `arousal` output and stretched so most electronic-dance music spans
            the 5–9 range. Filterable in rekordbox Intelligent Playlists via
            `Comments contains "Energy 07"`.

            **A** — raw *arousal* score from the Essentia DEAM model
            (~3 to 7 in practice, scale anchored at 1–9). Higher = more
            intense/awake. The integer Energy bucket is derived from this; we
            keep the raw value so you can re-bucket later with different
            cutoffs without re-analyzing.

            **Dance** *(rich only)* — probability the model thinks the track
            is danceable, 0.00–1.00.

            **Valence** *(rich only)* — emotional positivity, ~3–7. Low =
            sad/dark, high = happy/uplifting. Independent of energy:
            high-energy + low-valence = aggressive; high-energy + high-valence
            = euphoric.

            **Style** *(rich only)* — top-1 genre/style from the
            Discogs-EffNet 400-class classifier. Shortened (e.g.
            `Electronic—Tropical House` → `Tropical House`). Useful to spot
            stylistic outliers in a playlist that scored similar Energy.

            **Mood** *(rich only)* — top mood/theme tags from MTG-Jamendo
            (56 classes including `summer, club, dark, melancholic,
            uplifting, energetic, deep, party`). The most discriminating
            of the metrics — a "summer" mood in a deep-club playlist
            almost always means the track doesn't belong.
            """
        )

    st.caption(
        "Energy is written to each file's Comments tag as `Energy NN | A 5.67`. "
        "Reload Tag in rekordbox to import it. Format compatible with Mixed In Key."
    )


# ============================================================
# LIBRARY MODE — block browser
# ============================================================
if mode == "Library":
    from rekordbox_io import (
        load_collection, load_playlists, resolve_location, export_folder,
    )
    from microsets import (
        Track, cluster, next_up, transition_label, _camelot_parse,
        generate_sequences, color_for_energy,
    )

    xml_path = Path(xml_str).expanduser()
    if not xml_path.is_file():
        st.error(f"rekordbox.xml not found at {xml_path}")
        st.stop()

    @st.cache_data(show_spinner="Reading rekordbox.xml...")
    def _load_rb(xml_path_str: str, mtime: float):
        return load_collection(xml_path_str), load_playlists(xml_path_str)

    coll, playlists = _load_rb(str(xml_path), xml_path.stat().st_mtime)

    if not playlists:
        st.warning("No top-level user playlists found in this XML.")
        st.stop()

    pl_names = [n for n, _ in playlists]
    chosen_pl = st.selectbox(
        "Parent playlist",
        options=pl_names,
        index=pl_names.index("610 - DeepRemixes") if "610 - DeepRemixes" in pl_names else 0,
        format_func=lambda n: f"{n}  ({len([t for t in dict(playlists)[n]])} tracks)",
    )
    selected_ids = dict(playlists)[chosen_pl]

    # Build Track objects + tag-fill via file fallback.
    tracks = []
    missing_tags = 0
    missing_files = 0
    for tid in selected_ids:
        rb = coll.get(tid)
        if rb is None:
            continue
        path = resolve_location(rb.location)
        if path is None or not path.exists():
            missing_files += 1
            path = None
        t = Track.from_rekordbox(rb, path)
        if t.energy is None:
            missing_tags += 1
        tracks.append(t)

    sets = cluster(chosen_pl, tracks)

    # Top stats
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Tracks", len(tracks))
    c2.metric("Tagged", len(tracks) - missing_tags)
    c3.metric("Micro-sets", len(sets))
    c4.metric("Missing files", missing_files, help="Tracks whose Location can't be resolved locally (Tidal/streaming, moved, etc.).")

    if missing_tags:
        st.info(
            f"{missing_tags} track(s) in this playlist don't have Energy tags yet. "
            "They'll still be clustered (by BPM only) but the energy bands will be approximate. "
            "Switch to **Folder** mode and run the analyzer on that folder "
            "to fill them in."
        )

    st.divider()

    # Render each MS as a card.
    set_index = {ms.id: i for i, ms in enumerate(sets)}

    for i, ms in enumerate(sets):
        d = ms.dna
        e_lo, e_hi = d["energy_band"]
        e_label = (f"E{e_lo:02d}" if e_lo == e_hi else f"E{e_lo:02d}-{e_hi:02d}") if e_lo else "E?"
        bpm_lo, bpm_hi = d["bpm_range"]
        bpm_label = f"{int(bpm_lo)}" if int(bpm_lo) == int(bpm_hi) else f"{int(bpm_lo)}-{int(bpm_hi)}"
        keys_label = ",".join(d["keys"]) if d["keys"] else "?"
        color = ENERGY_COLORS.get(int(round(d["energy_median"])) if d["energy_median"] else 6, "#888")

        # Card header
        header = (
            f"<div style='border-left:6px solid {color};padding:10px 14px;background:#fafafa;border-radius:4px;'>"
            f"<div style='font-weight:700;font-size:1.05em;'>{ms.id} · {d['top_style'] or '—'} · {e_label} · {bpm_label} BPM · {keys_label}</div>"
            f"<div style='color:#6b7280;font-size:0.9em;margin-top:4px;'>{d['count']} tracks · "
            f"moods: <span style='color:#374151;'>{', '.join(d['top_moods']) or '—'}</span></div>"
            f"</div>"
        )
        st.markdown(header, unsafe_allow_html=True)

        # Expandable track list
        with st.expander(f"▶ tracks ({d['count']})", expanded=False):
            for t in ms.tracks:
                cols = st.columns([5, 2, 5], vertical_alignment="center")
                with cols[0]:
                    name = t.name or "?"
                    if t.artist:
                        st.markdown(f"**{t.artist} — {name}**")
                    else:
                        st.markdown(f"**{name}**")
                    st.caption(f"id {t.id} · {t.bpm:.0f} BPM · {t.key or '?'}")
                with cols[1]:
                    chips = []
                    if t.energy is not None:
                        chips.append(_chip("E", f"{t.energy:02d}", color, "Energy bucket."))
                    if t.style:
                        chips.append(_chip("style", t.style, "#d97706", "Top genre/style."))
                    if t.moods:
                        chips.append(_chip("mood", ",".join(t.moods), "#db2777", "Top mood/theme tags."))
                    st.markdown(
                        "<div style='display:flex;flex-direction:column;gap:4px;'>" + "".join(chips) + "</div>",
                        unsafe_allow_html=True,
                    )
                with cols[2]:
                    if t.path is not None and t.path.exists():
                        try:
                            st.audio(str(t.path))
                        except Exception as e:
                            st.warning(f"audio: {e}")
                    else:
                        st.caption("audio not available")

        # Next-up
        ups = next_up(ms, sets)
        if ups:
            lines = ["<div style='margin:6px 0 0 14px;font-size:0.92em;'>"
                     "<span style='color:#6b7280;'>next-up:</span>"]
            for nb, sc in ups:
                trans = transition_label(ms, nb)
                lines.append(
                    f"<div style='margin-top:3px;'>"
                    f"&nbsp;&nbsp;• <b>{nb.id}</b> — {nb.dna['top_style'] or '?'} ({trans}) "
                    f"<span style='color:#9ca3af;'>★ {sc}</span></div>"
                )
            lines.append("</div>")
            st.markdown("".join(lines), unsafe_allow_html=True)

        st.markdown("<div style='height:18px;'></div>", unsafe_allow_html=True)

    # ---- Sequences ----
    sequences = generate_sequences(sets, max_count=4, length=4, min_score=60)
    if sequences:
        st.divider()
        st.markdown("### 🎛️ Pre-built sequences")
        st.caption(
            "Greedy walks through the next-up graph. Each one is a ready-to-play set on "
            "the CDJ — load the playlist top-to-bottom, no thinking required."
        )
        for seq in sequences:
            track_count = len(seq.all_track_ids)
            steps = " → ".join(ms.id.split("-")[-1] for ms in seq.sets)
            st.markdown(
                f"<div style='border-left:6px solid #6366f1;padding:10px 14px;"
                f"background:#fafafa;border-radius:4px;margin-bottom:8px;'>"
                f"<div style='font-weight:700;font-size:1.05em;'>{seq.name}</div>"
                f"<div style='color:#6b7280;font-size:0.9em;margin-top:4px;'>"
                f"{track_count} tracks · {steps}</div>"
                f"</div>",
                unsafe_allow_html=True,
            )

    # ---- Export ----
    st.divider()
    st.markdown("### 📤 Export")

    exp_opts_l, exp_opts_r = st.columns(2)
    with exp_opts_l:
        export_sequences = st.checkbox(
            "Include pre-built sequences", value=True,
            help="Adds a 'Sequences' sub-folder with one playlist per pre-built route. "
                 "These are what you'll actually play on the CDJ.",
        )
    with exp_opts_r:
        export_colors = st.checkbox(
            "Set color tags by energy", value=True,
            help=(
                "Writes the rekordbox track Colour attribute based on Energy: "
                "blue (chill 1-3), aqua (mellow 4-5), green (groove 6), "
                "yellow (build 7), orange (push 8), red (peak 9-10). "
                "Caveat: rekordbox only applies these on tracks NOT yet in your "
                "main collection. For tracks already in your library, drag them "
                "from the rekordbox-xml linked panel to refresh the color, or use "
                "pyrekordbox direct-write later."
            ),
        )

    exp_l, exp_r = st.columns([2, 5])
    with exp_l:
        if st.button("📤 Export to rekordbox", type="primary", use_container_width=True):
            out_xml = xml_path.with_name(xml_path.stem + "-with-microsets.xml")
            ms_pairs = [(ms.name, [t.id for t in ms.tracks]) for ms in sets]
            seq_pairs = (
                [(s.name, s.all_track_ids) for s in sequences]
                if export_sequences else None
            )
            colors = None
            if export_colors:
                colors = {
                    t.id: c for t in tracks
                    if (c := color_for_energy(t.energy)) is not None
                }
            written = export_folder(
                str(xml_path), str(out_xml), chosen_pl, ms_pairs,
                sequences=seq_pairs, track_colors=colors,
            )
            n_seq = len(sequences) if seq_pairs else 0
            n_col = len(colors) if colors else 0
            st.success(
                f"Wrote {written}\n\n"
                f"• {len(ms_pairs)} block(s)"
                + (f"\n• {n_seq} pre-built sequence(s)" if n_seq else "")
                + (f"\n• Color tags applied to {n_col} track(s)" if n_col else "")
            )
            st.caption(
                "In rekordbox: **Preferences → View → Layout** → tick `rekordbox xml`, "
                "then **Preferences → Advanced → Database** → set the rekordbox xml path "
                "to this file. Refresh the rekordbox-xml panel and drag the new "
                "sub-playlists across to your main library."
            )
    with exp_r:
        st.caption(
            "Export writes a sibling XML (`-with-microsets.xml`) — your source "
            "rekordbox.xml is never modified. The parent playlist is morphed into a "
            "folder containing 'All', 'Micro-sets', and (optionally) 'Sequences' sub-folders."
        )

    st.stop()  # don't run Folder-mode code below


# ============================================================
# FOLDER MODE — original analyze + browse
# ============================================================
# ------------------------------ scan ------------------------------
df = scan_folder(folder)
skipped_unsupported = find_skipped_files(folder)

total = len(df)
tagged_count = int(df["energy"].notna().sum())
untagged_count = total - tagged_count

st.title(f"📁 {folder.name}")
st.caption(str(folder))

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total tracks", total)
c2.metric("Tagged", tagged_count)
c3.metric("Need analysis", untagged_count)
c4.metric("Unsupported", len(skipped_unsupported), help="WAV/AIFF/FLAC are skipped")

# ------------------------------ analyze ------------------------------
st.divider()
a1, a2 = st.columns([2, 5])
with a1:
    if untagged_count > 0:
        analyze_label = f"⚡ Analyze {untagged_count} track(s)"
        if rich:
            analyze_label += " (rich)"
        if st.button(analyze_label, type="primary", use_container_width=True):
            predictors = load_predictors(rich)
            untagged_df = df[df["energy"].isna()]
            progress = st.progress(0.0, text="Starting...")
            errors = []
            for i, (_, row) in enumerate(untagged_df.iterrows()):
                p = Path(row["path"])
                progress.progress(i / len(untagged_df), text=f"Analyzing {p.name[:50]}...")
                try:
                    res = analyze(p, predictors)
                    extras = {"arousal": res["arousal"]}
                    if rich:
                        extras["valence"] = res["valence"]
                        if "danceability" in res:
                            extras["danceability"] = res["danceability"]
                        if "genre" in res:
                            extras["genre"] = res["genre"]
                        if "moods" in res:
                            extras["moods"] = res["moods"]
                    write_energy(p, res["energy"], extras=extras)
                except Exception as e:
                    errors.append((p.name, str(e)))
            progress.progress(1.0, text=f"Done — {len(untagged_df) - len(errors)} tagged")
            if errors:
                st.error(f"{len(errors)} error(s):")
                for name, msg in errors:
                    st.write(f"• `{name}`: {msg}")
            st.rerun()
    else:
        st.success("✓ All tracks tagged")
with a2:
    with st.expander("⚙️ advanced", expanded=False):
        st.caption(
            "Re-analysis ignores existing tags and overwrites them. "
            "Use this to upgrade existing tags with rich data, or after "
            "tweaking the energy mapping."
        )
        force_label = "🔁 Force re-analyze ALL tagged tracks"
        if rich:
            force_label += " (rich)"
        if st.button(force_label, use_container_width=False):
            predictors = load_predictors(rich)
            progress = st.progress(0.0, text="Starting...")
            for i, (_, row) in enumerate(df.iterrows()):
                p = Path(row["path"])
                progress.progress(i / len(df), text=f"Re-analyzing {p.name[:50]}...")
                try:
                    res = analyze(p, predictors)
                    extras = {"arousal": res["arousal"]}
                    if rich:
                        extras["valence"] = res["valence"]
                        if "danceability" in res:
                            extras["danceability"] = res["danceability"]
                        if "genre" in res:
                            extras["genre"] = res["genre"]
                        if "moods" in res:
                            extras["moods"] = res["moods"]
                    write_energy(p, res["energy"], extras=extras)
                except Exception as e:
                    st.write(f"• `{p.name}`: {e}")
            progress.progress(1.0, text="Done")
            st.rerun()

# ------------------------------ display ------------------------------
st.divider()

tagged_df = df[df["energy"].notna()].copy()
if len(tagged_df) == 0:
    if untagged_count > 0:
        st.info("No tagged tracks yet. Click **Analyze** above to compute energy ratings.")
    else:
        st.warning("No supported audio files found in this folder.")
    st.stop()

tagged_df["energy"] = tagged_df["energy"].astype(int)
# Pre-split moods into a list column for easier filtering / first-mood grouping.
tagged_df["mood_list"] = tagged_df["moods"].apply(
    lambda s: [m.strip() for m in s.split(",")] if isinstance(s, str) and s else []
)
tagged_df["first_mood"] = tagged_df["mood_list"].apply(lambda xs: xs[0] if xs else None)

# Compute rarity within this folder so we can flag outliers.
style_counts = tagged_df["style"].value_counts(dropna=True).to_dict()
mood_flat: list[str] = [m for xs in tagged_df["mood_list"] for m in xs]
mood_counts: dict[str, int] = {m: mood_flat.count(m) for m in set(mood_flat)}
N = len(tagged_df)

def is_outlier_style(s) -> bool:
    return isinstance(s, str) and s and style_counts.get(s, 0) <= max(1, N // 10)

def is_outlier_mood(moods: list[str]) -> bool:
    return any(mood_counts.get(m, 0) <= max(1, N // 10) for m in moods)

tagged_df["outlier_style"] = tagged_df["style"].apply(is_outlier_style)
tagged_df["outlier_mood"] = tagged_df["mood_list"].apply(is_outlier_mood)


def _render_chips(row) -> str:
    chips = []
    if pd.notna(row["arousal"]):
        chips.append(_chip("arousal", f"{row['arousal']:.2f}", "#888",
                           "Raw DEAM arousal score (~3-7). Source of the Energy bucket."))
    if pd.notna(row["danceability"]):
        chips.append(_chip("dance", f"{row['danceability']:.2f}", "#7a4cd1",
                           "Danceability probability (0–1)."))
    if pd.notna(row["valence"]):
        chips.append(_chip("valence", f"{row['valence']:.2f}", "#2a8c8c",
                           "Emotional positivity (~3-7). Low=sad/dark, high=happy."))
    if isinstance(row["style"], str) and row["style"]:
        color = "#d83a3a" if row.get("outlier_style") else "#d97706"
        chips.append(_chip("style", row["style"], color,
                           ("⚠ rare style in this folder. " if row.get("outlier_style") else "")
                           + "Discogs-EffNet top-1 genre/style prediction."))
    if isinstance(row["moods"], str) and row["moods"]:
        color = "#d83a3a" if row.get("outlier_mood") else "#db2777"
        chips.append(_chip("mood", row["moods"], color,
                           ("⚠ rare mood tag in this folder — possible outlier. " if row.get("outlier_mood") else "")
                           + "MTG-Jamendo top mood/theme tags."))
    return "<div style='display:flex;flex-direction:column;gap:4px;'>" + "".join(chips) + "</div>"


def render_track_row(row, idx: int, total: int) -> None:
    """Render a single track row: name+comment | chips | audio. Adds a divider after."""
    is_outlier = bool(row.get("outlier_style") or row.get("outlier_mood"))
    with st.container():
        cols = st.columns([5, 2, 5], vertical_alignment="center")
        with cols[0]:
            prefix = "⚠ " if is_outlier else ""
            st.markdown(f"**{prefix}{row['name']}**")
            st.caption(row["comment"][:130] if row["comment"] else "—")
        with cols[1]:
            st.markdown(_render_chips(row), unsafe_allow_html=True)
        with cols[2]:
            try:
                st.audio(row["path"])
            except Exception as e:
                st.warning(f"audio: {e}")
    if idx < total - 1:
        st.markdown(
            "<hr style='border:none;border-top:1px solid #eee;margin:14px 0;'/>",
            unsafe_allow_html=True,
        )


def render_bucket(header_html: str, bucket: pd.DataFrame) -> None:
    st.markdown(header_html, unsafe_allow_html=True)
    rows = list(bucket.iterrows())
    for i, (_, row) in enumerate(rows):
        render_track_row(row, i, len(rows))
    st.markdown("<div style='height:28px;'></div>", unsafe_allow_html=True)


tab_energy, tab_style, tab_mood, tab_table = st.tabs([
    "🎚️ By Energy",
    "🎵 By Style",
    "💭 By Mood",
    "📋 Table",
])


# ---------- By Energy ----------
with tab_energy:
    all_energies = sorted(tagged_df["energy"].unique())
    chosen_e = st.multiselect(
        "Filter by energy",
        options=all_energies,
        default=all_energies,
        format_func=lambda e: f"{e:02d} — {ENERGY_LABELS.get(e, '?')}",
        key="filter_energy",
    )
    filtered = tagged_df[tagged_df["energy"].isin(chosen_e)].sort_values(["energy", "name"])
    st.caption(f"Showing {len(filtered)} of {len(tagged_df)} tagged tracks")
    for energy in sorted(filtered["energy"].unique()):
        bucket = filtered[filtered["energy"] == energy]
        label = ENERGY_LABELS.get(energy, "")
        color = ENERGY_COLORS.get(energy, "#888")
        header = (
            f"<span style='background:{color};color:white;padding:2px 10px;border-radius:6px;"
            f"font-weight:600;font-size:0.85em;'>Energy {energy:02d}</span> "
            f"<b>{label}</b> · {len(bucket)} track(s)"
        )
        render_bucket(header, bucket)


# ---------- By Style ----------
with tab_style:
    styles_with_count = sorted(style_counts.items(), key=lambda kv: (-kv[1], kv[0]))
    style_options = [s for s, _ in styles_with_count]
    chosen_s = st.multiselect(
        "Filter by style",
        options=style_options,
        default=style_options,
        format_func=lambda s: f"{s} ({style_counts[s]})",
        key="filter_style",
    )
    sub = tagged_df[tagged_df["style"].isin(chosen_s)].sort_values(["style", "energy", "name"])
    st.caption(f"Showing {len(sub)} of {len(tagged_df)} tagged tracks · {len(chosen_s)} style(s)")
    for style in [s for s in style_options if s in chosen_s]:
        bucket = sub[sub["style"] == style]
        if len(bucket) == 0:
            continue
        rare = " <span style='color:#d83a3a;font-size:0.8em;'>⚠ rare</span>" if is_outlier_style(style) else ""
        header = (
            f"<span style='background:#d97706;color:white;padding:2px 10px;border-radius:6px;"
            f"font-weight:600;font-size:0.85em;'>{style}</span>"
            f" · {len(bucket)} track(s){rare}"
        )
        render_bucket(header, bucket)


# ---------- By Mood ----------
with tab_mood:
    moods_sorted = sorted(mood_counts.items(), key=lambda kv: (-kv[1], kv[0]))
    mood_options = [m for m, _ in moods_sorted]
    col_l, col_r = st.columns([3, 1])
    with col_l:
        chosen_m = st.multiselect(
            "Filter by mood (track shown if ANY of its moods match)",
            options=mood_options,
            default=mood_options,
            format_func=lambda m: f"{m} ({mood_counts[m]})",
            key="filter_mood",
        )
    with col_r:
        group_mode = st.radio(
            "Group by",
            options=["top mood", "every mood (track may repeat)"],
            key="mood_group_mode",
            horizontal=False,
        )
    chosen_set = set(chosen_m)
    sub = tagged_df[tagged_df["mood_list"].apply(lambda xs: any(m in chosen_set for m in xs))]
    st.caption(f"Showing {len(sub)} of {len(tagged_df)} tagged tracks · {len(chosen_m)} mood(s)")

    if group_mode == "top mood":
        for mood in [m for m in mood_options if m in chosen_set]:
            bucket = sub[sub["first_mood"] == mood].sort_values(["energy", "name"])
            if len(bucket) == 0:
                continue
            rare = " <span style='color:#d83a3a;font-size:0.8em;'>⚠ rare</span>" if mood_counts.get(mood, 0) <= max(1, N // 10) else ""
            header = (
                f"<span style='background:#db2777;color:white;padding:2px 10px;border-radius:6px;"
                f"font-weight:600;font-size:0.85em;'>{mood}</span>"
                f" · {len(bucket)} track(s){rare}"
            )
            render_bucket(header, bucket)
    else:
        for mood in [m for m in mood_options if m in chosen_set]:
            bucket = sub[sub["mood_list"].apply(lambda xs: mood in xs)].sort_values(["energy", "name"])
            if len(bucket) == 0:
                continue
            rare = " <span style='color:#d83a3a;font-size:0.8em;'>⚠ rare</span>" if mood_counts.get(mood, 0) <= max(1, N // 10) else ""
            header = (
                f"<span style='background:#db2777;color:white;padding:2px 10px;border-radius:6px;"
                f"font-weight:600;font-size:0.85em;'>{mood}</span>"
                f" · {len(bucket)} track(s){rare}"
            )
            render_bucket(header, bucket)


# ---------- Table ----------
with tab_table:
    st.caption("Sortable table — click any column header. Outliers shown with ⚠.")
    table_df = tagged_df.copy()
    table_df["⚠"] = (table_df["outlier_style"] | table_df["outlier_mood"]).apply(lambda b: "⚠" if b else "")
    show = table_df[[
        "⚠", "name", "energy", "arousal", "valence", "danceability",
        "style", "moods", "format",
    ]].rename(columns={"name": "track"})
    # Size the table to fit all rows so the page scrolls instead of the table.
    # Row height ≈ 35px in default Streamlit theme; +1 for header, +3 for borders.
    table_height = 35 * (len(show) + 1) + 3
    st.dataframe(
        show,
        use_container_width=True,
        hide_index=True,
        height=table_height,
        column_config={
            "energy": st.column_config.NumberColumn(format="%d"),
            "arousal": st.column_config.NumberColumn(format="%.2f"),
            "valence": st.column_config.NumberColumn(format="%.2f"),
            "danceability": st.column_config.NumberColumn(format="%.2f"),
        },
    )

# ------------------------------ skipped ------------------------------
if skipped_unsupported:
    with st.expander(f"⏭️ {len(skipped_unsupported)} unsupported file(s) (WAV/AIFF/FLAC)"):
        for p in skipped_unsupported:
            st.text(p.name)
        st.caption("Convert to AIFF or M4A to include them — rekordbox WAV tagging is non-standard.")
