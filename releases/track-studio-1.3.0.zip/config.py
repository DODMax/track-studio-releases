"""Tiny local config loader — reads .env into os.environ, no dependency.

Personal project: secrets live in an untracked .env (see .gitignore), not in
Infisical and not committed. Call load_env() once at startup, then read with
os.environ / require().
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"


def load_env(path: Path = ENV_PATH) -> None:
    """Load KEY=VALUE lines from .env into os.environ (does not overwrite existing)."""
    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key, val = key.strip(), val.strip().strip('"').strip("'")
        os.environ.setdefault(key, val)


def require(key: str) -> str:
    """Return an env var or raise a clear error pointing at .env."""
    val = os.environ.get(key)
    if not val:
        raise RuntimeError(f"missing {key} — add it to {ENV_PATH}")
    return val


def save_env(values: dict, path: Path = ENV_PATH) -> None:
    """Merge `values` into the .env file and the live process env.

    Preserves unrelated lines/comments; updates a key in place if present, else
    appends it. Blank values are skipped (a field left empty won't wipe an
    existing secret). Also updates os.environ so a subsequent client build (which
    calls load_env → setdefault) sees the new value immediately.
    """
    values = {k: v for k, v in values.items() if v not in (None, "")}
    if not values:
        return
    lines = path.read_text().splitlines() if path.exists() else []
    remaining = dict(values)
    for i, raw in enumerate(lines):
        stripped = raw.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key = stripped.partition("=")[0].strip()
        if key in remaining:
            lines[i] = f"{key}={remaining.pop(key)}"
    for key, val in remaining.items():
        lines.append(f"{key}={val}")
    path.write_text("\n".join(lines) + "\n")
    for key, val in values.items():
        os.environ[key] = str(val)   # overwrite (load_env only setdefaults)
