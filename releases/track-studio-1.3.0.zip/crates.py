"""Crates — the preselection you dig out of the library before you program a set.

A crate is a pile you gather: a genre, a mood, a "maybe for Friday". It is not
a destination and not a playlist, and keeping those apart is most of
understanding this module:

    destination   exactly one per track, and the track *carries* it by sitting
                  in a folder of that name (`destinations`). Filing is a file
                  move, visible in Finder.
    crate         several per track, and nothing moves. Pure reference — a
                  track can sit in "Friday", "Deep" and "Maybe" at once while
                  living in exactly one folder.

That difference is why crates need real storage while destinations don't.

**Membership is evidence, not just a convenience.** The play history records
only what you played; a crate records what you *considered*, and the crate→set
step records what you considered and then left out. Negative examples from a
controlled context are the thing a ranking model can't get from rekordbox at
all, so this store is written to be read later by the suggester, not only by
the UI.

Adding to a crate has to work from anywhere — you notice a track while browsing
a playlist and put it in "Friday" without going anywhere — so this is a leaf
module with no UI and no `runtime`, and the affordance can sit on any row.

### Local now, syncable later

Multiplayer is coming back as local instances syncing to a server, so four
decisions are taken now because they cost nothing here and are brutal to
retrofit. They do not pick a sync strategy; they avoid foreclosing one.

- **UUIDs, never sequential ids.** Two instances both minting "crate 7" is
  unmergeable.
- **`created_at` / `updated_at` on everything.** Any merge has to know what
  happened when.
- **Tombstones, never hard deletes.** A row that is simply *gone* is
  indistinguishable from one the other side hasn't seen yet.
- **An author on every row**, always `LOCAL_AUTHOR` here. Cheap to write now,
  awkward to backfill later.

Nothing else in here is shaped for multiplayer.

### Where they are stored now: the board's shelf

Those four decisions were the right instinct, and the board made them real. Once
the board is mounted (`setline_local`), crates live on its shelf — Setline's own
`crates` tables, UUIDs and authors and all, with a change log that subsumes the
tombstones — and **this module keeps its API and stores through it**. The dock,
the fill screen and the library's chips don't know the difference. A crate there
belongs to no night and a night uses the ones attached to it, which is what
`night=` and `attach`/`detach` are for (0003 §8). `.crates.json` is read once more
to bring its crates over (`setline_local.import_crates_json`) and is then left
alone, and is still the store wherever the board isn't running — the analysis
workers, a Track Studio without a Setline checkout.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from config import ROOT

CRATES_PATH = ROOT / ".crates.json"

# Whose rows these are. One user locally, but the field exists from the start —
# see the module note.
LOCAL_AUTHOR = "me"

# Bumped only for a change the loader can't infer. Readers tolerate unknown
# keys, so adding a field is not a version bump.
VERSION = 1

MAX_NAME = 60


def _now() -> float:
    return time.time()


def _new_id() -> str:
    return uuid.uuid4().hex


@dataclass
class Item:
    """One track in one crate. The track itself lives in the library."""
    id: str
    track_key: str            # `library.track_key` — survives a file replacement
    added_at: float
    added_by: str = LOCAL_AUTHOR
    deleted_at: Optional[float] = None
    # What the record is, from the board's catalog — for an item the library has
    # no file for (a track found on Beatport on the board), so the dock can still
    # name it. Never stored in `.crates.json`.
    title: Optional[str] = None
    artist: Optional[str] = None
    bpm: Optional[float] = None
    key: Optional[str] = None

    @property
    def live(self) -> bool:
        return self.deleted_at is None

    def to_json(self) -> dict:
        return {"id": self.id, "track_key": self.track_key, "added_at": self.added_at,
                "added_by": self.added_by, "deleted_at": self.deleted_at}

    @staticmethod
    def from_json(d: dict) -> "Item":
        return Item(id=d.get("id") or _new_id(), track_key=d.get("track_key", ""),
                    added_at=float(d.get("added_at") or 0.0),
                    added_by=d.get("added_by") or LOCAL_AUTHOR,
                    deleted_at=d.get("deleted_at"))


@dataclass
class Crate:
    id: str
    name: str
    created_at: float
    updated_at: float
    created_by: str = LOCAL_AUTHOR
    deleted_at: Optional[float] = None
    items: list[Item] = field(default_factory=list)
    # On the board's shelf: the nights using this crate, and its place in the tab
    # strip of the night it was read for (None when read off the whole shelf).
    nights: list[int] = field(default_factory=list)
    position: Optional[int] = None

    @property
    def live(self) -> bool:
        return self.deleted_at is None

    @property
    def tracks(self) -> list[Item]:
        """Present membership, newest first — the order you built the pile in,
        so the thing you just added is where you are looking."""
        return sorted((i for i in self.items if i.live),
                      key=lambda i: -i.added_at)

    @property
    def keys(self) -> list[str]:
        return [i.track_key for i in self.tracks]

    def holds(self, track_key: str) -> bool:
        return any(i.track_key == track_key for i in self.items if i.live)

    def to_json(self) -> dict:
        return {"id": self.id, "name": self.name, "created_at": self.created_at,
                "updated_at": self.updated_at, "created_by": self.created_by,
                "deleted_at": self.deleted_at,
                "items": [i.to_json() for i in self.items]}

    @staticmethod
    def from_json(d: dict) -> "Crate":
        return Crate(id=d.get("id") or _new_id(), name=d.get("name") or "Untitled",
                     created_at=float(d.get("created_at") or 0.0),
                     updated_at=float(d.get("updated_at") or 0.0),
                     created_by=d.get("created_by") or LOCAL_AUTHOR,
                     deleted_at=d.get("deleted_at"),
                     items=[Item.from_json(x) for x in d.get("items") or []])


# ---------------------------------------------------------------- storage

def _board():
    """The board's store when it is mounted in this process; None means `.crates.json`."""
    try:
        import setline_local
    except Exception:            # noqa: BLE001 — no board, and the JSON store works
        return None
    return setline_local if setline_local.running() else None


def load(path: Path = CRATES_PATH, night: Optional[int] = None) -> list[Crate]:
    """Every crate. On the board: the ones `night` uses in its own order, or the
    whole shelf. On `.crates.json`: tombstones included — callers wanting the live
    ones use `live` either way."""
    board = _board() if path == CRATES_PATH else None
    if board is not None:
        return board.shelf(night)
    return load_json(path)


def load_json(path: Path = CRATES_PATH) -> list[Crate]:
    """`.crates.json` itself, tombstones included."""
    if not Path(path).exists():
        return []
    try:
        raw = json.loads(Path(path).read_text())
    except (json.JSONDecodeError, OSError):
        return []
    return [Crate.from_json(c) for c in raw.get("crates") or []]


def save(crates: Iterable[Crate], path: Path = CRATES_PATH) -> None:
    """Write the whole store. Small enough (hundreds of rows) that a rewrite is
    cheaper than anything incremental, and it keeps the file readable."""
    data = {"version": VERSION, "crates": [c.to_json() for c in crates]}
    Path(path).write_text(json.dumps(data, indent=1, ensure_ascii=False))


def live(crates: Iterable[Crate]) -> list[Crate]:
    """The crates that still exist, oldest first — a stable left-to-right order
    for the tab strip, so a crate doesn't move because you touched it. A night's
    crates keep the order that night gave them."""
    return sorted((c for c in crates if c.live),
                  key=lambda c: (c.position if c.position is not None else float("inf"), c.created_at))


# ---------------------------------------------------------------- mutations
#
# Each one loads, changes and saves. The file is small and the alternative — a
# long-lived in-memory copy — is a second source of truth that a background job
# or a second window can silently overwrite.

def _find(crates: list[Crate], crate_id: str) -> Optional[Crate]:
    return next((c for c in crates if c.id == crate_id), None)


def create(name: str, path: Path = CRATES_PATH, night: Optional[int] = None) -> Crate:
    """A new crate — on the board, used by `night` from the start when one is given."""
    name = (name or "").strip()[:MAX_NAME] or "Untitled"
    board = _board() if path == CRATES_PATH else None
    if board is not None:
        now = _now()
        return Crate(id=board.create(name, night), name=name, created_at=now, updated_at=now,
                     nights=[night] if night is not None else [])
    crates = load(path)
    now = _now()
    crate = Crate(id=_new_id(), name=name, created_at=now, updated_at=now)
    crates.append(crate)
    save(crates, path)
    return crate


def rename(crate_id: str, name: str, path: Path = CRATES_PATH) -> None:
    board = _board() if path == CRATES_PATH else None
    if board is not None:
        return board.rename(crate_id, (name or "").strip()[:MAX_NAME])
    crates = load(path)
    c = _find(crates, crate_id)
    if c is None:
        return
    c.name = (name or "").strip()[:MAX_NAME] or c.name
    c.updated_at = _now()
    save(crates, path)


def delete(crate_id: str, path: Path = CRATES_PATH) -> None:
    """Tombstone the crate. The tracks are untouched — they were never *in* it
    in any sense the filesystem knows about. On the board: off the shelf, and so
    off every night using it."""
    board = _board() if path == CRATES_PATH else None
    if board is not None:
        return board.delete(crate_id)
    crates = load(path)
    c = _find(crates, crate_id)
    if c is None or not c.live:
        return
    c.deleted_at = c.updated_at = _now()
    save(crates, path)


def add(crate_id: str, track_keys, path: Path = CRATES_PATH) -> int:
    """Put tracks in a crate. Returns how many were actually new.

    A track already in the crate is skipped rather than duplicated: a crate is
    a set, and the second copy would only ever be noise to both the reader and
    the suggester.
    """
    if isinstance(track_keys, str):
        track_keys = [track_keys]
    keys = [k for k in track_keys if k]
    if not keys:
        return 0
    board = _board() if path == CRATES_PATH else None
    if board is not None:
        return board.add(crate_id, keys)
    crates = load(path)
    c = _find(crates, crate_id)
    if c is None or not c.live:
        return 0
    now = _now()
    added = 0
    for key in keys:
        if c.holds(key):
            continue
        c.items.append(Item(id=_new_id(), track_key=key, added_at=now))
        added += 1
    if added:
        c.updated_at = now
        save(crates, path)
    return added


def remove(crate_id: str, track_keys, path: Path = CRATES_PATH) -> int:
    """Take tracks out, by track key. Tombstoned, not dropped — *what you took
    out* is as much a signal as what you left in, and a hard delete throws it
    away along with any hope of merging the change later."""
    if isinstance(track_keys, str):
        track_keys = [track_keys]
    wanted = {k for k in track_keys if k}
    if not wanted:
        return 0
    board = _board() if path == CRATES_PATH else None
    if board is not None:
        return board.remove(crate_id, list(wanted))
    crates = load(path)
    c = _find(crates, crate_id)
    if c is None:
        return 0
    now = _now()
    n = 0
    for item in c.items:
        if item.live and item.track_key in wanted:
            item.deleted_at = now
            n += 1
    if n:
        c.updated_at = now
        save(crates, path)
    return n


def move(from_id: str, to_id: str, track_keys, path: Path = CRATES_PATH) -> int:
    """Take out of one crate and put in another, as one write."""
    if from_id == to_id:
        return 0
    moved = add(to_id, track_keys, path)
    remove(from_id, track_keys, path)
    return moved


def attach(crate_id: str, night: int) -> bool:
    """A night starts using a crate off the shelf. The board only: a JSON crate
    belongs to no night because there are no nights to belong to."""
    board = _board()
    return board.attach(crate_id, night) if board is not None else False


def detach(crate_id: str, night: int) -> None:
    """A night stops using a crate; it stays on the shelf."""
    board = _board()
    if board is not None:
        board.detach(crate_id, night)


# ---------------------------------------------------------------- queries

def holding(crates: Iterable[Crate], track_key: str) -> list[Crate]:
    """Which live crates hold this track — what a row's chip reads from."""
    return [c for c in live(crates) if c.holds(track_key)]


def index(crates: Iterable[Crate]) -> dict[str, list[str]]:
    """track key -> the names of the live crates holding it.

    Built once per render and looked up per row; the alternative is a scan of
    every crate for every row on screen.
    """
    out: dict[str, list[str]] = {}
    for c in live(crates):
        for item in c.tracks:
            out.setdefault(item.track_key, []).append(c.name)
    return out


if __name__ == "__main__":       # a round trip in a temp store, touching nothing real
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "crates.json"
        a = create("Friday", p)
        b = create("Deep", p)
        print(f"created {[c.name for c in live(load(p))]}")

        print(f"added   {add(a.id, ['rb:1', 'rb:2', 'rb:3'], p)} to Friday")
        print(f"dupe    {add(a.id, 'rb:1', p)} (already there)")
        print(f"moved   {move(a.id, b.id, ['rb:3'], p)} to Deep")
        print(f"removed {remove(a.id, 'rb:2', p)} from Friday")

        crates = load(p)
        for c in live(crates):
            print(f"  {c.name:8s} {c.keys}")
        gone = [i for c in crates for i in c.items if not i.live]
        print(f"tombstones kept: {len(gone)}  (nothing is hard-deleted)")
        print(f"index: {index(crates)}")

        rename(a.id, "Friday night", p)
        delete(b.id, p)
        crates = load(p)
        print(f"after rename+delete: {[c.name for c in live(crates)]}")
        print(f"deleted crate still on disk: {any(not c.live for c in crates)}")
        ids = [c.id for c in crates] + [i.id for c in crates for i in c.items]
        print(f"all ids unique uuids: {len(ids) == len(set(ids))}, "
              f"len={len(ids[0])}")
