"""The one local cache file — SQLite, and only ever a cache.

`CLAUDE.md` has the rule this module exists to enforce: **the Comments tag is
the database.** What lives here is the narrow exception — data that is
*machine-derived, per-file and rebuildable*, and that a Comments string cannot
hold (a 1 280-dim vector) or should not hold (a duration the file header already
knows). Everything hand-made stays in its small JSON dotfile, because a file a
person can open and repair in a text editor is a better failure mode for
hand-made data than a binary DB.

Three rules, and they are what keep this from becoming a second source of truth:

1. **Deleting this file must never lose a fact.** It costs compute. Every reader
   copes with it being missing, empty, or stale.
2. **Every table is keyed on the file path and invalidated on `(size, mtime)`.**
   A re-download through `refetch.replace_in_place`, a tag write, a re-encode —
   all of them move at least one of the two, so a stale row can never be served.
3. **Never key on `library.track_key`.** That is `rekordbox_id or isrc or
   display`, which *changes* the moment a downloaded track is imported into
   rekordbox — keying a per-file cache on it orphans every row exactly when the
   library grows.

### Connections are per thread, on purpose

`sqlite3` connections belong to the thread that opened them, and this app is
threads all the way down: NiceGUI's event loop, `run.io_bound` workers, the
analysis job's own thread. A connection is therefore cached in thread-local
storage and opened lazily — reopening one per call would cost more than the file
read some of these caches exist to avoid (measured: ~0.5 ms to connect and
re-run the DDL, against a ~1.4 ms warm tag read).

The analysis *pool* is a different case: those are spawned processes, they get
their own thread-locals, and they must not write here at all — the parent is the
single writer (see `analysis._store_vector`).
"""
from __future__ import annotations

import sqlite3
import threading
from pathlib import Path
from typing import Optional

from config import ROOT

PATH = ROOT / ".cache.sqlite"

_local = threading.local()


def connect(schema: str) -> sqlite3.Connection:
    """A connection for this thread, with `schema` ensured once per thread.

    `schema` is the caller's own `CREATE TABLE IF NOT EXISTS …` — each cache
    owns its tables rather than this module knowing about all of them.
    """
    conn: Optional[sqlite3.Connection] = getattr(_local, "conn", None)
    if conn is None:
        conn = sqlite3.connect(PATH, timeout=30.0)
        # WAL so a long analysis pass writing rows never blocks the UI reading
        # them, and so a crash mid-pass leaves a consistent file.
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        _local.conn = conn
        _local.done = set()
    if schema not in _local.done:
        conn.executescript(schema)
        conn.commit()
        _local.done.add(schema)
    return conn


def close() -> None:
    """Drop this thread's connection (tests, and a cache that was deleted)."""
    conn = getattr(_local, "conn", None)
    if conn is not None:
        try:
            conn.close()
        finally:
            _local.conn = None
            _local.done = set()


def file_stamp(path) -> Optional[tuple[int, float]]:
    """`(size, mtime)` for the invalidation check, or None if unreadable."""
    try:
        st = Path(path).stat()
    except OSError:
        return None
    return st.st_size, st.st_mtime


def fresh(row_size: int, row_mtime: float, stamp: Optional[tuple]) -> bool:
    """Is a row still describing the file on disk?

    mtime is compared with a 1-second tolerance: some filesystems (and some of
    the copy paths files arrive here through) round it, and a false miss only
    costs one re-read while a false hit would serve a lie.
    """
    if stamp is None:
        return False
    return stamp[0] == row_size and abs(stamp[1] - row_mtime) < 1.0


def stats() -> dict:
    """Row counts per table plus the file size — for a sanity check or the UI."""
    if not PATH.exists():
        return {"tables": {}, "bytes": 0}
    conn = sqlite3.connect(PATH, timeout=30.0)
    try:
        names = [n for (n,) in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")]
        rows = {n: conn.execute(f"SELECT COUNT(*) FROM {n}").fetchone()[0]
                for n in names}
    finally:
        conn.close()
    return {"tables": rows, "bytes": PATH.stat().st_size}


if __name__ == "__main__":
    print(f"{PATH}: {stats()}")
