"""Where an arriving track is going — the question the flow never asked.

A track that has been acquired but has no destination is this app's most common
dead end. A thousand files landed in `Beatport/` over three days, in a folder
named after where they came *from*, and nothing ever asked which playlist they
belonged to; they are still there.

A destination is a rekordbox playlist name, and a track carries it by **sitting
in a folder of that name** under the download root. That isn't a new
representation — it is the one the sync path already uses (downloads land in
`<root>/<paired playlist>/`, and Incoming's export names the playlist after
the folder), extended to tracks that arrived by some other door.
Assigning a destination is therefore a file move, which has the nice property
of being visible in Finder and outliving this app entirely.

Only tracks rekordbox hasn't taken yet are ever moved. Moving a file rekordbox
knows about would break its link to it — which is precisely why the Incoming
population (not yet imported) is the only one this touches.

Leaf: names and paths in, names and paths out. No UI, no `runtime`.
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Iterable, Optional

from config import ROOT

# Folders named after the *door* a track came through rather than where it is
# going. A track sitting in one of these has no destination, however long it has
# been there. Matched case-insensitively.
DOORS = {"beatport", "youtube", "soundcloud", "imported", "spotify", "inbox",
         "downloads", "trackstudio"}

# Destinations the user has named that rekordbox doesn't have a playlist for
# yet — it will, the first time one of these is imported. Without this, a brand
# new playlist would read as "needs a destination" right after being chosen.
DECLARED_PATH = ROOT / ".destinations.json"

# Where a download judged redundant goes. A dotfolder, so `find_audio_files`
# and the batch scan skip it and the rows leave the lane — but still a folder
# in the download root, because "you already have this" is a fuzzy match and
# not a licence to delete audio. See `discard`.
DISCARD_DIRNAME = ".duplicates"


def safe(name: str) -> str:
    """A destination as a folder name. `/` is the one character a playlist may
    hold that a folder may not."""
    return name.strip().replace("/", "-")


def declared(path: Path = DECLARED_PATH) -> set[str]:
    if not path.exists():
        return set()
    try:
        return set(json.loads(path.read_text()))
    except (json.JSONDecodeError, OSError):
        return set()


def declare(name: str, path: Path = DECLARED_PATH) -> None:
    names = declared(path)
    names.add(safe(name))
    path.write_text(json.dumps(sorted(names), indent=0, ensure_ascii=False))


def forget(name: str, path: Path = DECLARED_PATH) -> None:
    """Drop a declaration — for when rekordbox has the playlist for real now."""
    names = declared(path)
    names.discard(safe(name))
    path.write_text(json.dumps(sorted(names), indent=0, ensure_ascii=False))


def known_names(rekordbox_index: dict, sources: Iterable = (),
                declared_names: Optional[set[str]] = None) -> set[str]:
    """Every name a track could be heading for, lowercased.

    Three feeds, because a destination shows up in three places in this setup
    and they are the same thing seen from different sides:

    - **rekordbox nodes, folders included.** A built set lands as a *folder*
      named for the bucket, holding "All" plus the arc leaves — so a folder by
      that name is the strongest evidence the bucket exists, not a reason to
      exclude it. (`sources._auto_pair` already pairs against folders for this
      reason.)
    - **synced sources.** The numbered buckets are curated as Spotify playlists
      first; one can be a destination before rekordbox has ever seen it.
    - **declared names**, for a bucket being started right now.
    """
    names = {node.name.strip().lower() for node in rekordbox_index.values()}
    names |= {s.rb_name.strip().lower() for s in sources if s.rb_name}
    names |= {n.strip().lower()
              for n in (declared() if declared_names is None else declared_names)}
    return names


def choices(rekordbox_index: dict, sources: Iterable = (),
            declared_names: Optional[set[str]] = None) -> list[str]:
    """The destinations to offer, in display form, best-first.

    Synced sources lead because those are the buckets a track is usually headed
    for — they are curated first and everything else follows from them. Then
    rekordbox's own nodes, alphabetically. Case-insensitively deduped, keeping
    the first spelling seen.
    """
    out: list[str] = []
    seen: set[str] = set()

    def add(name: str) -> None:
        name = (name or "").strip()
        if name and name.lower() not in seen:
            seen.add(name.lower())
            out.append(name)

    for s in sources:
        add(s.rb_name)
    for n in sorted(declared() if declared_names is None else declared_names):
        add(n)
    for node in sorted(rekordbox_index.values(), key=lambda n: n.name.lower()):
        add(node.name)
    return out


def of_folder(folder: str, known: set[str]) -> Optional[str]:
    """The destination a download folder stands for, or None if it is a door.

    Resolved by *name* rather than by a stored mapping, because that is what
    the export already does (`sources.rb_name_for_folder`) — one answer, not
    two that can disagree.
    """
    name = folder.strip()
    if name.lower() in DOORS:
        return None
    return name if name.lower() in known else None


def folder_for(destination: str, download_root: Path) -> Path:
    return Path(download_root) / safe(destination)


def assign(paths: Iterable[Path], destination: str, download_root: Path
           ) -> tuple[list[Path], list[tuple[Path, str]]]:
    """Move files into the destination's folder. Returns (moved, problems).

    A name already taken in the destination is reported rather than resolved:
    renaming to "… (2)" would manufacture the second copy at a second path that
    `dupes` exists to warn about, and rekordbox would import it as a separate
    track with its own play history.
    """
    dest = folder_for(destination, download_root)
    dest.mkdir(parents=True, exist_ok=True)
    moved: list[Path] = []
    problems: list[tuple[Path, str]] = []
    for src in paths:
        src = Path(src)
        if not src.exists():
            problems.append((src, "the file isn't there any more"))
            continue
        target = dest / src.name
        if target.exists():
            if target.resolve() == src.resolve():
                moved.append(target)      # already where it belongs
                continue
            problems.append((src, f"“{src.name}” is already in {dest.name}"))
            continue
        try:
            shutil.move(str(src), str(target))
        except OSError as e:
            problems.append((src, str(e)))
            continue
        moved.append(target)
    return moved, problems


def discard(paths: Iterable[Path], download_root: Path
            ) -> tuple[list[Path], list[tuple[Path, str]]]:
    """Move redundant downloads out of the lane. Returns (discarded, problems).

    **Nothing is deleted.** The files go to `<root>/.duplicates/`, a dotfolder
    so the batch scan skips it, and they can be dragged back out in Finder. The
    judgement behind this action is a fuzzy name match plus an agreeing
    duration (see `dupes`) — strong, but still inference, and inference is not
    grounds for destroying someone's audio. `refetch` takes the same line with
    `.broken_backup`.

    A clash keeps the newer file under a numbered name rather than being
    refused, which is the opposite of `assign`'s rule and right for the same
    reason: here a second copy is the *point*, nothing will import it, and
    refusing would strand the row in a lane it has already been judged out of.
    """
    dest = Path(download_root) / DISCARD_DIRNAME
    dest.mkdir(parents=True, exist_ok=True)
    gone: list[Path] = []
    problems: list[tuple[Path, str]] = []
    for src in paths:
        src = Path(src)
        if not src.exists():
            problems.append((src, "the file isn't there any more"))
            continue
        target = dest / src.name
        for i in range(2, 200):
            if not target.exists():
                break
            target = dest / f"{src.stem} ({i}){src.suffix}"
        else:
            problems.append((src, f"couldn't find a free name in {DISCARD_DIRNAME}"))
            continue
        try:
            shutil.move(str(src), str(target))
        except OSError as e:
            problems.append((src, str(e)))
            continue
        gone.append(target)
    return gone, problems


if __name__ == "__main__":        # real numbers off the live library
    import runtime
    from sources import SourceStore

    runtime._bootstrap()
    srcs = SourceStore().list()
    known = known_names(runtime.library.rekordbox_index, srcs)
    print(f"{len(known)} known destination names "
          f"({len(srcs)} synced sources, {len(declared())} declared)\n")
    for folder, tracks in runtime.incoming_batches.items():
        pending = [t for t in tracks if not t.in_rekordbox]
        if not pending:
            continue          # already in rekordbox — it has been through
        d = of_folder(folder, known)
        print(f"  {folder:28s} {len(pending):5d} waiting  →  {d or 'NEEDS A HOME'}")
