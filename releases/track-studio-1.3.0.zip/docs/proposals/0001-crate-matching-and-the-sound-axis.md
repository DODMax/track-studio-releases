# 0001 — What makes two tracks belong together

**Status:** Implemented (partly) · 2026-09-22 — §5 and §5b are built and
described in `CLAUDE.md`; §6 (a), (b), (d-display) and (e) are still open. A
gigs/transitions cache was considered alongside this and **rejected on
measurement** — see the end.
**Written for:** you, and whoever works on the matching next.

This note exists because "Fill this crate" proposed twelve tracks that had
nothing to do with the one track in the crate, and the honest reason was not a
bug in the ranking — it was that the app had almost nothing to rank *on*. What
follows is what DJs actually match on, what the field computes, what this
library actually carries (measured, not assumed), and what is needed to make the
feature worth trusting.

## 1. What the failure actually was

The crate held one track: **Wolfgang Gartner — Illmerica (Extended Mix)**, 129
bpm, 7A. It sits in a playlist you made called "1 · FrenchTouch", next to
Justice, Digitalism, Boys Noize, Mr. Oizo, SCNTST, Brodinski, Simian Mobile
Disco. Anyone can see what that crate is about.

What the app could see, before today:

| signal | coverage across 3 507 tracks |
|---|---|
| key | 99.9% |
| bpm | 99.9% |
| genre | **0.3%** (12 tracks) |
| energy / arousal / valence / danceability | 0.3–0.4% |
| texture (brightness, onset rate, …) | 0.03% (1 track) |

The scoring weighted key at 25%, bpm at 25%, and "vibe" at 10% — and the vibe
axis was reading fields that 99.7% of the library does not have. So the score
reduced to *key plus tempo*, and with 3 500 candidates there are hundreds of
tracks in 7A at 128–130. The twelve it offered were all "same key · steady bpm".
They were mixable strangers. That is not a ranking failure, it is an **input**
failure: the app was asked what belongs with this record and had no fact about
either record beyond its tempo and its key.

Worth stating plainly, because it applies to every idea below: **key and tempo
are mixability, not kinship.** They say two records can be beatmatched. They say
nothing about whether they belong in the same pile. Ranking a crate on key is
how you get big-room EDM next to French touch at the same tempo.

## 2. What DJs actually match on

From the DJ-facing literature (Mixed In Key's workflows, Lexicon's and Digital
DJ Tips' tagging guides, DJ TechTools' coding systems) the consensus list, in
rough order of how often it is named:

1. **Energy / set moment.** A 1–10 (or warm-up / builder / peak / closer) label.
   Two tracks at the same tempo can be a lounge record and a peak-time record;
   the rule of thumb is to mix within one energy step. This is the single most
   named tag, and it is *the* thing a crate is usually about ("Friday peak").
2. **Vocal or instrumental** (and: male/female, acapella intro). Named in the
   top three of every tagging guide, for a practical reason — a vocal record
   changes what you can do next, and two vocals in a row fight.
3. **Groove and drum signature.** How it moves: swung or straight, percussive or
   melodic, busy or sparse. This is what people mean by "same vibe" more often
   than genre is.
4. **Mood** — dark, uplifting, emotional, groovy, hypnotic.
5. **Tempo band**, and **key** for the transition itself (Camelot ±1, or the
   relative major/minor flip). Necessary for mixing, weak for belonging.
6. **Era, label, remixer, scene.** The crate digger's shortcuts: French touch
   *is* an era and a handful of labels, and "on Ed Banger around 2007" describes
   the crate better than any genre name does.

And the warning that matters most here, which the DJ press makes independently
of anything in this repo: **store genre labels are unreliable.** A swinging
90s-drums record and a clinical tool both end up filed "Minimal / Deep Tech"
because both sit near 130 bpm. Tools that match on sonic character rather than
on the label are the ones that surface cross-genre and cross-era matches.

We have a clean local demonstration of exactly that. Beatport files *Illmerica*
under **"Mainstage"**. Run the audio through the genre model this repo already
ships and Justice/Boys Noize comes back **"Electro"** — which is the right answer
for that crate, and "Mainstage" is not.

## 3. What the field computes

Music similarity in 2026 is not done with genre strings. It is done with
**pretrained audio embeddings and cosine similarity**: encode every track to a
vector, and "what goes with these" is the nearest neighbours of the seed set —
often just the centroid of 5–6 seed tracks. That is precisely the shape of the
"fill a crate" problem (the literature calls it *playlist continuation*).

Two things are worth knowing about the specific models:

- Essentia's **Discogs-EffNet** gives both an embedding and a 400-style Discogs
  classifier — a far finer taxonomy than Beatport's ~40 (it separates Electro,
  French House, Euro House, Bloghouse rather than lumping them under
  "Mainstage").
- Essentia also publishes **contrastive similarity embeddings** trained so that
  tracks from the same **artist**, **label**, or **release** land near each
  other. A "sounds like it came out on the same label" vector is, for this
  crate, exactly the French-touch signal — and it needs no tags at all.

(Models are CC BY-NC-SA 4.0 — fine for personal use, worth remembering if this
app ever ships commercially.)

## 4. What this app already has

This is the part worth knowing before planning anything, because the gap is much
smaller than it looks:

- **`models/` already contains** `discogs-effnet-bs64-1.pb` (the embedding
  model), `genre_discogs400-discogs-effnet-1.pb` (400 styles),
  `mtg_jamendo_moodtheme-…` (56 moods), `danceability-…`, `deam-…` (arousal +
  valence) and `voice_instrumental-msd-musicnn-1.pb`.
- **`energy.analyze` already computes the EffNet embedding** for every track it
  analyzes — it feeds the genre and mood heads with it, reads off the top label,
  and **throws the vector away**.
- **`voice_instrumental` is shipped and never run**, though vocal-vs-instrumental
  is a top-three DJ tag.
- The analysis is a cancellable background job with progress (`analysis.py`),
  already wired into the UI.
- Measured on this machine: **~3.5 s per track** for the full rich pass (1 s of
  one-time model loading). For 3 510 tracks that is **~3.4 hours, once**.
- 28 real gigs of play history are already reconstructed and learned from
  (`history.py`, `mixmodel.py`), and **117 hand-made rekordbox playlists** sit
  there unused by the matching.

So "what is needed" is mostly not new machinery. It is: *run the analysis, and
stop discarding the vector.*

## 5. What was done today

Genre, end to end, because it was the one style fact already sitting in the files
and read by nothing:

- `library.Track.genre`, filled from rekordbox's `Genre` **and** from the file's
  own tag (Beatport writes its store genre into every download). Coverage went
  **0.3% → 70%** (2 455 of 3 507) with no analysis pass at all.
- Note which source is the poorer one: rekordbox's XML has **no** Genre for 42%
  of the collection, including every track in "1 · FrenchTouch", where the files
  underneath carry one. A track that arrives through the rekordbox merge never
  has its file read, which is why a crate's own seed so often had no genre —
  `Library.hydrate_genres` now fixes that for the crate's tracks on demand
  (~18 ms per file cold, ~1.4 ms warm; a blanket pass would be 5–17 s to gain
  ~5%, so it is targeted).
- `genres.py` — genre *kinship* rather than string equality, because Beatport
  splits what DJs treat as one thing ("Techno (Peak Time / Driving)" vs "Hard
  Techno") and lumps what they don't. Same genre 100, same family 70,
  neighbouring family 45, unrelated 8, **unknown 22** — below a neighbour,
  because "we don't know what this is" must not outrank "we know it is the same
  thing".
- `mixmodel._kinship` — a separate scoring for belonging, against
  `_base_score`'s scoring for transitions: genre 42%, tempo **as a band** 18%
  (with half/double-time folded in at a discount), energy 12%, vibe 10%, texture
  8%, and key demoted to a **10% tie-break**. Coverage bites harder, so a
  track we know nothing about cannot win on tempo alone.
- The fill screen shows each proposal's genre, says what share of the library
  carries one, and says so plainly when the crate's own tracks carry none — in
  which case it admits it is ranking on tempo and key.

**Verdict, honestly: this fixed the mechanism, not the answer.** The ranking now
leads with style instead of key, which is right. But with Beatport's label as the
only style fact, a crate seeded on *Illmerica* gets "Mainstage, same as it" —
David Guetta, Hardwell, *Call on Me*. Correct by the data, wrong for the crate.
The vendor's one-word genre is the weakest form of style matching, exactly as the
DJ press says.

## 5b. The sound axis, closed end to end

Since the above was written, `(b)` and `(c)` below are built and proven:

- `energy.analyze` now **keeps** the embedding it always computed, and also
  captures the full 400-genre and 56-mood distributions and a `voice`
  probability from the `voice_instrumental` head that shipped unused in
  `models/`. The rule behind capturing all of it: the pass is ~3.4 hours, so
  anything not written now costs another 3.4 hours later.
- `mixmodel._kinship` gained a **sound** axis at weight 0.45 — the cosine
  between two tracks' embeddings — with genre demoted to 0.22 behind it.
- Verified on a real slice: with 180 tracks embedded, a crate seeded on
  *Illmerica* now puts **four of the nine FrenchTouch playlist mates in its top
  nine** (Justice .864, Boys Noize .843, deadmau5/Gartner .829, Digitalism .770)
  — none of which carries a genre tag at all. Before the sound axis, none of
  them appeared at all.
- The voice head works and discriminates as advertised: the one vocal track of
  three tested (Brodinski feat. Louisahhh) scored P(voice) 0.86 against 0.41 and
  0.43 for the instrumentals.
- The 400-style head is visibly better than the store's genre where it matters:
  Justice/Boys Noize reads "Electro .25 / Electro House .25 / House .20" against
  Beatport's "Mainstage".

What remains is `(a)` and `(b)`'s scale: the playlist signal, and running the
pass over the whole library.

## 6. What is needed to make this work properly

In order of value per unit of work:

**(a) The user's own playlists — free, today, no analysis.** You have 117
hand-made playlists; that is your own taxonomy, and it is better than any
vendor's. *Illmerica* sits in a 10-track playlist with nine tracks that are
literally the answer to "what belongs with this". Co-membership should be a
first-class signal, weighted by playlist size — a 10-track playlist is a
statement, a 147-track "All" is not. Same for the gig log: tracks played in the
same *night* (not just adjacent) are evidence of the same room.

**(b) Run the analyzer over the library — ~3.4 hours, once.** That turns energy,
mood, danceability, texture and a 400-style label from 0.3% coverage into ~100%,
for every crate, forever. Every axis the scoring already has becomes real. This
is the single highest-value action available and it needs no new code.

**(c) Keep the embedding.** While that pass runs, persist what it already
computes: the 1 280-dim EffNet vector (18 MB as float32 for the whole library,
9 MB as float16) and/or the 400-dim style-probability vector (5.6 MB). Then
`fill` becomes cosine similarity against the crate's members — the field-standard
answer, immune to what a store called the record. This needs a sidecar file and
is the **first deliberate exception to "the Comments tag is the database"**: a
1 280-dim vector is not human-readable and has no business in a Comments string.

**(d) Run the two heads already on disk but never used.** `voice_instrumental`
(a top-three DJ tag) and the mood themes, surfaced as tags you can see and filter
on, not only as scoring inputs.

**(e) Only then, if it still isn't sharp enough:** the contrastive
artist/label/release embeddings for "same scene" matching, and a text-queryable
model (CLAP / MuQ-MuLan) if you ever want to *ask* for "French touch electro with
a distorted saw bass" instead of seeding with a track.

One thing to keep doing regardless: the screen stays a screen with an **Add**
button. Measured by holding out one gig at a time, the ranking puts the track
actually played next in the top 5 of 3 493 candidates 4.9% of the time against
0.1% by chance — 34× better than chance and nowhere near good enough to write
into a crate by itself.

## 7. Ledger — what is built, what is open, what was rejected

**Built** (and now described in `CLAUDE.md`): the genre plumbing and
`genres.py`'s kinship table; `library.hydrate_genres`; `mixmodel._kinship` with
the sound axis leading at 0.45 and key demoted to a 0.05 tie-break;
`vectors.py` + `db.py` + the capture of the embedding, the 400 genre
probabilities, the 56 mood probabilities and `voice`; `tagcache.py`; the fill
screen's honesty lines; the dock's reserved room and the screen's back arrow.

**Open, in the order worth doing them:**

1. **Run the rich analysis pass** — ~3.4 h, once, writes Energy tags to ~3 400
   files. Takes every axis from 5% coverage to ~100%. Must be `--rich` / "Rich"
   on: a plain pass produces no embedding at all.
2. **The playlist signal** (§6 a) — free, no analysis, and the best evidence in
   the library. Not started.
3. **Surface what is already captured** — `voice` and the mood themes are stored
   and invisible; the 400-style label is better than the store's genre and is
   unused for display.
4. **(§6 e)** contrastive artist/label embeddings, and a text-queryable model,
   only if 1–3 still leave it blunt.

**Rejected — a gigs/transitions cache.** It was proposed to fix the 2.9 s the
first Fill or Build of a session paid. Measured, that cost was **tag reads**, and
`tagcache` took the mixmodel build from 1.93 s to 0.03 s on its own; what remains
is 0.37 s of reading rekordbox's play history — data that changes every time you
DJ. Caching that to save a third of a second would buy a staleness bug in exactly
the data the Histories page exists to show freshly. Do not re-propose it without
a new measurement.

A second argument for it — answering "when did I last play this, and with what"
per row — is a **feature request, not a cache**. If it is wanted, it is a UI
question first.

## Sources

- [Mixed In Key — Harmonic mixing guide](https://mixedinkey.com/harmonic-mixing-guide/)
  and [Energy level detection](https://mixedinkey.com/workflows/use-energy-level-detection/)
- [Lexicon — The 8 tags every serious DJ should use](https://www.lexicondj.com/blog/the-8-tags-every-serious-dj-should-be-using-energy-vibe-setlist-status-and-more)
- [Digital DJ Tips — Beyond genre: 5 tagging tricks for better DJ sets](https://www.digitaldjtips.com/beyond-genre-5-tagging-tricks-better-dj-sets/)
- [DJ TechTools — Develop a coding system for your library](https://djtechtools.com/amp/2016/08/15/breaking-the-code-coding-system-for-your-library/)
- [On The Rise DJ Academy — Ditching the genre tags: audio DNA for crate digging](https://ontheriseacademy.com/ditching-the-genre-tags-how-dig-deeper-uses-audio-dna-for-better-crate-digging/)
- [Essentia models](https://essentia.upf.edu/models.html) ·
  [TensorFlow models for Essentia](https://mtg.github.io/essentia-labs/news/tensorflow/2020/01/16/tensorflow-models-released/)
- [Interpretable and perceptually-aligned music similarity with pretrained embeddings](https://arxiv.org/html/2601.19109)
- [Controllable embedding transformation for mood-guided music retrieval](https://arxiv.org/html/2510.20759)
