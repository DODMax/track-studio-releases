# 0003 — Solo Setline and the shared one

**Status:** Accepted · 2026-10-09 (drafted 2026-09-22). All seven decisions below
were confirmed as written; 4 and 5 had been settled in conversation before.
**Written for:** you, and whoever builds the solo board.
**Follows:** [0002](0002-setline-becomes-the-set-builder.md), which assumed the board
simply moves here. It doesn't — it runs in two places at once, and this is what
that costs.

## In one sentence

The shared Setline at `setline.app` keeps existing for everyone without Track
Studio; Track Studio's Build page becomes **the same board, running locally
against the local library**; and the two are therefore *two live instances of one
schema* that replicate **through my draft, the one surface that can be made to
have a single writer** — which is a decision to take before the first line of the
solo board, not after.

## Why this can't be deferred

0002 costs a migration: the board moves here, the bridge is deleted. That is not
what is happening. The shared app stays, so what gets built is a **second
instance**, and every cheap decision taken while writing it — where a row's id
comes from, whether a delete leaves a trace, who a change is credited to —
either makes replication possible later or makes it a rewrite.

The four decisions in `crates.py` were taken on exactly this reasoning, a
feature ago, and they are the pattern: *"Multiplayer is coming back as local
instances syncing to a server, so four things are decided now because they cost
nothing and are brutal to retrofit."* This proposal extends that to the night
itself.

## The rule everything else follows

**One schema, two deployments.** The solo board is not a Track Studio-native set
builder that speaks Setline's API. It is `server/setline/` — the same models, the
same `apply_change`, the same Svelte app — configured for one person, one
SQLite file, one library of local files.

The alternative is two schemas and a translator between them, which is what
`setline_import.py` + `setline_push.py` already are: 431 lines whose entire job
is moving a set between two stores that disagree. 0002 deletes them precisely so
that they don't get rebuilt in a bigger form. If solo and shared are one schema,
**sync is replication**; if they are two, sync is translation, forever, with a
new edge case each time either side learns a field.

Everything below assumes the rule. If the rule is rejected, most of it changes.

## What each instance knows that the other cannot

| | Solo (Track Studio) | Shared (setline.app) |
|---|---|---|
| The audio | **The files on disk**, played through `/media` | Beatport HLS, and uploads |
| The collection | rekordbox: ids, playlists, 28 gigs of play history | Nothing — it has never seen your library |
| The ranking | `mixmodel.fill` / `next_tracks`, the embeddings (`vectors`), energy, texture | Tempo band + mixable keys (`tools.find_by_fit`) |
| The people | One author, `LOCAL_AUTHOR = "me"` | Members, presence, votes, comments, credit per row |
| Availability | Always — a venue's wifi is irrelevant | Requires the internet |
| Who else sees it | Nobody | Whoever holds the invite link |

Two consequences worth stating before any mechanism:

1. **A filesystem path must never cross to the server.** Not because it would
   break — because it is someone's disk, published to everyone holding a link.
   The same goes for rekordbox ids, which mean nothing off this machine.
2. **The local instance is the better one for building a set, and the shared one
   is the only one for building it *together*.** Neither is a subset of the
   other, which is why this is replication rather than one side winning.

## What already fits

Measured by reading `~/Code/setline` today, not assumed:

| Fact | Why it matters here |
|---|---|
| **Board rows already carry client-minted ids.** `web/src/lib/board/model.ts` mints `uid()` — 20 hex chars off `crypto.randomUUID` — and `api_board` accepts a client-chosen id of 8–40 chars on every new row | Moments, entries, lanes, crates, crate items, comments and flags are *already* globally unique across instances. The hardest retrofit is done and nobody did it for this reason |
| **There is exactly one door.** `api_board.apply_change` takes the set lock, applies, bumps `sets.version`, writes the activity line and publishes to the hub — and the HTTP API, the MCP tools, the in-app assistant, uploads, the playlist import and Track Studio's push all go through it | An op log costs *one function*, not an audit of 825 lines. This is the single most important fact in this document |
| **`sets.version` already increments on every change** | A watermark per peer already exists in everything but name |
| **A snapshot format already exists and nothing reads it back.** `board.snapshot_json` (`setline-snapshot` v1) carries every moment including parked ones, every draft, crates, the catalog, votes, comments, flags and the activity log, by id, with a `members` list — written, in its own words, "so a set can be put back one day" | That day is this proposal. It is the fallback for a peer too far behind to replay ops |
| **Lanes exist**: `models.Lane`, "someone's draft of the same night: the set's moments, their own running order" | The merge-free landing zone for offline edits — see below. This is the piece that makes the whole thing tractable |
| **The identity ladder is already built, twice.** `api_import.SentTrack` sends Beatport id → ISRC → strict artist/title; `matching.py` is a port of this repo's `match.py`, deliberately kept in step | Catalog reconciliation does not start from zero |
| **A local, invite-free identity already exists** (`auth.DEV_MEMBERS`) | Solo mode has a precedent in the code rather than needing a new auth path |

## What does not fit yet

| Fact | Consequence |
|---|---|
| **`tracks.id`, `sets.id`, `votes.id`, `activity.id` are server-minted integers** | Two instances mint `tracks.id = 412` for two different records. Tracks have natural keys (`beatport_id` unique, `isrc`); **sets have none** |
| **Nothing is tombstoned.** Every delete is a real delete with `ondelete="CASCADE"` | A row that is gone is indistinguishable from one the peer hasn't seen — the exact failure `crates.py` refuses to have |
| **Most rows have no `updated_at`.** `Moment`, `Entry`, `Crate`, `CrateItem` carry a creation time only; `entries.position` changes leave no timestamp | Row-diffing with last-writer-wins is not available without adding columns to six tables. An op log avoids needing them |
| **Crates belong to a set** (`Crate.set_id`, `ondelete=CASCADE`); Track Studio's are library-wide and belong to no night | Looked like the one genuine semantic collision; it wasn't — both readings are right and the relation is many-to-many (§8). It is still a migration on the shared side |
| **Track Studio runs Python 3.9.6; Setline requires ≥3.13** and uses `str \| None` annotations that SQLAlchemy 2 resolves at mapper configuration | "Mount Setline's API into NiceGUI's app" (0002) is blocked until Track Studio moves interpreter. **The good news, measured:** the installed `essentia-tensorflow 2.1b6.dev1389` is the exact release that ships cp313 arm64 wheels, so the analysis pipeline needs no version change. The blocker is our own `numpy<2` pin — numpy 1.26.4 has no cp313 wheel, and essentia's own metadata asks only for `numpy>=1.25`. So: a pin to lift and a pass to re-verify, not a rebuild |
| **Postgres-only SQL at runtime**, which a grep of models and migrations can't see: `board.py:152` takes `pg_advisory_xact_lock` (fails outright on SQLite), and `board.py:125/135` use `with_for_update()`, which SQLAlchemy **silently drops** on SQLite | The second one matters more. It is the set-row lock `apply_change` depends on. On SQLite it stops locking without saying so, and two writers then get `SQLITE_BUSY` instead of queueing. It needs a portable replacement (`BEGIN IMMEDIATE`), not a shrug |
| **`live.py` holds connections in one process**, which is why production runs a single uvicorn worker | Irrelevant locally, but it means the solo instance cannot be a second worker of the shared one — they really are separate deployments |

## The design

### 1. The sync unit is a night, not a database

A solo instance holds nights that never leave it. Replication is opt-in per set:
**Share** publishes a local night to the server; **Follow** pulls a shared one
down. Everything else stays where it was made. The shared set is authoritative
while it is shared — it is the one both people can reach — and the solo instance
keeps a replica it can edit offline.

This also answers the privacy question by construction: nothing crosses until
you press Share, and what crosses is a night, not a library.

### 2. The op log, written at the one door

Add one table, written in `apply_change` and nowhere else:

```
changes(set_uid, seq, op, payload json, actor_uid, at, origin_instance)
```

`apply_change` already has everything it needs at that point: the validated
`Apply`, the member, the set under lock, and the version it is about to bump.
Recording a semantic op there costs a few lines; reconstructing the same
information afterwards from `Activity` would not work, because activity lines are
*display text in parts* (`{"b": name}`), not operations.

Sync is then: "give me every op on set X after seq N", applied **through
`apply_change` on the receiving side** rather than written straight to its tables.
That is what keeps each instance's invariants its own — the uniqueness
constraints, the archived-set refusal, the credit rules all still run.

**Refusal is a first-class outcome, not an error to swallow.** Replaying "add
track T to lane L" against a state where it is already there violates
`uq_entries_set_lane_track`; replaying "move entry E" when E was removed hits a
missing row. Those are conflicts, and they surface to the person as conflicts —
they are not dropped, and they are not resolved by a heuristic. Per the house
rule that an inexact warning is worse than none.

**Ops make tombstones unnecessary**, which is worth saying plainly because
`crates.py` took the opposite decision: a tombstone is a way to diff two row sets
without a history, and with a history the delete *is* a row in it. The tombstone
instinct was right and the op log subsumes it.

### 3. Order does not merge — the draft is the sync surface

This is the part most likely to be got wrong by being clever.

A set is an ordered list. Two people reordering the same night offline produce
interleavings that no automatic rule resolves correctly: positions are integers
rewritten on every move, and `board.py` re-sorts by `(moment, position)` on
read. Any merge invents a running order neither person chose — for a *set*,
where the order is the entire artefact.

So nothing merges. Instead the thing that syncs is chosen so that it **cannot**
have two writers:

> **My draft is the sync surface. The set's own timeline is edited where everyone
> can see it happen.**

Setline already has the concept and already enforces one of these per person:
`POST /lanes` is documented as *"Your own draft, started the first time you ask
for one"*, `b.lane_for(session, s, who)` returns that person's lane, and the
timeline draws each under the set in its owner's colour. A draft is even a
capable workspace rather than a bare list — a whole section can be parked in one
(`moments.lane_id`), taking its tracks with it, invisible to everyone else.

**Sync is therefore two-way, on that lane only.** Edit your draft in the browser
at work, edit it on the desktop at home, and both ends converge — because at any
moment only one writer exists for those rows.

### 3a. The cost: only the owner may edit a draft

This is a **change to the shared product**, and it reverses a decision that was
taken on purpose. Setline's own brief says: *"Editing anyone's draft stays
allowed; it just can't be done by mistake (someone did, 2026-09-17)."* When
someone edited another person's draft by accident the fix was to make it hard to
do by mistake — the colour tint, the owner's stripe, the filled badge — not to
forbid it.

The new argument that didn't exist then: **a draft a second person can change is
a draft that cannot be a single-writer replica.** One other editor, once, and
every conflict this design avoids comes back.

What is lost is narrow, and worth stating rather than waving away: someone
tidying your run for you, or pulling a track out of your draft on your behalf.
What survives untouched is reading it and **carrying cards off it** — the
machinery for taking a track from one timeline to another already exists and
already keeps the finder's name (`b.place(credit=…)`, `from_entry`, and the
server only honours the credit for that same track on another timeline of the
same set). So a b2b partner can still *take* from your draft; they just can't
*change* it.

One thing this rule closes for free: `DELETE /lanes/{id}` becomes single-writer
too, so nobody can delete the draft your offline instance is busy editing.

### 3b. Several drafts locally, one of them shared

Your question of whether local drafts should exist at all answers itself once
they are the conflict mechanism:

- **Locally: as many as you like, all yours.** Two ideas for the same Friday is
  a normal way to work, and it costs nothing — this is one person's machine.
- **Shared: one of them at a time is "my draft" on that night.** The shared board
  keeps exactly the rule and the layout it has today, one line per person, and
  nothing about the multiplayer UI changes.

**And when both ends did move, the loser forks instead of merging.** If the
online lane advanced while the desktop was offline, the desktop's version does
not merge and does not vanish — it becomes another of my local drafts, named for
where it came from. Then I look at the two and pick, which is the only honest
resolution when both were mine and both were deliberate.

Note what this restores: `drafts.py` — named drafts plus a session slot, which
0002 deletes — turns out to have been the right idea in the wrong storage. The
concept survives as lanes; the JSON files don't.

### 3c. What may be done offline to a *shared* night

Not everything needs to wait for a connection, and the line isn't "your draft
only" — it is **whether the operation can land out of order without inventing
something**:

| Offline, on a shared night | Why |
|---|---|
| Anything at all to **my own draft** | Single writer, by §3a |
| **Promoting a track into the set** (`/lanes/{id}/send`) | It appends at the end of the moment it was drafted into. An append replays cleanly whatever else arrived first |
| Adding to crates, voting, commenting, flagging | Order-free (§4) |
| **Re-ordering or removing from the set itself** | Waits for a connection. This is the one genuinely multi-writer surface, and re-ordering a shared night from a train is also a conversation you didn't have |

A night that was **never shared** has none of these restrictions: it is yours,
it has no lanes unless you want them, and you edit the set directly.

### 3d. One case that has no tidy answer

A moment can be deleted or renamed online while your offline draft is filling
it. Setline already refuses to remove a moment holding someone's draft tracks —
but your offline tracks aren't visible to that guard, so the refusal can't fire.

On sync those entries reference a moment that no longer exists. They must not be
dropped. The least-bad resolution uses machinery that already exists: **re-create
the moment parked in my draft** (`moments.lane_id`), holding its tracks, exactly
as parking a section does — out of the night, visible to nobody else, waiting for
me to decide. It is not elegant. It is honest, and it loses nothing.

### 4. What does merge automatically

Everything order-free, which is more than it sounds:

| Rows | Rule |
|---|---|
| Crate membership | Union of adds, minus removes, by op order. A crate is a set, and `crate_items` has no position |
| Which crates a night uses | Same: a set of attachments (§8). Their order within the night is last-writer-wins |
| Votes | Last-writer-wins on `updated_at`, which they already have, keyed by `(set, track, member)` |
| Comments, flags | Append; a delete is an op. A flag is already one-per-join by constraint |
| Moment name / note / colour / target | Last-writer-wins per field |
| The catalog | Reconciled by natural key — see below |

### 5. What never crosses

Local file paths, rekordbox ids, energy tags, embeddings and everything in
`.cache.sqlite`; assistant conversations and usage (already excluded from the
snapshot, and private per member); uploaded audio (a file on a disk — the
snapshot already says so); presence and cursors, which are not state.

### 6. Who gets the credit

The solo instance acts as **you**, not as a robot. `api_import` currently credits
a pseudo-member `TRACK_STUDIO ("Track Studio")` with an optional `by` name, and
for a bridge that was right. For a replica it is not: every pick you made at home
would land in the activity rail under a tool's name, and `Entry.added_by` is how
a b2b remembers whose record it was.

So linking an instance to a shared set stores *which member it acts as*, and ops
carry that `actor_uid`. The instance is the transport; the person is the author.

### 7. When a peer is too far behind

Ops cannot be kept forever. Beyond the retention window — or on the very first
Follow — the peer takes `board.snapshot_json` and starts from there. The format
exists, it is versioned, and the only thing missing is a reader. Writing that
reader is also what makes the format honest: a snapshot nothing has ever restored
is a guess about what a restore needs.

### 8. Crates are library-wide, and a night uses the ones you attach

Both readings were right, which is why this looked like a collision. A crate is
a pile you keep — "Friday maybe", built while digging, belonging to no night. And
in set building a crate is a **preselection for this night**, which is the whole
point: not having to face the library. Those are the same object in two
relations, so:

> **A crate belongs to the shelf. A night uses the crates attached to it.
> Many-to-many.**

`Crate.set_id` becomes an attachment table — `set_crates(set_id, crate_id,
position, added_by, added_at)` — and three things move with it:

- **`position` moves to the attachment.** It orders the tab strip *within this
  night*, which is where it always meant something; a crate on the shelf has no
  inherent place.
- **Detach and delete become different verbs.** Today deleting is the only
  removal. Now: detach means this night stops using it, delete means it leaves
  the shelf and therefore every night. The confirm has to say which, and delete
  probably narrows to the owner — a crate someone else's night is using is not
  yours to bin.
- **The set's `CASCADE` stops deleting crates.** Deleting or archiving a night
  removes its *attachments*. Migration detail, easy to get wrong once.

**This is also the privacy boundary, for free.** Locally the shelf is your whole
library's worth of piles. A shared night only ever sees the crates you attached
to it, and **sync ships attached crates only** — an unattached crate never leaves
the machine. Nothing needs a rule for that; it falls out of the relation.

**Attached crates stay multi-writer, unlike drafts, and the contrast is the
reason.** A draft is single-writer because its order cannot merge (§3). Crate
membership is a set — union of adds minus removes (§4) — so it merges, and
therefore everyone piling candidates into a night's crate can keep working
exactly as it does today. Order is what forces ownership; membership doesn't.

Two consequences of that, both fine, both worth having said out loud:

- A track someone else drops into an attached crate lands on **your** shelf.
  That is a record you don't own — which is already a thing this app has words
  for: it is a "want it" row in the Incoming lane, and the sourcing pipeline
  takes it from there.
- A crate item crosses the wire as a track, so it takes the identity ladder with
  it (below). `crates.Item.track_key` is `rekordbox_id or isrc or display` and
  **must not** go up: a rekordbox id means nothing off this machine. Locally the
  item keeps pointing at the library; on the wire it is Beatport id → ISRC →
  artist/title, like everything else.

One thing this buys immediately: **`pages/crate_bar.py` survives 0002.** The dock
is already the library-wide shelf, already in Setline's CSS, and already the
place you notice a track and pile it. It becomes where you attach a crate to the
night, and "Fill this crate" keeps working against it unchanged.

### 8a. The dock follows the night

Once a night has crates attached, the shelf you see while digging should be that
night's. You attach them on the board; you then go to the Library to dig, and
**the selection comes with you** — so the piles under every page are the piles
this Friday is being built out of. That is the whole point of a preselection, and
it is lost if the dock keeps showing sixty crates from every night you ever
planned.

So the dock is scoped to the loaded night, with a **toggle: this night · all
crates**. Defaults: the night's when one is open, the whole shelf when none is —
which also covers pure digging, where you are filling piles for no particular
evening yet.

Two things that follow:

- **Attaching has to be possible from the Library, not only from the board.**
  You start a new pile mid-dig because you just found the record that defines
  tonight; making you go to the board to attach it is exactly the kind of trip
  this dock exists to avoid. A crate that isn't attached still works — it just
  doesn't appear in the night's tab strip.
- **"The loaded night" lives in `runtime`.** A NiceGUI page body re-runs from
  scratch on every visit, which is precisely why `build_state` and
  `setline_state` live there today; the open night replaces them, and the dock
  reads it the same way it reads the crates.

**And the architectural edge, which is the reason this is in here rather than in
a UI note:** the dock is a Track Studio surface that changes a night's state —
attaching a crate, and adding a track to an attached one. **It must go through
`apply_change`, never the tables.** That is the one door (§2): bypass it and the
op log gets holes, the shared side never learns what happened, and the activity
rail is silently wrong. The rule generalises past the dock — *every* Track Studio
surface that touches a night goes through the same door, however local it feels.

## The catalog is the hard half

Setline's `tracks` is a shared catalog keyed on an autoincrement id, and the two
instances will mint different ids for the same record. The join key is the ladder
both sides already implement: **`beatport_id` → `isrc` → strict artist/title**
(`matching.py` here, `match.record_key` / `dupes.Index` there), falling back to a
`uid` on the row for a track that has no natural key at all — a manual entry, an
upload, a promo.

Two directions, two different problems:

**Going up**, a local track may be a file with no Beatport id and no ISRC.
Setline already models that: `source="manual"`, with `link` or an uploaded
`file`. It goes up as metadata and a waveform, and the audio only if you upload
it deliberately.

**Coming down**, a track someone else added is *a record you do not own*. Track
Studio already has the vocabulary for exactly this, and it is not a new concept:

> want it → get it → know where it goes → rekordbox has it

A followed set's unmatched tracks are **"want it"** rows in the Incoming lane
(`incoming.from_gap` is already shaped for "a source's computed gap"). The
sourcing pipeline — Beatport id → download → destination → export — then runs
unchanged. The board does not need a downloader; it needs to say what is missing,
which is a thing this app was already built to answer.

## What this costs

| Side | Work |
|---|---|
| Setline | `uid` on `sets` and `tracks` (1 migration) · the `changes` table + ~20 lines in `apply_change` · a sync endpoint pair (pull since seq, push ops) · a snapshot *reader* · **lane edits restricted to the owner** (§3a — a rule in `apply_change`, plus the UI telling you why someone else's draft is read-only) · **crates off `set_id` onto a `set_crates` attachment table** (§8), with detach as a verb distinct from delete |
| Track Studio | Python 3.9 → 3.13 (lift `numpy<2`, re-verify the analysis pass) · the setline package on the path (how: open question) · a local config (SQLite, one member, no invite) · `.crates.json` → the crate tables, with the dock (`pages/crate_bar.py`) as the shelf, scoped to the open night with a this-night/all toggle, and attaching possible from any page (§8a) · the followed-set gap feeding `incoming` |
| Deleted, per 0002 | `setline_import.py` (312), `setline_push.py` (119), the `.setline.json` format, `SETLINE_URL` / `SETLINE_TOKEN` / `SETLINE_NAME` |

Note what is *not* on the list: a merge engine, a CRDT, a conflict-resolution UI
beyond "here is a lane, promote it if you like". That is the point of §3.

## Decide these before the first line of the solo board

Everything else can be got wrong and fixed. These cannot:

1. **One schema, two deployments** — or a Track Studio-native builder that talks
   Setline's API? Everything above assumes the first.
2. **Global ids on `sets` and `tracks`, now.** One migration today; an
   unmergeable pile of integers later.
3. **Write the op log from day one**, even though nothing reads it for months.
   History cannot be reconstructed retroactively — `Activity` proves it, being
   the one record that exists and is the wrong shape.
4. **Crates are library-wide and attach to a night, many-to-many** (§8).
   Decided in this round. It changes the *shared* product too — a crate you keep
   across nights, a shelf that outlives them — and it replaces `Crate.set_id`
   with an attachment table, which is a migration nobody wants to do twice.
5. **Only the owner edits a draft** (§3a). Decided in this round, and recorded
   here because it *reverses a dated decision* in Setline's own brief rather than
   filling a gap in it: editing anyone's draft was deliberately kept after the
   2026-09-17 mistake, and the fix was to make it hard to do by accident. If the
   reversal is wrong, the whole sync surface has to move somewhere else, so it is
   the one to be sure about.
6. **Python 3.13 for Track Studio**, which 0002 needs anyway and nothing in the
   analysis stack blocks.
7. **A linked instance acts as a member, not as a tool.**

## The road to done

Each phase ends in a gate, meaning something you can check rather than a feeling
that it's done. Phases 2 and 3 can overlap. Everything else is in order because
each phase needs the one before it.

**0 — Paperwork.** Confirm decisions 1, 2, 3, 6 and 7 above (4 and 5 were settled
in conversation) → 0003 **Accepted**. Fix `CLAUDE.md`'s *"Build is not on the way
out"*, which contradicts both proposals. Commit the folder.

**1 — Spikes: answers, not arguments.**
- Setline's own suite on SQLite: `SETLINE_TEST_DATABASE_URL=sqlite:///…` turns
  its 19 test files into the compatibility test. Two failures are already known
  (the advisory lock and `FOR UPDATE`, above).
- Track Studio on 3.13 in a scratch venv: lift `numpy<2`, run the four
  self-tests, re-analyze ten tracks and compare their embeddings with the 3.9
  ones (cosine ≈ 1.0, or we know why not).
- The mount: Setline's app inside NiceGUI's, `web/dist` at `/board`, one slice:
  a crate from `crates.py` shows up on the board. This settles in-process vs a
  second process, and how the package arrives.
- *Gate:* each one passes or has a written fallback.

**2 — Shared Setline, schema first.** This ships to the online app **before any
solo code**, because every migration done later has to move more live data.
`uid` on `sets` and `tracks` · the `changes` table written in `apply_change`, so
history starts building up now, with nothing reading it yet · crates onto the
shelf (`set_crates`, detach ≠ delete; this is useful online on its own) ·
owner-only drafts · the lock made portable.
- *Gate:* live online, tests green on both Postgres and SQLite.

**3 — Track Studio on 3.13, shipped.** The spike's result, made real, plus the
part the spike doesn't cover, which is getting it onto installed copies.
`install.sh` builds on the Mac's own `python3`, which is 3.9, so it has to fetch
3.13 itself (uv can). **The self-updater can't make this jump.** It
pip-installs into the existing venv, numpy ≥2 has no cp39 wheel, and the update
rolls back. Either `apply_update` learns to rebuild the venv when the interpreter
changes, or every install gets reinstalled by hand once. Pick one.
- *Gate:* an installed copy reaches 3.13 without anyone touching it, or the
  one-time reinstall is written down.

**4 — Solo Setline, no sync yet.**
- Wiring: the package, a local config (its own SQLite file at `ROOT`, not
  `.cache.sqlite`, because a set is a fact and not a cache), one member, no
  invite.
- **The catalog bridge**, the one piece no proposal has designed yet. Library
  tracks enter Setline's `tracks` table when they are first used. A local-only
  table maps them to `track_key`/path and never syncs. Audio plays from `/media`
  as a `kind: 'file'` stream, which the board already understands.
- Crates come over from `.crates.json`. The dock reads and writes through
  `apply_change`, is scoped to the open night with the toggle, and the open night
  lives in `runtime` (§8a).
- The learned model on the board: `fill` and `next_tracks` as proposals with an
  Add button. Analysis on the cards.
- rekordbox export from the board. Decide which of the two survives. Track
  Studio's is the likely one, since it writes the one XML rekordbox is pointed at.
- Several local drafts.
- *Gate:* a real night built on the board, exported and played. **Then** delete
  the Build page, `drafts.py`, the block half of `microsets.py` (split the module
  first) and the `/microsets` and `/builder` redirects → 0002 **Implemented**.
  **Keep `setline_import` / `setline_push`.** Until phase 5 they are the only way
  a set moves between the two instances.

**5 — Sync.**
- A per-member device credential for a linked instance. The invite cookie isn't
  one, and the instance acts as a member (§6).
- Pull and push endpoints for ops, replayed through `apply_change`, with
  refusals shown as conflicts.
- The snapshot reader, used for the first Follow and for any peer too far behind.
- Share (publish a local night) and Follow (pull a shared one).
- Catalog reconciliation over the wire: Beatport id, then ISRC, then
  artist/title. Local-only tracks go up as `manual`. Paths and rekordbox ids
  never cross.
- My draft syncs both ways, divergence forks into a local draft, and one draft
  is designated as the shared one.
- The offline rules (§3c) and the parked-moment rescue (§3d).
- Attached crates sync. Tracks you don't own arrive as "want it" rows in
  Incoming. A retention window for ops.
- *Gate:* one night, edited in the browser and on the desktop on the same day,
  converges or forks visibly. **Then** delete `setline_import.py`,
  `setline_push.py`, `.setline.json`, the `SETLINE_*` env and the `/download`
  route → 0003 **Implemented**.

**6 — Close out.** Both repos' `CLAUDE.md` describe what is now true, and a
release goes out.

**Alongside, off the critical path, and they're what makes the board worth
opening:**
- The rich pass (~3.4 h, no decisions needed). Run it now. It doubles as the
  baseline for phase 1's 3.9-vs-3.13 embedding check.
- The playlist signal, from 0001 (a).
- Voice, mood and the 400-style label on screen, from 0001 (d). Phase 4's cards
  need them anyway.
- Replace-in-rekordbox and the export handoff, tried on real files.

## Where it stands (2026-10-09)

Built in one go, phases 0–4, in both repos (uncommitted when this was written):

- **0 — Paperwork.** Accepted; `CLAUDE.md`'s "Build is not on the way out" fixed.
- **1 — Spikes, all three passed.** Setline's suite on SQLite: 171 of 172 at first — the
  known advisory lock and `FOR UPDATE`, plus three migrations that alter constraints in place
  and a timestamp resolution that tied two crate items — then 172. Track Studio on 3.13: the
  four self-tests byte-identical to 3.9, ten tracks re-analysed at embedding cosine 1.00000.
  The mount: in-process works; Setline's app inside NiceGUI's, NiceGUI 3.6 → 3.18 and
  Starlette 0.49 → 1.7 with no change to Track Studio's pages.
- **2 — Shared schema first.** Migration 0014 (`uid` on sets and tracks, `changes`, crates
  onto `set_crates`), the log written at `apply_change`, owner-only drafts in `board.own_draft`
  and on the board's UI, the lock made portable in `db.py`. Tested upgrade, downgrade and
  re-upgrade on a copy of the dev database and on a populated SQLite file. **Ships to the
  online app when it is committed and deployed** — nothing has been pushed.
- **3 — 3.13.** Picked: *the one-time reinstall, written down*. `install.sh` fetches 3.13 and
  rebuilds the venv; `requirements.txt` markers keep a 3.9 copy's pip step a no-op, so the
  updater can't fail there.
- **4 — Solo Setline.** `setline_local.py` + Setline's `local.py` / `api_local.py`; the
  catalog bridge (`ts_library_links`), crates from `.crates.json`, the dock as the shelf scoped
  to the open night, `fill` / `next_tracks` on the board, the export through Track Studio's
  XML, several local drafts. **The gate is still yours**: a real night built on the board,
  exported and played. Build, `drafts.py` and the block half of `microsets.py` stay until then.
- **5 — Sync.** Not started.

Decisions taken while building, which the sections above didn't settle:

- **The log records what was asked, not a hand-written op per endpoint.** A ContextVar set
  where requests enter (the HTTP middleware: method, route template, path params, JSON body;
  the tool wrapper: tool name and arguments) and read at `apply_change`. It is replayable
  input, and it cost one middleware and one decorator. Ids in it — and a local board's
  library keys, which are paths — are translated by the sender when ops cross.
- **A crate change reaches every night using it**: the door collects the crates a change
  touched as the session flushes, and each other night gets a version, an activity line and
  a log row of its own. `apply_to_shelf` is the same door for a change made from no night.
- **Your shelf, online**: crates you started, plus crates on any night you hold a link to. A
  crate leaves its night only when someone on both attaches it — a link is still a night.
- **Delete vs detach**: deleting a crate only this night uses stays anyone's call, as today;
  one other nights use too is its maker's alone.
- **SQLite migrations run the real chain**, not `create_all` + stamp: three historical
  migrations wrapped in batch mode (a no-op on Postgres), `now()` defaults made portable.
- **One build of the front end for both deployments**: relative asset URLs, and the server
  writes `<base href>` naming where it is mounted; `web/src/lib/base.ts` reads it.
- **The assistant is off locally** until asked for (your key, your tokens).

## Open questions

- *(Half answered: on this machine it's `SETLINE_HOME` on `sys.path`, and `vendor/setline`
  is looked for first so a release can carry it — the release step that copies it isn't built.)*
  How does the setline package reach Track Studio's venv — git submodule, path
  install, or vendored at release? It has to land in `release.payload_files`
  (what git tracks *or would track*), and the self-updater unpacks over an
  install, so a second repo inside the payload needs a rule of its own.
- *(Answered: inside the NiceGUI process, mounted at `/board` — it held.)* One uvicorn inside the NiceGUI process, or a second local process? The window
  is already separate from the server (`window.py`), so a third is not unthinkable
  — but it is a third thing to start, stop and update.
- Does the solo board ever talk to the remote API directly when online, or always
  to the local one with sync behind it? (Local-first is assumed above: the wifi
  at a venue is not a dependency a set builder may have.)
- **Which local draft is "my draft" on a shared night** (§3b) — one you designate,
  or whichever synced last? And when you point the shared lane at a different one,
  does it replace the old contents wholesale? That reads as a large, sudden change
  in everyone else's activity rail, for what was privately just "the other idea".
- Does a b2b partner see *why* your draft is read-only — "linked to a desktop" —
  or only that it is? The second is simpler and invites "why can't I fix this".
- What does Follow do about a night that gets archived on the server?
- Retention: how long are ops kept before a peer must take a snapshot?
- Does the solo instance need `live.py` at all — or is a second Track Studio
  window on the same Mac a case worth supporting? (An iPad on the couch against
  the Mac's library is the same question wearing better clothes.)
- Does the in-app assistant run locally, where an Anthropic key and a per-set
  token cost are the user's own? (0002 left this open; sync doesn't settle it.)

## What this is not

Not a general sync engine, not offline-first multiplayer, and not a merge
algorithm for running orders — §3 exists precisely to avoid writing one. It is
two instances of one program, a log of what each did, and a human deciding when
two nights become one.
