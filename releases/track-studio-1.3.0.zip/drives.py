"""Which external drives the library lives on, and whether they're plugged in.

A path under `/Volumes/<name>/` is on a drive that can be unplugged, and while it
is, the path simply doesn't exist. That has to read as *not connected*, never as
*gone*. Before this module the app answered both the same way, and both answers
were wrong in their own way:

- **It created folders there.** `export_path()` made the export file's folder on
  every call, including from Settings while the page was being drawn, so with
  the drive out the page died with "Permission denied: '/Volumes/<name>'" —
  `/Volumes` belongs to root. On a Mac where it doesn't, it is worse: the folder
  gets made, squats the mount point, and the drive mounts next to it as
  "<name> 1" with every saved path pointing into the empty decoy. Hence
  `ensure_dir`, which refuses rather than creates.
- **It called files lost.** A rekordbox track whose file isn't there is, to
  `dupes`, a track rekordbox has *lost* — so every download matching a track on
  the unplugged drive would wear "replaces a lost file". A file on a drive that
  isn't connected is unknown, not lost.

Stdlib only and imports nothing from the app: `shell` reads it to draw the
header chip and `shell` must not import `runtime`, so `runtime` writes what the
library keeps on each drive into `state` and the header reads it from here.
"""
from __future__ import annotations

import os
from pathlib import Path

VOLUMES = Path("/Volumes")

# What the app keeps on each external drive, as `runtime.note_drives` last
# counted it — {"Samsung T7": ["2 341 tracks", "the download folder"]} — and how
# many times the library has been re-read because one came back, which is how
# an open page knows the data under it changed. Mutated, never rebound.
state: dict = {"uses": {}, "reloads": 0}


class DriveOffline(OSError):
    """A path was needed on a drive that isn't plugged in."""

    def __init__(self, name: str) -> None:
        self.drive = name
        super().__init__(f"“{name}” isn't connected — plug the drive in and try again.")


def volume(path) -> str | None:
    """The drive `path` lives on — the <name> of /Volumes/<name>/… — or None
    when it's on the startup disk."""
    if not path:
        return None
    # A string test rather than Path.parts: this runs over every track in the
    # library each time `runtime.note_drives` counts them.
    s = os.path.expanduser(str(path))
    if not s.startswith("/Volumes/"):
        return None
    return s.split("/")[2] or None


def connected(name: str) -> bool:
    """Is /Volumes/<name> a mounted drive right now?

    A mount point, not merely something that exists: a plain folder of that
    name is exactly the decoy described above. The startup disk is listed in
    /Volumes as a symlink to `/`, which is not a mount point by that test but
    is certainly connected.
    """
    p = VOLUMES / name
    return os.path.ismount(p) or (p.is_symlink() and p.exists())


def offline(path) -> str | None:
    """The name of the unplugged drive `path` needs, or None if none is in the way."""
    name = volume(path)
    return name if name and not connected(name) else None


def ensure_dir(path) -> Path:
    """`mkdir -p`, except on a drive that isn't connected: that raises
    `DriveOffline`, whose message says what to do."""
    p = Path(path).expanduser()
    name = offline(p)
    if name:
        raise DriveOffline(name)
    p.mkdir(parents=True, exist_ok=True)
    return p


def missing() -> dict[str, list[str]]:
    """The drives the library uses that aren't plugged in, with what's on each.

    A `stat` per drive the library has anything on — cheap enough for every
    open page to ask every few seconds.
    """
    return {name: uses for name, uses in state["uses"].items() if not connected(name)}
