"""“Do I already have this?” — the check that runs before a download.

Rekordbox cannot answer this for you. Its collection is keyed by file location,
so a second copy of a track at a second path imports as a second entry, silently,
however identical the tags. And two entries costs more than disk: `history` and
`mixmodel` key on the rekordbox track id, so a duplicate splits a track's play
evidence across both copies — precisely what the "2+ nights = confirmed" rule is
most sensitive to.

So the check lives here, and runs at the point of *intent* — when a link is
fetched and when the inbox is listed, before any bytes move. It never blocks:
there are good reasons to fetch a second copy (a lossless replacement for a
128 kbps rip, a mix that only looks like one you own). It just refuses to let it
happen silently.

Matching reuses `match.match_track` rather than inventing a comparison,
deliberately: that one scores title and artist independently and strips generic
mix qualifiers ("Original Mix") while keeping "remix" and the remixer's name, so
a remix never collapses into the original it is named after.

**A name is not enough on its own, and the reason is that same stripping.**
"Extended Mix" and "Radio Edit" are generic qualifiers too, so a 7-minute
extended scores 100 against the 3½-minute radio edit of the same record. Where
the caller can measure both files it fills in `delta_s`, and a gap wider than
`EDIT_DIFFERENCE_S` demotes the verdict to "different edit" — which points the
opposite way from "you already have this", because the longer cut is usually
the one worth keeping.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import drives
from match import match_track, prep_choices

# Where a match was found, best answer first: owning a track in rekordbox is a
# stronger "you have this" than a file downloaded and not yet imported.
REKORDBOX, DOWNLOADED = "rekordbox", "downloaded"

# Past this many seconds apart, two files with the same name are not two copies
# of one record — they are two different edits of it, and treating one as a
# redundant copy of the other is the most costly mistake this module can make.
# `match._norm_part` strips "Extended Mix" and "Radio Edit" as generic mix
# qualifiers, deliberately, so a 7-minute extended and a 3½-minute radio edit
# score 100 against each other on name alone. Measured here: of 966 downloads
# that matched something in rekordbox by name, 35 were a different edit, and 34
# of those were the *extended* mix against a radio edit already in the
# collection — so the advice "you already have this, discard it" would have
# thrown away the better file every time. `refetch.EDIT_DIFFERENCE_S` is the
# same number for the same reason; nothing legitimate lands in between, which is
# why the gap is wide.
EDIT_DIFFERENCE_S = 20.0

# A remix *attribution* — "(Kolsch Remix)", "- Someone's Rework", "[X VIP]".
# Generic mix qualifiers ("Extended Mix", "Radio Edit") are deliberately not in
# here: those describe a rendition of the same record, this describes a new one.
_REMIX = re.compile(
    r"(?:[(\[]|\s[-–]\s)\s*"
    r"([^)\]]*?\b(?:remix|rework|bootleg|flip|vip|refix|mashup)\b[^)\]]*?)"
    r"\s*(?:[)\]]|$)",
    re.IGNORECASE)
_NONWORD = re.compile(r"[^a-z0-9 ]+")
_WS = re.compile(r"\s+")


def _mmss(seconds: float) -> str:
    return f"{int(seconds) // 60}:{int(seconds) % 60:02d}"


def different_edit(want_s: Optional[float], have_s: Optional[float]) -> bool:
    """Are these two lengths too far apart to be the same record?

    The one place that question is answered, because it is asked in three and
    the wrong answer costs something different each time: binning the extended
    mix you just bought (Incoming's discard), never being offered it at all
    (`sync.compute_sync` calling it "have"), or buying a second copy of what
    you own (the pre-download badge). Unknown on either side is not a
    disagreement — it is no evidence, and callers decide what to do with that.
    """
    if want_s is None or have_s is None:
        return False
    return abs(want_s - have_s) > EDIT_DIFFERENCE_S


def remix_tag(title: str) -> str:
    """The remix attribution in a title, normalized — '' when there is none.

    `match` keeps "remix" and the remixer's name in its comparison, but a long
    title can still clear the certainty bar with a whole remix credit bolted on:
    "Visual Distortion of Reality" against the same title + "(Kolsch Remix)"
    scores 88, and a longer one would score higher still. A remix is a different
    record, so when the two sides disagree here the match is never reported as
    certain — it drops to "possible dupe", which is honestly what it is.
    """
    m = _REMIX.search(title or "")
    if not m:
        return ""
    # Apostrophes are dropped rather than spaced, so a straight quote, a curly
    # one and none at all all reduce to the same credit.
    s = m.group(1).lower().replace("'", "").replace("’", "")
    return _WS.sub(" ", _NONWORD.sub(" ", s)).strip()


def isrc_index(tracks: list) -> dict[str, int]:
    """Map ISRC -> first track index, for exact matching when ids are present."""
    out: dict[str, int] = {}
    for i, t in enumerate(tracks):
        if t.isrc:
            out.setdefault(t.isrc.upper(), i)
    return out


@dataclass
class Existing:
    """A track already in the library that a pending download looks like."""
    track: "Track"          # noqa: F821 - library.Track, duck-typed (leaf module)
    where: str              # REKORDBOX / DOWNLOADED
    via: str                # isrc / fuzzy
    score: float            # 0..100 (100 for an ISRC hit)
    same_rendition: bool = True   # the two titles agree on the remix credit
    # Candidate length minus this track's, in seconds — None when either side
    # couldn't be read — and the candidate's own length, so `detail` can name
    # both. Set by whoever has both files; `lookup` only ever sees one of them.
    # See `EDIT_DIFFERENCE_S`.
    delta_s: Optional[float] = None
    candidate_s: float = 0.0

    @property
    def different_edit(self) -> bool:
        """The two files are too far apart in length to be the same record."""
        return self.delta_s is not None and abs(self.delta_s) > EDIT_DIFFERENCE_S

    @property
    def longer(self) -> bool:
        """The candidate is the longer of the two — usually the extended mix."""
        return (self.delta_s or 0) > 0

    @property
    def certain(self) -> bool:
        """An ISRC hit is identity; a high fuzzy score is as good as one here.

        Below that the names merely line up, which is worth showing but not
        worth stating as fact — see `match.Match.confidence` for the tiers. A
        disagreement over the remix credit caps it regardless of score, and so
        does a length gap: names are metadata and can be sloppy about which
        edit they describe, while duration is measured off the audio.
        """
        return ((self.via == "isrc" or self.score >= 92)
                and self.same_rendition and not self.different_edit)

    @property
    def missing_file(self) -> bool:
        """The collection claims this track, but its file is gone from disk.

        Worth its own question because it *inverts* the advice. "You already
        have this" normally argues against a second copy; when the copy it
        points at no longer exists, the candidate is not redundant at all — it
        is the replacement for something rekordbox has lost, and discarding it
        would leave the collection with a dead entry and no audio.

        Statted on read rather than at lookup time: a scan asks this of the few
        hundred rows it matched, never of the whole library.

        A file on a drive that isn't plugged in is not lost, and says so here:
        otherwise unplugging the drive would turn every match into a "lost"
        file, inverting the advice for the whole collection at once.
        """
        p = self.track.local_path
        if p and Path(p).exists():
            return False
        return not drives.offline(p or self.track.offline_path)

    @property
    def playlist(self) -> str:
        """The rekordbox playlist this sits in — '' when it's in none, or local.

        Live-DB playlists are leaf names, XML ones are "Folder / Name" paths;
        the leaf is what you'd recognise either way.
        """
        if self.where != REKORDBOX:
            return ""
        names = [p.split(" / ")[-1] for p in (self.track.rekordbox_playlists or [])]
        return names[0] if names else ""

    @property
    def where_label(self) -> str:
        if self.where == REKORDBOX:
            if self.missing_file:
                return "in rekordbox, but its file is gone"
            return f"in rekordbox — {self.playlist}" if self.playlist else "in rekordbox"
        folder = self.track.local_path.parent.name if self.track.local_path else ""
        return f"downloaded — {folder}" if folder else "downloaded, not yet imported"

    @property
    def chip(self) -> str:
        if self.where == REKORDBOX and self.missing_file:
            return "replaces a lost file"
        # Said before "already have", because it is the case where that advice
        # would be wrong — and which way it points decides what to do next.
        if self.different_edit:
            return "longer edit" if self.longer else "shorter edit"
        return "already have" if self.certain else "possible dupe"

    @property
    def detail(self) -> str:
        """One line for a tooltip: what matched, where it lives, how sure we are.

        Both lengths appear whenever they are known, not only when they
        disagree: a name match that *also* agrees on duration is a materially
        stronger claim than one that hasn't been asked, and a reader can't tell
        those apart from silence.
        """
        how = "same ISRC" if self.via == "isrc" else f"{self.score:.0f}% name match"
        if not self.same_rendition:
            how += ", different remix credit"
        if self.delta_s is not None:
            how += f", {_mmss(self.candidate_s)} against {_mmss(self.length_s)}"
            if self.different_edit:
                how += f" — this is the {'longer' if self.longer else 'shorter'} edit"
        return f"{self.track.display} · {self.where_label} ({how})"

    @property
    def length_s(self) -> float:
        """This track's length, derived from the candidate's and the gap."""
        return self.candidate_s - (self.delta_s or 0.0)


class Index:
    """The library, prepared once for repeated lookups.

    Building the pools costs a normalization pass over every track, so build one
    Index per scan and reuse it across candidates — never one per candidate.
    """

    def __init__(self, tracks: list) -> None:
        # A track you own is one with a file or a rekordbox entry. Spotify-only
        # rows (wanted, never sourced) are exactly what you're downloading, so
        # they must not count as having it.
        pools = [
            (REKORDBOX, [t for t in tracks if t.in_rekordbox]),
            (DOWNLOADED, [t for t in tracks if t.local_path and not t.in_rekordbox]),
        ]
        self._pools = [
            (where, pool, prep_choices((t.artist, t.title) for t in pool),
             isrc_index(pool))
            for where, pool in pools
        ]

    def lookup(self, artist: str, title: str, isrc: Optional[str] = None,
               cutoff: float = 78.0, where: Optional[str] = None) -> Optional[Existing]:
        """The library track this candidate looks like, or None.

        `artist` matters: `match_track` requires both fields to clear a bar, so a
        candidate with no artist (an unparseable video title, say) never matches.
        That's the intended trade — title-only matching is the false-positive
        trap `match` was written to avoid.

        **`where` restricts the search to one pool, and a caller asking about a
        track that is itself in the library must pass it.** Otherwise the
        candidate finds *itself*: a downloaded file carries the ISRC it was
        fetched with, the ISRC branch returns on the first exact hit, and the
        `DOWNLOADED` pool contains the very file being asked about — so the
        answer is always "yes, you have it, here it is" pointing at itself. The
        rekordbox pool holds no ISRCs at all (the DB doesn't store them), so
        that short-circuit fired before the fuzzy pass could ever run against
        the collection. `where=REKORDBOX` is the question "is this already in
        my collection?", and a pending download can't be in that pool by
        definition, so it cannot match itself.
        """
        pools = [p for p in self._pools if where is None or p[0] == where]
        isrc = (isrc or "").strip().upper() or None
        # ISRC across the pools first: an exact id beats a name that merely
        # resembles something.
        if isrc:
            for pool_where, pool, _choices, by_isrc in pools:
                i = by_isrc.get(isrc)
                if i is not None:
                    return Existing(pool[i], pool_where, "isrc", 100.0)
        want_remix = remix_tag(title)
        for pool_where, pool, choices, _by_isrc in pools:
            if not choices:
                continue
            m = match_track(artist or "", title or "", choices, cutoff=cutoff)
            if m.hit:
                hit = pool[m.target_index]
                return Existing(hit, pool_where, "fuzzy", m.score,
                                same_rendition=want_remix == remix_tag(hit.title))
        return None


if __name__ == "__main__":
    # Self-test against the live library: how much of the download root is
    # already sitting in rekordbox under a different path?
    #
    # `where=REKORDBOX` is load-bearing, not a filter for tidiness. Asking
    # without it returns each pending file's *own* row out of the DOWNLOADED
    # pool, via the ISRC it was downloaded with — so this printed 0 for every
    # library it was ever run on, which is exactly how the question went
    # unanswered while a thousand redundant files piled up.
    # `delta_s` is filled in here too, exactly as `incoming.scan_duplicates`
    # does it. Without that this reports every extended mix as a duplicate of
    # the radio edit it matched, which is the failure `EDIT_DIFFERENCE_S`
    # exists for — a self-test that can't see it is worse than none.
    import runtime
    from mutagen import File as MutagenFile

    def _dur(p):
        try:
            return MutagenFile(str(p)).info.length
        except Exception:
            return None

    runtime._bootstrap()
    idx = Index(runtime.library.tracks)
    pending = [t for t in runtime.library.tracks if t.local_path and not t.in_rekordbox]
    print(f"{len(runtime.library.tracks)} tracks indexed, {len(pending)} pending local")
    hits = lost = edits = 0
    for t in pending:
        e = idx.lookup(t.artist, t.title, t.isrc, where=REKORDBOX)
        if not e:
            continue
        mine, theirs = _dur(t.local_path), _dur(e.track.local_path)
        if mine is not None and theirs is not None:
            e.candidate_s, e.delta_s = mine, mine - theirs
        if e.missing_file:
            lost += 1
        elif e.different_edit:
            edits += 1
        elif e.certain:
            hits += 1
        print(f"  [{e.chip}]  {t.display}  ->  {e.detail}")
    print(f"{hits} pending file(s) duplicate something already in rekordbox; "
          f"{edits} are a different edit of one; "
          f"{lost} replace a file rekordbox has lost")
