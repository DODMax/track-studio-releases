"""Getting a synced playlist's missing tracks: matched, confirmed, downloaded.

What this replaced was two loops end to end. Every track was searched on
Beatport *one after another* behind a spinner that counted to fifty, and only
when the last search had come back did one beatportdl run start for whatever
had matched confidently. The rest was a number in a toast ("10 need review")
with nowhere to review them. You couldn't see which track was which, couldn't
hear anything, and the first download waited for the last search.

So this is a job with a row per track, and three things overlap rather than
queue:

- **Matching runs in parallel** (`MATCH_WORKERS` searches at once, one login
  shared through `Beatport.clone`) and starts the moment the list is shown —
  it is read-only, so the rows can fill in with their match, sleeve and
  preview clip while you are still deciding what to tick.
- **Downloading starts with the first match**, not the last. Once you say go,
  every confident match on a ticked row joins a queue that a single worker
  drains in beatportdl runs of up to `BATCH`; whatever matches during a run
  is the next run. Each track's own progress comes off the binary's output
  (`bpdl.track_event`), and each file is claimed back by ISRC, then by name.
- **Uncertain matches wait for a person.** A row the names don't settle
  (`REVIEW`) never downloads by itself — it carries every version the store
  offered, with a preview clip each, and moves only when someone picks one.
  A row with nothing (`MISSING`) can be searched again by hand.

Owned by `runtime.fetch_jobs`, not by a page: a NiceGUI page dies when you
click another tab, and a forty-track download should not. Nothing here touches
the library or the UI. Landed files go to `on_landed` (called on the worker
thread with the `library.Track`s already read), and the UI follows the job by
polling `rev`, which moves on every change, and each `Item.rev`, so a row is
redrawn only when it changed. Redrawing all of them would stop the preview
someone is listening to.
"""
from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import bpdl
from match import pair_score

# Searches at once. Each track is two catalog calls (ISRC + name) at ~1.2s
# each, so one at a time is ~2.5s a track. Measured on 40 tracks of a real
# playlist: 101s one by one, 16.5s with 6 workers, 9.0s with 10 — and no 429
# at 10 (`Beatport._get` waits one out if it comes).
MATCH_WORKERS = 10
# Tracks per beatportdl run. The binary fetches five at a time by itself, so a
# run of ten keeps it busy while still ending often enough for the files to
# reach the library in useful steps.
BATCH = 10
# How long the downloader waits before its first run, so the first few matches
# go together rather than one track per process.
COALESCE_S = 0.8

# Row states, in the order a track normally passes through them.
MATCHING = "matching"        # its Beatport search hasn't come back yet
MATCHED = "matched"          # a confident match — downloads once you say go
REVIEW = "review"            # the store has something; a person has to say which
MISSING = "missing"          # nothing on Beatport we'd call this
QUEUED = "queued"
DOWNLOADING = "downloading"
DONE = "done"
FAILED = "failed"

# Inside DOWNLOADING: where beatportdl has got to with this track.
WAITING, RECEIVING, SAVING = "waiting", "receiving", "saving"

# Matches made in this process, by Spotify id, so reopening the sheet — or
# getting what's left of a playlist after a first pass — doesn't search again.
# A pick someone made by hand is stored here too (via "you").
_RESOLVED: dict[str, bpdl.Resolution] = {}
# Rows someone unticked, so the next pass over the same playlist doesn't tick
# them again behind their back.
_UNWANTED: set[str] = set()
_CACHE_LOCK = threading.Lock()


@dataclass
class Item:
    """One track the playlist has and the collection hasn't."""
    key: str                      # the Spotify track id
    spotify: object               # spotify.SpotifyTrack
    wanted: bool = True
    state: str = MATCHING
    pick: Optional[object] = None             # beatport.BeatportTrack
    candidates: list = field(default_factory=list)
    confidence: str = "none"
    via: str = "none"             # isrc / fuzzy / you
    note: str = ""                # why this version, when it isn't the obvious one
    stage: str = ""               # WAITING / RECEIVING / SAVING while DOWNLOADING
    path: Optional[Path] = None   # the file it became
    error: str = ""               # why it failed, or why matching couldn't run
    warn: str = ""                # landed, but the audio isn't continuous
    searched: str = ""            # the last query typed for it by hand
    searching: bool = False       # a hand search is in flight
    asked_note: str = ""          # about what we have already ("you have the 3:31 edit")
    rev: int = 0

    @property
    def artists(self) -> str:
        return ", ".join(self.spotify.artists)


class FetchJob:
    def __init__(self, *, source_id: str, source_name: str, dest: Path,
                 tracks: list, notes: Optional[dict] = None,
                 on_landed: Optional[Callable[[list], None]] = None):
        self.source_id = source_id
        self.source_name = source_name
        self.dest = Path(dest)
        notes = notes or {}
        with _CACHE_LOCK:
            unwanted = set(_UNWANTED)
        self.items = [Item(key=t.id, spotify=t, wanted=t.id not in unwanted,
                           asked_note=notes.get(t.id, "")) for t in tracks]
        self.by_key = {i.key: i for i in self.items}
        self.on_landed = on_landed
        self.started = False          # the person pressed Download
        self.rev = 0
        self.error = ""               # matching couldn't start at all
        self.landed: list[Path] = []
        self._lock = threading.RLock()
        self._dl_thread: Optional[threading.Thread] = None
        self._matching = 0            # searches not yet back
        self._bp = None               # the logged-in client the workers clone

    # ------------------------------------------------------------ reading

    def count(self, *states: str, wanted: Optional[bool] = None) -> int:
        return sum(1 for i in self.items if i.state in states
                   and (wanted is None or i.wanted == wanted))

    @property
    def matching(self) -> bool:
        return self._matching > 0

    @property
    def downloading(self) -> bool:
        return self._dl_thread is not None

    @property
    def active(self) -> bool:
        """Is anything still moving by itself?"""
        return self.matching or self.downloading

    @property
    def n_landed(self) -> int:
        """Tracks whose audio is in: done, or finished by beatportdl and being
        checked. The run claims files only when it ends, and a track that came
        down first shouldn't read as pending for the rest of its batch."""
        return sum(1 for i in self.items if i.state == DONE
                   or (i.state == DOWNLOADING and i.stage == SAVING))

    @property
    def ready(self) -> list[Item]:
        """What Download would start right now."""
        return [i for i in self.items if i.wanted and i.state == MATCHED]

    # ------------------------------------------------------------ changes

    def _touch(self, item: Optional[Item] = None) -> None:
        if item is not None:
            item.rev += 1
        self.rev += 1

    def _set(self, item: Item, **fields) -> None:
        with self._lock:
            for k, v in fields.items():
                setattr(item, k, v)
            self._touch(item)

    # ------------------------------------------------------------ matching

    def start_matching(self) -> None:
        """Search every row on Beatport, several at a time, off the caller's
        thread. Rows already matched this session are filled in at once."""
        todo = []
        with _CACHE_LOCK:
            cached = {i.key: _RESOLVED.get(i.key) for i in self.items}
        for i in self.items:
            res = cached.get(i.key)
            if res is not None:
                self._apply(i, res)
            else:
                todo.append(i)
        if not todo:
            return
        self._matching = len(todo)
        threading.Thread(target=self._match_all, args=(todo,),
                         name="bp-match", daemon=True).start()

    def _match_all(self, todo: list[Item]) -> None:
        import beatport
        try:
            self._bp = beatport.connect()
        except Exception as e:                       # noqa: BLE001 — shown on the sheet
            with self._lock:
                self.error = f"Couldn't log in to Beatport: {e}"
                for i in todo:
                    i.state, i.error = MISSING, "not searched — Beatport login failed"
                    self._touch(i)
                self._matching = 0
            return
        local = threading.local()

        def _client():
            if getattr(local, "bp", None) is None:
                local.bp = self._bp.clone()
            return local.bp

        def _one(item: Item) -> None:
            try:
                res = bpdl.resolve_one(item.spotify, _client())
            except Exception as e:                   # noqa: BLE001
                res = None
                err = str(e)
            with self._lock:
                self._matching -= 1
                if res is None:
                    item.state, item.error = MISSING, f"search failed: {err}"
                    self._touch(item)
                    return
                with _CACHE_LOCK:
                    _RESOLVED[item.key] = res
                self._apply(item, res)

        t0 = time.time()
        with ThreadPoolExecutor(MATCH_WORKERS, thread_name_prefix="bp-match") as pool:
            list(pool.map(_one, todo))
        print(f"[fetch] {self.source_name}: matched {len(todo)} on Beatport in "
              f"{time.time() - t0:.1f}s")

    def _apply(self, item: Item, res: bpdl.Resolution) -> None:
        with self._lock:
            item.candidates = list(res.candidates)
            item.pick = res.beatport
            item.confidence, item.via, item.note = res.confidence, res.via, res.note
            item.error = ""
            if res.beatport is None:
                item.state = MISSING
            elif res.confidence == "high":
                item.state = MATCHED
            else:
                item.state = REVIEW
            self._touch(item)
            self._queue(item)
        self._kick()

    # ------------------------------------------------------------ decisions

    def go(self) -> None:
        """Start downloading: everything ready now, and everything that becomes
        ready from here on."""
        with self._lock:
            self.started = True
            for i in self.items:
                self._queue(i)
            self._touch()
        self._kick()

    def stop(self) -> None:
        """No further runs. The one in flight finishes — killing beatportdl
        mid-write would leave half a file where a track should be."""
        with self._lock:
            self.started = False
            for i in self.items:
                if i.state == QUEUED:
                    i.state = MATCHED
                    self._touch(i)
            self._touch()

    def set_wanted(self, key: str, on: bool) -> None:
        item = self.by_key.get(key)
        if item is None or item.state in (DOWNLOADING, DONE):
            return
        with self._lock:
            item.wanted = on
            if not on and item.state == QUEUED:
                item.state = MATCHED
            self._touch(item)
            self._queue(item)
        with _CACHE_LOCK:
            (_UNWANTED.discard if on else _UNWANTED.add)(key)
        self._kick()

    def set_all(self, on: bool) -> None:
        for i in self.items:
            self.set_wanted(i.key, on)

    def choose(self, key: str, bp_id: int) -> None:
        """A person said which Beatport track this is. Final for this session."""
        item = self.by_key.get(key)
        if item is None:
            return
        bt = next((c for c in item.candidates if c.id == bp_id), None)
        if bt is None:
            return
        with self._lock:
            item.pick, item.via, item.confidence = bt, "you", "high"
            item.note, item.error, item.wanted = "", "", True
            item.state = MATCHED
            self._touch(item)
            with _CACHE_LOCK:
                _RESOLVED[key] = bpdl.Resolution(item.spotify, bt, "high", "you",
                                                 list(item.candidates), 100.0)
                _UNWANTED.discard(key)
            self._queue(item)
        self._kick()

    def retry(self, key: str) -> None:
        item = self.by_key.get(key)
        if item is None or item.state != FAILED or item.pick is None:
            return
        with self._lock:
            item.state, item.error, item.wanted = MATCHED, "", True
            self._touch(item)
            self._queue(item)
        self._kick()

    def search(self, key: str, query: str) -> None:
        """A hand search for one row, when the store spells it differently.

        Its results become the row's candidates and the row goes to REVIEW —
        never straight to a download, because a typed query is exactly the
        case where the top hit may be something else entirely.
        """
        item = self.by_key.get(key)
        query = (query or "").strip()
        if item is None or not query or item.state in (DOWNLOADING, DONE):
            return
        self._set(item, searching=True, searched=query)

        def _work():
            try:
                bp = self._bp.clone() if self._bp is not None else None
                hits = bpdl.search_tracks(query, limit=10, bp=bp)
            except Exception as e:                   # noqa: BLE001
                self._set(item, searching=False, error=f"search failed: {e}")
                return
            sp = item.spotify
            hits.sort(key=lambda c: (pair_score(item.artists, sp.name,
                                                ", ".join(c.artists), c.full_name),
                                     bpdl.version_rank(c.mix_name, sp.name)),
                      reverse=True)
            hits = bpdl.distinct(hits)
            with self._lock:
                item.searching = False
                item.candidates = hits
                item.error = "" if hits else f"Beatport has nothing for “{query}”"
                if hits:
                    item.state, item.pick, item.confidence = REVIEW, None, "low"
                    item.via, item.note = "fuzzy", ""
                self._touch(item)

        threading.Thread(target=_work, name="bp-search", daemon=True).start()

    # ------------------------------------------------------------ downloading

    def _queue(self, item: Item) -> None:
        """Queue a row if it's ready and the person has said go. Caller holds
        the lock (it's re-entrant)."""
        with self._lock:
            if self.started and item.wanted and item.state == MATCHED:
                item.state = QUEUED
                self._touch(item)

    def _kick(self) -> None:
        """Start the download worker if there is work and none is running.

        The worker clears `_dl_thread` under the same lock it checks the queue
        with, so a row queued while it is deciding to stop is never stranded.
        """
        with self._lock:
            if self._dl_thread is not None:
                return
            if not any(i.state == QUEUED for i in self.items):
                return
            t = threading.Thread(target=self._download_loop, name="bp-download",
                                 daemon=True)
            self._dl_thread = t
            self._touch()
        t.start()

    def _download_loop(self) -> None:
        time.sleep(COALESCE_S)
        while True:
            with self._lock:
                batch = [i for i in self.items if i.state == QUEUED][:BATCH]
                if not batch or not self.started:
                    self._dl_thread = None
                    self._touch()
                    return
                for i in batch:
                    i.state, i.stage, i.error = DOWNLOADING, WAITING, ""
                    self._touch(i)
            self._run(batch)

    def _run(self, batch: list[Item]) -> None:
        by_name = {bpdl.display_key(i.pick): i for i in batch}

        def _line(line: str) -> None:
            ev = bpdl.track_event(line)
            if ev is None:
                return
            item = by_name.get(ev[1])
            if item is not None and item.state == DOWNLOADING:
                self._set(item, stage=RECEIVING if ev[0] == "start" else SAVING)

        try:
            files, log = bpdl.download([i.pick.id for i in batch], self.dest,
                                       on_line=_line)
        except Exception as e:                       # noqa: BLE001 — per row, below
            with self._lock:
                for i in batch:
                    i.state, i.stage, i.error = FAILED, "", str(e)
                    self._touch(i)
            return
        self._settle(batch, files, log)

    def _settle(self, batch: list[Item], files: list[Path], log: str) -> None:
        """Say which file each track became, and what went wrong for the rest.

        beatportdl names files after a template and reports nothing about which
        id produced which — so a file is claimed by the ISRC the binary writes
        into its tags, then by name. A file nobody in this run claims is left
        alone: it can be the last run's, landing inside this one's time window.
        """
        from library import track_from_file

        fresh = {}
        for p in files:
            if p in self.landed:
                continue
            try:
                fresh[p] = track_from_file(p)
            except Exception as e:                   # noqa: BLE001
                print(f"[fetch] couldn't read {p.name}: {e!r}")
        by_isrc = {}
        for p, t in fresh.items():
            if t.isrc:
                by_isrc.setdefault(t.isrc.upper(), p)
        claimed: dict[str, Path] = {}
        for i in batch:
            isrc = (i.pick.isrc or "").upper()
            p = by_isrc.get(isrc) if isrc else None
            if p is not None and p not in claimed.values():
                claimed[i.key] = p
        for i in batch:
            if i.key in claimed:
                continue
            artists = ", ".join(i.pick.artists)
            best, best_s = None, 0.0
            for p, t in fresh.items():
                if p in claimed.values():
                    continue
                s = pair_score(artists, i.pick.full_name,
                               t.artist or "", t.title or p.stem)
                if s > best_s:
                    best, best_s = p, s
            if best is not None and best_s >= bpdl.SAME_RECORD:
                claimed[i.key] = best

        bad = {}
        if claimed:
            try:
                import integrity
                bad = {f.path: f.summary
                       for f in integrity.verify_downloads(list(claimed.values()))}
            except Exception as e:                   # noqa: BLE001 — never fatal
                print(f"[fetch] integrity check failed: {e!r}")

        # The binary prefixes a failing line with the url it was given, so a
        # reason can usually be pinned on the track. When nothing came back at
        # all, the whole run's reason is everyone's (a quality the plan doesn't
        # include fails every track the same way).
        reasons = bpdl.failures_by_id(log)
        whole = "" if claimed else bpdl.failure_reason(log)
        with self._lock:
            for i in batch:
                p = claimed.get(i.key)
                i.stage = ""
                if p is not None:
                    i.state, i.path = DONE, p
                    i.warn = (f"discontinuous audio — {bad[p]}" if p in bad else "")
                else:
                    i.state = FAILED
                    own = reasons.get(i.pick.id)
                    i.error = (bpdl.failure_reason(own) if own
                               else whole or "beatportdl brought no file back for it")
                self._touch(i)
            self.landed.extend(claimed.values())
        if claimed and self.on_landed:
            try:
                self.on_landed([fresh[p] for p in claimed.values()])
            except Exception as e:                   # noqa: BLE001
                print(f"[fetch] on_landed failed: {e!r}")
