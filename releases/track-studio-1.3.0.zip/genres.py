"""Genre kinship — how close two store genres are, in one small table.

The genre string is the only *style* fact this app has about most of the
library. Measured on this collection: rekordbox carries a Genre for 58% of the
tracks, the file tag underneath carries Beatport's store genre for essentially
everything downloaded through the app, and together they cover roughly 70% —
against 0.3% for the analyzer's own `style`, which needs a DSP pass per track.
So until every track has been analyzed, this is what "does it belong with these"
has to be built on.

Two things make a bare string comparison useless on its own:

- **Beatport's taxonomy splits what DJs treat as one thing.** "Techno (Peak Time
  / Driving)", "Techno (Raw / Deep / Hypnotic)" and "Hard Techno" are three
  store genres and one crate. Equality alone would refuse the swap a DJ makes
  every night.
- **It also joins what they treat as different.** "Melodic House & Techno" is
  405 tracks of this library — a third of everything with a genre — and it spans
  Anyma stadium melodics and deep proggy tools. Inside such a family the genre
  says little, which is why the scoring that calls this treats a family match as
  evidence and never as proof.

So: identical genre scores full, the same family scores well, a neighbouring
family scores half, and anything else scores low but not zero — a crate is
allowed to be a genre-crossing idea, and this is one input among several.

The families are a DJ's swap groups, not a store's menu: two genres share a
family when a set would take one for the other without changing what the night
is. Unknown strings fall back to a keyword scan, so a Beatport genre added after
this was written ("Techno (Something New)") still lands in the right family.
"""
from __future__ import annotations

import re

# family -> the genre strings that belong to it, lowercased and punctuation-free
# (see `_norm`). Everything Beatport has filed this library under is here, plus
# the older names its exports still carry ("Nu-Disco", "Deep Techno").
_FAMILIES: dict[str, tuple[str, ...]] = {
    "house": (
        "house", "deep house", "tech house", "funky house", "jackin house",
        "bass house", "minimal deep tech", "minimal", "soulful house",
        "latin house", "tribal house", "garage house",
    ),
    "melodic": (
        "melodic house techno", "progressive house", "organic house downtempo",
        "organic house", "leftfield house techno", "deep progressive house",
    ),
    "techno": (
        "techno", "techno peak time driving", "techno raw deep hypnotic",
        "hard techno", "deep techno", "minimal techno", "detroit techno",
        "peak time techno", "melodic techno",
    ),
    "afro": ("afro house", "amapiano", "afro tech", "3 step"),
    "indie": (
        "indie dance", "nu disco disco", "nu disco", "nudisco", "disco",
        "electronica", "electronic", "dance electro pop", "dance pop",
        "electro classic detroit modern", "electro", "synth pop", "new wave",
        "french house", "filter house",
    ),
    "bigroom": (
        "mainstage", "dance edm", "big room", "future house", "electro house",
        "progressive edm",
    ),
    "trance": (
        "trance main floor", "trance raw deep hypnotic", "trance", "tech trance",
        "progressive trance", "psy trance", "psytrance", "uplifting trance",
        "goa trance",
    ),
    "hard": (
        "hard dance hardcore neo rave", "hardstyle", "hardcore", "neo rave",
        "raw hardstyle", "frenchcore", "gabber",
    ),
    "bass": (
        "drum bass", "dnb", "dubstep", "trap future bass", "bass club",
        "breaks breakbeat uk bass", "breaks", "breakbeat", "uk garage bassline",
        "uk garage", "garage", "grime", "jungle", "future bass",
    ),
    "urban": (
        "hip hop", "hip hop r b", "r b", "reggae dancehall dub", "dancehall",
        "reggaeton", "afrobeats", "pop",
    ),
    "ambient": ("downtempo", "ambient", "chill out", "lounge", "idm", "experimental"),
    "tools": ("dj tools", "loop samples", "acapellas", "sound effects"),
}

# Families a set crosses without anyone noticing the seam. Symmetric; each pair
# listed once.
_NEIGHBOURS: tuple[tuple[str, str], ...] = (
    ("house", "melodic"), ("house", "techno"), ("house", "afro"),
    ("house", "indie"), ("house", "bass"),
    ("melodic", "techno"), ("melodic", "trance"), ("melodic", "afro"),
    ("melodic", "ambient"),
    ("techno", "hard"), ("techno", "trance"), ("techno", "indie"),
    ("indie", "bigroom"), ("indie", "ambient"), ("indie", "urban"),
    ("bigroom", "trance"), ("bigroom", "hard"), ("bigroom", "urban"),
    ("bass", "urban"), ("afro", "urban"), ("afro", "indie"),
)

# Last resort for a genre string this table has never seen: the first keyword
# that appears in it decides the family. Order matters — "hard techno" must
# reach `techno` before "hardcore" claims it, and "tech house" must reach
# `house` before "techno" does.
_KEYWORDS: tuple[tuple[str, str], ...] = (
    ("amapiano", "afro"), ("afro", "afro"),
    ("psy", "trance"), ("trance", "trance"),
    ("drum bass", "bass"), ("dnb", "bass"), ("dubstep", "bass"),
    ("garage", "bass"), ("breaks", "bass"), ("breakbeat", "bass"),
    ("bassline", "bass"), ("jungle", "bass"),
    ("hardstyle", "hard"), ("hardcore", "hard"), ("rave", "hard"),
    ("melodic", "melodic"), ("progressive", "melodic"), ("organic", "melodic"),
    ("tech house", "house"), ("deep house", "house"), ("funky", "house"),
    ("jackin", "house"), ("bass house", "house"),
    ("techno", "techno"), ("minimal", "techno"),
    ("mainstage", "bigroom"), ("edm", "bigroom"), ("big room", "bigroom"),
    ("electro house", "bigroom"),
    ("disco", "indie"), ("indie", "indie"), ("electro", "indie"),
    ("electronica", "indie"), ("wave", "indie"),
    ("hip hop", "urban"), ("dancehall", "urban"), ("reggae", "urban"),
    ("house", "house"),
    ("downtempo", "ambient"), ("ambient", "ambient"), ("chill", "ambient"),
    ("tools", "tools"), ("samples", "tools"),
)

_BY_GENRE: dict[str, str] = {g: fam for fam, gs in _FAMILIES.items() for g in gs}
_NEIGHBOUR_SET = frozenset(
    frozenset(pair) for pair in _NEIGHBOURS)

# What each degree of relation is worth, 0..100.
SAME = 100.0
SAME_FAMILY = 70.0
NEIGHBOUR = 45.0
UNRELATED = 8.0
# What an *absent* genre is worth when the other side has one. Not zero — the
# track may well fit and we simply don't know — but below `UNRELATED`'s
# neighbourhood would be a lie in the other direction: a known mismatch is a
# fact, a blank tag is ignorance. Scored just under a neighbour so a track with
# no genre ranks behind every track with a related one, and ahead of a genre
# that is genuinely wrong.
UNKNOWN = 22.0


def _norm(g: str) -> str:
    """Canonical form: lowercase, punctuation to spaces, single-spaced.

    "Techno (Peak Time / Driving)" -> "techno peak time driving". Beatport's
    exports, rekordbox's XML and its live DB each punctuate differently, and the
    same genre must not depend on which one wrote it.
    """
    s = re.sub(r"[^a-z0-9]+", " ", (g or "").lower())
    return " ".join(s.split())


def family(g: str) -> str:
    """The swap group a genre belongs to, or "" when it carries no genre."""
    n = _norm(g)
    if not n:
        return ""
    fam = _BY_GENRE.get(n)
    if fam:
        return fam
    for kw, f in _KEYWORDS:
        if kw in n:
            return f
    return ""


def kinship(a: str, b: str) -> float:
    """0..100 — how close two genre strings are. `UNKNOWN` if either is blank.

    Note this is deliberately *not* a distance in a tree: the point is how
    freely a DJ swaps one for the other, and that is not symmetric with depth.
    "Deep House" and "Tech House" are one family and swap constantly; "Melodic
    House & Techno" and "Hard Techno" are neighbours on paper and rarely swap,
    which is what `NEIGHBOUR` being under half is for.
    """
    na, nb = _norm(a), _norm(b)
    if not na or not nb:
        return UNKNOWN
    if na == nb:
        return SAME
    fa, fb = family(na), family(nb)
    if fa and fb:
        if fa == fb:
            return SAME_FAMILY
        if frozenset((fa, fb)) in _NEIGHBOUR_SET:
            return NEIGHBOUR
        return UNRELATED
    # One of them is a string this table has never seen and no keyword caught —
    # a hand-typed genre, a label name, a language we don't cover. Shared words
    # are the only evidence left.
    shared = set(na.split()) & set(nb.split())
    return SAME_FAMILY if shared else UNRELATED


def label(g: str) -> str:
    """The genre as it should read in the UI — the store's own casing, trimmed."""
    return (g or "").strip()


if __name__ == "__main__":
    pairs = [
        ("Melodic House & Techno", "Melodic House & Techno"),
        ("Techno (Peak Time / Driving)", "Hard Techno"),
        ("Techno (Peak Time / Driving)", "Techno (Raw / Deep / Hypnotic)"),
        ("Deep House", "Tech House"),
        ("Indie Dance", "Nu Disco / Disco"),
        ("Mainstage", "Indie Dance"),
        ("Mainstage", "Melodic House & Techno"),
        ("Melodic House & Techno", "Progressive House"),
        ("Afro House", "Hard Techno"),
        ("Indie Dance", ""),
        ("Techno (Some New Split)", "Hard Techno"),
    ]
    for a, b in pairs:
        print(f"{kinship(a, b):6.1f}  {a or '—':32} {b or '—':32} "
              f"({family(a) or '?'} / {family(b) or '?'})")
