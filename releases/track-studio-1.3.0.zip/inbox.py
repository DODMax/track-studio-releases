"""The inbox — audio that arrived by browser download, on its way into the library.

Not every track comes down a pipe we control. Free-download gates (Hypeddit and
friends), Bandcamp purchases, promo mail, WeTransfer links: the file lands in
`~/Downloads` with whatever name the artist gave it, and the tedious part is
never the download — it's the filing afterwards.

This module owns that last mile. `scan()` lists audio in the inbox folder that
the library doesn't already have; `import_file()` parses an artist/title out of
the filename, stamps them into the tags, and moves the file into the download
root, where the existing batch machinery picks it up exactly like a Beatport or
YouTube download.

Deliberately dumb about *where* a file came from — a downloads folder is a pile
of files, not a source with an API. Everything it knows comes from the name and
the tags already on the file.
"""
from __future__ import annotations

import os
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import drives

# Everything rekordbox can use, not just what our tagger can write: a .wav or
# .aiff still belongs in the library, it just can't carry an Energy tag.
AUDIO_EXTS = {".mp3", ".m4a", ".wav", ".aiff", ".aif", ".flac", ".aac", ".ogg"}
# `energy.SUPPORTED_EXTS` — the subset the analyzer can actually tag.
TAGGABLE_EXTS = {".mp3", ".m4a"}

# The subfolder of the download root that imports land in. Named like the other
# batch folders (YouTube / SoundCloud / Beatport) so it lists alongside them.
IMPORT_FOLDER = "Imported"

# Promo noise that ends up in free-download filenames.
_NAME_NOISE = re.compile(
    r"\s*[\(\[]?\s*(free\s*(dl|download)|out\s+now|premiere|forthcoming|"
    r"master(ed)?|final|v\d+|www\.[\w.-]+|preview)\s*[\)\]]?",
    re.IGNORECASE,
)
# Leading track numbers ("01 ", "01. ", "01 - ", "A1 ").
_LEAD_NUM = re.compile(r"^\s*[A-Da-d]?\d{1,3}\s*[-._)]?\s+")
# Trailing site/tag junk some gates append.
_TRAIL_JUNK = re.compile(r"\s*[-_]\s*(hypeddit|toneden|artistunion)\S*\s*$", re.IGNORECASE)


@dataclass
class InboxFile:
    """One audio file sitting in the inbox, with a guess at what it is."""
    path: Path
    artist: str
    title: str
    size: int                       # bytes
    mtime: float
    from_tags: bool                 # artist/title came from the file's own tags

    @property
    def ext(self) -> str:
        return self.path.suffix.lower()

    @property
    def taggable(self) -> bool:
        """Whether the analyzer can write an Energy tag to this format."""
        return self.ext in TAGGABLE_EXTS

    @property
    def display(self) -> str:
        return f"{self.artist} — {self.title}" if self.artist else self.title


def responsible_app() -> Optional[str]:
    """The .app bundle macOS holds responsible for this process's file access.

    TCC grants attach to the *launching* application, not to the python binary,
    so "grant python access" is not a thing you can do — you grant Terminal, or
    iTerm, or the Track Studio bundle. Walk the parent chain and take the
    topmost bundle: the immediate ancestors are shells and helpers, and the one
    that owns the grant sits at the top, just under launchd.

    Our *own* process is skipped deliberately — a python installed inside a
    framework reports a bundle (`Xcode.app`, `Python.app`) that has nothing to
    do with who launched it. Returns None off macOS, or if `ps` is unavailable.
    """
    if sys.platform != "darwin":
        return None
    import re
    import subprocess
    found: list[str] = []
    pid = os.getppid()
    for _ in range(14):                       # bounded: never chase a cycle
        if pid <= 1:
            break
        try:
            r = subprocess.run(["ps", "-o", "ppid=,comm=", "-p", str(pid)],
                               capture_output=True, text=True, timeout=3)
        except Exception:
            break
        line = (r.stdout or "").strip()
        if not line:
            break
        ppid, _, comm = line.partition(" ")
        m = re.search(r"/([^/]+\.app)/", comm)
        if m:
            found.append(m.group(1))
        try:
            pid = int(ppid)
        except ValueError:
            break
    return found[-1] if found else None


def default_folder() -> Path:
    """Where browser downloads land. `~/Downloads` unless overridden in the
    studio state (`inbox_folder`) — some people point Safari elsewhere, and
    macOS gates `~/Downloads` behind a TCC grant an app bundle may not have."""
    try:
        from store import load_studio_state
        cfg = load_studio_state().get("inbox_folder")
    except Exception:
        cfg = None
    return Path(cfg).expanduser() if cfg else Path.home() / "Downloads"


def parse_name(stem: str) -> tuple[str, str]:
    """Best-effort (artist, title) from a filename stem.

    Free-download filenames are near-universally "Artist - Title (Mix)", so the
    first " - " is the split. Everything else is cleanup: underscores back to
    spaces, a leading track number off, promo noise dropped. Always editable in
    the UI afterwards — this only has to be right often enough to save typing.
    """
    s = (stem or "").strip()
    # Underscores in a music filename are always stand-ins for spaces, including
    # in names that also contain real spaces ("Some_Artist_-_Title (FREE DL)").
    s = s.replace("_-_", " - ").replace("_", " ")
    s = _TRAIL_JUNK.sub("", s)
    s = _NAME_NOISE.sub("", s)
    s = _LEAD_NUM.sub("", s)
    s = re.sub(r"\s{2,}", " ", s).strip(" -–—")
    artist, sep, title = s.partition(" - ")
    if sep and artist.strip() and title.strip():
        return artist.strip(), title.strip()
    return "", s


def _read_tags(path: Path) -> tuple[str, str]:
    """(artist, title) already on the file, if any. Beats the filename guess."""
    try:
        from library import _read_file_fields
        f = _read_file_fields(path)
    except Exception:
        return "", ""
    title = (f.get("title") or "").strip()
    # `_read_file_fields` falls back to the filename stem for a missing title;
    # that's the filename guess again, so don't count it as tag evidence.
    if title == path.stem:
        title = ""
    return (f.get("artist") or "").strip(), title


def scan(folder: Optional[Path] = None, known: Optional[set] = None,
         limit: int = 60) -> list[InboxFile]:
    """Audio in `folder` the library doesn't already have, newest first.

    `known` is a set of already-known paths (lowercased strings) — pass
    `library`'s so a file that's been imported already stops showing up.
    Non-recursive and dotfile-skipping, matching `energy.find_audio_files`.
    """
    folder = Path(folder or default_folder())
    if not folder.is_dir():
        raise FileNotFoundError(f"{folder} is not a folder")
    known = known or set()
    out: list[InboxFile] = []
    # macOS gates ~/Downloads behind TCC: a process without the grant can stat
    # the folder but not list it. Let that surface as an error the UI can
    # explain, rather than an empty list that reads as "nothing new".
    try:
        entries = list(folder.iterdir())
    except PermissionError as e:
        # The grant belongs to whatever *launched* python (Terminal, or the .app
        # wrapper), not to python itself. Full Disk Access is the pane with a "+"
        # you can add to; Files and Folders only lists apps that already
        # triggered a prompt, so it can't be used to fix this after the fact.
        app = responsible_app()
        who = f"“{app}”" if app else "the app you launched Track Studio from"
        raise PermissionError(
            f"macOS is blocking access to {folder}. Add {who} under System "
            f"Settings → Privacy & Security → Full Disk Access (that pane has a "
            f"“+”; Files and Folders only lists apps that already asked), then "
            f"restart it. Or point the inbox at a folder outside ~/Downloads, "
            f"~/Documents and ~/Desktop in Settings — those need no grant.") from e
    for p in entries:
        if not p.is_file() or p.name.startswith("."):
            continue
        if p.suffix.lower() not in AUDIO_EXTS:
            continue
        if str(p).lower() in known:
            continue
        try:
            st = p.stat()
        except OSError:
            continue
        t_artist, t_title = _read_tags(p)
        if t_artist and t_title:
            artist, title, from_tags = t_artist, t_title, True
        else:
            artist, title = parse_name(p.stem)
            from_tags = False
            # A title tag with no artist tag still beats guessing the title.
            if t_title and not artist:
                title = t_title
        out.append(InboxFile(path=p, artist=artist, title=title,
                             size=st.st_size, mtime=st.st_mtime,
                             from_tags=from_tags))
    out.sort(key=lambda f: -f.mtime)
    return out[:limit]


def _unique_path(dest_dir: Path, name: str) -> Path:
    """A free path in `dest_dir` — never silently overwrite an existing file."""
    target = dest_dir / name
    if not target.exists():
        return target
    stem, suffix = target.stem, target.suffix
    for i in range(2, 100):
        cand = dest_dir / f"{stem} ({i}){suffix}"
        if not cand.exists():
            return cand
    raise FileExistsError(f"couldn't find a free name for {name} in {dest_dir}")


def _safe_name(artist: str, title: str, suffix: str) -> str:
    base = f"{artist} - {title}" if artist else title
    base = re.sub(r'[/\\:*?"<>|]', "-", base).strip() or "Untitled"
    return f"{base[:180]}{suffix}"


def _write_tags(path: Path, artist: str, title: str) -> None:
    """Stamp artist/title into the file, so the library shows the corrected
    names rather than whatever the gate called it. Best-effort: a file we can't
    tag is still perfectly usable, so failure here is never fatal."""
    suffix = path.suffix.lower()
    try:
        if suffix == ".mp3":
            from mutagen.easyid3 import EasyID3
            from mutagen.id3 import ID3NoHeaderError
            try:
                m = EasyID3(str(path))
            except ID3NoHeaderError:
                from mutagen.id3 import ID3
                ID3().save(str(path))
                m = EasyID3(str(path))
            if title:
                m["title"] = title
            if artist:
                m["artist"] = artist
            m.save()
        elif suffix == ".m4a":
            from mutagen.mp4 import MP4
            m = MP4(str(path))
            if title:
                m["\xa9nam"] = [title]
            if artist:
                m["\xa9ART"] = [artist]
            m.save()
    except Exception:
        pass


def import_file(f: InboxFile, dest_root: Path, artist: str = "",
                title: str = "", move: bool = True,
                folder: Optional[str] = None) -> Path:
    """File one inbox track into `<dest_root>/<folder>`, returning its new path.

    Renames to "Artist - Title.ext" and writes those into the tags. Moves by
    default (the point is to clear the download folder); `move=False` copies,
    for anything you'd rather keep where it is.

    `folder` defaults to `Imported`, which is a *door* — a name for where the
    file came through, not where it is going, so everything landing there owes
    a destination afterwards (see `destinations.DOORS`). Pass a rekordbox
    playlist name and the file arrives already filed instead.
    """
    artist = (artist or f.artist).strip()
    title = (title or f.title).strip() or f.path.stem
    dest_dir = drives.ensure_dir(Path(dest_root) / (folder or IMPORT_FOLDER))
    target = _unique_path(dest_dir, _safe_name(artist, title, f.path.suffix.lower()))
    if move:
        shutil.move(str(f.path), str(target))
    else:
        shutil.copy2(str(f.path), str(target))
    _write_tags(target, artist, title)
    return target


if __name__ == "__main__":
    files = scan()
    print(f"{len(files)} importable file(s) in {default_folder()}")
    for f in files:
        flag = "" if f.taggable else "  (not taggable)"
        src = "tags" if f.from_tags else "name"
        print(f"  {f.size / 1e6:6.1f} MB  [{src}]  {f.display}{flag}")
