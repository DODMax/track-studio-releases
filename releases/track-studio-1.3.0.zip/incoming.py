"""The Incoming lane — everything on its way into the collection, in one list.

A track arrives across three thresholds: you get a file for it, the analyzer
writes its Energy tag, and rekordbox takes it into the collection. Each of those
used to be a different *screen* — the gap on Sync, the fetch on Download, the
analysis and the import on Library — so a single track's state was *where it
was*, and following one meant crossing the app. A batch imported before it was
analyzed even left the UI entirely, unfinished and invisible.

Here a track's state is what it wears, and every source pours into the same
list: a Spotify playlist's gap, a download folder, the inbox. A row leaves only
when it owes nothing.

Leaf: takes `library.Track` and `sync.SyncRow` shapes in, gives plain data out.
No UI, no `runtime`, no network.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

# The three thresholds a track crosses on its way in, in order:
#
#     want it  →  get it  →  know where it goes  →  rekordbox has it
#
# `destination` is the step the old flow never had, and its absence is this
# app's most common dead end — a thousand files sat in a folder named after the
# shop they came from because nothing ever asked which playlist they were for.
# See `destinations`.
STEPS = ("download", "destination", "rekordbox")

# What each step is called in a sentence ("6 to get · 999 to file").
STEP_LABELS = {"download": "get", "destination": "file", "rekordbox": "import"}

# Energy analysis is deliberately **not** a step. It is a tag a track may carry,
# not something it owes: only the Build page consumes it, that page is on its
# way out, and it has reached ~16% of the library in the time it has existed.
# Making it a step put the biggest button on screen in front of the job people
# are actually here for. It lives on as an explicit action over a selection.
# Loudness never was one, for the same kind of reason: it is a question about a
# playlist's mastering, not about one track being unfinished.

# The whole lane, as opposed to one source of it.
ALL = "*"


def needs(track, destination=None) -> tuple[str, ...]:
    """What a track still owes. `track` is None for something only wanted.

    Two rules that aren't obvious:
    - rekordbox holding a track settles *everything*. Whatever we can't see —
      the file, a folder — it has been through, and it is not arriving.
    - a destination is owed even before the file exists. A wanted track from a
      paired source already knows where it is going; one from an unpaired
      source does not, and that is worth saying before it is downloaded into
      another anonymous pile.
    """
    have_file = track is not None and track.local_path is not None
    in_rb = track is not None and track.in_rekordbox
    if in_rb:
        return ()
    owed = []
    if not have_file:
        owed.append("download")
    if not destination:
        owed.append("destination")
    owed.append("rekordbox")
    return tuple(owed)


@dataclass
class Item:
    """One row of the lane, whichever side of the app it came from."""
    key: str                      # stable row id: the file path, else a Spotify id
    title: str
    artist: str
    source: str                   # the drawer entry this row belongs to
    needs: tuple[str, ...]
    destination: Optional[str] = None   # the rekordbox playlist it's heading for
    arrived: float = 0.0          # file mtime; 0 for something not fetched yet
    track: Optional[object] = None    # library.Track, when anything local/rekordbox answers
    # The `sync.SyncRow` this came from, when it came from a source's gap. Kept
    # whole rather than flattened: it carries the set-membership decision and the
    # match score, which only mean something for a source and which the export
    # still needs. A row from a folder simply hasn't got one.
    row: Optional[object] = None
    index: int = -1               # position in that source's rows, for the set toggle
    # The collection track this one looks like (`dupes.Existing`), when the
    # duplicate scan has run and found one. Not a step and not something owed —
    # an *answer about* a row that owes a destination, which is why `needs`
    # knows nothing about it. See `scan_duplicates`.
    have: Optional[object] = None

    @property
    def spotify(self):
        return self.row.spotify if self.row is not None else None

    @property
    def display(self) -> str:
        return f"{self.artist} - {self.title}" if self.artist else self.title

    @property
    def ready(self) -> bool:
        return not self.needs

    @property
    def next_step(self) -> Optional[str]:
        return self.needs[0] if self.needs else None

    @property
    def chip(self) -> str:
        """The one word this row wears: what it needs next."""
        return STEP_LABELS[self.needs[0]] if self.needs else "ready"

    @property
    def summary(self) -> str:
        """What this row is waiting for, in words."""
        if not self.needs:
            return "ready"
        return " and then ".join(STEP_LABELS[s] for s in self.needs)

    @property
    def duplicate(self) -> bool:
        """A redundant second copy of something the collection already holds.

        Deliberately narrow. `have.certain` already excludes a weak name score,
        a disagreeing remix credit and a length gap wide enough to mean a
        different edit; this adds that the file it points at still exists, and
        that the length was actually *checked*.

        That last one matters because `different_edit` is false both when the
        lengths agree and when nobody could read them, and those are opposite
        situations. `certain` can't make the distinction — it is also asked
        before a download exists, where there is no file to measure and a name
        match is the best answer available. Here both files are on disk, so an
        unreadable one means something is wrong with it, and a row we have only
        a name for has no business in a pile that gets discarded in bulk.

        Every case this excludes stays in the filing worklist wearing its chip,
        rather than being swept into a pile labelled "you already have these" —
        the one label that would invite discarding them all.
        """
        return (self.have is not None and self.have.certain
                and not self.have.missing_file
                and self.have.delta_s is not None)

    @property
    def heals(self) -> bool:
        """This file replaces one rekordbox has lost — keep it, don't discard it."""
        return self.have is not None and self.have.missing_file

    @property
    def better_edit(self) -> bool:
        """A longer cut than the one in the collection — usually the extended
        mix against a radio edit, and the one case where a name match saying
        "you already have this" is not just useless but backwards."""
        return (self.have is not None and self.have.different_edit
                and self.have.longer)

    @property
    def local_path(self):
        return self.track.local_path if self.track else None

    @property
    def bpm(self):
        return self.track.bpm if self.track else None

    @property
    def camelot(self):
        return (self.track.key if self.track else None) or ""

    @property
    def energy(self):
        return self.track.energy if self.track else None


def _mtime(track) -> float:
    try:
        return track.local_path.stat().st_mtime if track and track.local_path else 0.0
    except OSError:
        return 0.0


def _key_for(track, spotify) -> str:
    if track is not None and track.local_path:
        return str(track.local_path).lower()
    if track is not None and track.rekordbox_id:
        return f"rb:{track.rekordbox_id}"
    if spotify is not None:
        return f"sp:{spotify.id}"
    return f"id:{id(track)}"


def of_track(track, source: str, destination: Optional[str] = None) -> Item:
    """A lane row for a library track — a downloaded file, or a rekordbox entry."""
    return Item(key=_key_for(track, None), title=track.title, artist=track.artist,
                source=source, needs=needs(track, destination),
                destination=destination, arrived=_mtime(track), track=track)


def of_row(row, source: str, index: int = -1, destination: Optional[str] = None) -> Item:
    """A lane row for a `sync.SyncRow` — what a source wants, matched or not.

    The track side is whichever of the row's matches exists: the downloaded file
    first, then the rekordbox entry. Neither means nothing has answered to it
    yet, which is exactly a row that owes all three steps.

    **A collection match that is a different edit does not answer the row.** It
    matched on name, but you own a different record — so the row still owes a
    download, and letting the rekordbox entry stand in for it is precisely how
    the longer version goes unnoticed (`sync.SyncRow.other_edit`). A file you
    have actually downloaded still answers, whatever the collection holds.

    The Spotify name wins over the matched track's for display, because that is
    the name you know it by in the playlist you are working from.
    """
    sp = row.spotify
    answers = row.local_match or (None if getattr(row, "other_edit", False)
                                  else row.collection_match)
    named = row.local_match or row.collection_match   # for a name to show
    title = sp.name if sp else (named.title if named is not None else "")
    artist = (", ".join(sp.artists) if sp
              else (named.artist if named is not None else ""))
    return Item(key=_key_for(answers or named, sp), title=title, artist=artist,
                source=source, needs=needs(answers, destination),
                destination=destination, arrived=_mtime(answers),
                track=answers, row=row, index=index)


def from_folders(folders: dict[str, list], destination_of=None) -> list[Item]:
    """Lane rows out of the download folders — the ones with files already.

    `destination_of(folder) -> str | None` says where that folder's tracks are
    heading; a folder named after the door they came through answers None, and
    everything in it owes a destination. See `destinations.of_folder`.
    """
    return [of_track(t, name, destination_of(name) if destination_of else name)
            for name, tracks in folders.items() for t in tracks]


def from_gap(rows, source: str, destination: Optional[str] = None) -> list[Item]:
    """Lane rows out of a source's computed gap (`sync.compute_sync`).

    Every row, including the ones that live in the rekordbox set but not in the
    source: they owe nothing, so `merge` drops them from the lane, but a page
    showing one source wants them on screen — they are what the export would
    carry, and silently hiding them is how a track gets clipped out of a set.
    """
    return [of_row(r, source, i, destination) for i, r in enumerate(rows)]


def merge(*groups: list[Item]) -> list[Item]:
    """One lane out of several feeds, deduped, in the order the work happens.

    First writer wins, so a caller passes the feed with the better provenance
    first: a track downloaded *for* a Spotify playlist should say so rather than
    read as an anonymous file in a folder.

    Sorted by step rather than by arrival — the lane is a worklist, so
    everything waiting on the same thing sits together and the top of the list
    is the next thing to do.
    """
    out: list[Item] = []
    seen: set = set()
    for group in groups:
        for item in group:
            if item.key in seen or item.ready:
                continue
            seen.add(item.key)
            out.append(item)
    out.sort(key=lambda i: (STEPS.index(i.needs[0]), -i.arrived, i.display.lower()))
    return out


def _duration(path) -> Optional[float]:
    """A file's length in seconds, or None if it can't be read."""
    if not path:
        return None
    from library import file_duration
    return file_duration(path)


def scan_duplicates(items: list[Item], index) -> dict[str, object]:
    """Which of these is the collection already holding? Keyed by `Item.key`.

    `index` is a `dupes.Index` over the whole library. The lookup is pinned to
    the rekordbox pool, which is both the question being asked ("is this already
    in my collection?") and the only way to get an answer at all — see
    `dupes.Index.lookup`, where a candidate that is itself in the library
    otherwise matches itself.

    **A name match is then checked against the two files' actual lengths**, and
    that second question is not optional: the normalizer treats "Extended Mix"
    and "Radio Edit" as noise, so the two score 100 against each other and a
    7-minute extended reads as a redundant copy of the 3½-minute edit already in
    the collection. Duration is measured off the audio and settles it. Only a
    hit pays for the read, so this costs two header reads per *match*, not per
    row (~1s for a thousand matches).

    Expensive overall: a fuzzy pass over the collection per row (~2ms against
    2.5k tracks). Run it off the event loop and cache the result by key — never
    once per render.
    """
    import dupes

    found: dict[str, object] = {}
    for item in items:
        t = item.track
        e = index.lookup(item.artist, item.title,
                         getattr(t, "isrc", None) if t is not None else None,
                         where=dupes.REKORDBOX)
        if e is None:
            continue
        mine = _duration(item.local_path)
        theirs = _duration(getattr(e.track, "local_path", None))
        if mine is not None and theirs is not None:
            e.candidate_s, e.delta_s = mine, mine - theirs
        found[item.key] = e
    return found


def apply_duplicates(items: list[Item], found: dict) -> None:
    """Re-attach a cached scan to a freshly-built lane. Cheap; every render.

    The lane is rebuilt from scratch on every render, so the annotation has to
    be re-applied rather than stored on the items — the same reason a page's
    working state lives in `runtime`.
    """
    if not found:
        return
    for item in items:
        item.have = found.get(item.key)


def by_source(items: list[Item]) -> list[tuple[str, list[Item]]]:
    """The lane grouped back into its sources, in first-seen order.

    The grouping survives because the *export* is per source: a batch goes into
    rekordbox under the playlist it is paired to (`sources.rb_name_for_folder`),
    and merging two into one import would fork a playlist instead of updating it.
    """
    order: list[str] = []
    groups: dict[str, list[Item]] = {}
    for i in items:
        if i.source not in groups:
            groups[i.source] = []
            order.append(i.source)
        groups[i.source].append(i)
    return [(name, groups[name]) for name in order]


def owed(items: list[Item], step: str) -> list[Item]:
    """The rows still waiting on one step."""
    return [i for i in items if step in i.needs]


def counts(items: list[Item]) -> dict[str, int]:
    """How many rows owe each step."""
    return {s: len(owed(items, s)) for s in STEPS}


def summary(items: list[Item]) -> str:
    """What's left, in one line: "6 to get · 12 to analyze · 19 to import".

    No total — whatever renders this already shows how many rows there are, and
    the interesting number is how much work is left, not how much arrived.
    """
    c = counts(items)
    return "  ·  ".join(f"{c[s]} to {STEP_LABELS[s]}" for s in STEPS if c[s])


if __name__ == "__main__":        # real numbers off the live library
    import destinations
    import runtime
    from sources import SourceStore

    runtime._bootstrap()
    known = destinations.known_names(runtime.library.rekordbox_index,
                                     SourceStore().list())
    lane = merge(from_folders(runtime.incoming_batches,
                              lambda f: destinations.of_folder(f, known)))
    print(f"{len(lane)} incoming  ·  {summary(lane) or 'nothing owed'}")
    for name, group in by_source(lane):
        going = group[0].destination or "— needs a home —"
        print(f"\n{name}  ({len(group)})  →  {going}")
        for item in group[:6]:
            print(f"  {item.chip:7s} {item.summary:22s} {item.display[:52]}")
