"""Library domain layer — the single source of truth the UI renders.

A `Track` is one unified record merged across every source, keyed by ISRC:
    - descriptive metadata (title/artist) + the Comments-tag analysis from the
      local file (energy/style/mood) and provenance (isrc/beatport/spotify),
    - later: Spotify playlist membership and Beatport catalog fields.

`Library` holds the tracks and the operations that mutate them. The services
(energy / spotify / beatport / bpdl / match) stay stateless; the Library
orchestrates them. Persistence remains on-file in the Comments tag — this layer
is the in-memory view, rebuildable by re-scanning a folder.
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields as dc_fields
from pathlib import Path
from typing import Optional

from mutagen import File as MutagenFile

import drives
import tagcache
from energy import SUPPORTED_EXTS, find_audio_files
from tagging import parse_comment


# ----------------------------------------------------------------------
# Track aggregate
# ----------------------------------------------------------------------

@dataclass
class Track:
    """A track unified across local file, Spotify and Beatport."""
    # identity
    isrc: Optional[str] = None
    spotify_id: Optional[str] = None
    beatport_id: Optional[int] = None
    # descriptive
    title: str = ""
    artist: str = ""
    bpm: Optional[float] = None
    key: Optional[str] = None
    # The *vendor's* genre — rekordbox's Genre field, or the file's own tag
    # (Beatport writes its store genre into every download). Distinct from
    # `style` below, which is what our own analyzer heard in the audio: this one
    # covers most of the library and that one covers what has been analyzed.
    genre: str = ""
    # energy analysis (from the file's Comments tag)
    energy: Optional[int] = None
    arousal: Optional[float] = None
    valence: Optional[float] = None
    danceability: Optional[float] = None
    style: Optional[str] = None
    moods: list[str] = field(default_factory=list)
    # texture (DSP descriptors written by the analyzer; see energy.analyze)
    brightness: Optional[float] = None
    dynamic_complexity: Optional[float] = None
    spectral_complexity: Optional[float] = None
    onset_rate: Optional[float] = None
    # EBU R128 loudness (measured separately; see energy.extract_loudness)
    lufs: Optional[float] = None
    lra: Optional[float] = None
    true_peak: Optional[float] = None
    # local presence
    local_path: Optional[Path] = None
    # Where the file is when it's on a drive that isn't plugged in. Never set
    # together with `local_path`, which keeps meaning "a file we can read"
    # everywhere it is used; this one only says the file isn't *lost* (see
    # `drives`). Cleared by the re-merge that runs when the drive comes back.
    offline_path: Optional[Path] = None
    # spotify presence (in a playlist we want to source)
    in_playlists: list[str] = field(default_factory=list)
    # rekordbox presence — a distinct source with its own state + signal
    in_rekordbox: bool = False
    removed_from_rekordbox: bool = False   # was present in a prior snapshot, now gone
    rekordbox_id: Optional[str] = None
    rekordbox_playlists: list[str] = field(default_factory=list)
    rekordbox_rating: int = 0
    rekordbox_source_kind: Optional[str] = None  # local / foreign / streaming
    # The path exactly as rekordbox stores it, whether or not this machine can
    # read the file. An export names a track by its location and rekordbox
    # matches the entry on it, so this is what keeps a track in a playlist
    # whose file is missing here — `local_path` alone drops it from the xml,
    # and importing over the playlist then takes it out.
    rekordbox_location: Optional[str] = None

    @property
    def is_local(self) -> bool:
        return self.local_path is not None

    @property
    def export_location(self) -> Optional[Path]:
        """Where an exported xml should say this track is.

        The file we can read, else where it sits on an unplugged drive, else
        the path rekordbox has for it — the same string back, so the import
        lands on the entry it already holds. None for what an xml can't name:
        a streaming entry, or a path from another OS.
        """
        if self.local_path:
            return self.local_path
        if self.offline_path:
            return self.offline_path
        loc = self.rekordbox_location or ""
        return Path(loc) if loc.startswith("/") else None

    @property
    def analyzed(self) -> bool:
        return self.energy is not None

    @property
    def wanted(self) -> bool:
        """In at least one Spotify playlist we're sourcing."""
        return bool(self.in_playlists)

    @property
    def sync_status(self) -> str:
        """One-word state for the download pipeline (Spotify -> file)."""
        if not self.is_local:
            if self.offline_path:
                return "offline"      # on a drive that isn't plugged in
            return "missing"          # wanted, not yet downloaded
        if not self.analyzed:
            return "untagged"         # downloaded, not yet energy-analyzed
        return "ready"

    @property
    def rekordbox_status(self) -> str:
        """Independent rekordbox dimension: in / removed / absent."""
        if self.in_rekordbox:
            return "in"
        if self.removed_from_rekordbox:
            return "removed"          # the "was here, now gone" signal
        return "absent"

    @property
    def pipeline_status(self) -> str:
        """Sourcing pipeline (composes the file + rekordbox axes):
        missing (not downloaded) -> downloaded (local, not in rekordbox) -> in_rekordbox."""
        if not self.is_local:
            return "missing"
        if not self.in_rekordbox:
            return "downloaded"
        return "in_rekordbox"

    @property
    def display(self) -> str:
        return f"{self.artist} - {self.title}" if self.artist else self.title


# ----------------------------------------------------------------------
# Reading local files
# ----------------------------------------------------------------------

def _read_file_fields(path: Path) -> dict:
    """Tag fields from an audio file: artist, title, comment, bpm, key, isrc, genre.

    Downloaded (beatportdl) files carry BPM (`tmpo`/TBPM), a Camelot KEY and ISRC,
    so reading them here lets a freshly-downloaded track feed set building without
    a rekordbox round-trip. Falls back to the filename stem for the title.

    The genre is Beatport's own store genre on anything downloaded, and it is
    worth reading even for tracks rekordbox already knows: measured on this
    library, rekordbox's XML carries no Genre for 42% of the collection while the
    file underneath it often does.

    **Served from `tagcache` when the file has not changed.** This is the most
    called disk read in the app and nearly every call is a repeat — see that
    module for why, and for the `(size, mtime)` invalidation that makes a stale
    row impossible to serve rather than merely unlikely.
    """
    cached = tagcache.get(path)
    if cached is not None:
        cached.pop("duration", None)
        return cached
    out = _read_file_fields_uncached(path)
    tagcache.put(path, out, duration=out.pop("_duration", None))
    return out


def _read_file_fields_uncached(path: Path) -> dict:
    """The actual read. Also returns `_duration` — the header is already parsed
    here, so taking it now is free and saves `file_duration` a second open."""
    mf = MutagenFile(path)
    out = {"artist": "", "title": "", "comment": "",
           "bpm": None, "key": None, "isrc": None, "genre": ""}
    if mf is not None and mf.tags is not None:
        suffix = path.suffix.lower()
        if suffix == ".mp3":
            out["artist"] = _id3_text(mf, "TPE1")
            out["title"] = _id3_text(mf, "TIT2")
            out["comment"] = next(
                ("".join(str(s) for s in v.text)
                 for k, v in mf.tags.items() if k.startswith("COMM")), "")
            out["bpm"] = _to_float(_id3_text(mf, "TBPM"))
            out["key"] = _id3_text(mf, "TKEY") or None
            out["isrc"] = _id3_text(mf, "TSRC") or None
            out["genre"] = _id3_text(mf, "TCON")
        elif suffix == ".m4a":
            out["artist"] = (mf.tags.get("\xa9ART") or [""])[0]
            out["title"] = (mf.tags.get("\xa9nam") or [""])[0]
            out["comment"] = (mf.tags.get("\xa9cmt") or [""])[0]
            tmpo = mf.tags.get("tmpo")
            out["bpm"] = float(tmpo[0]) if tmpo else None
            out["key"] = _mp4_freeform(mf, "KEY")
            out["isrc"] = _mp4_freeform(mf, "ISRC")
            out["genre"] = (mf.tags.get("\xa9gen") or [""])[0]
    if not out["title"]:
        out["title"] = path.stem
    try:
        out["_duration"] = float(mf.info.length) if (mf is not None and mf.info) else None
    except Exception:                    # noqa: BLE001 — a length is a bonus here
        out["_duration"] = None
    return out


def track_key(track) -> str:
    """How anything that stores a *reference* to a track names it.

    Rekordbox id first, because it survives the file being replaced — which is
    the whole point of `refetch.replace_in_place`, and means a crate holding a
    track still holds it after an upgrade swaps the audio underneath. Then
    ISRC, for something downloaded but not yet imported. Then the display name,
    which is a weak key and a last resort: two masters of the same title
    collide under it.

    Build's drafts have keyed tracks this way from the start (as
    `setline_import.set_track_id`, which now defers here). It lives in
    `library` because crates need it and the bridge modules are on their way
    out.
    """
    return track.rekordbox_id or track.isrc or track.display


def file_duration(path: Path) -> Optional[float]:
    """Track length in seconds read from the file on disk (mutagen header), or
    None if unreadable. Works for any local file — rekordbox-local or freshly
    downloaded — without a rekordbox round-trip.

    Cached: the Library and Build tables call this *per rendered row*, which is
    3 377 file opens to draw one table."""
    cached = tagcache.get(path)
    if cached is not None and cached.get("duration") is not None:
        return cached["duration"]
    try:
        mf = MutagenFile(path)
        dur = float(mf.info.length) if mf is not None and mf.info else None
        tagcache.put_duration(path, dur)
        return dur
    except Exception:
        return None


def _id3_text(mf, frame_id: str) -> str:
    frame = mf.tags.get(frame_id)
    return "".join(str(s) for s in frame.text) if frame else ""


def _to_float(s) -> Optional[float]:
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def _mp4_freeform(mf, name: str) -> Optional[str]:
    """Read an iTunes freeform MP4 atom (`----:com.apple.iTunes:<name>`)."""
    val = mf.tags.get(f"----:com.apple.iTunes:{name}")
    if not val:
        return None
    v = val[0]
    try:
        text = v.decode("utf-8", "ignore") if isinstance(v, bytes) else bytes(v).decode("utf-8", "ignore")
    except Exception:
        text = str(v)
    return text or None


def track_from_file(path: Path) -> Track:
    """Build a Track from a local audio file (tags + parsed Comments)."""
    f = _read_file_fields(path)
    parsed = parse_comment(f["comment"])
    return Track(
        isrc=parsed.get("isrc") or f["isrc"],
        spotify_id=parsed.get("spotify_id"),
        beatport_id=parsed.get("beatport_id"),
        title=f["title"],
        artist=f["artist"],
        bpm=f["bpm"],
        key=f["key"],
        genre=f["genre"],
        energy=parsed.get("energy"),
        arousal=parsed.get("arousal"),
        valence=parsed.get("valence"),
        danceability=parsed.get("danceability"),
        style=parsed.get("style"),
        moods=parsed.get("moods", []),
        brightness=parsed.get("brightness"),
        dynamic_complexity=parsed.get("dynamic_complexity"),
        spectral_complexity=parsed.get("spectral_complexity"),
        onset_rate=parsed.get("onset_rate"),
        lufs=parsed.get("lufs"),
        lra=parsed.get("lra"),
        true_peak=parsed.get("true_peak"),
        local_path=path,
    )


def fill_from_comment(t: Track, comment: str) -> bool:
    """Backfill a Track's energy/style/provenance from a Comments string,
    only filling fields that are currently empty. Returns True if energy found."""
    parsed = parse_comment(comment)
    if not parsed:
        return False
    if t.energy is None and "energy" in parsed:
        t.energy = parsed["energy"]
    if t.arousal is None and "arousal" in parsed:
        t.arousal = parsed["arousal"]
    if t.valence is None and "valence" in parsed:
        t.valence = parsed["valence"]
    if t.danceability is None and "danceability" in parsed:
        t.danceability = parsed["danceability"]
    if not t.style and parsed.get("style"):
        t.style = parsed["style"]
    if not t.moods and parsed.get("moods"):
        t.moods = parsed["moods"]
    if t.brightness is None and "brightness" in parsed:
        t.brightness = parsed["brightness"]
    if t.dynamic_complexity is None and "dynamic_complexity" in parsed:
        t.dynamic_complexity = parsed["dynamic_complexity"]
    if t.spectral_complexity is None and "spectral_complexity" in parsed:
        t.spectral_complexity = parsed["spectral_complexity"]
    if t.onset_rate is None and "onset_rate" in parsed:
        t.onset_rate = parsed["onset_rate"]
    for _k in ("lufs", "lra", "true_peak"):
        if getattr(t, _k) is None and _k in parsed:
            setattr(t, _k, parsed[_k])
    if not t.isrc and parsed.get("isrc"):
        t.isrc = parsed["isrc"]
    if not t.beatport_id and parsed.get("beatport_id"):
        t.beatport_id = parsed["beatport_id"]
    if not t.spotify_id and parsed.get("spotify_id"):
        t.spotify_id = parsed["spotify_id"]
    return "energy" in parsed


def read_comment_into_track(t: Track) -> bool:
    """Read the file's tags into a Track (energy Comments + bpm/key/isrc if missing).
    Returns True if energy found."""
    if not t.local_path:
        return False
    try:
        f = _read_file_fields(t.local_path)
    except Exception:
        return False
    if t.bpm is None and f["bpm"]:
        t.bpm = f["bpm"]
    if not t.key and f["key"]:
        t.key = f["key"]
    if not t.isrc and f["isrc"]:
        t.isrc = f["isrc"]
    if not t.genre and f["genre"]:
        t.genre = f["genre"]
    return fill_from_comment(t, f["comment"])


# ----------------------------------------------------------------------
# Library
# ----------------------------------------------------------------------

class Library:
    """In-memory collection of tracks plus the operations that act on them."""

    def __init__(self) -> None:
        self.tracks: list[Track] = []
        self.folder: Optional[Path] = None
        # rekordbox playlist tree (set on merge_rekordbox)
        self.rekordbox_roots: list = []
        self.rekordbox_index: dict = {}

    def load_folder(self, folder: Path) -> "Library":
        """Scan a folder of audio files into Track records (local source only).

        Resets any prior rekordbox merge — call merge_rekordbox() again after to
        re-overlay rekordbox state onto the freshly-scanned files.
        """
        self.folder = Path(folder)
        self.tracks = [track_from_file(p) for p in find_audio_files(self.folder)]
        self.rekordbox_roots = []
        self.rekordbox_index = {}
        return self

    def add_folder(self, folder: Path) -> int:
        """Append a folder's audio files (deduped by path) without resetting the
        library — for staging / extra tracks that aren't in rekordbox yet. Returns
        the number of new tracks added."""
        self.folder = Path(folder)
        existing = {self._norm_path(t.local_path) for t in self.tracks if t.local_path}
        added = 0
        for p in find_audio_files(self.folder):
            if self._norm_path(p) not in existing:
                self.tracks.append(track_from_file(p))
                added += 1
        return added

    # -- rekordbox merge ----------------------------------------------------

    @staticmethod
    def _norm_path(p: Optional[Path]) -> Optional[str]:
        """Normalize a path for matching (macOS filesystem is case-insensitive)."""
        if not p:
            return None
        return str(Path(p)).lower()

    def merge_rekordbox(self, collection, snapshot=None) -> dict[str, int]:
        """Fold a RekordboxCollection into the Tracks and apply the removed signal.

        Local rekordbox entries join existing local Tracks by path; entries we
        don't have locally (foreign-OS, streaming, or files outside the loaded
        folder) are added as rekordbox-only Tracks. Tracks seen in a previous
        snapshot but absent now are flagged `removed_from_rekordbox`.

        Returns a small stats dict for the UI.
        """
        stats = {"matched": 0, "added": 0, "removed": 0}
        # Idempotent: drop any rekordbox-only/ghost rows and clear rb flags so a
        # re-merge (e.g. bootstrap then manual reload) doesn't duplicate rows.
        self.tracks = [t for t in self.tracks if t.local_path is not None]
        for t in self.tracks:
            t.in_rekordbox = False
            t.removed_from_rekordbox = False
            t.rekordbox_id = None
            t.rekordbox_playlists = []
            t.rekordbox_rating = 0
            t.rekordbox_source_kind = None
            t.rekordbox_location = None
        self.rekordbox_roots = collection.playlist_roots
        self.rekordbox_index = collection.playlist_index
        by_path = {self._norm_path(t.local_path): t
                   for t in self.tracks if t.local_path}

        for rb in collection.tracks.values():
            target = by_path.get(self._norm_path(rb.location)) if rb.is_local_file else None
            if target is None:
                # rekordbox-only: keep the local_path only if the file truly exists,
                # but remember where it is when its drive is merely unplugged.
                lp = rb.location if (rb.is_local_file and rb.location and rb.location.exists()) else None
                away = rb.location if (lp is None and rb.is_local_file
                                       and drives.offline(rb.location)) else None
                target = Track(title=rb.name, artist=rb.artist, local_path=lp,
                               offline_path=away)
                self.tracks.append(target)
                stats["added"] += 1
            else:
                stats["matched"] += 1
            target.in_rekordbox = True
            target.rekordbox_id = rb.track_id
            target.rekordbox_playlists = rb.playlists
            target.rekordbox_rating = rb.rating
            target.rekordbox_source_kind = rb.source_kind
            target.rekordbox_location = rb.raw_path or (str(rb.location) if rb.location else None)
            # rekordbox carries its own analysis — backfill where we lack it.
            if target.bpm is None and rb.bpm:
                target.bpm = rb.bpm
            if not target.key and rb.key:
                target.key = rb.key
            # Genre: rekordbox's wins when it has one, because that one the user
            # can edit; the file's tag fills the 42% where the XML is blank.
            if rb.genre:
                target.genre = rb.genre
            # Free energy backfill from rekordbox's cached Comments (avoids a file
            # read); hydrate_local_energy() fills the rest from the files later.
            if target.energy is None and rb.comment:
                fill_from_comment(target, rb.comment)

        # Removed signal: durable diff against the persisted snapshot.
        if snapshot is not None:
            removed = snapshot.update(collection)
            existing_rb_ids = {t.rekordbox_id for t in self.tracks if t.rekordbox_id}
            for entry in removed:
                if entry.track_id in existing_rb_ids:
                    continue  # somehow still present; skip
                # If the file still exists locally, flag that Track; else a ghost.
                local = by_path.get(self._norm_path(Path(entry.path))) if entry.path.startswith("/") else None
                target = local or Track(title=entry.name, artist=entry.artist)
                if local is None:
                    self.tracks.append(target)
                target.removed_from_rekordbox = True
                target.rekordbox_id = entry.track_id
                target.rekordbox_source_kind = entry.source_kind
                stats["removed"] += 1

        return stats

    # -- energy hydration ----------------------------------------------------

    def hydrate_local_energy(self, only_missing: bool = True, progress=None) -> dict:
        """Read file Comments into Tracks that have a real local file but no energy.

        Slow (one mutagen read per file) — call on a background thread, never in
        bootstrap. `progress(done, total)` is invoked as it goes.
        """
        targets = [t for t in self.tracks
                   if t.local_path and t.local_path.exists()
                   and (not only_missing or t.energy is None)]
        total = len(targets)
        tagged = 0
        for i, t in enumerate(targets):
            if read_comment_into_track(t):
                tagged += 1
            if progress:
                progress(i + 1, total)
        return {"read": total, "tagged": tagged}

    def hydrate_genres(self, tracks=None) -> int:
        """Read the genre tag off disk for tracks that have a file but no genre.

        Needed because rekordbox is the *poorer* source here: its XML carries no
        Genre for 42% of this collection, and a track that came in through the
        rekordbox merge never has its file read, so a Beatport download the user
        has since imported ends up with the genre sitting in the file and
        nothing in the app. The seed of a crate is exactly that case, and a seed
        with no genre turns the whole genre axis off (see `mixmodel._kinship`).

        Targeted on purpose. Measured here: **~18 ms per file cold, ~1.4 ms once
        the OS has the file cached** — so the cost depends entirely on whether
        this is the first read since boot (and a file on the shared drive is
        worse than either). On a random sample of the 954 genre-less tracks only
        5% had a genre in the file, so a blanket pass is 5–17 seconds to gain
        ~48 tracks, while the handful in a crate is a third of a second to decide
        whether the ranking has a style axis at all. Pass `tracks` to say which;
        the default is the whole library, for a caller that has a background
        thread and means it.
        """
        targets = [t for t in (self.tracks if tracks is None else tracks)
                   if not t.genre and t.local_path]
        filled = 0
        for t in targets:
            try:
                if not t.local_path.exists():
                    continue
                g = _read_file_fields(t.local_path).get("genre") or ""
            except Exception:
                continue
            if g:
                t.genre = g
                filled += 1
        return filled

    # -- set building --------------------------------------------------------

    @staticmethod
    def _to_mix_track(t: "Track"):
        import microsets
        return microsets.Track(
            id=t.rekordbox_id or t.isrc or t.display,
            name=t.title,
            artist=t.artist,
            bpm=t.bpm,
            key=t.key or "",
            genre=t.genre or "",
            energy=t.energy,
            arousal=t.arousal,
            valence=t.valence,
            danceability=t.danceability,
            style=t.style,
            moods=list(t.moods),
            brightness=t.brightness,
            dynamic_complexity=t.dynamic_complexity,
            spectral_complexity=t.spectral_complexity,
            onset_rate=t.onset_rate,
            path=t.local_path,
        )

    def mix_tracks_from(self, tracks: list["Track"]):
        """Map an arbitrary Track list to the set-building `microsets.Track`.

        BPM is required — without a tempo a track can't be placed in a block or
        scored against a neighbour. Returns (included, excluded)."""
        included, excluded = [], []
        for t in tracks:
            (excluded if t.bpm is None else included).append(
                t if t.bpm is None else self._to_mix_track(t))
        return included, excluded

    def mix_tracks(self, node_id: str):
        """A rekordbox playlist's tracks, ready for set building (bpm required)."""
        return self.mix_tracks_from(self.tracks_in_playlist(node_id))

    # -- download batches (pending, not-yet-in-rekordbox) --------------------

    def scan_download_batches(self, dl_root: Path, *, pending_only: bool = True
                              ) -> list[tuple[str, list["Track"]]]:
        """Each immediate subfolder of dl_root is a download batch. Load its audio
        into the library (deduped by path) and return (batch_name, tracks).

        `pending_only` (the default) keeps what "a batch" has always meant to the
        batch pool and the Sync gap: only tracks that have a local file but
        aren't in rekordbox, and only folders that still have some. Pass False
        for the whole folder — the Incoming lane needs the imported ones too,
        since a track imported before it was analyzed is exactly the one that
        would otherwise drop out of sight unfinished (see `incoming`)."""
        out: list[tuple[str, list[Track]]] = []
        dl_root = Path(dl_root)
        if not dl_root.is_dir():
            return out
        by_path = {self._norm_path(t.local_path): t
                   for t in self.tracks if t.local_path}
        for sub in sorted(dl_root.iterdir(), key=lambda p: p.name.lower()):
            if not sub.is_dir() or sub.name.startswith("."):
                continue
            batch: list[Track] = []
            for p in find_audio_files(sub):
                key = self._norm_path(p)
                t = by_path.get(key)
                if t is None:
                    t = track_from_file(p)
                    self.tracks.append(t)
                    by_path[key] = t
                batch.append(t)
            keep = [t for t in batch if not t.in_rekordbox] if pending_only else batch
            if keep:
                out.append((sub.name, keep))
        return out

    # -- playlist-tree navigation -------------------------------------------

    def playlist_tree_nodes(self) -> list[dict]:
        """rekordbox tree as NiceGUI ui.tree nodes (id/label/children + kind)."""
        def conv(n) -> dict:
            cnt = len(n.all_track_ids()) if n.is_folder else len(n.track_ids)
            return {
                "id": n.id,
                "label": f"{n.name}  ({cnt})",
                "kind": n.kind,
                "children": [conv(c) for c in n.children],
            }
        return [conv(r) for r in self.rekordbox_roots]

    def tracks_in_playlist(self, node_id: str) -> list["Track"]:
        """Tracks in a playlist node (folders include all descendants)."""
        node = self.rekordbox_index.get(node_id)
        if node is None:
            return []
        ids = node.all_track_ids()
        return [t for t in self.tracks if t.rekordbox_id in ids]

    def playlist_named(self, name: str, prefer: Optional[str] = None):
        """The rekordbox playlist an xml import called `name` lands on.

        Found by name, because a name is all an import carries: importing a
        playlist and dragging it over the old one gives it a new id every
        time, so a pairing's id goes stale on every round trip. `prefer` (the
        pairing) settles which one when several share the name. Folders and
        smart playlists don't count — an import replaces neither.
        """
        key = (name or "").strip().lower()
        if not key:
            return None
        found = [n for n in self.rekordbox_index.values()
                 if not n.is_folder and not n.is_smart and n.name.strip().lower() == key]
        return next((n for n in found if n.id == prefer), found[0] if found else None)

    def playlist_entries(self, node_id: str) -> list["Track"]:
        """A playlist's tracks in rekordbox's order (`tracks_in_playlist` is
        library order, which is fine for a set but not for an export)."""
        node = self.rekordbox_index.get(node_id)
        if node is None or node.is_folder:
            return []
        by_id = {t.rekordbox_id: t for t in self.tracks if t.rekordbox_id}
        return [by_id[i] for i in dict.fromkeys(node.track_ids) if i in by_id]

    # -- summary helpers used by the UI -------------------------------------

    def counts(self) -> dict[str, int]:
        c = {"total": len(self.tracks), "ready": 0, "untagged": 0, "missing": 0,
             "offline": 0}
        for t in self.tracks:
            c[t.sync_status] += 1
        return c


TRACK_FIELDS = [f.name for f in dc_fields(Track)]
__all__ = ["Track", "Library", "track_from_file", "SUPPORTED_EXTS"]
