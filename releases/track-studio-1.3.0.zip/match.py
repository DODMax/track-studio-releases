"""Fuzzy + exact track matching across sources.

Two jobs:
  - Spotify -> Beatport: ISRC exact first, fuzzy artist+title fallback (download
    resolution; precise).
  - Spotify -> rekordbox: fuzzy artist+title only (rekordbox stores no ISRC and
    the legacy library predates our provenance), producing a confidence score so
    low-confidence matches can be flagged rather than silently trusted.

Normalization strips feat./remix noise and punctuation so "Artist - Title
(Extended Mix)" lines up with rekordbox's "Title" + Artist fields.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Sequence

from rapidfuzz import fuzz, process

# Strip the whole "feat. <artist>" clause (up to a bracket/dash), not just the
# keyword — the featured artist lives in the artist field on the Spotify side, so
# "Wolf feat. Bonnie Spacey (Kiko Remix)" must reduce to "Wolf (Kiko Remix)".
_FEAT = re.compile(r"\b(?:feat|ft|featuring)\b\.?\s*[^()\[\]\-]*", re.IGNORECASE)
# Spotify's spelling of a collaboration: "Good Things Fall Apart (with Jon
# Bellion)". Only in brackets — "with" loose in a title is usually the title.
_WITH = re.compile(r"[(\[]\s*(?:with|w/)\s[^)\]]*[)\]]", re.IGNORECASE)
_NONWORD = re.compile(r"[^a-z0-9 ]+")
_WS = re.compile(r"\s+")
# Generic mix qualifiers — drop so "Title (Original Mix)" == "Title", but NOT
# "remix" (a remix is a different track) or a remixer's name. "Mixed" is
# Spotify's tag for a track as it appears inside a DJ mix ("Title - Mixed"):
# the same record, cut to fit a compilation.
_MIX = re.compile(
    r"\b(original|extended|radio|club|dub|instrumental|acoustic|vocal|edit|mix|mixed|version)\b",
    re.IGNORECASE)


def normalize(artist: str, title: str) -> str:
    """Collapse 'artist title' into a comparable token string."""
    s = f"{artist} {title}".lower()
    s = _WITH.sub(" ", s)
    s = _FEAT.sub(" ", s)
    s = s.replace("&", " and ")
    s = _NONWORD.sub(" ", s)
    return _WS.sub(" ", s).strip()


def _norm_part(s: str) -> str:
    """Normalize a single field (artist OR title), stripping generic mix tags."""
    s = (s or "").lower()
    s = _WITH.sub(" ", s)
    s = _FEAT.sub(" ", s)
    s = s.replace("&", " and ")
    s = _MIX.sub(" ", s)
    s = _NONWORD.sub(" ", s)
    return _WS.sub(" ", s).strip()


def record_key(artist: str, title: str) -> str:
    """A "same record" key: artist + title with generic mix qualifiers stripped.

    "Xique-Xique - Quem Sou Eu" and "Xique-Xique - Quem Sou Eu (Original Mix)"
    share one, which is the point — this library holds ~931 duplicate pairs, so
    anything that ranks or lists tracks has to be able to say "that is the one
    I already have" without a fuzzy match. A *remix* keeps its own key: the
    remixer's name survives `_norm_part` (see `_MIX`).

    Exact, not fuzzy: cheap enough to call on every track in the library, and
    wrong in the safe direction — it misses a pair spelled differently rather
    than merging two records that aren't the same.
    """
    return f"{_norm_part(artist)}|{_norm_part(title)}"


def prep_choices(items) -> list[tuple[str, str]]:
    """Pre-normalize (artist, title) pairs once for reuse across many queries."""
    return [(_norm_part(a), _norm_part(t)) for a, t in items]


def match_track(q_artist: str, q_title: str, choices: Sequence[tuple[str, str]],
                *, title_min: float = 80.0, artist_min: float = 58.0,
                cutoff: float = 78.0) -> Match:
    """Match a track against pre-normalized (artist, title) `choices`.

    Title and artist are scored *independently* and both must clear a bar, with
    the title dominant. This avoids the token_set_ratio trap where a shared
    artist ("Far&High") or one common title word ("This Feeling") alone produced
    a false match against an entirely different track. Titles use token_sort
    (penalizes extra/missing words, so "X" ≠ "X (Korolova Remix)"); artists use
    the lenient token_set (multi-artist orderings vary)."""
    qt, qa = _norm_part(q_title), _norm_part(q_artist)
    if not qt:
        return Match(query=f"{qa} {qt}".strip(), target_index=None, score=0.0)
    best_idx, best_score = None, 0.0
    for idx, (ca, ct) in enumerate(choices):
        score = _pair(qa, qt, ca, ct, title_min, artist_min)
        if score > best_score:
            best_idx, best_score = idx, score
    if best_idx is None or best_score < cutoff:
        return Match(query=f"{qa} {qt}".strip(), target_index=None, score=best_score)
    return Match(query=f"{qa} {qt}".strip(), target_index=best_idx, score=best_score)


def _pair(qa: str, qt: str, ca: str, ct: str,
          title_min: float, artist_min: float) -> float:
    """`match_track`'s score for one already-normalized pair; 0 when either
    field misses its bar."""
    ts = fuzz.token_sort_ratio(qt, ct)
    if ts < title_min:
        return 0.0
    as_ = fuzz.token_set_ratio(qa, ca) if (qa and ca) else 0.0
    if as_ < artist_min:
        return 0.0
    return 0.65 * ts + 0.35 * as_


def pair_score(q_artist: str, q_title: str, c_artist: str, c_title: str,
               *, title_min: float = 80.0, artist_min: float = 58.0) -> float:
    """`match_track`'s judgement of one candidate, 0..100 (0 = not this record).

    For when every candidate's score matters rather than only the winner's —
    a store search returns the Original, the Extended and the Radio Edit of
    one record side by side, and choosing between them is a separate question
    from whether they are the record at all.
    """
    qt = _norm_part(q_title)
    if not qt:
        return 0.0
    return _pair(_norm_part(q_artist), qt, _norm_part(c_artist), _norm_part(c_title),
                 title_min, artist_min)


@dataclass
class Match:
    query: str
    target_index: Optional[int]   # index into the choices list, or None
    score: float                  # 0..100

    @property
    def hit(self) -> bool:
        return self.target_index is not None

    @property
    def confidence(self) -> str:
        if self.target_index is None:
            return "none"
        if self.score >= 92:
            return "high"
        if self.score >= 80:
            return "medium"
        return "low"


def best_match(query: str, choices: Sequence[str], cutoff: float = 78.0) -> Match:
    """Best fuzzy match of `query` among normalized `choices` (token-set ratio)."""
    res = process.extractOne(query, choices, scorer=fuzz.token_set_ratio,
                             score_cutoff=cutoff)
    if res is None:
        return Match(query=query, target_index=None, score=0.0)
    _, score, idx = res
    return Match(query=query, target_index=idx, score=score)


def match_many(queries: Sequence[str], choices: Sequence[str],
               cutoff: float = 78.0) -> list[Match]:
    """Match each query against the shared choice pool (choices normalized once)."""
    return [best_match(q, choices, cutoff=cutoff) for q in queries]
