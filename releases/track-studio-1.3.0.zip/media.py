"""The /media audio and /artwork cover endpoints — FastAPI routes on NiceGUI's
singleton `app`.

Named `media.py` (not `app.py`) to avoid colliding with the legacy Streamlit GUI's
`app.py` on import. Importing this module registers the routes as a side effect.

Both serve straight off disk and share one allowlist: a file the library knows
about. Neither is a general file server, and `/artwork` in particular must never
become one — it returns bytes out of the *inside* of a file, so a path it
accepts is a path it will read and hand over.
"""
from __future__ import annotations

import os
from collections import OrderedDict
from pathlib import Path

from fastapi.responses import FileResponse, Response
from nicegui import app

import runtime


# The allowlist, cached. Resolving every local path in the library costs ~53ms
# over 3 400 tracks, and this route is hit **once per audio element** — a table
# of fifty rows whose players preload metadata paid that fifty times over, which
# is what made a page freeze for seconds on open and again on every re-render.
# Keyed on the track count, so an added track (a fresh download) rebuilds it;
# a miss falls through to a direct check, so a stale cache can never wrongly
# refuse a file the library really does know about.
_allow: dict = {"n": -1, "paths": frozenset()}


def _allowed() -> frozenset:
    tracks = runtime.library.tracks
    if _allow["n"] != len(tracks):
        _allow["paths"] = frozenset(
            os.path.realpath(t.local_path) for t in tracks if t.local_path)
        _allow["n"] = len(tracks)
    return _allow["paths"]


def _known_to_library(real: str) -> bool:
    return any(t.local_path and os.path.realpath(t.local_path) == real
               for t in runtime.library.tracks)


def _permitted(path: str):
    """The real path, if the library knows this file. None otherwise."""
    real = os.path.realpath(path)
    if (real in _allowed() or _known_to_library(real)) and Path(real).is_file():
        return real
    return None


# Serve audio straight from disk — allowlist = any file the library knows about.
@app.get("/media")
def media(path: str):
    real = _permitted(path)
    return FileResponse(real) if real else Response(status_code=404)


# Cover art extracted from the file's own tags, cached. A crate shelf is dozens
# of cards, each asking for one, and pulling a picture out of an m4a means
# mutagen parsing the whole tag block — the same per-request cost that made
# `/media` freeze a page before it was cached. Bounded, because the values are
# images: ~50–200 KB each, so an unbounded dict over a 3 400-track library is
# several hundred MB of process memory for a screen that shows fifty.
_ART_CACHE: "OrderedDict[tuple[str, float], tuple[bytes, str] | None]" = OrderedDict()
_ART_CACHE_MAX = 256


# A card shows the sleeve at about 48px. Stores embed it at full resolution —
# measured over this library, 278 KB average — so serving the original would
# push ~11 MB for one shelf of forty cards to draw forty thumbnails. Downscaled
# once on the way out instead; Pillow is already a dependency (the app icon).
ART_PX = 160


def _thumb(data: bytes) -> tuple[bytes, str] | None:
    """Shrink a sleeve to `ART_PX`. Returns None if it isn't a readable image."""
    import io

    from PIL import Image
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception:          # noqa: BLE001 — a tag can hold anything
        return None
    if im.mode not in ("RGB", "L"):
        im = im.convert("RGB")
    im.thumbnail((ART_PX, ART_PX), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, format="JPEG", quality=82, optimize=True)
    return buf.getvalue(), "image/jpeg"


def _cover(real: str) -> tuple[bytes, str] | None:
    """(bytes, mime) of the embedded cover as a thumbnail, or None.

    Keyed on path + mtime, so a file replaced in place (see
    `refetch.replace_in_place`) stops serving the old record's sleeve.
    """
    try:
        key = (real, os.path.getmtime(real))
    except OSError:
        return None
    if key in _ART_CACHE:
        _ART_CACHE.move_to_end(key)
        return _ART_CACHE[key]

    raw: bytes | None = None
    try:
        from mutagen import File as MutagenFile
        mf = MutagenFile(real)
        tags = getattr(mf, "tags", None)
        if tags is not None:
            if real.lower().endswith(".m4a"):
                covr = tags.get("covr")
                if covr:
                    raw = bytes(covr[0])
            else:
                for k in tags.keys():
                    if k.startswith("APIC"):
                        raw = tags[k].data
                        break
    except Exception:          # noqa: BLE001 — no sleeve is not an error
        raw = None

    found = _thumb(raw) if raw else None
    _ART_CACHE[key] = found
    while len(_ART_CACHE) > _ART_CACHE_MAX:
        _ART_CACHE.popitem(last=False)
    return found


@app.get("/artwork")
def artwork(path: str):
    """The sleeve embedded in a track's tags. 404 when there isn't one — the
    card draws its own placeholder rather than being handed a blank image."""
    real = _permitted(path)
    if not real:
        return Response(status_code=404)
    found = _cover(real)
    if not found:
        return Response(status_code=404)
    data, mime = found
    # Immutable for a day: the URL carries the path, and the cache key carries
    # the mtime, so a changed file is a changed answer rather than a stale one.
    return Response(content=data, media_type=mime,
                    headers={"Cache-Control": "private, max-age=86400"})
