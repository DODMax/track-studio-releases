"""The learned model of how you actually mix — play history turned into advice.

`history.py` reconstructs what was played; this module learns from it. Every
piece of knowledge obeys one rule: **a one-off can be a miss — only repetition
across nights is proof.** Practicing means trying things, and some tries fail;
a transition played once is a weak hint, the same transition on two separate
nights is a habit.

Three layers of knowledge, from specific to general:

- **Pair evidence** — A→B actually played back-to-back. Confirmed (2+ nights)
  pairs get a strong boost and the teal ♥ in the UI; one-night pairs only
  nudge. The reverse direction and same-gig proximity count for less again.
  Measured on this library that's ~a dozen confirmed pairs — gold but sparse.
- **The move profile** — night-weighted distributions of the *kind* of move
  made: Camelot move class, |ΔBPM| bucket, Δenergy bucket. This is the
  generalizer that scores the ~100% of candidate pairs no history covers, by
  how much the move resembles the way you actually mix.
- **Playlist affinity** — which playlists source the same nights (again 2+
  shared gigs to count). Powers "often gigged with" pool suggestions.

Sits above `history` + `microsets`. Pages get a cached instance from
`runtime.mix_model()`. `microsets.compatibility` takes the model duck-typed
(it only calls `set_evidence`), so that module stays leaf.
"""
from __future__ import annotations

import math
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Iterable, Optional

import genres
import history
import vectors
from match import record_key as _match_record_key
from microsets import Track, _camelot_distance, _camelot_parse, _arousal_of


def _record_key(t: Track) -> str:
    """"Same record?" for a mix track — see `match.record_key`."""
    return _match_record_key(t.artist, t.name)


# ----------------------------------------------------------------------
# Evidence + suggestion records
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class PairEvidence:
    """Why a candidate pair has history behind it."""
    kind: str        # confirmed | once | reverse | pocket
    nights: int
    points: float    # additive boost on the 0..100 score

    @property
    def confirmed(self) -> bool:
        return self.kind == "confirmed"

    @property
    def label(self) -> str:
        if self.kind == "confirmed":
            return f"♥ {self.nights} nights"
        if self.kind == "once":
            return "played once"
        if self.kind == "reverse":
            return "played reversed"
        return "same pocket"


@dataclass(frozen=True)
class SetEvidence:
    """Aggregate play-history link between two blocks."""
    bonus: float     # capped additive bonus for microsets.compatibility
    confirmed: int   # max nights among confirmed pairs (0 = none)
    pairs: int       # played pairs linking the two sets (any strength)


@dataclass
class Suggestion:
    """One recommended next (or opening) track, with its explanation."""
    track: Track
    score: int
    pair: Optional[PairEvidence]
    typicality: float        # 0..1 — how much this move resembles real mixing
    favor_nights: int        # distinct nights the track was gigged
    reason: str              # one-line plain-language explanation
    # Only `fill` sets these: which member of the crate this sits closest to,
    # and how many members it has real play evidence with. A suggestion made
    # against a single current track has neither.
    seed: Optional[Track] = None
    seeds_played: int = 0
    # Cosine similarity to `seed` in the embedding space, when both have been
    # analyzed. None means "not analyzed", never "not similar".
    sound: Optional[float] = None

    @property
    def badge(self) -> Optional[str]:
        """The single strongest evidence label for the card's corner."""
        if self.seeds_played >= 2:
            return f"played with {self.seeds_played} of them"
        if self.sound is not None and self.sound >= 0.80:
            return "sounds like it"
        if self.pair is not None:
            return self.pair.label
        if self.typicality >= 0.75:
            return "typical move"
        if self.favor_nights >= 2:
            return "gig favorite"
        return None


# ----------------------------------------------------------------------
# Move classification (the profile's vocabulary)
# ----------------------------------------------------------------------

def _move_class(a_key: str, b_key: str) -> Optional[str]:
    """Coarse Camelot move class, or None if either key is unparseable."""
    pa, pb = _camelot_parse(a_key or ""), _camelot_parse(b_key or "")
    if pa is None or pb is None:
        return None
    (ha, ma), (hb, mb) = pa, pb
    hd = min((ha - hb) % 12, (hb - ha) % 12)
    md = 0 if ma == mb else 1
    if hd == 0:
        return "same" if md == 0 else "flip"
    if hd == 1:
        return "adjacent" if md == 0 else "diagonal"
    if hd == 2 and md == 0:
        return "two"
    return "off"


_MOVE_CLASSES = ("same", "adjacent", "flip", "diagonal", "two", "off")
_BPM_BUCKETS = ((0.0, 1.0), (1.0, 3.0), (3.0, 6.0), (6.0, 10.0), (10.0, 1e9))


def _bpm_bucket(delta: float) -> int:
    d = abs(delta)
    for i, (lo, hi) in enumerate(_BPM_BUCKETS):
        if lo <= d < hi:
            return i
    return len(_BPM_BUCKETS) - 1


def _energy_bucket(delta: int) -> int:
    return max(-3, min(3, delta))


def _typicality_weights(counts: Counter, keys: Iterable, alpha: float = 0.5,
                        sizes: Optional[dict] = None) -> dict:
    """Laplace-smoothed, occupancy-corrected, max-normalized weights.

    `sizes[k]` is how many raw outcomes bucket k aggregates (e.g. the "off"
    move class covers 16 of the 24 key relations; the 3-6 bpm bucket spans 3
    bpm). Dividing by it turns raw frequency into frequency *per option*, so a
    catch-all bucket can't out-score a specific habit just by being wide. The
    modal (per-option) move scores 1.0.
    """
    keys = list(keys)
    total = sum(counts.values())
    probs = {k: (counts.get(k, 0.0) + alpha) / (total + alpha * len(keys))
             / (sizes.get(k, 1.0) if sizes else 1.0)
             for k in keys}
    top = max(probs.values()) if probs else 1.0
    return {k: p / top for k, p in probs.items()}


# Occupancy of each move class within the 24 possible key relations (fixed
# source key: 12 hours x 2 modes), and each bpm bucket's width in bpm.
_MOVE_SIZES = {"same": 1, "flip": 1, "adjacent": 2, "diagonal": 2, "two": 2,
               "off": 16}
_BPM_SIZES = {0: 1.0, 1: 2.0, 2: 3.0, 3: 4.0, 4: 10.0}


# ----------------------------------------------------------------------
# The model
# ----------------------------------------------------------------------

# How far apart two tracks of one gig may sit and still count as "same pocket".
NEAR_WINDOW = 2
# A playlist must source at least this share of a gig to count as one of the
# night's sources (keeps huge catch-all playlists from claiming every gig).
SOURCE_MIN_SHARE = 0.15
# Openers = the first few tracks of a gig.
OPENER_SLOTS = 3
# How many of a crate's own tracks a candidate's score is averaged over, and
# how many are scored against at all. The ceiling is arithmetic: 3 500
# candidates against every member of a 200-track crate is a minute of work for
# a ranking that has stopped moving well before the sixteenth seed.
FILL_COUNTED = 3
FILL_MAX_SEEDS = 16


class MixModel:
    """Everything learned from the play log. Build with `build(...)`."""

    def __init__(self) -> None:
        self.gig_count = 0
        self.adj: dict[tuple[str, str], history.Transition] = {}
        self.near_nights: Counter = Counter()          # frozenset({a, b}) -> nights
        self.track_nights: Counter = Counter()         # track_id -> distinct gig days
        self.opener_nights: Counter = Counter()        # track_id -> nights opened
        self.move_w: dict = {}                          # move class -> 0..1
        self.bpm_w: dict = {}                           # bpm bucket -> 0..1
        self.energy_w: dict = {}                        # energy delta -> 0..1
        self.playlist_days: dict[str, set] = {}         # playlist path -> gig days

    # -- pair evidence ------------------------------------------------------

    def pair_evidence(self, a_id: str, b_id: str) -> Optional[PairEvidence]:
        """Strongest played-history link for the transition a→b, if any."""
        best: Optional[PairEvidence] = None

        def consider(ev: PairEvidence) -> None:
            nonlocal best
            if best is None or ev.points > best.points:
                best = ev

        fwd = self.adj.get((a_id, b_id))
        if fwd is not None:
            if fwd.nights >= 2:
                consider(PairEvidence("confirmed", fwd.nights,
                                      18.0 + 3.0 * min(fwd.nights - 2, 4)))
            else:
                consider(PairEvidence("once", 1, 6.0))
        rev = self.adj.get((b_id, a_id))
        if rev is not None:
            consider(PairEvidence("reverse", rev.nights,
                                  9.0 if rev.nights >= 2 else 3.0))
        near = self.near_nights.get(frozenset((a_id, b_id)), 0)
        if near:
            consider(PairEvidence("pocket", near, 5.0 if near >= 2 else 2.0))
        return best

    def set_evidence(self, a_ids: Iterable[str], b_ids: Iterable[str]) -> SetEvidence:
        """Aggregate evidence between two groups of tracks (block A → B)."""
        bonus, confirmed, pairs = 0.0, 0, 0
        for a in a_ids:
            for b in b_ids:
                ev = self.pair_evidence(a, b)
                if ev is None:
                    continue
                pairs += 1
                bonus += ev.points * 0.5
                if ev.confirmed:
                    confirmed = max(confirmed, ev.nights)
        return SetEvidence(bonus=min(12.0, bonus), confirmed=confirmed, pairs=pairs)

    # -- move profile -------------------------------------------------------

    def move_typicality(self, a: Track, b: Track) -> float:
        """0..1 — how typical the a→b move is of real play. 0.5 = no signal."""
        parts = []
        cls = _move_class(a.key, b.key)
        if cls is not None and self.move_w:
            parts.append(self.move_w.get(cls, 0.0))
        if a.bpm and b.bpm and self.bpm_w:
            parts.append(self.bpm_w.get(_bpm_bucket(b.bpm - a.bpm), 0.0))
        if a.energy is not None and b.energy is not None and self.energy_w:
            parts.append(self.energy_w.get(_energy_bucket(b.energy - a.energy), 0.0))
        return sum(parts) / len(parts) if parts else 0.5

    # -- track favor --------------------------------------------------------

    def favor(self, track_id: str) -> int:
        return self.track_nights.get(track_id, 0)

    def _favor_points(self, track_id: str) -> float:
        n = self.favor(track_id)
        return 4.0 * min(1.0, math.log1p(n) / math.log1p(5)) if n else 0.0

    # -- playlist affinity --------------------------------------------------

    def companions(self, paths, k: int = 4) -> list[tuple[str, float]]:
        """Playlists that sourced the same nights as `paths`, ranked.

        `paths` is one path or several (a selection's whole subtree, or a
        multi-playlist pool) — their gig nights are unioned, and the paths
        themselves are never returned as their own companions.

        Requires 2+ shared gigs — the outlier rule again: one shared night can
        be an odd gig, two is a pattern. Share is of the selection's own gigs.
        """
        if isinstance(paths, str):
            paths = [paths]
        mine_paths = set(paths)
        mine: set = set()
        for p in mine_paths:
            mine |= self.playlist_days.get(p, set())
        if not mine:
            return []
        out = []
        for other, days in self.playlist_days.items():
            if other in mine_paths:
                continue
            shared = len(mine & days)
            if shared >= 2:
                out.append((other, shared / len(mine), shared))
        out.sort(key=lambda x: (-x[2], -x[1], x[0]))
        return [(p, share) for p, share, _ in out[:k]]

    # -- recommendations ----------------------------------------------------

    def next_tracks(self, current: Track, candidates: list[Track], k: int = 3,
                    offset: int = 0, exclude: Iterable[str] = (),
                    energy_dir: int = 0, valence_dir: int = 0) -> list[Suggestion]:
        """Top candidates to play after `current`, best first.

        `energy_dir` steers the arc (+1 build, 0 hold, -1 cool); `valence_dir`
        steers brightness the same way. `offset` pages through the ranking
        ("More" in the UI). `exclude` = track ids already in the set.
        """
        skip = set(exclude) | {current.id}
        scored = []
        for cand in candidates:
            if cand.id in skip:
                continue
            skip.add(cand.id)          # dedup: a pool can list a track twice
            scored.append(self._suggest(current, cand, energy_dir, valence_dir))
        scored.sort(key=lambda s: -s.score)
        return scored[offset:offset + k]

    def fill(self, seeds: list[Track], candidates: list[Track], k: int = 10,
             offset: int = 0, exclude: Iterable[str] = ()) -> list[Suggestion]:
        """Tracks that belong with a whole crate, best first.

        Different question from `next_tracks`. A crate is not a sequence — it
        is a statement about a feel — so nothing here is about what follows
        what: each candidate is scored against the crate's own tracks and the
        answer is "does this belong with these?".

        How the members are combined is the whole design. Averaging over every
        one of them punishes a crate that deliberately holds two moods, and
        taking the single best match rewards an accidental twin — so the score
        is the mean of the best `FILL_COUNTED`. Fitting three of your Friday
        tracks is belonging; fitting exactly one is a coincidence.

        On top of that, play evidence with *several* members is worth more than
        a strong link to one, because it is the crate the evidence is about
        rather than a pair. `seeds_played` carries that to the UI.
        """
        held = list(seeds)
        seeds = held[:FILL_MAX_SEEDS]
        if not seeds:
            return []
        skip = set(exclude) | {s.id for s in held}
        # Duplicates are not a hypothetical here — this library holds ~931
        # pairs of the same record under two ids. Without this the first thing
        # a crate of "Quem Sou Eu" gets offered is "Quem Sou Eu (Original
        # Mix)", which is not a suggestion, it is the same track back. Both
        # halves matter: never propose a record the crate already holds, and
        # never propose the same record twice in one list.
        crate_records = {_record_key(s) for s in held}
        # Every seed-to-candidate similarity in one matrix multiply, once, here
        # — rather than a lookup per pair inside the scoring loop. Empty (and
        # falsy) when nothing involved has been analyzed yet, in which case the
        # sound axis simply never fires.
        space = vectors.SoundSpace([s.path for s in seeds],
                                   [c.path for c in candidates])
        scored: list[tuple[str, Suggestion]] = []
        for cand in candidates:
            if cand.id in skip:
                continue
            skip.add(cand.id)          # a library can list a track twice
            rk = _record_key(cand)
            if rk in crate_records:
                continue
            scored.append((rk, self._fit(seeds, cand, space)))
        scored.sort(key=lambda x: -x[1].score)
        out, seen = [], set()
        for rk, s in scored:           # best copy of each record wins
            if rk in seen:
                continue
            seen.add(rk)
            out.append(s)
        return out[offset:offset + k]

    def _fit(self, seeds: list[Track], cand: Track, space=None) -> Suggestion:
        """Score one candidate against the crate's tracks (see `fill`)."""
        per, played = [], 0
        for s in seeds:
            sound = space.get(s.path, cand.path) if space else None
            base, coverage = _kinship(s, cand, sound)
            # Symmetric on purpose: a crate has no direction, so the move is as
            # likely to be played the other way round.
            typ = max(self.move_typicality(s, cand), self.move_typicality(cand, s))
            pair = self.pair_evidence(s.id, cand.id)     # folds the reverse in
            # Coverage bites harder here than in a transition score: "same key,
            # same tempo, style unknown" is a *mixable stranger*, and offering
            # one as something that belongs in a crate is exactly the complaint
            # this scoring exists to answer.
            score = base * (0.6 + 0.4 * coverage) * (0.9 + 0.1 * typ)
            if pair is not None:
                played += 1
                score += pair.points
            per.append((score, s, typ, pair, sound))
        per.sort(key=lambda x: -x[0])
        top = per[:FILL_COUNTED]
        score = sum(p[0] for p in top) / len(top)
        # Half of what a transition suggestion gives it: "you play this a lot"
        # is a reason to remember a track, not evidence that it belongs with
        # these particular ones, and at full weight it floats your favourites to
        # the top of every crate regardless of what the crate is.
        score += 0.5 * self._favor_points(cand.id)
        score += min(8.0, 4.0 * max(0, played - 1))
        _, seed, typ, pair, sound = per[0]
        return Suggestion(
            track=cand, score=int(round(max(0.0, min(100.0, score)))),
            pair=pair, typicality=typ, favor_nights=self.favor(cand.id),
            reason=_fit_reason(seed, cand, pair, sound), seed=seed,
            seeds_played=played, sound=sound)

    def openers(self, candidates: list[Track], k: int = 3,
                offset: int = 0) -> list[Suggestion]:
        """Good first tracks: historically opened gigs, gentle arousal, gig-proven."""
        seen: set[str] = set()
        pool = [t for t in candidates
                if not (t.id in seen or seen.add(t.id))]
        if not pool:
            return []
        arousals = sorted(a for a in (_arousal_of(t) for t in pool) if a is not None)
        max_open = max((self.opener_nights.get(t.id, 0) for t in pool), default=0)

        def pct(t: Track) -> float:
            a = _arousal_of(t)
            if a is None or not arousals:
                return 0.5
            return sum(1 for x in arousals if x <= a) / len(arousals)

        out = []
        for t in pool:
            opened = self.opener_nights.get(t.id, 0)
            open_term = (opened / max_open) if max_open else 0.0
            score = 45.0 * open_term + 35.0 * (1.0 - pct(t)) + 5 * min(
                4.0, self._favor_points(t.id))
            bits = []
            if opened:
                bits.append(f"opened {opened} gig{'s' if opened > 1 else ''}")
            if t.energy is not None:
                bits.append(f"gentle start (E{t.energy})" if pct(t) <= 0.35
                            else f"E{t.energy}")
            if self.favor(t.id) >= 2:
                bits.append(f"gigged {self.favor(t.id)} nights")
            out.append(Suggestion(track=t, score=int(round(score)), pair=None,
                                  typicality=0.0, favor_nights=self.favor(t.id),
                                  reason=" · ".join(bits) or "fits the pool"))
        out.sort(key=lambda s: -s.score)
        return out[offset:offset + k]

    # -- scoring internals --------------------------------------------------

    def _suggest(self, cur: Track, cand: Track, energy_dir: int,
                 valence_dir: int) -> Suggestion:
        base, coverage = _base_score(cur, cand, energy_dir, valence_dir)
        typ = self.move_typicality(cur, cand)
        pair = self.pair_evidence(cur.id, cand.id)
        # Discount by how much we actually know about the pair, so a fully
        # analyzed match outranks an untagged one that merely shares a key and
        # a tempo — and no candidate reaches the ceiling on thin evidence.
        score = base * (0.75 + 0.25 * coverage) * (0.85 + 0.15 * typ)
        score += pair.points if pair else 0.0
        score += self._favor_points(cand.id)
        return Suggestion(track=cand, score=int(round(max(0.0, min(100.0, score)))),
                          pair=pair, typicality=typ, favor_nights=self.favor(cand.id),
                          reason=_reason_line(cur, cand, pair, typ, self.favor(cand.id)))


# ----------------------------------------------------------------------
# Base (audio-only) transition score — works with no history at all
# ----------------------------------------------------------------------

# axis -> weight; missing axes are skipped and the blend renormalized, mirroring
# microsets._distance so sparsely-tagged tracks stay comparable.
_BASE_WEIGHTS = {"bpm": 0.25, "key": 0.25, "energy": 0.20,
                 "valence": 0.10, "vibe": 0.10, "texture": 0.10}
# Arc steering: the arousal delta each direction aims for (DEAM units).
_ENERGY_TARGET = {1: 0.35, 0: 0.0, -1: -0.35}


def _base_score(a: Track, b: Track, energy_dir: int = 0,
                valence_dir: int = 0) -> tuple[float, float]:
    """(score 0..100, coverage 0..1) — coverage is the share of the weighted
    axes both tracks actually carried data for. A pair judged on BPM and key
    alone can look perfect while nothing is known about its feel, so callers
    discount by coverage rather than letting thin evidence score full marks."""
    acc, used = 0.0, 0.0

    def add(axis: str, value: Optional[float]) -> None:
        nonlocal acc, used
        if value is None:
            return
        acc += _BASE_WEIGHTS[axis] * max(0.0, min(100.0, value))
        used += _BASE_WEIGHTS[axis]

    add("bpm", (100.0 - 10.0 * abs(b.bpm - a.bpm)) if a.bpm and b.bpm else None)

    kd = _camelot_distance(a.key, b.key)
    add("key", float(kd) if kd > 0 else None)

    aa, ab = _arousal_of(a), _arousal_of(b)
    if aa is not None and ab is not None:
        target = _ENERGY_TARGET.get(energy_dir, 0.0)
        add("energy", 100.0 - 40.0 * abs((ab - aa) - target))
    if a.valence is not None and b.valence is not None:
        dv = b.valence - a.valence
        add("valence", (100.0 - 40.0 * abs(dv)) if valence_dir == 0
            else 50.0 + 40.0 * dv * valence_dir)

    # "Vibe" is whatever style evidence exists, averaged: the analyzer's style
    # and moods where a track has been analyzed, and the store's genre — which
    # covers most of the library and used to be read by nothing at all.
    vibe_parts = []
    if a.style or b.style or a.moods or b.moods:
        part = 0.0
        if a.style and a.style == b.style:
            part += 50.0
        part += min(50.0, 25.0 * len(set(a.moods or []) & set(b.moods or [])))
        vibe_parts.append(part)
    if a.genre and b.genre:
        vibe_parts.append(genres.kinship(a.genre, b.genre))
    add("vibe", sum(vibe_parts) / len(vibe_parts) if vibe_parts else None)

    if a.brightness is not None and b.brightness is not None:
        add("texture", 100.0 - 100.0 * min(1.0, abs(b.brightness - a.brightness) / 700.0))

    if not used:
        return 50.0, 0.0
    return acc / used, used / sum(_BASE_WEIGHTS.values())


# ----------------------------------------------------------------------
# Kinship — "does this belong with that", which is not the same question as
# "does this mix into that"
# ----------------------------------------------------------------------

# axis -> weight, as `_BASE_WEIGHTS` but for belonging rather than for a
# transition. The difference is the whole point:
#
# - **Genre leads.** It is what a crate is *about*, and the one style fact this
#   app has for most of the library (see `genres`).
# - **Key is nearly irrelevant.** Two tracks in 7A mix; that says nothing about
#   whether they belong in the same pile. It stays only as a tie-break, because
#   between two equally fitting tracks the one that also mixes is the better
#   offer. Ranking a crate on key is what produced "same key · steady bpm" for
#   twelve straight proposals with nothing else in common.
# - **Tempo is a band, not a delta.** A crate lives in a tempo range; ±1 bpm is
#   not ten times better than ±4, it is the same crate.
# `sound` is the cosine similarity between the two tracks' audio embeddings
# (`vectors`), and it leads when it exists: it is the only axis derived from
# what the records actually sound like rather than from what someone filed them
# under. Everything else is a fallback for tracks the analyzer has not reached —
# an axis with no data is skipped and the rest renormalize, so an unanalyzed
# library still ranks, genre-led, exactly as it did before.
_KIN_WEIGHTS = {"sound": 0.45, "genre": 0.22, "bpm": 0.12, "energy": 0.08,
                "vibe": 0.05, "texture": 0.03, "key": 0.05}


def _bpm_band(a: float, b: float) -> float:
    """0..100 for two tempos sitting in the same band.

    Half- and double-time count, at a discount: 70 and 140 are one mix and two
    different crates more often than not, so they score as a wide match rather
    than a perfect one.
    """
    d = abs(a - b)
    folded = min(abs(a - 2 * b), abs(2 * a - b))
    ceiling = 100.0
    if folded < d:                      # judged on the half/double relation
        d, ceiling = folded, 80.0
    for limit, score in ((2, 100.0), (4, 88.0), (6, 72.0), (10, 50.0), (16, 25.0)):
        if d <= limit:
            return min(ceiling, score)
    return 6.0


def _kinship(a: Track, b: Track, sound: Optional[float] = None) -> tuple[float, float]:
    """(score 0..100, coverage 0..1) — how much `b` belongs with `a`.

    Coverage is the share of the weighted axes both tracks carried data for, and
    the caller discounts by it. An axis is *skipped* when `a` has nothing to
    compare against — but a missing genre on `b` when `a` has one is scored, not
    skipped (`genres.UNKNOWN`): "we don't know what this is" has to rank below
    "we know it is the same thing", or every untagged track in the library
    outranks the tagged ones the moment it shares a tempo.
    """
    acc, used = 0.0, 0.0

    def add(axis: str, value: Optional[float]) -> None:
        nonlocal acc, used
        if value is None:
            return
        acc += _KIN_WEIGHTS[axis] * max(0.0, min(100.0, value))
        used += _KIN_WEIGHTS[axis]

    add("sound", vectors.sim_score(sound) if sound is not None else None)

    # Genre, and the one asymmetry worth spelling out. `genres.UNKNOWN` exists so
    # that a track with no genre cannot outrank a known-same-genre one on tempo
    # alone — it is a penalty for *ignorance*. But ignorance about a shop's label
    # is not ignorance about the music once the embedding has spoken, so when
    # `sound` is known the missing-genre case is **skipped rather than scored**.
    # Without this the ranking put Justice at 0.86 similarity below a track at
    # 0.76 that merely shared a Beatport label, which is the tag deciding over
    # the audio — exactly backwards.
    if a.genre and b.genre:
        add("genre", genres.kinship(a.genre, b.genre))
    elif a.genre and sound is None:
        add("genre", genres.UNKNOWN)
    add("bpm", _bpm_band(a.bpm, b.bpm) if (a.bpm and b.bpm) else None)

    kd = _camelot_distance(a.key, b.key)
    add("key", float(kd) if kd > 0 else None)

    aa, ab = _arousal_of(a), _arousal_of(b)
    if aa is not None and ab is not None:
        add("energy", 100.0 - 55.0 * abs(ab - aa))

    # The analyzer's own reading, where it has been run: its style is a finer
    # judgement than the store's genre (it heard the audio), and its moods are
    # the closest thing here to "vibe" in the sense a DJ means it.
    parts = []
    if a.style and b.style:
        parts.append(100.0 if a.style == b.style else 15.0)
    if a.moods and b.moods:
        parts.append(min(100.0, 35.0 * len(set(a.moods) & set(b.moods))))
    add("vibe", sum(parts) / len(parts) if parts else None)

    if a.brightness is not None and b.brightness is not None:
        add("texture", 100.0 - 100.0 * min(1.0, abs(b.brightness - a.brightness) / 700.0))

    if not used:
        return 40.0, 0.0
    return acc / used, used / sum(_KIN_WEIGHTS.values())


def _fit_reason(a: Track, b: Track, pair: Optional[PairEvidence],
                sound: Optional[float] = None) -> str:
    """One line for a crate proposal — why `b` belongs with `a`.

    Ordered the way the ranking is: what it sounds like first when that is
    known, then the genre relation, then tempo, then key. A reason that doesn't
    match the ranking is worse than no reason.
    """
    bits = []
    if sound is not None:
        # Only claimed when the similarity is actually high — advertising a weak
        # match as "sounds like" is how a ranking loses the right to be believed.
        if sound >= 0.82:
            bits.append("sounds a lot like it")
        elif sound >= 0.72:
            bits.append("sounds close to it")
        elif sound >= 0.62:
            bits.append("loosely similar sound")
    if pair is not None:
        if pair.kind == "confirmed":
            bits.append(f"you've mixed these on {pair.nights} nights")
        elif pair.kind == "once":
            bits.append("played back-to-back once")
        elif pair.kind == "reverse":
            bits.append("you've mixed these (reversed)")
        else:
            bits.append("played in the same pocket")
    if a.genre and b.genre:
        k = genres.kinship(a.genre, b.genre)
        if k >= genres.SAME:
            bits.append(f"{genres.label(b.genre)}, same as it")
        elif k >= genres.SAME_FAMILY:
            bits.append(f"{genres.label(b.genre)} — same family")
        elif k >= genres.NEIGHBOUR:
            bits.append(f"{genres.label(b.genre)} — next door")
        else:
            bits.append(f"{genres.label(b.genre)}, not {genres.label(a.genre)}")
    elif a.genre and not b.genre and sound is None:
        # Only worth saying when it actually cost the candidate something — with
        # a sound score in hand the missing tag no longer enters the ranking.
        bits.append("no genre on the file")
    if a.bpm and b.bpm:
        d = b.bpm - a.bpm
        bits.append(f"same tempo ({round(b.bpm)})" if abs(d) < 1.5
                    else f"{d:+.0f} bpm")
    cls = _move_class(a.key, b.key)
    if cls in ("same", "adjacent", "flip"):
        bits.append(f"mixes in key ({a.key}→{b.key})")
    return " · ".join(bits[:4])


def _reason_line(a: Track, b: Track, pair: Optional[PairEvidence],
                 typicality: float, favor: int) -> str:
    """One plain-language line for the suggestion card."""
    bits = []
    if pair is not None:
        if pair.kind == "confirmed":
            bits.append(f"you played this after it on {pair.nights} nights")
        elif pair.kind == "once":
            bits.append("played back-to-back once")
        elif pair.kind == "reverse":
            bits.append("you've mixed these (reversed)")
        else:
            bits.append("played in the same pocket")
    cls = _move_class(a.key, b.key)
    if cls == "same":
        bits.append("same key")
    elif cls == "adjacent":
        bits.append(f"key {a.key}→{b.key}")
    elif cls == "flip":
        bits.append(f"major/minor flip {a.key}→{b.key}")
    elif cls in ("diagonal", "two"):
        bits.append(f"key stretch {a.key}→{b.key}")
    elif cls == "off":
        bits.append(f"key clash {a.key}→{b.key}")
    if a.bpm and b.bpm:
        d = b.bpm - a.bpm
        bits.append("steady bpm" if abs(d) < 1 else f"{d:+.0f} bpm")
    if pair is None and typicality >= 0.75:
        bits.append("your usual move")
    if pair is None and favor >= 2:
        bits.append(f"gigged {favor} nights")
    return " · ".join(bits[:3])


# ----------------------------------------------------------------------
# Building the model
# ----------------------------------------------------------------------

def build(gigs: list, membership: dict,
          energy_cache: Optional[dict] = None) -> MixModel:
    """Learn a MixModel from classified gigs + playlist membership.

    `energy_cache` (path -> parsed tags) enables the Δenergy profile by
    hydrating each gig's energies from file tags (shared with the Histories
    page cache, so the reads are paid once). Pass None to skip the file reads.
    """
    m = MixModel()
    m.gig_count = len(gigs)

    if energy_cache is not None:
        for g in gigs:
            history.hydrate_energy(g, energy_cache)

    # pair evidence — adjacent pairs via the same miner the Histories page uses
    m.adj = {(t.a.track_id, t.b.track_id): t
             for t in history.transitions(gigs, min_nights=1)}

    # near pairs ("same pocket"): within NEAR_WINDOW but not adjacent
    near_days: dict[frozenset, set] = defaultdict(set)
    for g in gigs:
        ts = g.tracks
        for off in range(2, NEAR_WINDOW + 1):
            for x, y in zip(ts, ts[off:]):
                if x.track_id != y.track_id:
                    near_days[frozenset((x.track_id, y.track_id))].add(g.day)
    m.near_nights = Counter({k: len(v) for k, v in near_days.items()})

    # track favor + openers
    track_days: dict[str, set] = defaultdict(set)
    opener_days: dict[str, set] = defaultdict(set)
    for g in gigs:
        for t in g.tracks:
            track_days[t.track_id].add(g.day)
        for t in g.tracks[:OPENER_SLOTS]:
            opener_days[t.track_id].add(g.day)
    m.track_nights = Counter({k: len(v) for k, v in track_days.items()})
    m.opener_nights = Counter({k: len(v) for k, v in opener_days.items()})

    # move profile — every unique adjacent pair, weighted by its nights so a
    # habit shapes the profile and a one-off experiment barely registers
    moves: Counter = Counter()
    bpms: Counter = Counter()
    energies: Counter = Counter()
    for tr in m.adj.values():
        w = tr.nights
        cls = _move_class(tr.a.key or "", tr.b.key or "")
        if cls is not None:
            moves[cls] += w
        if tr.a.bpm and tr.b.bpm:
            bpms[_bpm_bucket(tr.b.bpm - tr.a.bpm)] += w
        if tr.a.energy is not None and tr.b.energy is not None:
            energies[_energy_bucket(tr.b.energy - tr.a.energy)] += w
    if moves:
        m.move_w = _typicality_weights(moves, _MOVE_CLASSES, sizes=_MOVE_SIZES)
    if bpms:
        m.bpm_w = _typicality_weights(bpms, range(len(_BPM_BUCKETS)),
                                      sizes=_BPM_SIZES)
    if energies:
        m.energy_w = _typicality_weights(energies, range(-3, 4))

    # playlist affinity — which playlists sourced each night
    days: dict[str, set] = defaultdict(set)
    for g in gigs:
        for src in history.gig_sources(g, membership):
            if src.share >= SOURCE_MIN_SHARE:
                days[src.path].add(g.day)
    m.playlist_days = dict(days)

    return m


def playlist_paths(index: dict) -> dict[str, str]:
    """Full playlist path -> node id, matching `history.build_membership`'s
    path format — so companion paths can be resolved back to tree nodes."""
    out: dict[str, str] = {}
    for node in index.values():
        if node.is_folder:
            continue
        parts = [node.name]
        parent = index.get(node.parent_id)
        while parent is not None:
            parts.append(parent.name)
            parent = index.get(parent.parent_id)
        out[" / ".join(reversed(parts))] = node.id
    return out


def short_path(path: str, segments: int = 2) -> str:
    """The tail of a playlist path, for a chip label.

    Leaf names alone are useless here — a gig's sources are things like "All"
    and "3 · Climax", which only mean something with their parent attached.
    """
    parts = path.split(" / ")
    return " › ".join(parts[-segments:])


def node_label(index: dict, node_id: str) -> str:
    """Display name for a playlist node: 'Parent › Leaf' when it sits inside
    another playlist or folder, else its plain name. Works for folders too,
    which `playlist_paths` deliberately skips."""
    node = index.get(node_id)
    if node is None:
        return ""
    parent = index.get(node.parent_id)
    return f"{parent.name} › {node.name}" if parent is not None else node.name


def drop_covered(index: dict, have_ids: Iterable[str], ranked: list,
                 max_overlap: float = 0.7) -> list:
    """Filter ranked (node_id, score) companions down to the ones that add tracks.

    A gig's source playlists overlap by construction — "805 - High Dance / All"
    and "805 - High Dance / 3 · Climax" score alike and are largely the same
    tracks. Keep the best-ranked of an overlapping family and drop the rest, so
    the chips offer distinct pools rather than restatements of one.
    """
    covered: set = set()
    for nid in have_ids:
        node = index.get(nid)
        if node is not None:
            covered |= node.all_track_ids()
    # Within one overlapping family the broader playlist is the better offer
    # ("805 - High Dance › All" over "… › 3 · Climax"), so let size break the
    # score tie before the covered-filter picks a survivor.
    ordered = sorted(
        ranked,
        key=lambda r: (-r[1], -len(index[r[0]].all_track_ids()) if r[0] in index else 0))
    out = []
    for entry in ordered:
        nid = entry[0]
        node = index.get(nid)
        if node is None:
            continue
        ids = node.all_track_ids()
        if not ids:
            continue
        if len(ids & covered) / len(ids) > max_overlap:
            continue
        covered |= ids
        out.append(entry)
    return out


def subtree_paths(index: dict, node_id: str, by_id: Optional[dict] = None) -> list[str]:
    """Every playlist path at or under `node_id`.

    Selecting a playlist selects its children's tracks too (`all_track_ids`),
    and history attributes a gig to whichever node actually holds the track —
    often a child ("806 - High Chase / All") rather than the parent the user
    ticked. Walking the subtree lets the parent inherit that history.
    """
    if by_id is None:
        by_id = {v: k for k, v in playlist_paths(index).items()}
    out: list[str] = []
    stack = [node_id]
    while stack:
        nid = stack.pop()
        node = index.get(nid)
        if node is None:
            continue
        p = by_id.get(nid)
        if p:
            out.append(p)
        stack.extend(c.id for c in node.children)
    return out


# ----------------------------------------------------------------------
# Self-test against the live library
# ----------------------------------------------------------------------

if __name__ == "__main__":
    import rekordbox

    sessions = history.load_sessions()
    gigs = history.build_gigs(sessions)
    membership = history.build_membership(rekordbox.from_live().playlist_index)
    model = build(gigs, membership, energy_cache={})

    confirmed = [t for t in model.adj.values() if t.nights >= 2]
    print(f"{len(gigs)} gigs -> {len(model.adj)} adjacent pairs "
          f"({len(confirmed)} confirmed on 2+ nights), "
          f"{len(model.near_nights)} pocket pairs")
    print(f"move profile:   { {k: round(v, 2) for k, v in model.move_w.items()} }")
    print(f"bpm profile:    { {k: round(v, 2) for k, v in model.bpm_w.items()} }")
    print(f"energy profile: { {k: round(v, 2) for k, v in model.energy_w.items()} }")

    top_pl = sorted(model.playlist_days.items(), key=lambda kv: -len(kv[1]))[:3]
    for path, ds in top_pl:
        comps = model.companions(path)
        print(f"\n{path}  ({len(ds)} gigs) often gigged with:")
        for p, share in comps:
            print(f"   {share:.0%}  {p}")

    if gigs:
        g = gigs[0]
        pool = [Track(id=t.track_id, name=t.name, artist=t.artist,
                      bpm=t.bpm or 0.0, key=t.key or "", energy=t.energy)
                for t in g.tracks]
        cur = pool[len(pool) // 2]
        print(f"\nafter “{cur.artist} - {cur.name}” ({cur.key} {cur.bpm:.0f}bpm) play:")
        for s in model.next_tracks(cur, pool, k=5):
            badge = f"  [{s.badge}]" if s.badge else ""
            print(f"  {s.score:>3}  {s.track.artist[:22]:22} - "
                  f"{s.track.name[:30]:30} {s.reason}{badge}")
