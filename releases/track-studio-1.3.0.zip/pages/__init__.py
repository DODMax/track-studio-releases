"""Route registration package.

Importing this package imports each page module, whose `@ui.page(...)` decorator
registers its route as an import-time side effect. `main.py` does `import pages`.

`/microsets` and `/builder` were merged into `/build`, and `/sync` into
`/incoming`; all three keep redirecting so old bookmarks still land somewhere
useful. `sync_page.py` is left on disk, unregistered, until `/incoming` has
been lived with — it is the reference for anything the move missed.
"""
from nicegui import ui

from . import (library_page, incoming_page, build_page, download_page,  # noqa: F401
               history_page, settings_page)


def _query(batch: str, node: str, gig: str, crates: str = "") -> str:
    from urllib.parse import urlencode
    params = {k: v for k, v in
              (("batch", batch), ("node", node), ("gig", gig), ("crates", crates))
              if v}
    return f"/build?{urlencode(params)}" if params else "/build"


@ui.page("/sync")
def _sync_redirect():
    ui.navigate.to("/incoming")


@ui.page("/microsets")
def _microsets_redirect(batch: str = "", node: str = "", gig: str = ""):
    ui.navigate.to(_query(batch, node, gig))


@ui.page("/builder")
def _builder_redirect(batch: str = "", node: str = "", gig: str = "",
                      crates: str = ""):
    ui.navigate.to(_query(batch, node, gig, crates))
