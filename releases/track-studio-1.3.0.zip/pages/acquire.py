"""Acquiring a track — the panel Incoming shows, not a page of its own.

Three ways in, because tracks arrive three ways:

- **A link — or a name.** One field, source-detecting: a Beatport track/release
  URL goes through your beatportdl subscription, any other link through yt-dlp
  (YouTube, SoundCloud, ~1800 sites), and anything that isn't a link at all is
  searched on Beatport, whose catalog answers "that track I half-remember" far
  better than yt-dlp can. All three show what you're getting *before* the
  download — quality for streams, the tracklist for a release, the hits to pick
  from for a search, and for every one of them whether you already own it.
- **Your Downloads folder.** Free-download gates, Bandcamp, promo mail and
  WeTransfer all end the same way: a file in `~/Downloads` with whatever name
  the artist gave it. The inbox lists those, guesses artist/title, and files
  them into the library in one click (see `inbox`).

**Everything here asks where it is going before it fetches anything**, which is
the one thing the old Download page never did — and the reason a thousand files
accumulated in a folder named after the shop they came from. The destination is
a rekordbox playlist name; picking one means the download lands in that folder
and arrives already filed (see `destinations`). Leaving it blank is allowed and
says so: the file lands in the door folder and joins "Needs a home", which is a
choice rather than an accident.

Not here: the Setline set import, which stays on `/download`. It is a bridge
between two libraries and goes away entirely once the board runs locally
against this one, so porting it would be work spent on something condemned.

A panel, not a page: `panel()` builds itself into the current container and
hands back a `refresh()`. Incoming owns the container, the drawer entry and the
notifications, so a download's result can outlive the list that started it.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Callable, Optional

from nicegui import run, ui

import bpdl
import destinations
import drives
import dupes
import inbox
import runtime
import widgets
import ytdl

from . import kit

# How many inbox files to show before "show all" — a Downloads folder is a
# midden, and the track you just grabbed is at the top.
INBOX_PREVIEW = 12

# A link has no spaces and carries either a scheme or a dotted host. Anything
# else in that field is a track someone typed from memory, and the one thing
# that must never happen to it is being handed to yt-dlp as a URL.
_URLISH = re.compile(r"^(?:[a-z][a-z0-9+.\-]*://|www\.)"
                     r"|^[\w\-]+(?:\.[\w\-]+)+(?:[/?#]|$)", re.IGNORECASE)


def _looks_like_url(text: str) -> bool:
    text = (text or "").strip()
    return " " not in text and bool(_URLISH.match(text))


# Setline's geometry over the shared palette (`kit`), scoped to this panel —
# the same tokens the dock uses, because the shelf a track is gathered onto and
# the panel it arrives through are two halves of one job and should not read as
# two different apps. Stock Quasar's outlined field is a hairline
# drawn on the page colour; Setline's is a filled well with a hairline, which
# is what makes a form read as a panel rather than a list of controls.
#
# Everything is under `.ts-acq` so the Quasar overrides can't reach the rest of
# the app — Incoming's table sits in the same DOM.
_CSS = "<style>\n" + kit.scope(".ts-acq") + """
.ts-acq { color:var(--ink); font-size:13px; }
.ts-acq .a-title { font-size:19px; font-weight:700; letter-spacing:-.015em; color:var(--ink); }
/* `open ↗` on every hit. Stock link blue is the one colour in this app that
   belongs to nothing — the palette is orange for what you're acting on, teal
   for what's already yours. A link out is neither until you're on it. */
.ts-acq a { color:var(--ink-3); text-decoration:none; }
.ts-acq a:hover { color:var(--accent); text-decoration:underline; }
.ts-acq .a-sub { font-size:12.5px; color:var(--ink-3); line-height:1.5; }
.ts-acq .a-eyebrow { font-size:10.5px; font-weight:700; letter-spacing:.09em;
  text-transform:uppercase; color:var(--ink-3); white-space:nowrap; }

/* The two questions in one box, in the order they're answered: where it goes,
   then what to get. Boxed rather than stacked loose, because the destination is
   set once and the field is used many times — the box is what says they belong
   to the same act. */
.ts-acq .a-box { background:var(--surface); border:1px solid var(--line); border-radius:10px;
  padding:11px 13px 13px; }
.ts-acq .a-rule { height:1px; background:var(--line); margin:2px 0 0; }
.ts-acq .a-line { flex:1 1 auto; height:1px; background:var(--line); min-width:12px; }

.ts-acq .q-field--outlined .q-field__control { background:var(--raised); border-radius:8px; }
.ts-acq .q-field--outlined .q-field__control:before { border-color:var(--line); }
.ts-acq .q-field--outlined .q-field__control:hover:before { border-color:var(--line-2); }
.ts-acq .q-field--outlined.q-field--focused .q-field__control:after { border-color:var(--accent); }
.ts-acq .q-field__native, .ts-acq .q-field__input { color:var(--ink); }
.ts-acq .q-field__label, .ts-acq input::placeholder { color:var(--ink-3); }
/* Quasar's badge is a rounded lozenge; Setline's pills are squarer and quieter.
   The colours stay — they're carrying the verdict. */
.ts-acq .q-badge { border-radius:5px; font-size:10.5px; font-weight:650;
  letter-spacing:.02em; padding:4px 6px; }

.ts-acq .a-hint { font-size:12px; color:var(--ink-3); line-height:1.45; }
.ts-acq .a-hint.warn { color:var(--warn); }

/* Something to read, rather than a stray orange sentence in the margin — this
   is where a blocked Downloads folder explains itself, and the explanation is
   four lines long. */
.ts-acq .a-callout { background:rgba(210,153,34,.07); border:1px solid rgba(210,153,34,.28);
  border-left:3px solid var(--warn); border-radius:8px; padding:10px 12px;
  font-size:12px; line-height:1.55; color:var(--ink-2); }

/* One fetched result: the dock's card, unrolled into a row. */
.ts-acq .a-hit { background:var(--raised); border:1px solid var(--line); border-radius:10px;
  padding:9px 11px; transition:border-color .15s, background .15s; }
.ts-acq .a-hit:hover { border-color:var(--line-2); background:var(--raised-2); }
.ts-acq .a-art { width:48px; height:48px; border-radius:6px; flex:none; overflow:hidden;
  background:var(--raised-2); display:grid; place-items:center; color:var(--ink-3); }
.ts-acq .a-art img { width:100%; height:100%; object-fit:cover; display:block; }
.ts-acq .a-key { font:650 10px/1 ui-monospace,Menlo,monospace; padding:4px 6px;
  border-radius:4px; color:#fff; }
.ts-acq .a-mono { font-family:ui-monospace,Menlo,monospace; font-size:11px; color:var(--ink-2); }

/* One file waiting in the Downloads folder. A hairline per row rather than a
   rule under each: the hover is what separates them. */
.ts-acq .a-file { border-radius:7px; padding:4px 7px; border:1px solid transparent; }
.ts-acq .a-file:hover { background:var(--raised); border-color:var(--line); }
</style>
"""


def _attr(s) -> str:
    """Escape for a double-quoted HTML attribute — sleeve URLs come from the
    store's CDN and from yt-dlp, neither of which is our input."""
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _fmt_duration(secs) -> str:
    if not secs:
        return "—"
    m, s = divmod(int(secs), 60)
    return f"{m}:{s:02d}"


def _cover(url: Optional[str]) -> None:
    """A 48px sleeve — or a hole the same size, so a list of hits stays a column.

    A missing cover that renders as nothing shunts every badge on its row left,
    which is worse than the blank it was trying to avoid. The hole carries the
    dock's ♪ for the same reason a crate card does: an empty well reads as a
    thing still loading, a glyph reads as a track with no sleeve.
    """
    with ui.element("div").classes("a-art"):
        if url:
            # A plain <img>, not `ui.image`: Quasar's q-img is a ratio box that
            # fights a fixed-size square, and a sleeve that 404s should leave
            # the ♪ behind rather than a broken-image glyph. `sanitize=False`
            # because the sanitiser strips `onerror`, which is what does that —
            # the URL is escaped at the point of use instead.
            ui.html(f'<img src="{_attr(url)}" alt="" loading="lazy" '
                    'draggable="false" onerror="this.remove()">', sanitize=False)
        else:
            ui.label("♪")


def _quality(mi: ytdl.MediaInfo) -> tuple[str, str]:
    """(label, quasar-color) for the audio-quality badge, colored by bitrate."""
    abr = mi.abr
    codec = (mi.acodec or "").split(".")[0] or "?"
    if not abr:
        return f"{codec} · ? kbps", "grey-7"
    label = f"{codec} · {abr:.0f} kbps"
    if abr >= 256:
        return label, "positive"
    if abr >= 128:
        return label, "warning"
    return label, "negative"


def panel(*, default_destination: Callable[[], str],
          choices: Callable[[], list],
          on_landed: Callable[[list], None],
          toast: Callable, spinner: Callable) -> Callable[[], None]:
    """Build the acquire panel into the current container; return its refresh().

    `default_destination()` seeds the playlist picker from whatever the page is
    looking at, so acquiring *into* the playlist you were just working through
    takes no extra click. `on_landed(paths)` is called once files are in the
    library, for the caller to re-render its own counts.
    """
    # Per-visit only. rows: {kind: "media"|"beatport", mi|bt, title_in,
    # artist_in, have}; `have` maps a path-string to a `dupes.Existing` for the
    # inbox listing; `picked` holds the row indexes ticked in a search — a menu
    # you choose from, unlike a link, which already said which tracks it meant.
    state = {"rows": [], "kind": None, "picked": set(), "inbox": [],
             "show_all": False, "filter": "", "checked": set(), "have": {},
             "error": "", "scanned": False}

    ui.add_head_html(_CSS)
    with ui.column().classes("w-full gap-3 ts-acq").style("max-width:56rem") as root_col:
        with ui.column().classes("gap-1"):
            ui.label("Acquire a track").classes("a-title")
            ui.label("Paste a Beatport, YouTube or SoundCloud link — or type an "
                     "artist and title and search Beatport’s catalog.") \
                .classes("a-sub")

        # The destination and the field share one box, in the order they're
        # answered: everything here asks where a track is going before it
        # fetches it, and two loose rows never said that they were one act.
        with ui.column().classes("w-full gap-3 a-box"):
            # --- where it goes, before anything is fetched ---
            with ui.column().classes("w-full gap-1"):
                with ui.row().classes("items-center gap-2 w-full no-wrap"):
                    ui.icon("playlist_add", size="19px").style("color:#2dd4bf")
                    ui.label("Goes to").classes("a-eyebrow")
                    dest_select = ui.select([], with_input=True,
                                            new_value_mode="add-unique",
                                            on_change=lambda: _sync_dest()) \
                        .props('outlined dense clearable '
                               'placeholder="a rekordbox playlist"') \
                        .style("min-width:19rem")
                # Under the row, not beside it: the no-playlist answer is a
                # sentence, and in the margin it wrapped into the column of
                # whatever came next.
                dest_lbl = ui.label("").classes("a-hint")

            ui.element("div").classes("a-rule")

            with ui.row().classes("items-center gap-2 w-full no-wrap"):
                url_in = ui.input(placeholder="Paste a link, or type an artist "
                                              "and title",
                                  on_change=lambda e: _sync_fetch_btn(e.value)) \
                    .props("outlined dense clearable").classes("flex-grow") \
                    .style("min-width:0")
                url_in.on("keydown.enter", lambda: fetch())
                fetch_btn = ui.button("Fetch info", icon="search",
                                      on_click=lambda: fetch()) \
                    .props("unelevated no-caps color=primary")

        with ui.row().classes("items-center gap-3 w-full no-wrap"):
            dl_btn = ui.button("Download", icon="cloud_download",
                               on_click=lambda: do_download()) \
                .props("unelevated no-caps color=primary")
            dl_btn.set_visibility(False)
            have_lbl = ui.label("").classes("a-hint").style("color:#d29922")
        results = ui.column().classes("w-full gap-2")

        # --- inbox ---
        with ui.row().classes("items-center gap-3 w-full no-wrap q-mt-md"):
            ui.label("FROM YOUR DOWNLOADS FOLDER").classes("a-eyebrow")
            ui.element("div").classes("a-line")
        with ui.row().classes("items-center justify-between w-full no-wrap gap-3"):
            inbox_lbl = ui.label("").classes("a-hint").style("min-width:0")
            with ui.row().classes("items-center gap-2 no-wrap"):
                ui.input(placeholder="filter…",
                         on_change=lambda e: set_filter(e.value)) \
                    .props("dense outlined clearable").style("width:150px")
                ui.button(icon="refresh", on_click=lambda: refresh_inbox()) \
                    .props("flat dense round size=sm color=grey") \
                    .tooltip("Re-scan the folder and re-check it against the library")
                import_btn = ui.button("Import", icon="library_add",
                                       on_click=lambda: do_import()) \
                    .props("unelevated dense no-caps size=sm color=primary")
                import_btn.set_visibility(False)
        inbox_col = ui.column().classes("w-full gap-1")

    # ==================================================================
    # the destination
    # ==================================================================

    def _dest_name() -> str:
        return (dest_select.value or "").strip()

    def _dest_dir() -> Path:
        """Where the next download lands.

        A chosen destination wins over the door the track came through, which is
        the whole point: the file arrives already filed, and never joins the
        pile this panel exists to stop forming.
        """
        root = runtime._dl_root()
        name = _dest_name()
        if name:
            return destinations.folder_for(name, root)
        if state["kind"] in ("beatport", "search"):
            return root / "Beatport"
        src = state["rows"][0]["mi"].source if state["rows"] else "web"
        return root / {"youtube": "YouTube", "soundcloud": "SoundCloud"}.get(src, "Downloads")

    def _sync_dest() -> None:
        name = _dest_name()
        if name:
            dest_lbl.set_text(f"→ {_dest_dir()}")
            dest_lbl.classes(remove="warn")
        else:
            # Said out loud rather than left blank: landing in a door folder is
            # a real outcome with a cost, not an absence of one. Which door is
            # only known once something has been fetched — before that, naming
            # one would be a guess, and it would be wrong for every Beatport
            # search, which is most of them.
            where = (f"in {_dest_dir().name}/" if state["rows"]
                     else "in a folder named after where it came from")
            dest_lbl.set_text(f"no playlist — lands {where} and joins "
                              "“Needs a home”")
            dest_lbl.classes(add="warn")
        _sync_dl_btn()

    def _remember(name: str) -> None:
        """A destination rekordbox hasn't got a playlist for yet is still a real
        answer — it will exist the first time this is imported."""
        if name and name.lower() not in {c.lower() for c in (dest_select.options or [])}:
            destinations.declare(name)

    # ==================================================================
    # link + search
    # ==================================================================

    def _sync_fetch_btn(value=None) -> None:
        """Say which of the two things Enter will do, before it's pressed."""
        text = (value or "").strip()
        fetch_btn.text = ("Search Beatport" if text and not _looks_like_url(text)
                          else "Fetch info")

    def _mark_have(rows) -> None:
        """Tag each fetched row with the library track it looks like, if any.

        Runs before anything is downloaded — the whole point is to say "you own
        this" while it's still a decision. Never blocks the download: replacing a
        128 kbps rip with lossless is a real reason to fetch a second copy.
        """
        from library import file_duration

        idx = dupes.Index(runtime.library.tracks)
        for r in rows:
            if r["kind"] == "beatport":
                bt = r["bt"]
                # Beatport hands us the ISRC, so this is an identity check, not
                # a guess — the mix name rides along for the fuzzy fallback.
                e = idx.lookup(", ".join(bt.artists),
                               f"{bt.name} {bt.mix_name}".strip(), isrc=bt.isrc)
                want_s = (bt.length_ms or 0) / 1000 or None
            else:
                mi = r["mi"]
                e = idx.lookup(mi.artist, mi.title)
                want_s = mi.duration or None
            # The store tells us how long this is and the matched file can be
            # measured, so "you already have this" can be checked rather than
            # assumed — the case that matters is the 6-minute extended matching
            # the radio edit you own, where the badge would otherwise talk you
            # out of the one worth buying.
            if e is not None and want_s and e.via != "isrc":
                have_s = file_duration(e.track.local_path) if e.track.local_path else None
                if have_s:
                    e.candidate_s, e.delta_s = want_s, want_s - have_s
            r["have"] = e

    # "already have" argues against buying; "longer edit" argues *for* it, and
    # colouring them alike is how the one worth having reads as the one to skip.
    _HAVE_COLOR = {"already have": "warning", "possible dupe": "grey-7",
                   "longer edit": "positive", "shorter edit": "grey-7",
                   "replaces a lost file": "info"}

    def _have_badge(row) -> None:
        """The 'you already have this' chip, if the row matched something."""
        have = row.get("have")
        if not have:
            return
        ui.badge(have.chip) \
            .props(f"color={_HAVE_COLOR.get(have.chip, 'grey-7')}") \
            .tooltip(have.detail)

    def pick_row(idx: int, on: bool) -> None:
        state["picked"].add(idx) if on else state["picked"].discard(idx)
        _sync_dl_btn()

    def _sync_dl_btn() -> None:
        """The Download button. A search downloads what's ticked, a link its lot.

        The destination is in the label because it is the decision most worth
        catching before the click, not after.
        """
        rows = state["rows"]
        name = _dest_name()
        into = f" → {name}" if name else ""
        if state["kind"] == "search":
            n = len(state["picked"])
            dl_btn.text = (f"Download {n}{into}" if n else "Download")
            dl_btn.set_enabled(bool(n))
        else:
            dl_btn.text = (f"Download {len(rows)}{into}" if len(rows) > 1
                           else f"Download{into}")
            dl_btn.set_enabled(True)
        dl_btn.props(f"color={'primary' if name else 'warning'}")

    def render_results() -> None:
        results.clear()
        rows = state["rows"]
        dl_btn.set_visibility(bool(rows))
        _sync_dl_btn()
        n_have = sum(1 for r in rows if r.get("have"))
        if state["kind"] == "search":
            # A search result is an instruction, not a warning: amber here made
            # "tick what you want" read as something going wrong. The rows that
            # *are* a warning carry their own badge.
            have_lbl.style("color:#a4abb7")
            have_lbl.set_text(
                f"{len(rows)} on Beatport — tick what you want"
                + (f"  ·  {n_have} already in your library" if n_have else ""))
        else:
            have_lbl.style("color:#d29922")
            have_lbl.set_text(
                f"{n_have} of {len(rows)} already in your library"
                if n_have and len(rows) > 1
                else ("you already have this one" if n_have else ""))
        _sync_dest()
        with results:
            for i, row in enumerate(rows):
                if row["kind"] == "beatport":
                    _render_beatport_row(row, i)
                else:
                    _render_media_row(row)

    def _render_media_row(row) -> None:
        mi = row["mi"]
        qlabel, qcolor = _quality(mi)
        with ui.column().classes("w-full a-hit gap-2"):
            with ui.row().classes("items-center w-full no-wrap gap-3"):
                _cover(mi.thumbnail)
                ui.badge(mi.source).props("color=grey-8")
                ui.badge(qlabel).props(f"color={qcolor}")
                _have_badge(row)
                ui.label(_fmt_duration(mi.duration)).classes("a-mono")
                ui.space()
                if mi.filesize:
                    ui.label(f"~{mi.filesize / 1e6:.1f} MB").classes("a-mono")
                ui.link("open ↗", mi.url, new_tab=True).classes("text-caption")
            with ui.row().classes("items-center w-full no-wrap gap-2"):
                row["artist_in"] = ui.input("Artist", value=mi.artist) \
                    .props("outlined dense").classes("flex-grow").style("min-width:0")
                row["title_in"] = ui.input("Title", value=mi.title) \
                    .props("outlined dense").classes("flex-grow").style("min-width:0")
            if mi.raw_title and mi.raw_title != mi.title:
                ui.label(f"source: {mi.raw_title}").classes("a-hint")

    def _render_beatport_row(row, idx: int) -> None:
        """A Beatport hit. Artist/title aren't editable here: beatportdl writes
        the store's own tags, which are canonical — unlike a scraped video title.

        A search's rows tick, play and link out: twelve near-identical remixes
        is exactly the moment you want to hear one before buying it, and the
        store's own two-minute clip (`BeatportTrack.sample_url`) answers that
        without leaving the page.
        """
        bt, searching = row["bt"], state["kind"] == "search"
        with ui.column().classes("w-full a-hit gap-2"):
            with ui.row().classes("items-center w-full no-wrap gap-3"):
                if searching:
                    ui.checkbox(value=idx in state["picked"],
                                on_change=lambda e, i=idx: pick_row(i, e.value)) \
                        .props("dense")
                _cover(bt.artwork())
                ui.badge("beatport").props("color=grey-8")
                _have_badge(row)
                ui.label(bt.display).classes("flex-grow ellipsis").style("min-width:0")
                if bt.key:
                    # The wheel colour, same formula as the dock's cards and the
                    # Library's pills — a key is read by its hue here.
                    ui.label(bt.key).classes("a-key") \
                        .style(f"background:{widgets.camelot_color(bt.key)}")
                if bt.bpm:
                    ui.label(f"{bt.bpm}").classes("a-mono")
                ui.label(_fmt_duration((bt.length_ms or 0) / 1000)).classes("a-mono")
                if bt.sample_url:
                    # Fixed width, flex:0 0 auto — the scrub bar must not
                    # breathe with the title beside it, or every row in a
                    # search result gets a different-length transport.
                    with ui.element("div").style("width:230px; flex:0 0 auto"):
                        widgets.preview_player(bt.sample_url)
                        win = bt.sample_window
                        if win:
                            # "preview", explicitly: the transport's clock counts
                            # the clip, so beside the row's full duration it
                            # otherwise reads as the track being the wrong length.
                            ui.label(f"preview from {_fmt_duration(win[0])}") \
                                .classes("text-caption text-grey") \
                                .style("font-size:10px; line-height:1") \
                                .tooltip("A ~90s clip cut from the middle of the "
                                         "track, not the whole thing")
                if searching:
                    # flex:0 0 auto, not just nowrap: the player took the slack
                    # out of the row, so a shrinkable link gets squeezed below
                    # its own text and breaks the arrow onto a second line.
                    ui.link("open ↗", bt.url, new_tab=True).classes("text-caption") \
                        .style("white-space:nowrap; flex:0 0 auto")

    async def fetch():
        query = (url_in.value or "").strip()
        if not query:
            toast("Paste a link, or type a track to search Beatport", type="warning")
            return
        typed = not _looks_like_url(query)
        fetch_btn.props("loading")
        n = spinner(f"Searching Beatport for “{query}”…" if typed else "Fetching info…")
        try:
            if bpdl.is_beatport_url(query):
                kind, tracks = await run.io_bound(bpdl.tracks_for_url, query)
                state["kind"] = "beatport"
                state["rows"] = [{"kind": "beatport", "bt": bt} for bt in tracks]
                if kind == "release":
                    toast(f"Release: {len(tracks)} tracks", type="info")
            elif typed:
                hits = await run.io_bound(bpdl.search_tracks, query)
                if not hits:
                    n.dismiss()
                    toast(f"Beatport has nothing for “{query}”. Try fewer words, "
                          "or paste a YouTube/SoundCloud link instead.",
                          type="warning", timeout=9000)
                    return
                state["kind"] = "search"
                state["rows"] = [{"kind": "beatport", "bt": bt} for bt in hits]
            else:
                infos = await run.io_bound(ytdl.probe, query)
                if not infos:
                    n.dismiss()
                    toast("No tracks found at that URL", type="warning")
                    return
                state["kind"] = "media"
                state["rows"] = [{"kind": "media", "mi": mi,
                                  "title_in": None, "artist_in": None}
                                 for mi in infos]
        except Exception as e:
            n.dismiss()
            toast(f"Couldn't search Beatport: {e}" if typed
                  else f"Couldn't read that URL: {e}",
                  type="negative", timeout=8000)
            return
        finally:
            fetch_btn.props(remove="loading")
        # Indexing the library is a pass over every track — off the event loop,
        # and never fatal: a failed check must not cost you the fetched result.
        try:
            await run.io_bound(_mark_have, state["rows"])
        except Exception as e:
            print(f"[acquire] duplicate check failed: {e!r}")
        state["picked"] = set()      # a new result set, none of it chosen yet
        n.dismiss()
        render_results()

    async def do_download():
        rows = state["rows"]
        if state["kind"] == "search":
            rows = [r for i, r in enumerate(rows) if i in state["picked"]]
            if not rows:
                toast("Tick the ones you want first", type="warning")
                return
        if not rows:
            return
        _remember(_dest_name())
        dest = _dest_dir()
        try:
            drives.ensure_dir(dest)
        except drives.DriveOffline as e:
            toast(str(e), type="warning")
            return
        if state["kind"] == "media":
            await _download_media(rows, dest)
        else:
            await _download_beatport(rows, dest)

    def _landed(new_files, dest: Path, extra: str = "") -> None:
        """Fold arrivals into the library, check them, and tell the page."""
        from library import track_from_file
        runtime.library.tracks.extend(track_from_file(p) for p in new_files)
        runtime.refresh_batches()
        _verify_arrivals(new_files)
        name = _dest_name()
        toast(f"Downloaded {len(new_files)} → "
              + (f"“{name}” — ready to send." if name
                 else f"{dest.name}/. They need a home — file them from Incoming.")
              + extra,
              type="positive", timeout=12000)
        on_landed(new_files)

    async def _download_beatport(rows, dest: Path):
        ids = [r["bt"].id for r in rows]
        # The worker writes plain fields, a timer on the main loop renders them.
        # beatportdl says nothing per-track, so what it counts is the files that
        # have landed (`bpdl.download`).
        prog = {"done": 0, "total": len(ids), "label": ""}
        n = spinner(f"Downloading {len(ids)} from Beatport…")

        def _render():
            cur = f"  ·  {prog['label'][:46]}" if prog["label"] else ""
            n.message = f"Downloading {prog['done']}/{prog['total']} from Beatport{cur}"
        with root_col:                      # not the sender's slot — see `toast`
            timer = ui.timer(0.3, _render)

        def _on_prog(done, total, _frac, label):
            prog.update(done=done, total=total, label=label)

        try:
            new_files, log = await run.io_bound(bpdl.download, ids, dest,
                                                progress=_on_prog)
        except Exception as e:
            timer.deactivate()
            n.dismiss()
            toast(f"Beatport download failed: {e}", type="negative", timeout=9000)
            return
        timer.deactivate()
        n.dismiss()
        if new_files:
            _landed(new_files, dest)
        else:
            toast(f"Nothing downloaded. {bpdl.failure_reason(log)}",
                  type="negative", timeout=15000)

    async def _download_media(rows, dest: Path):
        entries = [{"url": r["mi"].url,
                    "title": (r["title_in"].value or "").strip(),
                    "artist": (r["artist_in"].value or "").strip()} for r in rows]
        prog = {"done": 0, "total": len(entries), "frac": 0.0, "label": ""}
        n = spinner("Downloading…")

        def _render():
            pct = f"  ·  {prog['frac'] * 100:.0f}%" if prog["frac"] else ""
            cur = f"  ·  {prog['label'][:46]}" if prog["label"] else ""
            n.message = f"Downloading {prog['done']}/{prog['total']}{pct}{cur}"
        with root_col:
            timer = ui.timer(0.3, _render)

        def _on_prog(done, total, frac, label):
            prog.update(done=done, total=total, frac=frac, label=label)

        try:
            new_files, log = await run.io_bound(ytdl.download, entries, dest, _on_prog)
        except Exception as e:
            timer.deactivate()
            n.dismiss()
            toast(f"Download error: {e}", type="negative", timeout=8000)
            return
        timer.deactivate()
        n.dismiss()
        if new_files:
            _landed(new_files, dest,
                    extra=(f"  ({len(entries) - len(new_files)} failed)"
                           if len(new_files) < len(entries) else ""))
        else:
            toast(f"No files downloaded. {log[:200]}", type="negative", timeout=10000)

    def _verify_arrivals(paths) -> None:
        """Packet-check what just landed, and say so if the audio isn't continuous.

        Seconds on a handful of files, against a set that falls apart on stage.
        A store download is always clean, so anything this finds means the file
        came down some other way — which is worth knowing at the moment it
        arrives, not the night you play it. Never fatal: the file is kept either
        way, because a false alarm must not cost you a download.
        """
        import integrity
        try:
            bad = integrity.verify_downloads(paths)
        except Exception as e:
            print(f"[acquire] integrity check failed: {e!r}")
            return
        if not bad:
            return
        worst = bad[0]
        toast(f"⚠ {len(bad)} of {len(paths)} downloaded file(s) have discontinuous "
              f"audio — “{worst.path.name}”: {worst.summary}. The beatgrid will "
              "drift; re-download or check Library → Check for problems.",
              type="warning", timeout=20000)

    # ==================================================================
    # inbox — files that arrived via the browser
    # ==================================================================

    def _known_paths() -> set:
        return {str(t.local_path).lower() for t in runtime.library.tracks
                if t.local_path}

    async def refresh_inbox() -> None:
        """Re-scan the inbox, and check each file against what you already own.

        The scan's own `known` filter is by path, which catches only a file
        already sitting in the library folder — an import *moves* the file, so
        the copy you own is somewhere else entirely under a different name. That
        case is what the library check below is for.

        Both halves read files and walk the whole library, so they run off the
        event loop together: the page paints before the folder is read.
        """
        def _work():
            files = inbox.scan(known=_known_paths())
            idx = dupes.Index(runtime.library.tracks)
            have = {str(f.path): e for f in files
                    if (e := idx.lookup(f.artist, f.title))}
            return files, have

        try:
            state["inbox"], state["have"] = await run.io_bound(_work)
            state["error"] = ""
        except Exception as e:
            state["inbox"], state["have"] = [], {}
            state["error"] = str(e)
            print(f"[inbox] scan failed: {e!r}")
        state["checked"] = set()
        state["scanned"] = True
        render_inbox()

    def set_filter(value) -> None:
        state["filter"] = (value or "").strip().lower()
        render_inbox()

    def _visible() -> list:
        q = state["filter"]
        files = [f for f in state["inbox"]
                 if not q or q in f.path.name.lower() or q in f.display.lower()]
        return files if state["show_all"] else files[:INBOX_PREVIEW]

    def toggle_check(path_str: str, on: bool) -> None:
        state["checked"].discard(path_str) if not on else state["checked"].add(path_str)
        _sync_import_btn()

    def _sync_import_btn() -> None:
        n = len(state["checked"])
        name = _dest_name()
        import_btn.set_visibility(bool(n))
        import_btn.text = f"Import {n}" + (f" → {name}" if name else "")

    def render_inbox() -> None:
        inbox_col.clear()
        files, total = _visible(), len(state["inbox"])
        folder = inbox.default_folder()
        n_have = len(state["have"])
        inbox_lbl.set_text(
            f"{total} file(s) in {folder} not yet in the library"
            + (f"  ·  {n_have} you may already have" if n_have else "")
            if total else f"Nothing new in {folder}")
        _sync_import_btn()
        if state["error"]:
            # Four lines of macOS permissions instructions. As loose orange text
            # it read as an alarm; in a box it reads as the thing to do next.
            with inbox_col:
                with ui.row().classes("a-callout items-start no-wrap gap-2 w-full"):
                    ui.icon("lock", size="17px") \
                        .style("color:#d29922; flex:none; margin-top:1px")
                    ui.label(state["error"]).style("min-width:0")
            return
        if not files:
            return
        with inbox_col:
            for f in files:
                key = str(f.path)
                with ui.row().classes("items-center gap-2 no-wrap w-full a-file"):
                    ui.checkbox(value=key in state["checked"],
                                on_change=lambda e, k=key: toggle_check(k, e.value)) \
                        .props("dense")
                    f.artist_in = ui.input(placeholder="Artist", value=f.artist) \
                        .props("outlined dense").style("width:200px")
                    f.title_in = ui.input(placeholder="Title", value=f.title) \
                        .props("outlined dense").classes("flex-grow") \
                        .style("min-width:0")
                    have = state["have"].get(key)
                    if have:
                        ui.badge(have.chip) \
                            .props("color=warning" if have.certain else "color=grey-7") \
                            .tooltip(have.detail)
                    ui.label(f"{f.size / 1e6:.0f} MB").classes("a-mono") \
                        .style("width:52px; text-align:right")
                    badge = ui.badge(f.ext.lstrip("."))
                    badge.props("color=grey-8" if f.taggable else "color=warning")
                    if not f.taggable:
                        badge.tooltip("the analyzer writes .mp3/.m4a only — this "
                                      "will import but can't carry an Energy tag")
                    if f.from_tags:
                        ui.icon("sell").classes("text-caption") \
                            .style("color:#2dd4bf").tooltip("names read from the "
                                                            "file's own tags")
            if total > len(files) and not state["show_all"]:
                ui.button(f"Show all {total}",
                          on_click=lambda: (state.update(show_all=True),
                                            render_inbox())) \
                    .props("flat dense no-caps size=sm color=grey")

    async def do_import():
        picked = [f for f in state["inbox"] if str(f.path) in state["checked"]]
        if not picked:
            return
        root = runtime._dl_root()
        name = _dest_name()
        _remember(name)
        # The destination's folder, so an imported file arrives filed like any
        # other arrival. Without one it lands in `Imported/`, a door.
        folder = destinations.safe(name) if name else inbox.IMPORT_FOLDER
        edits = [(f, (getattr(f, "artist_in", None).value if getattr(f, "artist_in", None) else f.artist),
                  (getattr(f, "title_in", None).value if getattr(f, "title_in", None) else f.title))
                 for f in picked]

        def _work():
            done, errors = [], []
            for f, artist, title in edits:
                try:
                    done.append(inbox.import_file(f, root, artist, title, folder=folder))
                except Exception as e:
                    errors.append(f"{f.path.name}: {e}")
            return done, errors

        n = spinner(f"Importing {len(picked)}…")
        moved, errors = await run.io_bound(_work)
        from library import track_from_file
        runtime.library.tracks.extend(track_from_file(p) for p in moved)
        runtime.refresh_batches()
        n.dismiss()
        await refresh_inbox()
        if moved:
            toast(f"Imported {len(moved)} → {root / folder}."
                  + ("  They're ready to send." if name
                     else "  They need a home — file them from Incoming.")
                  + (f"  ({len(errors)} failed)" if errors else ""),
                  type="positive" if not errors else "warning", timeout=12000)
            on_landed(moved)
        else:
            toast(f"Nothing imported. {errors[0] if errors else ''}",
                  type="negative", timeout=9000)

    # ==================================================================
    # refresh — called by the page whenever the panel comes on screen
    # ==================================================================

    def refresh() -> None:
        """Re-seed the picker from the page's selection and scan the inbox once.

        The scan reads tags and walks the library, so it is paid the first time
        the panel is actually looked at — never on every Incoming visit.
        """
        opts = choices()
        dest_select.options = opts
        if not _dest_name():
            default = default_destination()
            if default and default in opts:
                dest_select.value = default
        dest_select.update()
        _sync_dest()
        if not state["scanned"]:
            inbox_lbl.set_text("Scanning your downloads folder…")
            ui.timer(0.05, refresh_inbox, once=True)

    _sync_fetch_btn()
    return refresh
