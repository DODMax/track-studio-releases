"""The crate dock — a slide-out shelf along the bottom of any page.

Crates are a preselection you gather while you dig (see `crates`), and the
whole point is that gathering happens **wherever you happen to be**: you are
looking at a playlist, you notice a track, you put it in "Friday" and carry on.
So this is not a page. It mounts on any page that lists tracks, and the rest of
that page keeps working underneath it.

### Why it is written in raw HTML and CSS

It is deliberately **Setline's** UI, not Track Studio's: the card with its
sleeve, the shelf that scrolls sideways, the tab strip. That look is 628 lines
of hand-written CSS in Setline's `app.css` — there is no component library to
adopt — so the honest way to have it here is to bring the CSS. The classes,
sizes and colours below are lifted from `.dock`, `.tabs`, `.shelf` and `.card`
there, prefixed `ts-` so they cannot collide with Quasar's.

The two palettes turned out to be the same language typed twice — Setline's
`--accent` and `--smooth` are the exact hexes Track Studio already uses, and
both derive a Camelot pill from the wheel hour with the same formula — so the
tokens here are Setline's `:root` block and `widgets.camelot_color` is used
unchanged.

### Why the dragging never touches the server

A drag is a stream of events at pointer rate; a NiceGUI round trip costs tens
of milliseconds (a table checkbox measured ~60 ms). So the drag is plain HTML5
drag-and-drop handled entirely in the browser, and **only the drop crosses the
wire** — one `emitEvent` carrying a track key. Same rule that fixed the table:
keep the interaction local, send the decision.

Listeners are delegated from `document`, because the dock's markup is replaced
wholesale on every change and anything bound to an element inside it would be
thrown away with it.

### It follows the night open on the board

With the board mounted (`setline_local`) the dock *is* the board's shelf: a
crate belongs to no night, and a night uses the crates attached to it (0003 §8).
So once a night is open on the board, the piles under every page are that
night's — you attach them there, go and dig, and the selection comes with you —
with a switch to the whole shelf, and an "on tonight" toggle on any crate, so a
pile started mid-dig can join the night without a trip back to the board. With
no night open it is the whole shelf, which is also what pure digging wants.
"""
from __future__ import annotations

import json
from typing import Callable, Optional

from nicegui import ui

import crates
import runtime
from library import track_key
from widgets import camelot_color

from . import crate_fill, kit

# Setline's tokens live in `kit`, scoped here to the dock — they are shared
# with the acquire panel and the fill screen, and one drifting copy is how two
# surfaces stop looking like one app. Kept out of `shell.apply_theme` so the
# block can still be compared against Setline side by side, which is what its
# own brief asks for when its CSS and the mockup drift.
_CSS = "<style>\n" + kit.scope(".ts-dock") + """
.ts-dock {
  /* The closed height, in one place: the header is exactly this tall and the
     dock slides down by everything else, so the two can't disagree and leave
     the strip clipped by a pixel. */
  --head:38px;
  position:fixed; left:0; right:0; bottom:0; z-index:2000;
  background:var(--surface); border-top:1px solid var(--line);
  color:var(--ink); font-size:13px;
  box-shadow:0 -12px 40px rgba(0,0,0,.45);
  transform:translateY(calc(100% - var(--head))); transition:transform .22s ease;
}
/* Borders and padding count *inside* the boxes here. Without it the header's
   own border-bottom lands outside its declared height, which both clips the
   closed strip and makes the content taller than the box that holds it. */
.ts-dock, .ts-dock * { box-sizing:border-box; }
.ts-dock.open { transform:translateY(0); }
/* The grabbed track follows the pointer; the shelf has to be reachable while it
   does, so the dock comes up on its own the moment a drag starts. */
body.ts-dragging .ts-dock { transform:translateY(0); }

/* `overflow-x:auto` makes the browser compute `overflow-y:auto` as well — the
   other axis can't stay `visible` — so a header one pixel over its own height
   grows a vertical scrollbar. It is a fixed-height strip and has nothing to
   scroll to vertically, so that axis is shut off explicitly. */
.ts-tabs { display:flex; gap:2px; padding:0 8px; border-bottom:1px solid var(--line);
  overflow-x:auto; overflow-y:hidden; height:var(--head); align-items:stretch;
  scrollbar-width:none; }
.ts-tabs::-webkit-scrollbar { display:none; }
/* Setline pulls the tab down a pixel (`margin-bottom:-1px`) so the selected
   underline covers the header's own border. That works there because its
   header has no fixed height and simply grows; here it made the tab's box a
   pixel taller than the strip holding it, which is the overflow. The underline
   sits just inside instead — against the border rather than over it, which
   reads the same. */
.ts-tab { background:none; border:0; padding:0 12px; cursor:pointer; color:var(--ink-2);
  font-weight:600; font-size:13px; border-bottom:2px solid transparent;
  white-space:nowrap; font-family:inherit; }
.ts-tab:hover { color:var(--ink); }
.ts-tab[aria-selected="true"] { color:var(--ink); border-bottom-color:var(--accent); }
.ts-tab .n { font:500 11px ui-monospace,Menlo,monospace; color:var(--ink-3); margin-left:5px; }
.ts-tab.add { color:var(--smooth); }
.ts-grip { margin-left:auto; display:flex; align-items:center; gap:10px; padding-left:12px;
  color:var(--ink-3); font-size:11.5px; white-space:nowrap; }
.ts-grip button { background:none; border:0; color:var(--ink-3); cursor:pointer;
  font-size:15px; line-height:1; padding:4px 6px; font-family:inherit; }
.ts-grip button:hover { color:var(--ink); }
/* The one verb in the strip, so it carries the accent — everything else up
   here is navigation. */
.ts-fill-btn { color:var(--accent) !important; font-weight:650; font-size:12px !important;
  border:1px solid rgba(255,122,26,.35) !important; border-radius:6px;
  padding:3px 9px !important; }
.ts-fill-btn:hover { background:rgba(255,122,26,.14); color:var(--accent) !important; }

.ts-panel { padding:10px 12px 12px; }
.ts-shelf { display:flex; gap:8px; overflow-x:auto; padding-bottom:6px; min-height:124px;
  border-radius:8px; align-items:flex-start; }
.ts-shelf.drop-target { outline:2px dashed var(--accent); outline-offset:2px; }
body.ts-dragging .ts-shelf { outline:2px dashed var(--line-2); outline-offset:2px; }

.ts-card { position:relative; width:196px; height:116px; flex:none;
  background:var(--raised); border:1px solid var(--line); border-radius:8px;
  padding:7px 8px 6px; display:grid; grid-template-rows:auto 1fr auto; gap:4px;
  cursor:grab; user-select:none; overflow:hidden;
  transition:border-color .15s, background .15s; }
.ts-card:hover { border-color:var(--line-2); background:var(--raised-2); }
.ts-card .c-top { display:flex; gap:7px; align-items:flex-start; min-width:0; }
.ts-card .art { width:46px; height:46px; border-radius:4px; flex:none; overflow:hidden;
  background:var(--raised-2); display:grid; place-items:center; color:var(--ink-3); }
.ts-card .art img { width:100%; height:100%; object-fit:cover; display:block; }
.ts-card .c-text { min-width:0; }
.ts-card .c-title { font-size:12px; font-weight:650; line-height:1.2; color:var(--ink);
  display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
.ts-card .c-artist { font-size:11px; color:var(--ink-3); margin-top:2px;
  white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.ts-card .c-foot { display:flex; align-items:center; gap:6px; font-size:11px; color:var(--ink-2); }
.ts-card .mono { font-family:ui-monospace,Menlo,monospace; font-size:10.5px; }
.ts-card .key { font:600 10px/1 ui-monospace,Menlo,monospace; padding:3px 5px; border-radius:4px; }
.ts-card .c-remove { position:absolute; top:5px; right:5px; width:18px; height:18px;
  border:0; border-radius:4px; background:rgba(12,13,17,.6); color:var(--ink-3);
  cursor:pointer; opacity:0; display:grid; place-items:center; font-size:13px;
  line-height:1; font-family:inherit; }
.ts-card:hover .c-remove { opacity:1; }
.ts-card .c-remove:hover { color:var(--ink); background:rgba(12,13,17,.9); }

/* Whose crates these are: the night open on the board, or the whole shelf. */
.ts-scope { display:inline-flex; border:1px solid var(--line-2); border-radius:6px; overflow:hidden; }
.ts-scope button { font-size:11.5px !important; padding:3px 8px !important; border-radius:0; color:var(--ink-3); }
.ts-scope button[aria-pressed="true"] { background:var(--raised-2); color:var(--ink) !important; }
.ts-tonight { font-size:11.5px !important; border:1px solid var(--line-2) !important; border-radius:6px;
  padding:3px 8px !important; }
.ts-tonight[aria-pressed="true"] { color:var(--smooth) !important; border-color:rgba(45,212,191,.45) !important; }
.ts-tab .on-night { display:inline-block; width:6px; height:6px; border-radius:50%; background:var(--smooth);
  margin-left:6px; vertical-align:middle; }

.ts-hint { color:var(--ink-3); font-size:12.5px; padding:10px 2px; }
.ts-hint b { color:var(--ink-2); font-weight:600; }

/* Room for the dock. It is fixed to the bottom of the viewport, so anything a
   page puts at the bottom of a scroll area ends up *under* it — the sidebar's
   last playlist was unreachable, which is the whole bug. Reserve the closed
   strip always, and the open shelf while it is open, so both scroll areas can
   still reach their last row. The custom property is on `body` so a browser
   without `:has()` still gets the closed reserve rather than nothing. */
body { --ts-dock-room:38px; }
body:has(.ts-dock.open) { --ts-dock-room:200px; }
body.ts-dragging { --ts-dock-room:200px; }
.q-drawer .q-drawer__content { padding-bottom:var(--ts-dock-room); }
.q-page-container { padding-bottom:var(--ts-dock-room); }
/* The fill screen is a maximized dialog *over* the dock, not a page under it. */
.q-dialog .q-page-container, .ts-fill { padding-bottom:0; }

/* The crate cell in a track table. Outside the dock, so it can't use the
   dock's custom properties and carries its own hexes — the same ones. */
.ts-cell { display:flex; align-items:center; gap:4px; justify-content:flex-start; }
.ts-grab { cursor:grab; color:#4b5563; font-size:13px; line-height:1; padding:2px 4px;
  border-radius:4px; user-select:none; flex:none; }
.ts-grab:hover { color:#e8eaef; background:#2a2d35; }
.ts-grab:active { cursor:grabbing; }
/* What this track is already in. Teal rather than orange: orange is the accent
   for what you're acting on, and membership is a standing fact about the row. */
.ts-in { cursor:pointer; font-size:10px; font-weight:700; line-height:1;
  padding:3px 6px; border-radius:10px; background:rgba(45,212,191,.15);
  color:#2dd4bf; border:1px solid rgba(45,212,191,.35); white-space:nowrap; }
.ts-in:hover { background:rgba(45,212,191,.3); color:#7ff0e2; }
/* The way in without dragging — for a trackpad, a keyboard, or a long list
   where dragging to the bottom of the screen is the worse gesture. Quiet until
   the row is under the pointer, so 3 500 of them don't read as content. */
.ts-add { cursor:pointer; color:#3a3f4b; font-size:13px; line-height:1;
  padding:2px 5px; border-radius:4px; }
tr:hover .ts-add { color:#6b7280; }
.ts-add:hover { color:#2dd4bf; background:#2a2d35; }
</style>
"""

# One delegated listener set per client, wired once. `emitEvent` is NiceGUI's
# own global bridge (nicegui.js), which is how raw markup talks back to Python.
_JS = """
<script>
(() => {
  if (window.__tsCrateWired) return;
  window.__tsCrateWired = true;
  const KEY = 'application/x-track-key';

  document.addEventListener('dragstart', (e) => {
    const h = e.target.closest && e.target.closest('[data-track-key]');
    if (!h) return;
    e.dataTransfer.setData(KEY, h.dataset.trackKey);
    e.dataTransfer.setData('text/plain', h.dataset.trackKey);
    e.dataTransfer.effectAllowed = 'copy';
    document.body.classList.add('ts-dragging');
  });
  document.addEventListener('dragend', () => {
    document.body.classList.remove('ts-dragging');
    document.querySelectorAll('.ts-shelf').forEach(s => s.classList.remove('drop-target'));
  });

  const shelfOf = (e) => e.target.closest && e.target.closest('.ts-shelf');
  document.addEventListener('dragover', (e) => {
    const s = shelfOf(e);
    if (!s) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    s.classList.add('drop-target');
  });
  document.addEventListener('dragleave', (e) => {
    const s = shelfOf(e);
    if (s && !s.contains(e.relatedTarget)) s.classList.remove('drop-target');
  });
  document.addEventListener('drop', (e) => {
    const s = shelfOf(e);
    if (!s) return;
    e.preventDefault();
    s.classList.remove('drop-target');
    const key = e.dataTransfer.getData(KEY) || e.dataTransfer.getData('text/plain');
    if (key) emitEvent('crate_drop', {key: key});
  });

  document.addEventListener('click', (e) => {
    const el = e.target.closest && e.target.closest('[data-crate-act]');
    if (!el) return;
    e.preventDefault();
    emitEvent('crate_act', {act: el.dataset.crateAct, id: el.dataset.crateId || '',
                            key: el.dataset.trackKey || ''});
  });
})();
</script>
"""


def grab_cell(key: str = "props.row.crate_key",
              label: str = "props.row.in_crates",
              full: str = "props.row.in_crates_full") -> str:
    """The crate cell for a track table: drag handle, plus what it's already in.

    Two jobs in one narrow column. The handle starts a drag; the chip beside it
    says which crates already hold this track — without it the dock is
    write-only from the table's side, and the only way to answer "have I
    crated this?" is to open each crate and look. Both the chip and the `+`
    open the picker, which is the path for anyone not dragging.

    Arguments are JS expressions so a page can name its own row fields.
    """
    return (
        '<div class="ts-cell">'
        f'<span class="ts-grab" draggable="true" :data-track-key="{key}" '
        'title="Drag into a crate">⠿</span>'
        f'<span v-if="{label}" class="ts-in" data-crate-act="pick" '
        f':data-track-key="{key}" :title="{full}">{{{{ {label} }}}}</span>'
        f'<span v-else class="ts-add" data-crate-act="pick" :data-track-key="{key}" '
        'title="Add to a crate">+</span>'
        '</div>')


def membership(index: dict, key: str) -> tuple[str, str]:
    """(chip label, tooltip) for a row, given `crates.index()`.

    One crate reads as its name; more than one reads as a count, because three
    names in a table column is a paragraph. The full list is the tooltip.
    """
    names = index.get(key) or []
    if not names:
        return "", ""
    label = names[0] if len(names) == 1 else f"{len(names)} crates"
    return label, "In " + ", ".join(names)


def mount(*, on_change: Optional[Callable[[], None]] = None) -> Callable[[], None]:
    """Build the dock into the current page. Returns its `refresh()`.

    `on_change` fires after anything is added or removed, so the host page can
    repaint the chips that say which crates a row is in.
    """
    ui.add_head_html(_CSS)
    ui.add_head_html(_JS)
    st = runtime.crate_state
    holder = ui.element("div").classes("ts-dock")

    def _active(live: list) -> Optional[object]:
        if not live:
            return None
        found = next((c for c in live if c.id == st["active"]), None)
        return found or live[0]

    def _card(item, by_key: dict) -> str:
        # A crate on the board can hold a record with no file here (found on
        # Beatport on the board): it carries its own name for exactly this.
        t = by_key.get(item.track_key)
        title = t.title if t is not None else (item.title or item.track_key)
        artist = (t.artist if t is not None else item.artist) or "—"
        bpm_v = t.bpm if t is not None else item.bpm
        bpm = f"{round(bpm_v)}" if bpm_v else "—"
        key = (t.key if t is not None else item.key) or ""
        art = (f'<img src="/artwork?path={_q(str(t.local_path))}" alt="" loading="lazy" '
               f'draggable="false" onerror="this.remove()">'
               if (t is not None and t.local_path) else "")
        pill = (f'<span class="key" style="background:{camelot_color(key)};color:#fff">'
                f'{_e(key)}</span>' if key else "")
        return (
            f'<div class="ts-card" draggable="true" data-track-key="{_a(item.track_key)}">'
            f'<div class="c-top">'
            f'<div class="art">{art or "♪"}</div>'
            f'<div class="c-text"><div class="c-title" title="{_a(title)}">{_e(title)}</div>'
            f'<div class="c-artist">{_e(artist)}</div></div>'
            f'</div>'
            f'<div class="c-foot"><span class="mono">{bpm}</span>{pill}</div>'
            f'<button class="c-remove" title="Take out of this crate" '
            f'data-crate-act="remove" data-track-key="{_a(item.track_key)}">×</button>'
            f'</div>')

    def _night() -> tuple[Optional[int], str]:
        """The night open on the board and its name, or (None, "") — no board, no
        night open, or one that has since gone."""
        import setline_local
        night = runtime.board_state.get("night") if setline_local.running() else None
        if night is None:
            return None, ""
        name = next((n for i, n, _ in setline_local.nights() if i == night), None)
        if name is None:
            runtime.board_state["night"] = None
            return None, ""
        return night, name

    def _scoped() -> tuple[list, Optional[int], str, bool]:
        """(live crates shown, the open night, its name, whether showing just its own)."""
        night, name = _night()
        mine = night is not None and st.get("scope", "night") != "all"
        return crates.live(crates.load(night=night if mine else None)), night, name, mine

    def render() -> None:
        live, night, night_name, mine = _scoped()
        active = _active(live)
        st["active"] = active.id if active else None
        by_key = {track_key(t): t for t in runtime.library.tracks}

        tabs = "".join(
            f'<button class="ts-tab" role="tab" aria-selected="{str(active is not None and c.id == active.id).lower()}" '
            f'data-crate-act="open" data-crate-id="{_a(c.id)}">{_e(c.name)}'
            f'<span class="n">{len(c.tracks)}</span>'
            + ('<span class="on-night" title="On tonight"></span>' if (not mine and night in c.nights) else "")
            + '</button>'
            for c in live)
        tabs += ('<button class="ts-tab add" data-crate-act="new">+ New crate</button>')
        # "Fill" only once the crate has something to rank against — the screen
        # is seeded from what's in the crate, so offering it on an empty one
        # promises an answer it can't give.
        fill = ('<button class="ts-fill-btn" data-crate-act="fill" '
                'title="Suggest tracks that belong with this crate">'
                '✨ Fill</button>'
                if active is not None and active.tracks else "")
        scope = ""
        if night is not None:
            # Whose crates these are, said where you'd look for it, and switchable.
            scope = ('<span class="ts-scope" role="group" aria-label="Which crates">'
                     f'<button data-crate-act="scope" data-crate-id="night" aria-pressed="{str(mine).lower()}" '
                     f'title="The crates on {_a(night_name)}, the night open on the board">{_e(night_name)}</button>'
                     f'<button data-crate-act="scope" data-crate-id="all" aria-pressed="{str(not mine).lower()}" '
                     'title="Every crate you keep, on any night or none">All crates</button></span>')
            if active is not None:
                on = night in active.nights
                scope += (f'<button class="ts-tonight" data-crate-act="{"detach" if on else "attach"}" '
                          f'data-crate-id="{_a(active.id)}" aria-pressed="{str(on).lower()}" '
                          f'title="{"Take " + _a(active.name) + " off" if on else "Put " + _a(active.name) + " on"} '
                          f'{_a(night_name)}">{"✓ On tonight" if on else "+ On tonight"}</button>')
        grip = ('<span class="ts-grip">'
                + ("drag a track here" if not live else "")
                + scope
                + fill
                + f'<button data-crate-act="toggle" title="{"Hide" if st["open"] else "Show"} crates">'
                + ("▾" if st["open"] else "▴") + "</button></span>")

        # The shelf is always the drop target, empty or not — including with no
        # crates at all, which is exactly when someone drags for the first time.
        # A hint that isn't droppable makes the first gesture fail silently.
        if active is None and mine:
            inner = (f'<div class="ts-hint"><b>No crates on {_e(night_name)} yet.</b> Drop a track '
                     "here and one starts on it, name one, or put one of yours on it from "
                     "<b>All crates</b>.</div>")
        elif active is None:
            inner = ('<div class="ts-hint"><b>No crates yet.</b> A crate is a pile '
                     "you dig out of the library before you program a set — a "
                     "genre, a mood, a “maybe for Friday”. Drop a track here and "
                     "one starts itself, or name one first.</div>")
        else:
            inner = "".join(_card(i, by_key) for i in active.tracks)
            if not inner:
                inner = ('<div class="ts-hint">Nothing in ' + _e(active.name)
                         + " yet — drag a track in from the table above.</div>")
        body = f'<div class="ts-panel"><div class="ts-shelf">{inner}</div></div>'

        holder.classes(add="open" if st["open"] else "", remove="" if st["open"] else "open")
        holder.clear()
        with holder:
            # `sanitize=False` because the markup carries the `draggable` and
            # `data-crate-act` attributes the whole dock is wired through, and
            # a sanitiser strips them. Everything interpolated into it is
            # escaped at the point of use instead — see `_e` / `_a` / `_q`.
            ui.html(f'<div class="ts-tabs" role="tablist">{tabs}{grip}</div>{body}',
                    sanitize=False)

    # ---------------- events from the markup ----------------

    def _changed() -> None:
        render()
        if on_change:
            on_change()

    def on_drop(e) -> None:
        key = (e.args or {}).get("key") or ""
        if not key:
            return
        live, night, _, mine = _scoped()
        active = _active(live)
        if active is None:
            # Dropping with nothing to drop into is a request for a crate, not
            # an error — the alternative is a dead gesture and a toast.
            active = crates.create("Crate 1", night=night if mine else None)
            st["active"] = active.id
        n = crates.add(active.id, key)
        st["open"] = True
        _changed()
        with holder:
            ui.notify(f"Added to “{active.name}”" if n else f"Already in “{active.name}”",
                      type="positive" if n else "info")

    def on_act(e) -> None:
        args = e.args or {}
        act, cid, key = args.get("act"), args.get("id"), args.get("key")
        if act == "toggle":
            st["open"] = not st["open"]
            render()
        elif act == "open":
            st["active"] = cid
            st["open"] = True
            render()
        elif act == "scope":
            st["scope"] = "all" if cid == "all" else "night"
            st["open"] = True
            render()
        elif act in ("attach", "detach") and cid:
            night, name = _night()
            if night is None:
                return
            crates.attach(cid, night) if act == "attach" else crates.detach(cid, night)
            _changed()
            with holder:
                ui.notify(f"On {name}" if act == "attach" else f"Off {name} — still on your shelf",
                          type="positive" if act == "attach" else "info")
        elif act == "new":
            _new_crate_dialog()
        elif act == "fill":
            live = _scoped()[0]
            active = _active(live)
            if active is not None:
                crate_fill.open_fill(active.id, on_change=_changed)
        elif act == "pick" and key:
            _pick_dialog(key)
        elif act == "remove" and key:
            live = _scoped()[0]
            active = _active(live)
            if active:
                crates.remove(active.id, key)
                _changed()

    def _pick_dialog(key: str) -> None:
        """Which crates hold this track, as a list you can tick.

        The same act as dragging, for when dragging is the worse gesture — a
        trackpad, or a row near the top of three thousand with the dock at the
        bottom of the screen. Ticks apply immediately rather than on a Save:
        there is nothing to be consistent across, and a dialog you can leave
        open while you change your mind is the point.
        """
        t = next((x for x in runtime.library.tracks if track_key(x) == key), None)
        with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[26rem]"):
            ui.label("Crates").classes("text-subtitle1 text-weight-bold")
            ui.label(t.display if t is not None else key) \
                .classes("text-caption text-grey ellipsis").style("min-width:0")
            holder = ui.column().classes("w-full gap-0 q-mt-sm")

            def paint() -> None:
                holder.clear()
                lives = crates.live(crates.load())
                with holder:
                    if not lives:
                        ui.label("No crates yet — start one below.") \
                            .classes("text-caption text-grey")
                    for c in lives:
                        ui.checkbox(f"{c.name}   ({len(c.tracks)})", value=c.holds(key),
                                    on_change=lambda e, cid=c.id: toggle(cid, e.value)) \
                            .props("dense")

            def toggle(cid: str, on: bool) -> None:
                crates.add(cid, key) if on else crates.remove(cid, key)
                st["active"] = cid
                _changed()
                paint()

            def new_here() -> None:
                _, night, _, mine = _scoped()
                c = crates.create("Untitled", night=night if mine else None)
                crates.add(c.id, key)
                st["active"] = c.id
                st["open"] = True
                _changed()
                paint()

            paint()
            with ui.row().classes("items-center w-full gap-2 q-mt-md"):
                ui.button("New crate with this", icon="add", on_click=new_here) \
                    .props("flat dense no-caps color=secondary")
                ui.space()
                ui.button("Done", on_click=d.close).props("unelevated color=primary")
        d.open()

    def _new_crate_dialog() -> None:
        with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[26rem]"):
            ui.label("New crate").classes("text-subtitle1 text-weight-bold")
            ui.label("A pile to dig out of the library before you program a set.") \
                .classes("text-caption text-grey")
            name = ui.input("Name it: Techno, Friday, Maybe…") \
                .props("outlined dense autofocus").classes("w-full")

            def make() -> None:
                _, night, _, mine = _scoped()
                c = crates.create(name.value or "", night=night if mine else None)
                st["active"] = c.id
                st["open"] = True
                d.close()
                _changed()
            name.on("keydown.enter", make)
            with ui.row().classes("justify-end w-full gap-2 q-mt-md"):
                ui.button("Cancel", on_click=d.close).props("flat color=grey")
                ui.button("Create", on_click=make).props("unelevated color=primary")
        d.open()

    ui.on("crate_drop", on_drop)
    ui.on("crate_act", on_act)
    render()
    return render


# ---------------------------------------------------------------- escaping
# The dock is built as a markup string, so everything interpolated into it is
# escaped at the point of use. Track titles are read from file tags and are
# not trustworthy input: this library already contains filenames carrying raw
# `&#39;` entities from whatever wrote them.

def _e(s) -> str:
    """Escape for element text."""
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _a(s) -> str:
    """Escape for a double-quoted attribute."""
    return _e(s).replace('"', "&quot;")


def _q(s) -> str:
    """Percent-encode for a query string."""
    from urllib.parse import quote
    return quote(str(s), safe="")
