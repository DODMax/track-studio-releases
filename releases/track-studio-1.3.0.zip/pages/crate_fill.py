"""“Fill this crate” — proposals for a crate, on a screen of their own.

The point of the screen is that it is **intermediary**. Nothing enters a crate
because the app thought it should: each proposal arrives with its reason, its
artwork and a player, and the crate changes only when you press Add on that
one. A crate is a hand-made thing (see `crates`), and a suggester that wrote
into it directly would be quietly un-making it.

What it ranks against is the crate itself, not one track — `mixmodel.fill`
scores every library track against the crate's own members and keeps the best
few, so "belongs with this pile" is the question rather than "plays after this
track". Every row says which member it sits closest to and why, because a
recommendation you can't disagree with is one you can't use either.

Why it is worth trusting at all: measured by holding out one gig at a time and
rebuilding the model without it, the track actually played next landed in the
top 5 of 3 493 candidates 4.9% of the time against 0.1% by chance — ~34x. That
is the same scoring this screen ranks with, and it is also why the reasons
matter: ×34 is far from certainty.

A dialog rather than a route, because filling a crate happens *in the middle of
something else* — you are digging through a playlist, you open it, you close it
and the page underneath is exactly where you left it, scroll position and all.
"""
from __future__ import annotations

from typing import Callable, Optional
from urllib.parse import quote

from nicegui import run, ui

import crates
import runtime
import vectors
from library import track_key
from widgets import ENERGY_COLORS, audio_player, camelot_color

from . import kit

# Proposals per page. Ten is about what fits on a screen with a player each,
# and about as far down a ranking as anyone reads before re-ranking is the
# better move anyway.
PAGE = 10

_CSS = "<style>\n" + kit.scope(".ts-fill") + """
.ts-fill { background:var(--ground); color:var(--ink); font-size:13px;
  width:100%; height:100%; max-width:none; padding:0; border-radius:0; }
/* Width has to be said out loud on every band: the dialog's card lays its
   children out in a flex column that sizes them to their content, so a header
   with a background of its own otherwise stops halfway across the screen. */
.ts-fill .f-wrap { width:100%; max-width:62rem; margin:0 auto; }
/* The head stays put: it carries the crate's name, its count as it grows, and
   the way out. Scrolling ten proposals should never lose any of the three. */
.ts-fill .f-head { position:sticky; top:0; z-index:3; width:100%;
  background:var(--surface); border-bottom:1px solid var(--line);
  padding:11px 16px; }
.ts-fill .f-title { font-size:19px; font-weight:700; letter-spacing:-.015em; }
.ts-fill .f-back { color:var(--ink-2) !important; flex:none; }
.ts-fill .f-back:hover { color:var(--ink) !important; background:var(--raised-2); }
.ts-fill .f-sub { font-size:12.5px; color:var(--ink-3); line-height:1.5; }
.ts-fill .f-seeded { font-size:12px; color:var(--ink-3); }
.ts-fill .f-seeded b { color:var(--ink-2); font-weight:600; }
.ts-fill .f-body { width:100%; padding:14px 16px 28px; }

.ts-fill .f-hit { background:var(--raised); border:1px solid var(--line);
  border-radius:10px; padding:10px 12px; transition:border-color .15s; }
.ts-fill .f-hit:hover { border-color:var(--line-2); }
/* Taken: the row stays where it is, dimmed. Re-sorting under the pointer the
   moment you add something is how you lose your place in a list you are
   reading. */
.ts-fill .f-hit.taken { opacity:.55; border-color:var(--smooth); }
.ts-fill .f-score { font:700 17px/1 ui-sans-serif,system-ui; min-width:26px; }
.ts-fill .f-art { width:52px; height:52px; border-radius:6px; flex:none;
  overflow:hidden; background:var(--raised-2); display:grid; place-items:center;
  color:var(--ink-3); }
.ts-fill .f-art img { width:100%; height:100%; object-fit:cover; display:block; }
.ts-fill .f-name { font-size:13.5px; font-weight:600; color:var(--ink); }
.ts-fill .f-artist { font-size:12px; color:var(--ink-3); }
.ts-fill .f-genre { font-size:10.5px; color:var(--ink-3); background:var(--raised-2);
  border:1px solid var(--line); border-radius:4px; padding:2px 5px; flex:none;
  white-space:nowrap; }
.ts-fill .f-why { font-size:12px; color:var(--ink-2); line-height:1.45; }
.ts-fill .f-why b { color:var(--ink); font-weight:600; }
.ts-fill .f-pill { font:650 10px/1 ui-monospace,Menlo,monospace; padding:4px 6px;
  border-radius:4px; color:#fff; }
.ts-fill .f-chip { font-size:10.5px; font-weight:650; line-height:1; padding:4px 7px;
  border-radius:10px; background:rgba(45,212,191,.15); color:var(--smooth);
  border:1px solid rgba(45,212,191,.35); white-space:nowrap; }
.ts-fill .f-mono { font-family:ui-monospace,Menlo,monospace; font-size:11px;
  color:var(--ink-2); }
.ts-fill .f-note { font-size:12px; color:var(--warn); }
.ts-fill .f-empty { color:var(--ink-3); font-size:13px; line-height:1.6; }
</style>
"""


def _art(path) -> None:
    """The sleeve, at the size `media.ART_PX` already serves thumbnails in."""
    with ui.element("div").classes("f-art"):
        if path:
            ui.html(f'<img src="/artwork?path={quote(str(path), safe="")}" alt="" '
                    'loading="lazy" onerror="this.remove()">', sanitize=False)
        else:
            ui.label("♪")


def open_fill(crate_id: str, on_change: Optional[Callable[[], None]] = None) -> None:
    """Open the fill screen for one crate. `on_change` fires after each Add."""
    ui.add_head_html(_CSS)
    crate = next((c for c in crates.live(crates.load()) if c.id == crate_id), None)
    if crate is None:
        ui.notify("That crate is gone", type="warning")
        return

    # Per-opening. `added` is what this session put in, which is the only thing
    # the screen needs to remember: everything else is re-read from disk.
    state = {"offset": 0, "items": [], "added": set(), "seeds": [], "gigs": 0,
             "n_cands": 0, "known": 0, "heard": 0, "seeds_heard": 0}

    with ui.dialog().props("maximized") as dlg, \
            ui.card().classes("ts-fill").props("flat"):
        with ui.element("div").classes("f-head"):
            with ui.row().classes("f-wrap items-center no-wrap gap-3"):
                # The way out, where a full-screen sheet is read from: leftmost,
                # before the title. "Done" in the far corner is the commit
                # gesture, and on a screen that commits nothing it was the only
                # exit — which read as no exit at all.
                ui.button(icon="arrow_back", on_click=dlg.close) \
                    .props("flat round dense") \
                    .classes("f-back").tooltip("Back to what you were doing (Esc)")
                with ui.column().classes("gap-0").style("min-width:0; flex:1 1 auto"):
                    title = ui.label(f"Fill “{crate.name}”").classes("f-title")
                    sub = ui.label("").classes("f-sub")
                ui.space()
                more_btn = ui.button("Re-rank", icon="refresh",
                                     on_click=lambda: _rerank()) \
                    .props("flat dense no-caps color=secondary") \
                    .tooltip("Score again, with what you just added counted in")
                more_btn.set_visibility(False)
                ui.button("Done", icon="check", on_click=dlg.close) \
                    .props("unelevated no-caps color=primary")
        with ui.element("div").classes("f-body"):
            body = ui.column().classes("f-wrap gap-2")
    # The two containers inside `body` that an append writes into: the rows,
    # and the footer holding "show more". Built by the first render.
    rows = more = None

    def _seed_line() -> str:
        names = [s.name for s in state["seeds"][:3]]
        rest = len(state["seeds"]) - len(names)
        return ", ".join(names) + (f" and {rest} more" if rest > 0 else "")

    async def _compute(append: bool = False) -> None:
        """Rank the library against the crate, off the event loop.

        The model is the slow part and only on its first build (history read
        plus a tag read per played track); the ranking itself is ~0.2s over
        3 500 candidates. Both go to a worker thread either way — the dialog is
        already on screen and should be painting a spinner, not frozen.
        """
        if append:
            more.clear()
            with more:
                ui.spinner(size="sm")
        else:
            body.clear()
            with body:
                with ui.row().classes("items-center gap-3 q-py-md"):
                    ui.spinner(size="sm")
                    ui.label("Reading your play history…").classes("f-sub")
            sub.set_text("")

        def _work():
            model = runtime.mix_model()
            fresh = next((c for c in crates.live(crates.load())
                          if c.id == crate_id), None)
            keys = list(fresh.keys if fresh is not None else [])
            # The crate's own tracks first: a seed with no genre turns off the
            # axis the ranking leans on hardest, and rekordbox hands us a blank
            # Genre for 42% of the collection even where the file has one. A few
            # file reads, not the library's ~950.
            held = set(keys)
            runtime.library.hydrate_genres(
                [t for t in runtime.library.tracks if track_key(t) in held])
            cands, _ = runtime.library.mix_tracks_from(runtime.library.tracks)
            by_id = {t.id: t for t in cands}
            seeds = [by_id[k] for k in keys if k in by_id]
            items = model.fill(seeds, cands, k=PAGE, offset=state["offset"])
            known = sum(1 for c in cands if c.genre)
            heard = vectors.have([c.path for c in cands if c.path])
            seeds_heard = sum(1 for s in seeds if s.path and str(s.path) in heard)
            return (model, seeds, items, len(cands), known, len(heard),
                    seeds_heard)

        try:
            (model, seeds, items, n_cands, known, heard,
             seeds_heard) = await run.io_bound(_work)
        except Exception as e:                    # noqa: BLE001 — shown, not swallowed
            body.clear()
            with body:
                ui.label(f"Couldn't rank this crate: {e}").classes("f-note")
            return
        state.update(seeds=seeds, items=items, gigs=model.gig_count,
                     n_cands=n_cands, known=known, heard=heard,
                     seeds_heard=seeds_heard)
        sub.set_text(f"{n_cands} tracks in the library, ranked against the "
                     f"{len(seeds)} in this crate · "
                     f"{known * 100 // max(1, n_cands)}% carry a genre · "
                     f"{heard} analyzed")
        _render(append)

    def _render(append: bool = False) -> None:
        """Paint the ranking. Appending adds the new page *under* the old one
        and leaves everything above it alone — a track you are auditioning
        keeps playing, and the row you were reading doesn't move."""
        nonlocal rows, more
        if not append:
            body.clear()
            with body:
                if not state["seeds"]:
                    ui.label("This crate is empty.").classes("f-title")
                    ui.label("The proposals are ranked against what is already "
                             "in it, so put one track in first — drag any row "
                             "into the dock — and this screen has something to "
                             "go on.").classes("f-empty")
                    return
                ui.html(f'Seeded from <b>{_seed_line()}</b>', sanitize=False) \
                    .classes("f-seeded")
                # What the ranking actually had to go on. A crate whose own
                # tracks carry no genre can only be matched on tempo and key —
                # which is mixability, not style — and saying so is the
                # difference between a thin answer and a misleading one.
                # The strongest axis first: whether this crate can be ranked on
                # how it *sounds* at all. Only analyzed tracks have an embedding,
                # so on an unanalyzed library the whole thing falls back to the
                # genre and tempo story below — and it should say which it is
                # rather than let a thin ranking pass for a good one.
                if not state["seeds_heard"]:
                    # Naming the exact control matters: only a **rich** pass
                    # loads the Discogs-EffNet model, so a plain Analyze gives
                    # an energy and no sound axis at all.
                    ui.label("None of this crate's tracks has been analyzed, so "
                             "nothing here is ranked on how it sounds — only on "
                             "genre, tempo and key. Run Library → Analyze energy "
                             "with “Rich” on and this gets much sharper.") \
                        .classes("f-note")
                elif state["heard"] < state["n_cands"]:
                    pct = state["heard"] * 100 // max(1, state["n_cands"])
                    ui.label(f"{state['heard']} of {state['n_cands']} library "
                             f"tracks are analyzed ({pct}%) — those can be judged "
                             "on how they sound, the rest only on genre, tempo "
                             "and key.").classes("f-note")
                styled = [s for s in state["seeds"] if s.genre]
                if not styled:
                    ui.label("None of this crate's tracks has a genre on file, so "
                             "these are ranked on tempo and key alone — that is "
                             "about what mixes, not about what sounds alike. "
                             "Import them through the app or set a genre in "
                             "rekordbox and this gets much sharper.") \
                        .classes("f-note")
                elif len(styled) < len(state["seeds"]):
                    ui.label(f"{len(styled)} of {len(state['seeds'])} tracks in "
                             "this crate carry a genre — the rest are matched on "
                             "tempo and key only.").classes("f-note")
                if not state["gigs"]:
                    ui.label("No play history learned yet — these are ranked on "
                             "how the tracks sit together, not on what you've "
                             "played.").classes("f-note")
                rows = ui.column().classes("w-full gap-2")
                more = ui.row().classes("items-center gap-2 q-mt-sm")
        if not state["items"] and not append:
            with rows:
                ui.label("Nothing left to propose — every track in the library "
                         "is either in this crate already or a copy of one.") \
                    .classes("f-empty")
            return
        with rows:
            for s in state["items"]:
                _row(s)
        more.clear()
        # A short page is the end of the ranking; offering more would be a
        # button that does nothing.
        if len(state["items"]) == PAGE:
            with more:
                ui.button(f"Show {PAGE} more", icon="expand_more",
                          on_click=lambda: _more()) \
                    .props("flat dense no-caps color=grey")

    def _row(s) -> None:
        t = s.track
        with ui.column().classes("f-hit w-full gap-2") as card:
            if t.id in state["added"]:
                card.classes(add="taken")
            with ui.row().classes("items-center no-wrap gap-3 w-full"):
                ui.label(str(s.score)).classes("f-score") \
                    .style(f"color:{_score_color(s.score)}") \
                    .tooltip("How well it fits this crate, 0-100")
                _art(t.path)
                with ui.column().classes("gap-0").style("min-width:0; flex:1 1 auto"):
                    ui.label(t.name).classes("f-name ellipsis") \
                        .style("min-width:0").tooltip(t.display)
                    with ui.row().classes("items-center no-wrap gap-2").style("min-width:0"):
                        ui.label(t.artist or "—").classes("f-artist ellipsis") \
                            .style("min-width:0")
                        # The genre, in the row rather than only in the reason:
                        # it is what the ranking leans on hardest, so it has to
                        # be visible enough to disagree with.
                        if t.genre:
                            ui.label(t.genre).classes("f-genre")
                if s.badge:
                    ui.label(s.badge).classes("f-chip")
                if t.energy:
                    ui.label(str(t.energy)).classes("f-pill") \
                        .style(f"background:{ENERGY_COLORS.get(t.energy, '#888')}") \
                        .tooltip("Energy")
                if t.key:
                    ui.label(t.key).classes("f-pill") \
                        .style(f"background:{camelot_color(t.key)}")
                if t.bpm:
                    ui.label(f"{round(t.bpm)}").classes("f-mono")
                btn = ui.button("Add", icon="add",
                                on_click=lambda s=s, c=card: _add(s, c, btn)) \
                    .props("unelevated dense no-caps color=primary") \
                    .style("min-width:86px")
                if t.id in state["added"]:
                    _mark_added(btn)
            # The reason, said out loud: which crate track it sits with, and
            # what makes them sit together.
            seed = f'goes with <b>{_esc(s.seed.name)}</b> — ' if s.seed else ""
            ui.html(seed + _esc(s.reason), sanitize=False).classes("f-why")
            if t.path:
                audio_player(t.path, compact=True)

    def _mark_added(btn) -> None:
        btn.text = "Added"
        btn.props("flat dense no-caps color=secondary")
        btn.set_enabled(False)

    def _add(s, card, btn) -> None:
        """One track into the crate. Everything else on screen stays put."""
        n = crates.add(crate_id, s.track.id)
        state["added"].add(s.track.id)
        card.classes(add="taken")
        _mark_added(btn)
        more_btn.set_visibility(True)
        title.set_text(f"Fill “{crate.name}” · {len(state['added'])} added")
        if on_change:
            on_change()
        ui.notify(f"Added to “{crate.name}”" if n else "Already in it",
                  type="positive" if n else "info")

    async def _more() -> None:
        state["offset"] += PAGE
        await _compute(append=True)

    async def _rerank() -> None:
        """Score again with the new picks counted as part of the crate."""
        state["offset"] = 0
        more_btn.set_visibility(False)
        await _compute()

    # Kick the work off after the dialog is on screen, so the spinner is the
    # first thing painted rather than the last. Parented to the dialog, not to
    # whatever slot the click handler happened to run in.
    with dlg:
        ui.timer(0.05, _compute, once=True)
    dlg.open()


def _score_color(score: int) -> str:
    if score >= 75:
        return "#3fb950"
    if score >= 55:
        return "#d29922"
    return "#9aa0a8"


def _esc(s) -> str:
    return (str(s or "").replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;"))
