"""Download page (`/download`) — now only the Setline bridge.

**Acquiring moved to Incoming** (`pages/acquire.py`): the link box, the Beatport
search and the Downloads-folder inbox are a step of the arrival job, not a place
of their own, and keeping them here meant a track could be fetched without
anything ever asking which playlist it was for. That is how a thousand files
came to sit in a folder named after the shop they came from. On Incoming the
destination is asked *before* the fetch, and the file lands already filed.

What stays is the one thing that isn't part of that job: **a set from Setline**.
The shared planner's export is matched against the library, the missing tracks
fetched from Beatport, then exported to rekordbox or saved as a Build draft —
all of it, or the slice you filter it down to (some moments, someone's picks)
(see `setline_import`).

It stays here rather than moving because it is a bridge between two libraries
and goes away entirely once the board runs locally against this one —
`setline_import.py`, `setline_push.py` and the `.setline.json` format with it.
Porting it would be work spent on something already condemned.
"""
from __future__ import annotations

from typing import Optional

from nicegui import run, ui

import bpdl
import drafts
import rekordbox_io
import runtime
import setline_import
from drives import DriveOffline, ensure_dir
from export_ui import export_handoff
from shell import apply_theme, header


def _filter_chip(text: str, on: bool, color: str, handler) -> None:
    """A clickable pill for the Setline filters, lit when it's in effect.

    The colour is passed as a hex, which `ui.chip` writes as an inline style —
    a Quasar colour name would land as a `bg-*` class, and those are `!important`,
    so the unlit half of the pair could never be hollowed out.
    """
    ui.chip(text, color=color if on else "transparent",
            text_color="#fff" if on else color, on_click=handler) \
        .props("dense size=sm") \
        .style("font-weight:600" if on else f"border:1px solid {color}66")


@ui.page("/download")
def download_page():
    apply_theme()
    # "Incoming" stays lit: a set from Setline is tracks arriving, and this page
    # is reached from there, so the nav shouldn't claim you have gone elsewhere.
    header("Incoming")

    with ui.column().classes("w-full p-4 gap-4") \
            .style("max-width:56rem; margin:auto") as page_col:
        with ui.row().classes("items-center gap-2 w-full no-wrap"):
            ui.button("Back to Incoming", icon="arrow_back",
                      on_click=lambda: ui.navigate.to("/incoming")) \
                .props("flat dense no-caps color=primary")
            ui.space()
            # An old bookmark lands here expecting a link box. Say where it went
            # rather than leaving someone to conclude the feature was dropped.
            ui.button("Paste a link or search Beatport", icon="add",
                      on_click=lambda: ui.navigate.to("/incoming")) \
                .props("outline dense no-caps color=secondary") \
                .tooltip("Acquiring moved to Incoming, where it asks which "
                         "playlist the track is for before fetching it")

        ui.label("A set from Setline").classes("text-h6")
        ui.label("In Setline: Export → Set file for Track Studio. Drop the file "
                 "here to see what you already have, fetch the rest from "
                 "Beatport, then send it to rekordbox or save it as a Build "
                 "draft — the whole set, or just the moments and the picks "
                 "you're preparing.") \
            .classes("text-caption").style("color:#6b7280")
        ui.upload(label="Drop a .setline.json file", auto_upload=True, max_files=1,
                  on_upload=lambda e: load_setline(e)) \
            .props('accept=".json,application/json" flat bordered') \
            .classes("w-full")
        setline_col = ui.column().classes("w-full gap-1")

    # ==================================================================
    # notifications, anchored to the page
    # ==================================================================
    # A notification is an element like any other, and NiceGUI runs a handler in
    # the *sender's* parent slot — so a spinner started from a button inside a
    # list belongs to that list. The Setline handlers re-render their own list
    # mid-job, and `setline_col.clear()` was quietly taking the spinner with it:
    # the message vanished after a second and the result, created in a dead
    # slot, never reached the browser at all. Anchored to the page column, a
    # message outlives the thing that was clicked to produce it.

    def toast(*args, **kwargs):
        with page_col:
            return ui.notify(*args, **kwargs)

    def spinner(message: str):
        with page_col:
            return ui.notification(message, spinner=True, timeout=None)

    def later(fn) -> None:
        """Kick an async refresh from a sync callback, anchored the same way."""
        with page_col:
            ui.timer(0.05, fn, once=True)

    def _ingest(paths) -> None:
        """Fold freshly-arrived files into the in-memory library + batch list."""
        from library import track_from_file
        runtime.library.tracks.extend(track_from_file(p) for p in paths)
        runtime.refresh_batches()

    def _verify_arrivals(paths) -> None:
        """Packet-check what just landed, and say so if the audio isn't continuous.

        Seconds on a handful of files, against a set that falls apart on stage.
        A store download is always clean, so anything this finds means the file
        came down some other way — worth knowing at the moment it arrives, not
        the night you play it. Never fatal: the file is kept either way, because
        a false alarm must not cost you a download.
        """
        import integrity
        try:
            bad = integrity.verify_downloads(paths)
        except Exception as e:
            print(f"[download] integrity check failed: {e!r}")
            return
        if not bad:
            return
        worst = bad[0]
        toast(f"⚠ {len(bad)} of {len(paths)} downloaded file(s) have discontinuous "
              f"audio — “{worst.path.name}”: {worst.summary}. The beatgrid will "
              "drift; re-download or check Library → Check for problems.",
              type="warning", timeout=20000)

    # ==================================================================
    # a set from Setline — see setline_import.py
    # ==================================================================

    STATUS_BADGE = {
        setline_import.HAVE: ("in library", "positive"),
        setline_import.POSSIBLE: ("check match", "grey-7"),
        setline_import.FETCH: ("to download", "primary"),
        setline_import.MANUAL: ("not on Beatport", "warning"),
    }

    # The dropped set lives in `runtime.setline_state`, not here: see
    # `runtime.new_setline_session`. `sl` is a plain alias for the same dict —
    # it's mutated, never rebound, so it can't go stale.
    sl = runtime.setline_state

    async def load_setline(e) -> None:
        raw = await e.file.read()
        e.sender.reset()
        try:
            export = setline_import.read(raw)
        except setline_import.ImportError_ as err:
            toast(str(err), type="negative", timeout=9000)
            return
        sl.update(runtime.new_setline_session())   # a new set, not a second one
        sl["export"] = export
        await replan_setline()

    def clear_setline() -> None:
        sl.update(runtime.new_setline_session())
        render_setline()

    async def replan_setline() -> None:
        export = sl["export"]
        if not export:
            return
        try:
            p = await run.io_bound(
                setline_import.plan, export, runtime.library.tracks)
        except Exception as err:
            toast(f"Couldn't check the set against the library: {err}",
                  type="negative", timeout=9000)
            return
        # The filter survives a re-plan: downloading the slice re-matches the
        # whole set against a library that grew, and you're still on that slice.
        p.keep_moments, p.keep_added_by = sl["moments"], sl["added_by"]
        sl["plan"] = p
        render_setline()

    def pick_setline(key: str, value: Optional[str], every: list) -> None:
        """A filter chip: from "all", narrow to the one clicked; then add/remove.

        Clicking the last one off — or ticking every one — is the same thing as
        no filter, so both land back on "all" rather than on an empty set.
        """
        kept = sl[key]
        if value is None:
            kept = None
        else:
            kept = {value} if kept is None else set(kept) ^ {value}
            if not kept or kept == set(every):
                kept = None
        sl[key] = kept
        if sl["plan"]:
            sl["plan"].keep_moments, sl["plan"].keep_added_by = sl["moments"], sl["added_by"]
        render_setline()

    def setline_filter_row(label: str, key: str, options: list,
                           colors: Optional[dict] = None) -> None:
        """One line of chips — the moments, or the people who planned the set."""
        kept = sl[key]
        with ui.row().classes("items-center gap-1 w-full").style("flex-wrap:wrap"):
            ui.label(label).classes("text-caption text-grey").style("width:5rem")
            _filter_chip("All", kept is None, "#6b7280",
                         lambda: pick_setline(key, None, options))
            for o in options:
                color = (colors or {}).get(o) or "#ff7a1a"
                _filter_chip(o, kept is not None and o in kept, color,
                             lambda o=o: pick_setline(key, o, options))

    def render_setline() -> None:
        setline_col.clear()
        p = sl["plan"]
        if not p:
            return
        n_fetch, n_manual = p.count(setline_import.FETCH), p.count(setline_import.MANUAL)
        n_have, n_possible = p.count(setline_import.HAVE), p.count(setline_import.POSSIBLE)
        rows = p.selected
        moments, people = p.moment_names, p.contributors
        with setline_col:
            with ui.row().classes("items-center justify-between w-full q-mt-sm"):
                with ui.column().classes("gap-0"):
                    ui.label(p.name).classes("text-subtitle1 text-weight-bold")
                    ui.label(
                        (f"{len(rows)} of {len(p.rows)} tracks" if p.filtered
                         else f"{len(p.rows)} tracks")
                        + f" · starts {p.starts_at}  ·  {n_have} in the library"
                        + (f" · {n_possible} to check" if n_possible else "")
                        + (f" · {n_fetch} to download" if n_fetch else "")
                        + (f" · {n_manual} not on Beatport" if n_manual else "")) \
                        .classes("text-caption text-grey")
                with ui.row().classes("items-center gap-2"):
                    if n_fetch:
                        ui.button(f"Download {n_fetch} from Beatport", icon="cloud_download",
                                  on_click=lambda: fetch_setline()) \
                            .props("unelevated dense no-caps color=primary")
                    # The set arrived already programmed, so rekordbox is one
                    # click away — Build is for *re*-programming it, not a toll
                    # gate on the way out.
                    ui.button("Export to rekordbox", icon="ios_share",
                              on_click=lambda: export_setline()) \
                        .props("unelevated dense no-caps color=primary") \
                        .tooltip(f"Write the set in order to {runtime.export_path()}")
                    ui.button("Save as Build draft", icon="playlist_add_check",
                              on_click=lambda: save_setline_draft()) \
                        .props("outline dense no-caps color=primary")
                    ui.button(icon="close", on_click=lambda: clear_setline()) \
                        .props("flat dense round size=sm color=grey") \
                        .tooltip("Put this set away — the only thing that does, "
                                 "now that it survives leaving the page")
            # Only worth a filter when there's something to choose between: a
            # one-moment set or a set you planned alone gets no chips.
            if len(moments) > 1:
                setline_filter_row("Moment", "moments", moments, p.moment_colors)
            if len(people) > 1:
                setline_filter_row("Added by", "added_by", people)
            if not rows:
                ui.label("Nothing in this slice of the set.") \
                    .classes("text-caption text-grey q-mt-sm")
            # Name who picked each track only while that still tells them apart.
            credit = len({r.added_by for r in rows if r.added_by}) > 1
            current = None
            for r in rows:
                if r.moment != current:
                    current = r.moment
                    ui.label(current.upper() or "—").classes("text-caption text-weight-bold q-mt-sm") \
                        .style("color:#9aa0a8; letter-spacing:.06em")
                label, color = STATUS_BADGE[r.status]
                # A fetch that Beatport refused leaves the row "to download",
                # which invites the same click and the same nothing. Say so.
                failed = (sl["failed"].get(r.beatport_id)
                          if r.status == setline_import.FETCH else None)
                if failed:
                    label, color = "wouldn't download", "negative"
                with ui.row().classes("items-center gap-2 no-wrap w-full q-py-xs"):
                    ui.label(r.clock).classes("text-caption text-grey") \
                        .style("font-family:monospace; width:3.2rem")
                    badge = ui.badge(label).props(f"color={color}")
                    if failed:
                        badge.tooltip(failed)
                    elif r.have and r.status == setline_import.POSSIBLE:
                        badge.tooltip(r.have.detail)
                    ui.label(r.display).classes("flex-grow ellipsis").style("min-width:0")
                    if r.added_by and credit:
                        ui.label(r.added_by).classes("text-caption text-grey no-wrap")
                    if r.key:
                        ui.badge(r.key).props("color=grey-8")
                    if r.bpm:
                        ui.label(f"{r.bpm}").classes("text-caption text-grey") \
                            .style("font-family:monospace")
                    if r.status == setline_import.MANUAL and r.link:
                        ui.button(icon="open_in_new",
                                  on_click=lambda link=r.link: ui.navigate.to(link, new_tab=True)) \
                            .props("flat dense round size=sm color=grey").tooltip(r.link)

    async def fetch_setline() -> None:
        p = sl["plan"]
        if not p or not p.to_fetch:
            return
        ids = p.to_fetch
        dest = runtime._dl_root() / setline_import.batch_name(p.name)
        try:
            ensure_dir(dest)
        except DriveOffline as e:
            toast(str(e), type="warning")
            return
        prog = {"done": 0, "total": len(ids), "label": ""}
        n = spinner(f"Downloading {len(ids)} from Beatport…")

        def _render():
            cur = f"  ·  {prog['label'][:46]}" if prog["label"] else ""
            n.message = (f"Downloading {prog['done']}/{prog['total']} "
                         f"from Beatport{cur}")
        with page_col:                      # not the sender's slot — see `toast`
            timer = ui.timer(0.3, _render)

        def _on_prog(done, total, _frac, label):
            prog.update(done=done, total=total, label=label)

        try:
            new_files, log = await run.io_bound(bpdl.download, ids, dest,
                                                progress=_on_prog)
        except Exception as err:
            timer.deactivate()
            n.dismiss()
            toast(f"Beatport download failed: {err}", type="negative", timeout=9000)
            return
        timer.deactivate()
        _ingest(new_files)
        _verify_arrivals(new_files)
        sl["batch"] = dest.name
        # Remember what the log blamed each id for. Only ids still wanting a
        # download read it back, so a line about one that did arrive is inert.
        sl["failed"].update(bpdl.failures_by_id(log))
        await replan_setline()
        still = sl["plan"].count(setline_import.FETCH) if sl["plan"] else 0

        def _finish():
            n.dismiss()
            if not new_files:
                toast(f"Nothing downloaded. {bpdl.failure_reason(log)}",
                      type="negative", timeout=15000)
            elif still:
                toast(f"Downloaded {len(new_files)} → {dest}. {still} still "
                      f"missing: {bpdl.failure_reason(log)}",
                      type="warning", timeout=15000)
            else:
                toast(f"Downloaded {len(new_files)} → {dest}. Export to rekordbox "
                      "now, or save the set as a Build draft.",
                      type="positive", timeout=12000)
        runtime._safe_ui(_finish)

    def export_setline() -> None:
        """The set — or the slice — straight to rekordbox's import file.

        Everything in it that's in the library with a file goes, tagged or not:
        an Energy tag is what Build needs to *program* a set, and this one came
        programmed.
        """
        p = sl["plan"]
        if not p:
            return
        tracks, playlists = setline_import.to_playlists(p)
        if not playlists:
            toast(f"None of {'this slice' if p.filtered else 'the set'}’s tracks are "
                  "in the library with a file yet — download the missing ones first.",
                  type="warning", timeout=9000)
            return
        try:
            out = str(runtime.export_target())
        except DriveOffline as e:
            toast(str(e), type="warning")
            return
        folder = setline_import.export_name(p)
        rekordbox_io.export_folder(out, folder, tracks, playlists)
        n_set = len(playlists[0][1])
        left_out = len(p.selected) - n_set
        export_handoff(
            out,
            f"{len(playlists)} playlist(s) · {n_set} tracks in set order"
            + (f"  ·  {p.selection_label}" if p.filtered else ""),
            f"the “{folder}” folder",
            re_export=export_setline,
            note=(f"{left_out} of the set’s tracks aren’t in the library yet and "
                  "were left out." if left_out else ""),
            # Reloading rekordbox is what turns the freshly-imported tracks into
            # matches, so re-plan against it: the rows go green.
            on_reloaded=lambda: later(replan_setline))

    def save_setline_draft() -> None:
        p = sl["plan"]
        if not p:
            return
        d = setline_import.to_draft(p)
        if not d.entries:
            toast(f"None of {'this slice of the set' if p.filtered else 'the set'}’s tracks "
                  "are in the library with a BPM yet. Download them first "
                  "(and analyze if needed).", type="warning", timeout=9000)
            return
        drafts.save(d)
        left_out = len(p.selected) - len(d.entries)
        toast(f"Saved the Build draft “{d.name}” with {len(d.entries)} tracks in set order"
              + (f" ({left_out} not in the library yet)" if left_out else "")
              + ". Open it from Build → Drafts.", type="positive", timeout=12000)

    # A set dropped on an earlier visit paints back immediately from its last
    # match, then re-matches: the trip this page sends you on — download here,
    # import in rekordbox, come back — is exactly the one that grows the
    # library, so the statuses you left behind are the ones most likely stale.
    if sl["plan"]:
        render_setline()
    if sl["export"]:
        ui.timer(0.05, replan_setline, once=True)
