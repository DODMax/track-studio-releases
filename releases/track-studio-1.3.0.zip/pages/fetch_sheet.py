"""“Get what's missing” — the sheet a synced playlist's gap is fetched through.

The old way was a spinner at the bottom of the page counting Beatport searches
to fifty, one by one, then a toast saying ten needed review and nowhere to
review them. This sheet is that job with the lights on:

- **Every track is a row before anything happens.** Ticked by default, with the
  title, the artist and Spotify's length, so "what is about to land on my
  drive" is a list you read rather than a number you trust.
- **Matching starts the moment the sheet opens** (`fetchjob`), several
  searches at once. It is read-only, so there is nothing to confirm about it,
  and by the time you have read the list most rows carry their Beatport match:
  sleeve, version, key, tempo, length and the store's preview clip.
- **Download starts what's matched and keeps going.** Rows move through
  queued → downloading → ✓ one by one, while the rest are still being matched
  and while you listen to the ones that need you.
- **"Needs you" is a tab, not a toast.** A match the names don't settle never
  downloads by itself: its row opens on every version the store offered, each
  with a preview and a "This one" button, plus a search box for when Beatport
  spells it differently. Rows with nothing found get the same search box.

A dialog rather than a route, like the fill screen: you open it from the
playlist you are working through and close it back onto the same scroll
position. The job does not live here — closing the sheet, or the page, leaves
it running (`runtime.fetch_jobs`), and opening it again shows where it got to.

**Why every row is one string of markup.** The first version built rows out of
NiceGUI elements — twenty to a hundred components a row, a player each — and
rebuilt parts of them as tracks moved. While a playlist was being matched and
downloaded that was thousands of components mounted and torn down in the
window, and the sheet lagged exactly while it was working; a click on Done sat
behind the backlog. Now a row is one `ui.html`, re-sent only when its markup
actually changed, so a track moving from "downloading" to ✓ is one small string.
Clicks go through one delegated listener and come back as `emitEvent` (the crate
dock's pattern), and there is **one** player, in the head: every ▶ swaps its
source. Fifty-odd `<audio>` elements, one per row, were the other half of the
weight — and with one, a row can be redrawn while you listen without stopping
the clip.
"""
from __future__ import annotations

import weakref
from typing import Callable, Optional

from nicegui import ui

import drives
import fetchjob as fj
import widgets

from . import kit

# Candidate versions shown before "show all": the record's versions come
# first, so the ones worth hearing are almost always in the first few.
CANDIDATES = 5

_CSS = "<style>\n" + kit.scope(".ts-get") + """
.ts-get { background:var(--ground); color:var(--ink); font-size:13px;
  width:100%; height:100%; max-width:none; padding:0; border-radius:0; }
.ts-get .g-wrap { width:100%; max-width:76rem; margin:0 auto; }
/* The head stays put: the count, the bar, the button and the player are the
   job, and a long list must never scroll them away. */
.ts-get .g-head { position:sticky; top:0; z-index:3; width:100%;
  background:var(--surface); border-bottom:1px solid var(--line); padding:11px 16px 9px; }
.ts-get .g-title { font-size:19px; font-weight:700; letter-spacing:-.015em; }
.ts-get .g-back { color:var(--ink-2) !important; flex:none; }
.ts-get .g-back:hover { color:var(--ink) !important; background:var(--raised-2); }
.ts-get .g-sub { font-size:12.5px; color:var(--ink-3); line-height:1.5; }
.ts-get .g-sum { font-size:12.5px; color:var(--ink-2); }
.ts-get .g-sum b { color:var(--ink); font-weight:650; }
.ts-get .g-body { width:100%; padding:12px 16px 40px; }
.ts-get .ell { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; min-width:0; }

/* Two layers: how far matching has got (quiet), how much has landed (green). */
.ts-get .g-bar { position:relative; height:4px; border-radius:2px; background:var(--raised-2);
  overflow:hidden; width:100%; }
.ts-get .g-bar i { position:absolute; left:0; top:0; bottom:0; border-radius:2px;
  transition:width .4s ease; }
.ts-get .g-bar i.m { background:rgba(45,212,191,.28); }
.ts-get .g-bar i.d { background:#3fb950; }

/* The one player: what's playing, and its transport. */
.ts-get .g-now { display:flex; align-items:center; gap:12px; min-width:0; width:100%; }
.ts-get .g-now-label { font-size:12px; color:var(--ink-3); flex:0 1 auto; min-width:0; }
.ts-get .g-now.live .g-now-label { color:var(--ink); font-weight:600; }
.ts-get .g-now .ts-player { width:320px; flex:none; }

/* Filter tabs — Setline's segmented chips. */
.ts-get .g-tabs { display:flex; gap:4px; align-items:center; }
.ts-get .g-tab { font-size:12px; font-weight:600; color:var(--ink-3); padding:4px 10px;
  border-radius:14px; border:1px solid transparent; cursor:pointer; white-space:nowrap;
  user-select:none; }
.ts-get .g-tab:hover { color:var(--ink-2); background:var(--raised); }
.ts-get .g-tab.on { color:var(--ink); background:var(--raised-2); border-color:var(--line-2); }
.ts-get .g-tab.warn { color:var(--warn); }
.ts-get .g-tab .n { font-family:ui-monospace,Menlo,monospace; font-size:11px; opacity:.8;
  margin-left:4px; }

/* One track: tick | what the playlist asked for | what Beatport has | ▶ |
   where it's got to. A grid, so every row's columns line up down the screen. */
.ts-get .g-row { background:var(--raised); border:1px solid var(--line);
  border-left:3px solid var(--line); border-radius:9px; margin-bottom:4px; }
.ts-get .g-row:hover { border-color:var(--line-2); }
.ts-get .g-line { display:grid; align-items:center; gap:12px; padding:8px 12px 8px 8px;
  grid-template-columns:24px minmax(0,1fr) minmax(0,1.4fr) 30px 150px; }
.ts-get .g-row.s-review { border-left-color:var(--warn); }
.ts-get .g-row.s-matched, .ts-get .g-row.s-queued { border-left-color:var(--smooth); }
.ts-get .g-row.s-downloading { border-left-color:var(--accent); }
.ts-get .g-row.s-done { border-left-color:#3fb950; }
.ts-get .g-row.s-failed { border-left-color:#f85149; }
.ts-get .g-row.off { opacity:.5; }
/* Every text cell holds to its column and cuts with an ellipsis: a long title
   ran on under the next column when a cell sized itself to its text. */
.ts-get .g-cell { min-width:0; overflow:hidden; display:flex; flex-direction:column; }
.ts-get .g-l { display:flex; align-items:center; gap:8px; min-width:0; }
.ts-get .g-name { font-size:13.5px; font-weight:600; color:var(--ink); }
.ts-get .g-artist { font-size:12px; color:var(--ink-3); }
.ts-get .g-mono { font-family:ui-monospace,Menlo,monospace; font-size:11px; color:var(--ink-2);
  flex:none; white-space:nowrap; }
.ts-get .g-mono.diff { color:var(--ink); }
.ts-get .g-note { font-size:11.5px; color:var(--smooth); line-height:1.35; }
.ts-get .g-note.warn { color:var(--warn); }
.ts-get .g-quiet { font-size:12px; color:var(--ink-3); }
.ts-get a.g-quiet { text-decoration:none; flex:none; }
.ts-get a.g-quiet:hover { color:var(--accent); }
.ts-get .g-found { display:flex; align-items:center; gap:12px; min-width:0; }
.ts-get .g-col { display:flex; flex-direction:column; min-width:0; flex:1 1 auto; }
.ts-get .g-art { width:40px; height:40px; border-radius:5px; flex:none; overflow:hidden;
  background:var(--raised-2); display:grid; place-items:center; color:var(--ink-3); }
.ts-get .g-art img { width:100%; height:100%; object-fit:cover; display:block; }
.ts-get .g-pill { font:650 10px/1 ui-monospace,Menlo,monospace; padding:3px 5px;
  border-radius:4px; color:#fff; flex:none; }
.ts-get .g-via { font-size:10px; font-weight:650; letter-spacing:.03em; padding:2px 6px;
  border-radius:9px; flex:none; white-space:nowrap; border:1px solid var(--line-2);
  color:var(--ink-3); }
.ts-get .g-via.isrc { color:var(--smooth); border-color:rgba(45,212,191,.4); }
.ts-get .g-via.you { color:var(--accent); border-color:rgba(255,122,26,.45); }

/* The tick: a plain button, drawn. */
.ts-get .g-chk { width:18px; height:18px; border-radius:4px; border:1.5px solid var(--ink-3);
  background:transparent; cursor:pointer; padding:0; display:grid; place-items:center;
  color:transparent; font-size:12px; line-height:1; }
.ts-get .g-chk.on { background:var(--ink-2); border-color:var(--ink-2); color:var(--ground); }
.ts-get .g-chk:disabled { cursor:default; opacity:.45; }

/* ▶ — every one plays through the head's player. */
.ts-get .g-play { width:26px; height:26px; border-radius:50%; border:1px solid #3a3f47;
  background:#1b1e24; color:var(--accent); cursor:pointer; padding:0; flex:none;
  display:grid; place-items:center; font-size:10px; }
.ts-get .g-play:hover { border-color:var(--accent); }
.ts-get .g-play.on { background:var(--accent); color:var(--ground); border-color:var(--accent); }
.ts-get .g-play .p { display:none; }
.ts-get .g-play.on .p { display:inline; }
.ts-get .g-play.on .t { display:none; }

/* Status: a word, coloured by which way it points. */
.ts-get .g-status { flex-direction:row; align-items:center; justify-content:flex-end; gap:4px; }
.ts-get .g-chip { font-size:11px; font-weight:650; padding:3px 8px; border-radius:10px;
  white-space:nowrap; display:inline-flex; align-items:center; gap:5px; }
.ts-get .c-quiet { color:var(--ink-3); background:var(--raised-2); }
.ts-get .c-ready { color:var(--smooth); background:rgba(45,212,191,.12); }
.ts-get .c-you { color:#1a1203; background:var(--warn); }
.ts-get .c-busy { color:var(--accent); background:rgba(255,122,26,.12); }
.ts-get .c-done { color:#3fb950; background:rgba(63,185,80,.13); }
.ts-get .c-bad { color:#f85149; background:rgba(248,81,73,.12); }
.ts-get .g-ico { width:26px; height:26px; border-radius:50%; border:0; background:transparent;
  color:var(--ink-3); cursor:pointer; padding:0; font-size:14px; line-height:1; flex:none; }
.ts-get .g-ico:hover { color:var(--ink); background:var(--raised-2); }
.ts-get .g-spin { width:11px; height:11px; border-radius:50%; border:2px solid currentColor;
  border-right-color:transparent; display:inline-block; flex:none;
  animation:g-rot .8s linear infinite; }
@keyframes g-rot { to { transform:rotate(360deg); } }

/* The expansion: every version the store offered, to hear and pick from. */
.ts-get .g-more { border-top:1px solid var(--line); padding:10px 12px 12px 44px; }
.ts-get .g-cand { display:grid; align-items:center; gap:10px; padding:5px 6px; border-radius:7px;
  grid-template-columns:26px 36px minmax(0,1fr) auto 96px; }
.ts-get .g-cand:hover { background:var(--raised-2); }
.ts-get .g-cand.picked { background:rgba(45,212,191,.08); }
.ts-get .g-cand .g-art { width:36px; height:36px; }
.ts-get .g-ask { font-size:12px; font-weight:650; color:var(--ink-2); margin-bottom:4px; }
.ts-get .g-btn { font-size:12px; font-weight:650; border-radius:6px; padding:5px 10px;
  border:0; cursor:pointer; white-space:nowrap; }
.ts-get .g-btn.go { background:var(--accent); color:var(--accent-ink); }
.ts-get .g-btn.go:hover { background:#ff8f3d; }
.ts-get .g-btn.flat { background:transparent; color:var(--ink-2); }
.ts-get .g-btn.flat:hover { background:var(--raised-2); color:var(--ink); }
.ts-get .g-btn.link { background:transparent; color:var(--accent); }
.ts-get .g-search { display:flex; align-items:center; gap:8px; margin-top:8px; }
.ts-get input.g-q { background:var(--raised-2); border:1px solid var(--line); border-radius:7px;
  color:var(--ink); padding:6px 10px; font-size:13px; width:min(30rem, 100%); outline:none; }
.ts-get input.g-q:focus { border-color:var(--accent); }
.ts-get .g-callout { background:rgba(210,153,34,.07); border:1px solid rgba(210,153,34,.28);
  border-left:3px solid var(--warn); border-radius:8px; padding:9px 12px; font-size:12.5px;
  color:var(--ink-2); line-height:1.5; }
</style>
"""

# One delegated listener set per window. Rows are replaced wholesale as they
# change, so nothing is bound to a row: a click finds its `data-act` and goes
# back as one `emitEvent`. ▶ never reaches the server at all — it swaps the
# head player's source, and the playing mark is put back after every redraw.
#
# Run with `ui.run_javascript`, not added as a <script>: the sheet opens from a
# click, after the page has loaded, and a script tag inserted then is inert.
_JS = """
(() => {
  if (window.__tsGetWired) return;
  window.__tsGetWired = true;
  const sheetOf = el => el.closest('.ts-get');
  const send = (el, extra) => {
    const s = sheetOf(el);
    if (!s) return;
    emitEvent('ts_get', Object.assign({sheet: s.dataset.sheet, act: el.dataset.act,
      key: el.dataset.key || '', id: el.dataset.id || ''}, extra || {}));
  };
  const audioOf = s => s.querySelector('.g-now audio');
  const mark = s => {
    const a = audioOf(s);
    if (!a) return;
    const src = a.getAttribute('src') || '';
    const on = !!src && !a.paused;
    s.querySelectorAll('.g-play').forEach(b => b.classList.toggle('on', on && b.dataset.src === src));
  };
  document.addEventListener('click', e => {
    const el = e.target.closest && e.target.closest('.ts-get [data-act]');
    if (!el || el.disabled) return;
    const s = sheetOf(el);
    if (el.dataset.act === 'play') {
      e.preventDefault();
      const a = audioOf(s);
      if (a.getAttribute('src') === el.dataset.src) { a.paused ? a.play() : a.pause(); return; }
      a.setAttribute('src', el.dataset.src);
      const now = s.querySelector('.g-now');
      now.classList.add('live');
      now.querySelector('.g-now-label').textContent = el.dataset.label || '';
      a.play().catch(() => {});
      return;
    }
    e.preventDefault();
    if (el.dataset.act === 'search') {
      const box = el.closest('.g-more').querySelector('input.g-q');
      send(el, {q: box ? box.value : ''});
      return;
    }
    send(el);
  });
  document.addEventListener('keydown', e => {
    const box = e.target.closest && e.target.closest('.ts-get input.g-q');
    if (!box || e.key !== 'Enter') return;
    e.preventDefault();
    send(box, {act: 'search', q: box.value});
  });
  for (const ev of ['play', 'pause', 'ended', 'emptied']) {
    document.addEventListener(ev, e => {
      const s = e.target.closest && e.target.closest('.ts-get');
      if (s) mark(s);
    }, true);
  }
  let queued = false;
  new MutationObserver(() => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => { queued = false; document.querySelectorAll('.ts-get').forEach(mark); });
  }).observe(document.documentElement, {childList: true, subtree: true});
})();
"""

TABS = (("all", "All"), ("you", "Needs you"), ("missing", "Not on Beatport"),
        ("done", "Downloaded"), ("failed", "Failed"), ("skipped", "Skipped"))

# The sheet open on each page visit, so one listener per visit can route a
# click to whichever sheet is showing — a sheet can be opened many times over
# one page, and NiceGUI's `ui.on` has no way to take a listener off again.
_SHEETS: "weakref.WeakKeyDictionary" = weakref.WeakKeyDictionary()
_WIRED: "weakref.WeakSet" = weakref.WeakSet()


def _in_tab(item, tab: str) -> bool:
    if tab == "you":
        return item.wanted and item.state == fj.REVIEW
    if tab == "missing":
        return item.wanted and item.state == fj.MISSING
    if tab == "done":
        return item.state == fj.DONE
    if tab == "failed":
        return item.state == fj.FAILED
    if tab == "skipped":
        return not item.wanted and item.state != fj.DONE
    return True


def _clock(seconds) -> str:
    if not seconds:
        return "–:––"
    m, s = divmod(int(round(seconds)), 60)
    return f"{m}:{s:02d}"


def _e(s) -> str:
    """Escape for text and double-quoted attributes alike. Titles come from
    Spotify and Beatport, which are not our input."""
    return (str(s or "").replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _art(url: Optional[str]) -> str:
    if url:
        return (f'<div class="g-art"><img src="{_e(url)}" alt="" loading="lazy" '
                'draggable="false" onerror="this.remove()"></div>')
    return '<div class="g-art">♪</div>'


def _play(bt) -> str:
    """▶ for one Beatport clip, played through the head's player."""
    if bt is None or not bt.sample_url:
        return '<span class="g-quiet" title="No preview on Beatport">–</span>'
    label = f"{', '.join(bt.artists)} — {bt.full_name}"
    return (f'<button class="g-play" data-act="play" data-src="{_e(bt.sample_url)}" '
            f'data-label="{_e(label)}" title="Preview (~2 min from the middle)">'
            '<span class="t">▶</span><span class="p">❚❚</span></button>')


def _version_line(bt, spotify_s: Optional[float]) -> str:
    """Artists, key, tempo and length of one Beatport track, on one line."""
    artists = ", ".join(bt.artists)
    out = [f'<span class="g-artist ell" title="{_e(artists)}">{_e(artists)}</span>']
    if bt.key:
        out.append(f'<span class="g-pill" style="background:{widgets.camelot_color(bt.key)}">'
                   f'{_e(bt.key)}</span>')
    if bt.bpm:
        out.append(f'<span class="g-mono">{_e(bt.bpm)}</span>')
    length = (bt.length_ms or 0) / 1000
    # The length against Spotify's: the one cheap fact that tells an extended
    # mix from a radio edit before you have heard either.
    if length and spotify_s and abs(length - spotify_s) > 20:
        out.append(f'<span class="g-mono diff" title="Spotify\'s is {_clock(spotify_s)}">'
                   f'{_clock(length)}</span>')
    else:
        out.append(f'<span class="g-mono">{_clock(length)}</span>')
    return '<div class="g-l">' + "".join(out) + "</div>"


def _found(item) -> str:
    if item.state == fj.MATCHING:
        return ('<div class="g-l g-quiet"><span class="g-spin"></span>'
                'searching Beatport…</div>')
    bt = item.pick
    if bt is None:
        if item.state == fj.MISSING:
            text = item.error or "nothing on Beatport under these names"
            return f'<div class="g-quiet ell" title="{_e(text)}">{_e(text)}</div>'
        return '<div class="g-quiet">pick one below ↓</div>'
    via_text, via_cls = {"isrc": ("same ISRC", "isrc"),
                         "you": ("your pick", "you")}.get(item.via, ("by name", ""))
    note = (f'<div class="g-note ell" title="{_e(item.note)}">{_e(item.note)}</div>'
            if item.note else "")
    return (f'<div class="g-found">{_art(bt.artwork(80))}<div class="g-col">'
            f'<div class="g-l"><span class="g-name ell" title="{_e(bt.display)}">'
            f'{_e(bt.full_name)}</span><span class="g-via {via_cls}">{via_text}</span></div>'
            f'{_version_line(bt, item.spotify.duration_ms / 1000)}{note}</div></div>')


def _status(item, opened: bool) -> str:
    st_ = item.state
    if not item.wanted and st_ not in (fj.DONE, fj.DOWNLOADING):
        chip = '<span class="g-chip c-quiet">skipped</span>'
    elif st_ == fj.MATCHING:
        chip = '<span class="g-chip c-quiet">searching</span>'
    elif st_ == fj.MATCHED:
        chip = ('<span class="g-chip c-ready" title="Downloads when you press '
                'Download">ready</span>')
    elif st_ == fj.REVIEW:
        chip = ('<span class="g-chip c-you" title="Not sure this is the right one — '
                'pick a version">needs you</span>')
    elif st_ == fj.MISSING:
        chip = '<span class="g-chip c-quiet">not found</span>'
    elif st_ == fj.QUEUED:
        chip = '<span class="g-chip c-quiet">queued</span>'
    elif st_ == fj.DOWNLOADING and item.stage == fj.SAVING:
        # The audio is in; what's left is the run ending and the file being
        # claimed and checked. Reads as done, because for the person it is.
        chip = '<span class="g-chip c-done" title="In — checking the file">✓ downloaded</span>'
    elif st_ == fj.DOWNLOADING:
        word = "downloading" if item.stage == fj.RECEIVING else "starting"
        chip = f'<span class="g-chip c-busy"><span class="g-spin"></span>{word}</span>'
    elif st_ == fj.DONE and item.warn:
        chip = f'<span class="g-chip c-you" title="{_e(item.warn)}">⚠ check audio</span>'
    elif st_ == fj.DONE:
        chip = (f'<span class="g-chip c-done" title="{_e(item.path or "")}">'
                '✓ downloaded</span>')
    else:   # FAILED
        chip = (f'<span class="g-chip c-bad" title="{_e(item.error)}">failed</span>'
                f'<button class="g-ico" data-act="retry" data-key="{_e(item.key)}" '
                'title="Try again">↻</button>')
    toggle = ""
    # The way into the expansion: versions to switch between, or a search for
    # a row that found nothing.
    if st_ in (fj.MATCHED, fj.REVIEW, fj.MISSING, fj.FAILED, fj.QUEUED):
        if st_ == fj.MISSING and not item.candidates:
            icon, tip = "⌕", "Search Beatport by hand"
        else:
            icon, tip = ("▴", "Hide") if opened else ("▾", "Other versions, or search again")
        toggle = (f'<button class="g-ico" data-act="toggle" data-key="{_e(item.key)}" '
                  f'title="{tip}">{icon}</button>')
    return f'<div class="g-cell g-status">{chip}{toggle}</div>'


def _more(item, show_all: bool) -> str:
    sp = item.spotify
    cands = item.candidates
    key = _e(item.key)
    out = ['<div class="g-more">']
    if item.state == fj.FAILED and item.error:
        out.append(f'<div class="g-note warn" style="margin-bottom:6px">{_e(item.error)}</div>')
    if cands:
        ask = {fj.REVIEW: "Is it one of these? Listen, then pick the right version.",
               fj.MISSING: "Nothing matched well enough to take. Closest on Beatport:"} \
            .get(item.state, "Every version Beatport has — pick another if you'd "
                             "rather have it.")
        out.append(f'<div class="g-ask">{ask}</div>')
        shown = cands if show_all else cands[:CANDIDATES]
        pid = item.pick.id if item.pick is not None else None
        # The current pick is always in sight, wherever it ranks — it is the
        # one the row is asking you about.
        if pid is not None and all(c.id != pid for c in shown):
            shown = [item.pick] + shown[:-1]
        locked = item.state in (fj.DOWNLOADING, fj.DONE)
        for c in shown:
            if c.id == pid and item.state != fj.REVIEW:
                act = '<span class="g-chip c-ready">picked</span>'
            elif locked:
                act = "<span></span>"
            else:
                act = (f'<button class="g-btn go" data-act="choose" data-key="{key}" '
                       f'data-id="{c.id}">This one</button>')
            out.append(
                f'<div class="g-cand{" picked" if c.id == pid else ""}">{_play(c)}'
                f'{_art(c.artwork(72))}<div class="g-col">'
                f'<div class="g-name ell" title="{_e(c.display)}">{_e(c.full_name)}</div>'
                f'{_version_line(c, sp.duration_ms / 1000)}</div>'
                f'<a class="g-quiet" href="{_e(c.url)}" target="_blank">open ↗</a>{act}</div>')
        if len(cands) > len(shown):
            out.append(f'<button class="g-btn flat" data-act="all" data-key="{key}">'
                       f'Show all {len(cands)}</button>')
    elif item.state == fj.MISSING:
        out.append('<div class="g-ask">Beatport has nothing under these names. It may '
                   'spell them differently — try fewer words, or the remixer\'s name.</div>')
    query = item.searched or f"{' '.join(sp.artists)} {sp.name}"
    busy = '<span class="g-spin" style="color:var(--accent)"></span>' if item.searching else ""
    skip = (f'<span style="flex:1"></span><button class="g-btn flat" data-act="skip" '
            f'data-key="{key}">⊘ Skip this one</button>'
            if item.wanted and item.state in (fj.REVIEW, fj.MISSING) else "")
    out.append(f'<div class="g-search"><input class="g-q" data-key="{key}" '
               f'value="{_e(query)}" placeholder="Search Beatport" spellcheck="false">'
               f'<button class="g-btn link" data-act="search" data-key="{key}">⌕ Search'
               f'</button>{busy}{skip}</div>')
    out.append("</div>")
    return "".join(out)


def _row(item, opened: bool, show_all: bool) -> str:
    sp = item.spotify
    cls = f"g-row s-{item.state}" + ("" if item.wanted else " off")
    locked = item.state in (fj.DOWNLOADING, fj.DONE)
    chk = (f'<button class="g-chk{" on" if item.wanted else ""}" data-act="want" '
           f'data-key="{_e(item.key)}"{" disabled" if locked else ""} '
           f'title="{"Untick to leave it out" if item.wanted else "Tick to get it"}">✓</button>')
    spotify = (f'<a class="g-quiet" href="{_e(sp.url)}" target="_blank" '
               'title="Open in Spotify">↗</a>' if sp.url else "")
    asked_note = (f'<div class="g-note warn ell" title="{_e(item.asked_note)}">'
                  f'{_e(item.asked_note)}</div>' if item.asked_note else "")
    asked = (f'<div class="g-cell"><div class="g-name ell" title="{_e(sp.name)}">'
             f'{_e(sp.name)}</div><div class="g-l"><span class="g-artist ell" '
             f'title="{_e(item.artists)}">{_e(item.artists)}</span>'
             f'<span class="g-mono" title="Spotify\'s length">{_clock(sp.duration_ms / 1000)}'
             f'</span>{spotify}</div>{asked_note}</div>')
    return (f'<div class="{cls}"><div class="g-line">{chk}{asked}'
            f'<div class="g-cell">{_found(item)}</div>'
            f'<div>{_play(item.pick) if item.state != fj.MATCHING else ""}</div>'
            f'{_status(item, opened)}</div>'
            f'{_more(item, show_all) if opened else ""}</div>')


def open_sheet(job: fj.FetchJob, *, destination: str,
               on_close: Optional[Callable[[], None]] = None) -> None:
    """Open the sheet over the current page, following `job` until closed."""
    client = ui.context.client
    if client not in _WIRED:
        _WIRED.add(client)
        ui.add_head_html(_CSS)
        ui.run_javascript(_JS)
        ui.on("ts_get", lambda e, c=client: (_SHEETS.get(c) or (lambda _e: None))(e))

    # Per-opening. `open` is which rows are expanded; `rows` each row's
    # element, the markup it last showed, and the job rev that markup was for.
    st = {"tab": "all", "open": set(), "show_all": set(), "rev": -1, "head": {}}
    rows: dict[str, dict] = {}
    offline = drives.offline(job.dest)

    with ui.dialog().props("maximized") as dlg, \
            ui.card().classes("ts-get").props("flat") as card:
        token = f"g{card.id}"
        card._props["data-sheet"] = token
        with ui.element("div").classes("g-head"):
            with ui.column().classes("g-wrap gap-2"):
                with ui.row().classes("items-center no-wrap gap-3 w-full"):
                    ui.button(icon="arrow_back", on_click=lambda: _close()) \
                        .props("flat round dense").classes("g-back") \
                        .tooltip("Back to the playlist (Esc) — this keeps going")
                    with ui.column().classes("gap-0").style("min-width:0; flex:1 1 auto"):
                        title = ui.label(f"Get what “{job.source_name}” is missing") \
                            .classes("g-title ell").style("max-width:100%")
                        title._props["title"] = job.source_name
                        sub = ui.label("").classes("g-sub ell").style("max-width:100%")
                        sub._props["title"] = str(job.dest)
                    stop_btn = ui.button("Pause", icon="pause",
                                         on_click=lambda: (job.stop(), tick())) \
                        .props("flat dense no-caps color=grey") \
                        .tooltip("No more downloads after the ones in flight")
                    go_btn = ui.button("Download", icon="cloud_download",
                                       on_click=lambda: _go()) \
                        .props("unelevated no-caps color=primary")
                    done_btn = ui.button("Done", icon="check", on_click=lambda: _close()) \
                        .props("unelevated no-caps color=secondary")
                # `sanitize` is passed even where nothing interpolated is a
                # string: NiceGUI 3.6 (what a copy still on Python 3.9 runs)
                # has no default for it, and the sheet died opening there.
                bar = ui.html("", sanitize=False).classes("w-full")
                with ui.row().classes("items-center no-wrap gap-3 w-full"):
                    summary = ui.html("", sanitize=False).classes("g-sum")
                    ui.space()
                    hint = ui.label("").classes("g-quiet")
                # The one player. Drawn once and never sent again: the page's
                # script swaps its source and label, and the server never
                # needs to know what is playing.
                ui.html('<div class="g-now"><span class="g-now-label ell">Press ▶ on '
                        'any track to hear the store\'s preview</span>'
                        f'{widgets.player_markup()}</div>', sanitize=False) \
                    .classes("w-full")
                with ui.row().classes("items-center no-wrap gap-1 w-full"):
                    tabs = ui.html("", sanitize=False)
                    ui.space()
                    ui.button("Tick all", on_click=lambda: (job.set_all(True), tick())) \
                        .props("flat dense no-caps size=sm color=grey")
                    ui.button("Untick all", on_click=lambda: (job.set_all(False), tick())) \
                        .props("flat dense no-caps size=sm color=grey")
        with ui.element("div").classes("g-body"):
            with ui.column().classes("g-wrap gap-0"):
                if offline:
                    ui.label(f"The drive “{offline}” isn't connected, so there is "
                             "nowhere to download into. Plug it in, then reopen "
                             "this.").classes("g-callout w-full q-mb-sm")
                err = ui.label("").classes("g-callout w-full q-mb-sm")
                err.set_visibility(False)
                empty = ui.label("").classes("g-quiet q-pa-md")
                empty.set_visibility(False)
                for item in job.items:
                    rows[item.key] = {"el": ui.html("", sanitize=False).classes("w-full"),
                                      "html": None, "rev": None, "shown": None}

    # ------------------------------------------------------------ actions

    def _close() -> None:
        dlg.close()

    def _go() -> None:
        if offline:
            ui.notify(f"“{offline}” isn't connected", type="warning")
            return
        job.go()
        tick()

    def _on_event(e) -> None:
        a = e.args or {}
        if a.get("sheet") != token:
            return
        act, key = a.get("act"), a.get("key") or ""
        item = job.by_key.get(key)
        if act == "tab":
            st["tab"] = key
            st["head"].pop("tabs", None)
            for i in job.items:
                _draw(i)
            _head()
            return
        if item is None:
            return
        if act == "want":
            job.set_wanted(key, not item.wanted)
        elif act == "toggle":
            st["open"].symmetric_difference_update({key})
            _draw(item)
        elif act == "all":
            st["show_all"].add(key)
            _draw(item)
        elif act == "choose":
            st["open"].discard(key)
            job.choose(key, int(a.get("id") or 0))
        elif act == "retry":
            job.retry(key)
        elif act == "search":
            st["open"].add(key)
            job.search(key, a.get("q") or "")
        elif act == "skip":
            # Closed *before* the job changes: the redraw that change
            # triggers is the one that has to see the row shut.
            st["open"].discard(key)
            job.set_wanted(key, False)
        tick()
    _SHEETS[client] = _on_event

    # ------------------------------------------------------------ drawing

    def _draw(item) -> None:
        """Redraw one row, and only if its markup changed — a track that moved
        from "downloading" to "downloading" sends nothing."""
        r = rows[item.key]
        # A row that needs you opens by itself the first time it gets there —
        # the versions to pick from are the whole of what it needs. Once only,
        # so closing it sticks.
        if item.state == fj.REVIEW and item.wanted and not r.get("auto"):
            r["auto"] = True
            st["open"].add(item.key)
        html = _row(item, item.key in st["open"], item.key in st["show_all"])
        if html != r["html"]:
            r["html"] = html
            r["el"].set_content(html)
        shown = _in_tab(item, st["tab"])
        if shown != r["shown"]:
            r["shown"] = shown
            r["el"].set_visibility(shown)

    def _set(el, key: str, value) -> None:
        """Set a head element's markup only when it changes."""
        if st["head"].get(key) != value:
            st["head"][key] = value
            el.set_content(value)

    def _head() -> None:
        items = job.items
        total = len(items)
        searching = job.count(fj.MATCHING)
        ready = len(job.ready)
        you = sum(1 for i in items if i.wanted and i.state == fj.REVIEW)
        missing = sum(1 for i in items if i.wanted and i.state == fj.MISSING)
        done = job.n_landed
        failed = job.count(fj.FAILED)
        inflight = job.count(fj.QUEUED, fj.DOWNLOADING)
        matched = job.count(fj.MATCHED, fj.QUEUED, fj.DOWNLOADING, fj.DONE, fj.FAILED)
        # Saving rows are counted in both `done` and `inflight`; once here.
        to_get = (job.count(fj.DONE, fj.QUEUED, fj.DOWNLOADING, fj.FAILED)
                  + (ready if not job.started else 0))

        sub.set_text(f"{total} track(s) the playlist has and your collection hasn't"
                     f"  ·  downloading into “{destination}”")
        _set(bar, "bar",
             '<div class="g-bar">'
             f'<i class="m" style="width:{100 * (total - searching) / max(1, total):.1f}%"></i>'
             f'<i class="d" style="width:{100 * done / max(1, total):.1f}%"></i></div>')

        parts = []
        if searching:
            parts.append(f"Searching Beatport <b>{total - searching}/{total}</b>")
        parts.append(f"<b>{matched}</b> matched")
        if you:
            parts.append(f'<b style="color:var(--warn)">{you}</b> need you')
        if missing:
            parts.append(f"<b>{missing}</b> not on Beatport")
        if done or inflight or job.started:
            parts.append(f'<b style="color:#3fb950">{done}</b>/{to_get} downloaded')
        if failed:
            parts.append(f'<b style="color:#f85149">{failed}</b> failed')
        _set(summary, "summary", "  ·  ".join(parts))

        if not job.started:
            go_btn.set_text(f"Download {ready}" if ready else "Download")
            go_btn.set_enabled(bool(ready) and not offline)
            hint.set_text(
                (f"{searching} still being searched — they'll follow once you start. "
                 if searching else "")
                + (f"{you} need you first." if you else ""))
        else:
            hint.set_text("" if (inflight or searching) else
                          (f"{you} still need you — pick one and it downloads straight away."
                           if you else ""))
        go_btn.set_visibility(not job.started)
        stop_btn.set_visibility(job.started and bool(inflight))
        done_btn.set_visibility(job.started and not inflight and not searching)

        err.set_text(job.error)
        err.set_visibility(bool(job.error))

        counts = {t: sum(1 for i in items if _in_tab(i, t)) for t, _ in TABS}
        _set(tabs, "tabs", '<div class="g-tabs">' + "".join(
            f'<span class="g-tab{" on" if st["tab"] == t else ""}'
            f'{" warn" if t == "you" else ""}" data-act="tab" data-key="{t}">'
            f'{label}<span class="n">{counts[t]}</span></span>'
            for t, label in TABS if t == "all" or counts[t] or st["tab"] == t) + "</div>")
        empty.set_text({"you": "Nothing needs you.",
                        "missing": "Everything was found.",
                        "failed": "Nothing failed."}.get(st["tab"], "Nothing here."))
        empty.set_visibility(not counts[st["tab"]])

    def tick() -> None:
        # Each rev is read *before* drawing from it: the workers keep moving
        # while this runs, and a change landing mid-draw must still count as
        # unseen next time.
        rev = job.rev
        if rev == st["rev"]:
            return
        for item in job.items:
            r = rows[item.key]
            seen = item.rev
            if r["rev"] != seen:
                _draw(item)
                r["rev"] = seen
        _head()
        st["rev"] = rev

    tick()
    with dlg:
        timer = ui.timer(0.5, tick)

    def _closed() -> None:
        timer.deactivate()
        if _SHEETS.get(client) is _on_event:
            _SHEETS.pop(client, None)
        if on_close:
            on_close()
        dlg.delete()
    dlg.on("hide", _closed)
    dlg.open()
