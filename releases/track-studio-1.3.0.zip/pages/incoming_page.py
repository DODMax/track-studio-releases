"""Incoming (`/incoming`) — get tracks, say where they go, push them to rekordbox.

The job this page exists for, in one sentence: *sync a playlist or acquire a
track, make sure it ends up in the right playlist, and send it to rekordbox so
the actual playlist updates.* Everything here is built from that sentence
rather than from the steps the old screens happened to have.

Which is why the spine is **where a track is going**, not what has been done to
it. A track carries its destination by sitting in a folder of that name (see
`destinations`), so filing one is a file move and the export machinery needs to
know nothing new. The two views that lead are the two things you can act on:

    Needs a home   — acquired, nobody said which playlist. The dead end:
                     a thousand files sat in `Beatport/` because the flow
                     never asked.
    Ready to send  — destination known, rekordbox hasn't got it yet.

Energy analysis is **not here at all**. It is a tag a track may carry, only
the Build page consumes it, and that page is on its way out — so it has no
claim on the screen where tracks arrive. It lives on the Library page, over a
playlist you have chosen to analyze.

Not here either: the Setline set import, still on `/download`. It bridges two
libraries and goes away entirely once the board runs locally against this one.
"""
from __future__ import annotations

from pathlib import Path
from urllib.parse import quote

from nicegui import run, ui

import bpdl
import crates
import destinations
import incoming
import rekordbox_io
import runtime
from drives import DriveOffline
from export_ui import export_handoff, reload_rekordbox, reloaded_message
from library import track_key

from . import acquire as acquire_panel
from . import crate_bar
from . import fetch_sheet
from sources import SourceStore, SyncedSource
from store import load_studio_state, save_export_order
from sync import REKORDBOX_ORDER, SPOTIFY_ORDER, compute_sync, export_tracks
from widgets import player_vue, resizable, sized_columns

from shell import apply_theme, header, settings_dialog


# The job-shaped views, as selection keys. Prefixed so they can't collide with
# a download folder that happens to be called "ready".
VIEW_HOME = "!needs-a-home"
VIEW_DUPES = "!already-have"
# The mirror of VIEW_DUPES: the collection has this record, but the copy you
# just got is the longer cut. Its own view because its verb is its own — filing
# would leave the worse file in rekordbox holding all the play history.
VIEW_BETTER = "!better-edit"
VIEW_READY = "!ready-to-send"
# Acquiring is a step of this job, not a place, so it is a view of this page
# rather than a page of its own — and the one that asks where a track is going
# *before* fetching it, which is what stops the "needs a home" pile re-forming.
VIEW_ACQUIRE = "!acquire"
VIEWS = (VIEW_HOME, VIEW_DUPES, VIEW_BETTER, VIEW_READY, VIEW_ACQUIRE)

COLUMNS = sized_columns([
    {"name": "grab", "label": "Crate", "field": "in_crates", "align": "left", "sortable": True},
    {"name": "title", "label": "Title", "field": "title", "align": "left", "sortable": True},
    {"name": "artist", "label": "Artist", "field": "artist", "align": "left", "sortable": True},
    {"name": "going", "label": "Going to", "field": "going", "align": "left", "sortable": True},
    {"name": "collection", "label": "In your collection", "field": "collection",
     "align": "left", "sortable": True},
    {"name": "needs", "label": "Needs", "field": "needs", "align": "center", "sortable": True},
    {"name": "source", "label": "Came from", "field": "source", "align": "left", "sortable": True},
    {"name": "bpm", "label": "BPM", "field": "bpm", "align": "center", "sortable": True},
    {"name": "key", "label": "Key", "field": "key", "align": "center", "sortable": True},
    {"name": "set", "label": "Set", "field": "set", "align": "center", "sortable": True},
    {"name": "preview", "label": "Preview", "field": "audio", "align": "left"},
], {
    # Where each column starts; drag a header's edge to change it.
    # Sized to fit beside the drawer on a laptop screen; a fixed-layout table
    # shares out any extra width, so a bigger window only makes them roomier.
    "grab": 76, "title": 190, "artist": 130, "going": 120, "collection": 190,
    "needs": 80, "source": 120, "bpm": 70, "key": 64, "set": 96, "preview": 240,
})


@ui.page("/incoming")
def incoming_page(source: str = ""):
    """`?source=<folder name>` opens with that download folder selected."""
    apply_theme()
    header("Incoming")
    # The crate dock sits over the bottom of every track-listing page.
    ui.query("body").style("padding-bottom:190px")
    # Crating from a row changes that row's chip, so the table repaints with
    # the dock. `render` is defined below; the lambda resolves it at call time.
    crate_bar.mount(on_change=lambda: render())
    # The "Show paths" state, as a class on the table rather than a field on
    # every row — see `table_rows`.
    ui.add_head_html("<style>.ts-paths{display:none}"
                     ".ts-show-paths .ts-paths{display:block}"
                     ".ts-here{box-shadow:0 0 0 2px #e8eaef !important}</style>")
    store = SourceStore()
    st = runtime.incoming_state

    # ---------------- drawer ----------------
    with ui.left_drawer(value=True, bordered=True).props("width=300").style(
            "background:#121419; border-right:1px solid #23262d"):
        # Acquiring is the way in, so it sits at the top of the way in.
        # Both ways in, side by side and equally weighted. One filled button
        # saying "download" teaches a first-time reader that downloading is the
        # only door, and syncing a playlist — the thing most visits are actually
        # about — read as a footnote under the list it fills.
        ui.label("BRING TRACKS IN").classes("text-caption text-weight-bold") \
            .style("color:#6b7280; letter-spacing:.08em")
        ui.button("Sync a playlist", icon="sync",
                  on_click=lambda: add_source_dialog()) \
            .props("unelevated no-caps color=primary").classes("w-full q-mt-xs") \
            .tooltip("Follow a Spotify playlist and see what you're missing from it")
        acquire_btn = ui.button("Acquire a track", icon="add",
                                on_click=lambda: select(VIEW_ACQUIRE)) \
            .props("unelevated no-caps color=secondary").classes("w-full q-mt-xs q-mb-sm") \
            .tooltip("Paste a link, search Beatport, or pick up a browser download")
        drawer_col = ui.column().classes("w-full gap-0")

    # ---------------- body ----------------
    with ui.column().classes("w-full p-4 gap-3") as page_col:
        title_lbl = ui.label("Incoming").classes("text-h6")
        summary_lbl = ui.label("").classes("text-caption text-grey")

        # --- filing bar: the whole point of the "needs a home" view ---
        with ui.row().classes("items-center gap-2 w-full") as file_bar:
            ui.label("Send the selected tracks to").classes("text-caption text-grey")
            dest_select = ui.select([], with_input=True,
                                    new_value_mode="add-unique",
                                    label="playlist") \
                .props("outlined dense").style("min-width:18rem")
            file_btn = ui.button("File", icon="drive_file_move",
                                 on_click=lambda: do_file()) \
                .props("unelevated color=secondary")
            # Not on the duplicates view: "Discard all N" does that job without
            # pushing a row dict per tick, and ticking 931 boxes to reach the
            # same place is exactly what made this screen lag.
            all_btn = ui.button("Select all shown", on_click=lambda: select_all()) \
                .props("flat dense no-caps color=primary")
            # Collapsed by default: two paths per row is the evidence, not the
            # summary, and 931 rows of it would bury the thing you came to read.
            # Toggled with a class on the table rather than a re-render — the
            # rows already carry the paths, and rebuilding a thousand of them to
            # change their visibility is how a switch comes to feel slow.
            paths_switch = ui.switch("Show paths", on_change=lambda e: table.classes(
                add="ts-show-paths" if e.value else "",
                remove="" if e.value else "ts-show-paths")) \
                .props("dense").classes("text-caption") \
                .tooltip("Where each copy actually is. Hover a row for the full "
                         "paths and both lengths.")
            ui.space()
            # Only on the duplicates view, where filing is the *dissenting*
            # answer — "no, keep it" — and discarding is the expected one.
            discard_btn = ui.button("Discard", icon="delete_sweep",
                                    on_click=lambda: confirm_discard()) \
                .props("unelevated color=warning") \
                .tooltip("Move them out of the way, into .duplicates in your "
                         "download folder. Nothing is deleted.")
            replace_btn = ui.button("Replace", icon="upgrade",
                                    on_click=lambda: confirm_replace()) \
                .props("unelevated color=positive") \
                .tooltip("Put the longer cut at the path rekordbox already "
                         "points at, so the track keeps its playlists and "
                         "play history. The old file is backed up.")

        with ui.row().classes("items-center gap-2 w-full") as action_bar:
            get_btn = ui.button("Get missing", icon="cloud_download",
                                on_click=lambda: open_get()) \
                .props("unelevated no-caps color=primary") \
                .tooltip("See them matched on Beatport, pick, and download")
            send_btn = ui.button("Send to rekordbox", icon="ios_share",
                                 on_click=lambda: send()) \
                .props("unelevated color=primary")
            # A synced playlist's export order. The list above stays in
            # Spotify's order either way — that is the source you're reading;
            # this only says how the playlist rekordbox gets is arranged.
            order_toggle = ui.toggle(
                {REKORDBOX_ORDER: "rekordbox order", SPOTIFY_ORDER: "Spotify order"},
                value=load_studio_state().get("export_order") or REKORDBOX_ORDER,
                on_change=lambda e: save_export_order(e.value)) \
                .props("dense no-caps unelevated toggle-color=secondary color=grey-9 "
                       "text-color=grey-5 size=sm") \
                .tooltip("How the playlist you send is ordered: as you arranged "
                         "it in rekordbox with the new tracks at the end, or as "
                         "the Spotify playlist has it")
            # The other half of sending: once they're imported, re-reading
            # rekordbox is what makes them leave this list. Here because the
            # export dialog's own reload can be switched off, and then the
            # only one left was on the Library page.
            reload_btn = ui.button("Reload rekordbox", icon="album",
                                   on_click=lambda: reload_rb()) \
                .props("flat no-caps color=secondary") \
                .tooltip("Imported them? Re-read rekordbox so they leave this list")
            ui.space()
            relink_btn = ui.button("Re-link rb", icon="link",
                                   on_click=lambda: relink_dialog()) \
                .props("flat dense no-caps color=grey") \
                .tooltip("Re-point this source at a rekordbox playlist")
            library_btn = ui.button("Show in Library", icon="library_music",
                                    on_click=lambda: go_to_library()) \
                .props("flat dense no-caps color=primary")
            with ui.button(icon="more_vert").props("flat dense round color=grey") \
                    .tooltip("Less common things"):
                with ui.menu():
                    ui.menu_item("Open the download root",
                                 on_click=lambda: reveal_root())
                    ui.separator()
                    ui.menu_item("Settings…", on_click=lambda: settings_dialog())

        # The acquire panel lives beside the table, not instead of it: built on
        # first use (its inbox scan reads tags and walks the library, which no
        # visit that never opens it should pay for) and toggled thereafter.
        acquire_col = ui.column().classes("w-full")
        acquire_col.set_visibility(False)

        table = resizable(ui.table(columns=COLUMNS, rows=[], row_key="id",
                                   pagination=50).classes("w-full"), "incoming")
        # Crating happens wherever you notice a track, arrivals included — the
        # drag never reaches the server, see `crate_bar`. A row with no track
        # behind it yet carries no key and so isn't draggable.
        table.add_slot("body-cell-grab", f"""
            <q-td :props="props">
              <span v-if="props.row.crate_key">{crate_bar.grab_cell()}</span>
            </q-td>
        """)
        table.add_slot("body-cell-needs", r"""
            <q-td :props="props">
              <q-badge :color="{get:'negative',file:'warning',import:'info',ready:'positive'}[props.value]"
                       :text-color="props.value==='file'||props.value==='import' ? 'dark' : 'white'">
                {{ props.value }}
              </q-badge>
            </q-td>
        """)
        # The destination, or the absence of one said out loud — a dash would
        # read as "no data" when it actually means "nobody has decided".
        table.add_slot("body-cell-going", r"""
            <q-td :props="props">
              <span v-if="props.value">{{ props.value }}</span>
              <span v-else style="color:#d29922">needs a home</span>
            </q-td>
        """)
        # The duplicate verdict rides on the title, not in a column of its own:
        # it is a fact *about this track*, and it has to stay visible in the
        # filing view too, where a "possible dupe" is the one row you want to
        # look at twice before moving it into a playlist.
        table.add_slot("body-cell-title", r"""
            <q-td :props="props">
              {{ props.value }}
              <q-badge v-if="props.row.only_rb" color="deep-orange-10"
                       text-color="orange-3" class="q-ml-sm">not in Spotify</q-badge>
              <q-badge v-if="props.row.have_chip" :color="props.row.have_color"
                       :text-color="props.row.have_color==='warning' ? 'dark' : 'white'"
                       class="q-ml-sm">
                {{ props.row.have_chip }}
                <q-tooltip>{{ props.row.have_detail }}</q-tooltip>
              </q-badge>
            </q-td>
        """)
        # Where the collection already has it. A dash would read as "no data"
        # when it means "nothing in rekordbox looks like this" — which, in this
        # view, is the whole reason a row is interesting.
        #
        # The playlist name alone can't settle "is this really the same file?",
        # and the two full paths are far too long to live in a column, so they
        # come in two collapsed states: the last two components inline behind
        # the "Show paths" switch, for scanning a screenful at a time, and the
        # whole path plus both lengths on hover, which is the actual evidence.
        table.add_slot("body-cell-collection", r"""
            <q-td :props="props">
              <div v-if="props.value">
                <div class="ellipsis">{{ props.value }}</div>
                <div v-if="props.row.rb_path" class="ts-paths"
                     style="font-family:monospace; font-size:10px; color:#6b7280;
                            line-height:14px; margin-top:3px; max-width:30rem">
                  <div class="ellipsis">new&nbsp; …/{{ props.row.mine_path.split('/').slice(-2).join('/') }}</div>
                  <div class="ellipsis">rb&nbsp;&nbsp; …/{{ props.row.rb_path.split('/').slice(-2).join('/') }}</div>
                </div>
                <q-tooltip v-if="props.row.rb_path" style="max-width:none">
                  <div style="font-family:monospace; font-size:11px; white-space:nowrap">
                    <div style="color:#9aa0a8">this download{{ props.row.mine_len }}</div>
                    <div>{{ props.row.mine_path }}</div>
                    <div style="color:#9aa0a8; margin-top:6px">in rekordbox{{ props.row.rb_len }}</div>
                    <div>{{ props.row.rb_path }}</div>
                  </div>
                </q-tooltip>
              </div>
              <span v-else style="color:#555">—</span>
            </q-td>
        """)
        table.add_slot("body-cell-set", r"""
            <q-td :props="props">
              <q-badge v-if="props.value !== 'n_a'"
                       :color="{in:'secondary',out:'grey-9'}[props.value]"
                       :text-color="props.value==='in' ? 'dark' : 'grey-5'"
                       class="cursor-pointer"
                       @click="() => $parent.$emit('toggle_set', props.row.id)">
                {{ props.value === 'in' ? 'in set' : 'not in set' }}
                <q-icon name="swap_horiz" size="13px" class="q-ml-xs" />
              </q-badge>
              <span v-else style="color:#555">—</span>
            </q-td>
        """)
        # A row with no file of its own gets a button instead of a transport:
        # the tracks you are about to *buy* are the ones you most want to hear.
        table.add_slot("body-cell-preview", f"""
            <q-td :props="props">
              <div v-if="props.row.audio" style="width:220px">
                {player_vue("props.row.audio")}
              </div>
              <q-btn v-else-if="props.row.can_preview"
                     dense flat no-caps size="sm" color="primary"
                     icon="play_circle_outline" label="preview"
                     :loading="props.row.previewing"
                     @click="() => $parent.$emit('preview_row', props.row.id)" />
              <span v-else style="color:#555">—</span>
            </q-td>
        """)

    def toast(*args, **kwargs):
        """A notification anchored to the page, not to whatever was clicked.

        NiceGUI builds an element in the *sender's* parent slot, so a message
        raised from a button inside a list the handler then re-renders is
        deleted mid-job and its result never reaches the browser.
        """
        with page_col:
            return ui.notify(*args, **kwargs)

    def notification(message: str):
        with page_col:
            return ui.notification(message, spinner=True, timeout=None)

    # ==================================================================
    # what's where it's going
    # ==================================================================

    # The destination-name set, and the source list behind it, memoized for one
    # render. Both re-read `.synced_sources.json` from disk, and the drawer used
    # to rebuild the set once per folder inside a lambda — cheap individually,
    # silly in a loop, and this page re-renders on every click.
    cache: dict = {"known": None, "sources": None}

    def _sources() -> list:
        if cache["sources"] is None:
            cache["sources"] = store.list()
        return cache["sources"]

    def _known() -> set:
        if cache["known"] is None:
            cache["known"] = destinations.known_names(
                runtime.library.rekordbox_index, _sources())
        return cache["known"]

    def _invalidate() -> None:
        """Anything that changes the sources or the collection drops the memo."""
        cache["known"] = cache["sources"] = None

    def _destination_of(folder: str):
        return destinations.of_folder(folder, _known())

    def _name_of(pid: str) -> str:
        s = store.get(pid)
        return s.last_name if s else pid

    def _sel_source():
        sel = st["sel"]
        return store.get(sel[3:]) if sel.startswith("sp:") else None

    def _marked(items: list) -> list:
        """Re-attach the cached duplicate scan. The lane is rebuilt every render,
        so the annotation has to be re-applied rather than stored on the rows."""
        incoming.apply_duplicates(items, runtime.duplicate_scan["found"])
        return items

    def _lane() -> list:
        """Every arriving track, from every feed, deduped and worklist-ordered."""
        known = _known()
        gaps = []
        for pid, rows in runtime.source_rows.items():
            s = store.get(pid)
            gaps.append(incoming.from_gap(rows, _name_of(pid),
                                          s.rb_name if s else None))
        return _marked(incoming.merge(*gaps, incoming.from_folders(
            runtime.incoming_batches, lambda f: destinations.of_folder(f, known))))

    def _homeless(lane) -> list:
        """Owes a destination and isn't something the collection already holds.

        The split is the whole point of the scan: filing a redundant copy is
        not a smaller version of the right action, it is the wrong one — it
        puts a second path under a track rekordbox already has, which is what
        `dupes` exists to prevent. Until the scan has run nothing is marked and
        this is simply everything, which is honest: we haven't asked yet.
        """
        return [i for i in incoming.owed(lane, "destination")
                if not i.duplicate and not _replaceable(i)]

    def _dupes(lane) -> list:
        return [i for i in incoming.owed(lane, "destination") if i.duplicate]

    def _replaceable(i) -> bool:
        """A longer cut than rekordbox's, with a file at *both* ends.

        The second half is what makes the row actionable: replacing is a swap,
        so it needs somewhere to swap into. One predicate, used by both slices,
        so a row that is a better edit but has nothing to swap into falls back
        into the filing worklist instead of out of every view.
        """
        return bool(i.better_edit and i.local_path
                    and getattr(i.have.track, "local_path", None))

    def _better(lane) -> list:
        return [i for i in incoming.owed(lane, "destination") if _replaceable(i)]

    def _items(lane=None) -> list:
        """The rows for the current selection. `lane` is reused when the caller
        has already built it — the job views are just slices of it."""
        sel = st["sel"]
        if sel == VIEW_HOME:
            return _homeless(lane if lane is not None else _lane())
        if sel == VIEW_DUPES:
            return _dupes(lane if lane is not None else _lane())
        if sel == VIEW_BETTER:
            return _better(lane if lane is not None else _lane())
        if sel == VIEW_READY:
            return [i for i in incoming.owed(
                        lane if lane is not None else _lane(), "rekordbox")
                    if "destination" not in i.needs and i.local_path]
        if sel.startswith("sp:"):
            # A source shows *all* its rows, finished ones included — that is
            # what the export would carry, and hiding a track already in the
            # set is how one gets silently clipped out of it.
            pid = sel[3:]
            s = store.get(pid)
            return _marked(incoming.from_gap(runtime.source_rows.get(pid, []),
                                             _name_of(pid), s.rb_name if s else None))
        known = _known()
        return _marked(incoming.merge(incoming.from_folders(
            {sel: runtime.incoming_batches.get(sel, [])},
            lambda f: destinations.of_folder(f, known))))

    # ==================================================================
    # set membership (a source's export decision)
    # ==================================================================

    def _sel_rows() -> list:
        s = _sel_source()
        return runtime.source_rows.get(s.spotify_playlist_id, []) if s else []

    def _default_in_set(r) -> bool:
        """Downloads are added; tracks pulled out of the rekordbox set stay out."""
        if r.in_set == "in":
            return True
        if r.pipeline == "downloaded":
            return True
        if r.needs_add_to_set:
            return False
        return True

    def _is_in_set(i: int, r) -> bool:
        return st["set_override"].get(i, _default_in_set(r))

    def _toggle_set(e):
        # A folder row carries a negative id — it belongs to no source's row
        # list, so there is nothing to flip. Without the guard a negative index
        # would silently address the list from the other end.
        i = int(e.args)
        rows = _sel_rows()
        if i < 0 or i >= len(rows) or rows[i].in_set == "n_a":
            return
        st["set_override"][i] = not _is_in_set(i, rows[i])
        render()
    table.on("toggle_set", _toggle_set)

    # ==================================================================
    # rendering
    # ==================================================================

    # A chip's colour has to say which *way* the verdict points. "Already have"
    # argues against keeping the file; "replaces a lost file" and "longer edit"
    # argue for it, and colouring those like a duplicate is how someone bins the
    # one download that was an upgrade.
    HAVE_COLOR = {"already have": "warning", "possible dupe": "grey-7",
                  "replaces a lost file": "info", "longer edit": "positive",
                  "shorter edit": "grey-7"}

    def _clock(seconds: float) -> str:
        """" · 7:17", or nothing when the file's length couldn't be read."""
        if not seconds:
            return ""
        return f"  ·  {int(seconds) // 60}:{int(seconds) % 60:02d}"

    def table_rows(items: list, chips: bool = True) -> list[dict]:
        """`chips=False` on the duplicates view, where the verdict is the same on
        every line and the "In your collection" column already carries it."""
        # Every field here is multiplied by the row count and crosses the wire
        # again on every selection change, so anything derivable in the browser
        # stays out of it: the short path forms are `.split('/').slice(-2)` in
        # the cell template, and whether they are *shown* is a class on the
        # table, not a boolean repeated on 931 rows.
        crate_index = crates.index(crates.load())
        out = []
        for n, item in enumerate(items):
            r = item.row
            p = item.local_path
            have = item.have
            rb_path = getattr(have.track, "local_path", None) if have else None
            ckey = track_key(item.track) if item.track is not None else ""
            cchip, ctip = crate_bar.membership(crate_index, ckey) if ckey else ("", "")
            out.append({
                "collection": have.where_label if have else "",
                "have_chip": have.chip if (have and chips) else "",
                "have_color": HAVE_COLOR.get(have.chip, "grey-7") if have else "",
                # Only the chip's tooltip reads this, so it is dead weight on
                # the view that doesn't draw the chip.
                "have_detail": have.detail if (have and chips) else "",
                "mine_path": str(p) if p else "",
                "rb_path": str(rb_path) if rb_path else "",
                "mine_len": _clock(have.candidate_s) if have else "",
                "rb_len": _clock(have.length_s) if have else "",
                # The length gap, so the discard dialog can state what it
                # actually checked rather than a rule the batch may beat.
                "delta": (round(have.delta_s, 1)
                          if have and have.delta_s is not None else None),
                # The row id is the source's row index where there is one, so the
                # Set chip and the preview button address the list the handlers
                # do. Folder rows get a negative id and their file path instead.
                "id": item.index if item.index >= 0 else -(n + 1),
                # The crate cell. A row with no track behind it yet (wanted,
                # not fetched) has no stable key, so it isn't draggable at all.
                "crate_key": ckey,
                "in_crates": cchip,
                "in_crates_full": ctip,
                "path": str(p) if p else "",
                "title": item.title,
                "artist": item.artist,
                "going": item.destination or "",
                "needs": item.chip,
                "source": item.source,
                "bpm": round(item.bpm) if item.bpm else "",
                "key": item.camelot,
                "set": ("n_a" if r is None or r.in_set == "n_a"
                        else ("in" if _is_in_set(item.index, r) else "out")),
                "only_rb": bool(r is not None and not r.in_spotify),
                "audio": (f"/media?path={quote(str(p))}" if p
                          else ((r.preview_url if r else None) or "")),
                "can_preview": bool(r is not None and not p and not r.preview_url
                                    and not r.preview_checked and r.spotify),
                "previewing": item.index in st["previewing"],
            })
        return out

    def _dl_dest() -> Path:
        s = _sel_source()
        root = runtime._dl_root()
        return root / destinations.safe(s.rb_name) if s else root

    # The acquire panel's `refresh`, once it has been built, and the selection
    # it was opened from. Per-visit rather than in `runtime`: the first closes
    # over this client's elements, and the second is only meaningful while the
    # panel is on screen.
    acquire = {"refresh": None, "from": VIEW_HOME}

    def _default_destination() -> str:
        """Where the page thinks the next track is going.

        Read from where you *came from*, not from the selection — by the time
        the panel asks, the selection is the panel. Opening it while working
        through a synced playlist means the next track is almost certainly for
        that playlist; from a folder that resolves to a destination, likewise.
        From a job view there is nothing to infer, and a guess would file
        tracks somewhere nobody asked for.
        """
        origin = acquire["from"]
        if origin.startswith("sp:"):
            s = store.get(origin[3:])
            return (s.rb_name or "") if s else ""
        return "" if origin in VIEWS else (_destination_of(origin) or "")

    def _open_acquire():
        if acquire["refresh"] is None:
            with acquire_col:
                acquire["refresh"] = acquire_panel.panel(
                    default_destination=_default_destination,
                    choices=lambda: destinations.choices(
                        runtime.library.rekordbox_index, _sources()),
                    on_landed=lambda paths: _after_acquire(),
                    toast=toast, spinner=notification)
        acquire["refresh"]()

    def _after_acquire():
        """Something landed: the lane and the counts move, the panel stays put."""
        runtime.refresh_batches()
        render()
        ui.timer(0.05, lambda: scan_duplicates(), once=True)

    def render():
        _invalidate()          # one memo generation per render
        sel = st["sel"]
        # Built once and handed down: `_items` slices it and the drawer counts
        # it, and each used to rebuild it from scratch (a stat() per arriving
        # file, both times) on every click.
        lane = _lane()

        # Acquiring replaces the worklist rather than sitting under it: nothing
        # in the table, and none of the verbs over it, applies to a track that
        # hasn't been fetched yet.
        acquiring = sel == VIEW_ACQUIRE
        # The button at the top is the only way in, so it is also what says
        # you are here — a second, smaller "Acquire a track" in the list below
        # only ever led to the same place.
        acquire_btn.classes(add="ts-here" if acquiring else "",
                            remove="" if acquiring else "ts-here")
        acquire_col.set_visibility(acquiring)
        table.set_visibility(not acquiring)
        action_bar.set_visibility(not acquiring)
        title_lbl.set_visibility(not acquiring)
        summary_lbl.set_visibility(not acquiring)
        if acquiring:
            file_bar.set_visibility(False)
            drawer(lane)
            _open_acquire()
            return

        items = _items(lane)
        rows = table_rows(items, chips=sel != VIEW_DUPES)
        table.rows = rows
        picking = sel in (VIEW_HOME, VIEW_DUPES, VIEW_BETTER)
        # Drop columns that would say the same thing on every line.
        one_source = sel.startswith("sp:") or sel not in VIEWS
        table.columns = [
            c for c in COLUMNS
            if (c["name"] != "source" or not one_source)
            and (c["name"] != "set" or any(r["set"] != "n_a" for r in rows))
            and (c["name"] != "going" or not picking)
            # Not just the duplicates view: once the scan has run, Needs a home
            # is where the repairs and the longer edits live, and "which one is
            # already in rekordbox" is exactly what decides those.
            and (c["name"] != "collection" or any(r["collection"] for r in rows))]
        # Filing is a bulk act over a selection, so the table only offers ticks
        # where there is something to tick them for.
        table.props(f"selection={'multiple' if picking else 'none'}")
        if not picking:
            table.selected = []
        table.update()

        s = _sel_source()
        n_ready = len([i for i in items
                       if "destination" not in i.needs and "rekordbox" in i.needs
                       and i.local_path])
        n_get = len([i for i in incoming.owed(items, "download") if i.spotify])

        if sel == VIEW_HOME:
            title_lbl.set_text("Needs a home")
            # What the scan found about *these* rows. Each of these matched
            # something in rekordbox and is still here because the match argues
            # for keeping the file, not against it — which is worth saying, or
            # the numbers look like the duplicates view failed to catch them.
            better = len([i for i in items if i.better_edit])
            lost = len([i for i in items if i.heals])
            notes = [f"{better} a longer edit than the one in rekordbox" if better else "",
                     f"{lost} replacing a file rekordbox has lost" if lost else ""]
            summary_lbl.set_text(
                f"{len(items)} track(s) nobody has said a playlist for. Tick them, "
                "pick one, and they move into it."
                + ("  ·  checking them against your collection…" if scanning["now"]
                   else ("  ·  " + ", ".join(n for n in notes if n)
                         if any(notes) else "")))
        elif sel == VIEW_DUPES:
            title_lbl.set_text("Already in your collection")
            kept = len([i for i in incoming.owed(lane, "destination")
                        if i.heals or i.better_edit])
            summary_lbl.set_text(
                f"{len(items)} download(s) that rekordbox already has under another "
                "path, at the same length. Filing one would put a second copy in "
                "your collection, and rekordbox would count its plays separately — "
                "so discarding is usually the answer. They move to .duplicates; "
                "nothing is deleted."
                + (f"  {kept} more matched by name but aren't copies — a longer "
                   "edit, or a repair for a lost file — and stay in Needs a home."
                   if kept else ""))
        elif sel == VIEW_BETTER:
            title_lbl.set_text("Longer than rekordbox's")
            summary_lbl.set_text(
                f"{len(items)} download(s) that run longer than the copy in your "
                "collection — usually the extended mix against a radio edit. "
                "Replace puts the new file where rekordbox already looks, so the "
                "track keeps its playlists, rating and play history and only the "
                "audio changes. The old file is backed up first.")
        elif sel == VIEW_READY:
            title_lbl.set_text("Ready to send")
            by_dest = {}
            for i in items:
                by_dest[i.destination] = by_dest.get(i.destination, 0) + 1
            summary_lbl.set_text(
                f"{len(items)} track(s) → "
                + ", ".join(f"{d} ({n})" for d, n in sorted(by_dest.items()))
                if items else "Nothing is waiting to go over.")
        elif s:
            stale = bool(s.paired_rb_id) and s.paired_rb_id not in runtime.library.rekordbox_index
            pair = (f"   ↔ rb: {s.paired_rb_name}" if s.paired_rb_name
                    else "   (no paired set)")
            if stale:
                pair = f"   ⚠ rb: {s.paired_rb_name} (not found — Re-link rb)"
            title_lbl.set_text(f"♫ {s.last_name}{pair}")
            summary_lbl.set_text(
                f"{len(items)} in the playlist  ·  {n_get} to get  ·  "
                f"{n_ready} ready to send  ·  downloads → {_dl_dest()}")
        else:
            going = _destination_of(sel)
            title_lbl.set_text(f"⬇ {sel}")
            summary_lbl.set_text(
                f"{len(items)} track(s)  →  " + (going or "nobody has said where"))

        file_bar.set_visibility(picking)
        discard_btn.set_visibility(sel == VIEW_DUPES)
        replace_btn.set_visibility(sel == VIEW_BETTER)
        all_btn.set_visibility(sel == VIEW_HOME)
        paths_switch.set_visibility(any(r["rb_path"] for r in rows))
        if picking:
            dest_select.options = destinations.choices(
                runtime.library.rekordbox_index, _sources())
            dest_select.update()
            _sync_picked()
        get_btn.set_visibility(bool(s) and (bool(n_get) or _fetching(s)))
        _sync_get_btn(n_get)
        send_btn.set_visibility(bool(n_ready))
        send_btn.set_text(f"Send {n_ready} to rekordbox")
        order_toggle.set_visibility(bool(s) and bool(n_ready))
        reload_btn.set_visibility(sel == VIEW_READY or bool(n_ready))
        relink_btn.set_visibility(bool(s))
        library_btn.set_visibility(bool(s and s.paired_rb_id
                                        and s.paired_rb_id in runtime.library.rekordbox_index))
        drawer(lane)

    def _sync_picked():
        """Put the count on both verbs, so neither reads as "all of them".

        With nothing ticked, Discard means the whole view — and says so with the
        number. That is not a convenience: Quasar's `selected` is a list of full
        row dicts pushed to the browser as a prop, so ticking 931 boxes to
        discard 931 rows sends about a megabyte, and every further tick resends
        it. The bulk path never touches the selection.
        """
        n = len(table.selected or [])
        file_btn.set_text(f"File {n}" if n else "File")
        discard_btn.set_text(f"Discard {n}" if n else f"Discard all {len(table.rows)}")
        replace_btn.set_text(f"Replace {n}" if n else f"Replace all {len(table.rows)}")
    table.on("selection", _sync_picked)

    def select_all():
        table.selected = list(table.rows)
        table.update()
        _sync_picked()

    # ==================================================================
    # the drawer
    # ==================================================================

    def _caption(text: str, indent: int) -> None:
        if not text:
            return
        ui.label(text).style(
            f"margin:-2px 0 6px {indent}px; font-size:10px; color:#6b7280; "
            "line-height:12px; white-space:nowrap; overflow:hidden; "
            "text-overflow:ellipsis")

    def _entry(label: str, key: str, *, color: str, indent: int = 0) -> None:
        btn = ui.button(label, on_click=lambda k=key: select(k)) \
            .props(f"flat dense no-caps align=left color={color}") \
            .classes("w-full").style(f"padding-left:{indent + 8}px; min-width:0")
        if st["sel"] == key:
            btn.style("background:#1e2127; border-radius:4px")

    def drawer(lane=None):
        drawer_col.clear()
        known = _known()
        # `render` has already built the lane; building it again here meant a
        # second `stat()` over every arriving file on every click.
        lane = _lane() if lane is None else lane
        homeless = _homeless(lane)
        dupes_n = _dupes(lane)
        better_n = _better(lane)
        ready = [i for i in lane if "destination" not in i.needs
                 and "rekordbox" in i.needs and i.local_path]
        with drawer_col:
            # The things you can act on, first and by name.
            _entry(f"⚠ Needs a home  ({len(homeless)})", VIEW_HOME,
                   color="warning" if homeless else "grey-6")
            if scanning["now"]:
                _caption("checking these against your collection…", 16)
            elif dupes_n:
                # Only once there is an answer — an "Already have it (0)" sitting
                # there before the scan has run is a claim we haven't earned.
                _entry(f"⧉ Already have it  ({len(dupes_n)})", VIEW_DUPES,
                       color="warning")
                _caption("downloads rekordbox already has", 16)
            if better_n:
                _entry(f"⬆ Longer than rekordbox's  ({len(better_n)})",
                       VIEW_BETTER, color="positive")
                _caption("you have the short edit of these", 16)
            _entry(f"✓ Ready to send  ({len(ready)})", VIEW_READY,
                   color="secondary" if ready else "grey-6")
            if ready:
                going = sorted({i.destination for i in ready})
                _caption(" · ".join(going[:3]) + ("…" if len(going) > 3 else ""), 16)

            srcs = _sources()
            with ui.row().classes("items-center justify-between w-full no-wrap q-mt-md"):
                ui.label("SYNCED PLAYLISTS").classes("text-caption text-weight-bold") \
                    .style("color:#6b7280; letter-spacing:.08em")
                ui.button(icon="add", on_click=lambda: add_source_dialog()) \
                    .props("flat dense round size=sm color=primary") \
                    .tooltip("Follow another Spotify playlist")
            if not srcs:
                # An empty list that just sits there is what makes people assume
                # downloading is the only door. Say what this is for instead.
                _caption("None yet — follow one and this page will tell you what", 8)
                _caption("you're missing from it, and get it.", 8)
            for s in srcs:
                pid = s.spotify_playlist_id
                rows = runtime.source_rows.get(pid)
                with ui.row().classes("items-center no-wrap w-full gap-0"):
                    with ui.column().classes("flex-grow gap-0").style("min-width:0"):
                        _entry(s.last_name + (f"  ({len(rows)})" if rows is not None else ""),
                               f"sp:{pid}", color="grey-5", indent=4)
                    ui.button(icon="refresh", on_click=lambda x=s: open_source(x)) \
                        .props("flat dense round size=sm color=grey") \
                        .tooltip("Pull this playlist from Spotify again")
                    ui.button(icon="delete_outline", on_click=lambda x=s: remove_source(x)) \
                        .props("flat dense round size=sm color=grey") \
                        .tooltip("Stop syncing this playlist")
                if rows is None:
                    _caption("not pulled yet", 20)
                else:
                    gap = incoming.merge(incoming.from_gap(rows, s.last_name, s.rb_name))
                    _caption(incoming.summary(gap) or "nothing waiting", 20)
            folders = incoming.by_source(incoming.merge(incoming.from_folders(
                runtime.incoming_batches,
                lambda f: destinations.of_folder(f, known))))
            if folders:
                ui.label("FOLDERS").classes("text-caption text-weight-bold q-mt-md") \
                    .style("color:#6b7280; letter-spacing:.08em")
            for name, group in folders:
                _entry(f"{name}  ({len(group)})", name, color="grey-5", indent=4)
                going = group[0].destination
                _caption(f"→ {going}" if going else "→ needs a home", 20)

    def select(key: str):
        if key == VIEW_ACQUIRE and st["sel"] != VIEW_ACQUIRE:
            acquire["from"] = st["sel"]   # seeds the panel's destination
        st["sel"] = key
        if key.startswith("sp:"):
            pid = key[3:]
            if pid not in runtime.source_rows:
                s = store.get(pid)
                if s:
                    open_source(s)
                    return
            st["set_override"] = {}
            st["previewing"] = set()
        table.selected = []
        render()

    def reveal_root():
        import subprocess
        subprocess.Popen(["open", str(runtime._dl_root())])

    # ==================================================================
    # ① acquire — synced sources
    # ==================================================================

    def open_source(s: SyncedSource):
        if not any(t.in_rekordbox for t in runtime.library.tracks):
            toast("Load rekordbox first (Library tab)", type="warning")
            return
        # Always work from the persisted source: the drawer's buttons close over
        # the objects the last render captured, so a pairing made since then
        # lives only on disk, and opening the stale object would drop it.
        s = store.get(s.spotify_playlist_id) or s
        runtime.refresh_batches()
        n = notification(f"Pulling “{s.last_name}” from Spotify…")
        try:
            tracks = runtime._sp().playlist_tracks(s.spotify_playlist_id)
        except Exception as e:
            n.dismiss()
            toast(f"Spotify error: {e}", type="negative", timeout=8000)
            return
        s = _auto_pair(s)
        runtime.source_rows[s.spotify_playlist_id] = compute_sync(
            tracks, runtime.library, paired_rb_id=s.paired_rb_id)
        st["sel"] = f"sp:{s.spotify_playlist_id}"
        st["set_override"] = {}
        st["previewing"] = set()
        n.dismiss()
        render()

    def _recompute(s: SyncedSource) -> None:
        """Re-match a pulled source against the library, without a Spotify trip."""
        rows = runtime.source_rows.get(s.spotify_playlist_id)
        if rows is None:
            return
        runtime.source_rows[s.spotify_playlist_id] = compute_sync(
            [r.spotify for r in rows if r.spotify], runtime.library,
            paired_rb_id=s.paired_rb_id)

    def _auto_pair(s: SyncedSource) -> SyncedSource:
        """Bind to a rekordbox node whose name matches, so importing the export
        and reloading lights up "in set". Also self-heals a stale pairing."""
        return store.auto_pair(s, runtime.library.rekordbox_index)

    def relink_dialog():
        s = _sel_source()
        if not s:
            return
        nodes = sorted(runtime.library.rekordbox_index.items(),
                       key=lambda kv: kv[1].name.lower())
        options = {nid: node.name for nid, node in nodes}
        with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[32rem]"):
            ui.label("Re-link rekordbox playlist").classes("text-subtitle1 text-weight-bold")
            ui.label(f"“{s.last_name}” currently points at "
                     f"{s.paired_rb_name or 'nothing'}.").classes("text-caption text-grey")
            pick = ui.select(options, with_input=True, label="rekordbox playlist") \
                .props("outlined dense").classes("w-full")

            def save():
                if not pick.value:
                    return
                s.paired_rb_id = pick.value
                s.paired_rb_name = options[pick.value]
                store.upsert(s)
                d.close()
                open_source(s)
            with ui.row().classes("justify-end w-full gap-2 q-mt-md"):
                ui.button("Cancel", on_click=d.close).props("flat color=grey")
                ui.button("Link", on_click=save).props("unelevated color=primary")
        d.open()

    def add_source_dialog():
        with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[32rem]"):
            ui.label("Add Spotify playlist").classes("text-subtitle1 text-weight-bold")
            holder = ui.column().classes("w-full")
            with holder:
                ui.label("Loading playlists from Spotify…").classes("text-grey")

            async def load():
                try:
                    pls = await run.io_bound(lambda: runtime._sp().list_playlists())
                except Exception as e:
                    holder.clear()
                    with holder:
                        ui.label(f"Spotify error: {e}").classes("text-caption") \
                            .style("color:#f85149")
                    return
                known = {x.spotify_playlist_id for x in store.list()}
                options = {p.id: f"{p.name}  ({p.track_count})"
                           for p in pls if p.id not in known}
                holder.clear()
                with holder:
                    if not options:
                        ui.label("Every playlist is already synced.") \
                            .classes("text-caption text-grey")
                        return
                    pick = ui.select(options, with_input=True, label="playlist") \
                        .props("outlined dense").classes("w-full")

                    def add():
                        if not pick.value:
                            return
                        s = SyncedSource(spotify_playlist_id=pick.value,
                                         last_name=options[pick.value].rsplit("  (", 1)[0])
                        store.upsert(s)
                        d.close()
                        open_source(s)
                    with ui.row().classes("justify-end w-full gap-2 q-mt-md"):
                        ui.button("Cancel", on_click=d.close).props("flat color=grey")
                        ui.button("Add", on_click=add).props("unelevated color=primary")
            d.open()
            ui.timer(0.05, load, once=True)

    def remove_source(s: SyncedSource):
        store.remove(s.spotify_playlist_id)
        runtime.source_rows.pop(s.spotify_playlist_id, None)
        if st["sel"] == f"sp:{s.spotify_playlist_id}":
            st["sel"] = VIEW_HOME
        render()
        toast(f"Stopped syncing “{s.last_name}”")

    def go_to_library():
        s = _sel_source()
        if s and s.paired_rb_id in runtime.library.rekordbox_index:
            ui.navigate.to(f"/?node={quote(str(s.paired_rb_id))}")

    async def _preview_row(e):
        """Resolve one row on Beatport and hand its clip to the transport.

        One track at a time on purpose: `resolve` is a catalog search each, and
        a missing playlist is fifty of them — worth paying for the row you're
        curious about, not for the other forty-nine.
        """
        i = int(e.args)
        rows = _sel_rows()
        if i < 0 or i >= len(rows):
            return
        r = rows[i]
        if not r.spotify or r.preview_url or r.preview_checked:
            return
        st["previewing"].add(i)
        render()
        try:
            res = await run.io_bound(lambda: bpdl.resolve([r.spotify]))
            bt = res[0].beatport if res else None
            r.preview_url = bt.sample_url if bt else None
            r.preview_checked = True
        except Exception as err:            # noqa: BLE001
            # Not `preview_checked` — a network blip should leave the button
            # there to try again, unlike "Beatport hasn't got it".
            toast(f"Couldn't reach Beatport: {err}", type="negative")
        finally:
            st["previewing"].discard(i)
            render()
        if r.preview_checked and not r.preview_url:
            toast(f"No Beatport clip for “{r.spotify.name}”", type="info")
    table.on("preview_row", _preview_row)

    # ------------------------------------------------------------------
    # getting what a source is missing — the sheet (`fetch_sheet`)
    # ------------------------------------------------------------------

    def _job_of(s):
        return runtime.fetch_jobs.get(s.spotify_playlist_id) if s else None

    def _fetching(s) -> bool:
        job = _job_of(s)
        return job is not None and job.active

    def open_get():
        """Open the sheet for the selected source: the running job if there is
        one, else a fresh one over whatever is missing now.

        Fresh rather than the last finished one, because the gap moved — what
        downloaded is no longer missing. Nothing is searched twice for it:
        matches and picks from earlier this session come back from
        `fetchjob`'s cache, so reopening is instant.
        """
        s = _sel_source()
        if not s:
            toast("Pick a synced playlist to fetch its missing tracks", type="warning")
            return
        job = _job_of(s)
        if job is None or not job.active:
            rows = [r for r in _sel_rows() if r.needs_source and r.spotify]
            if not rows:
                toast("Nothing missing to download", type="info")
                return
            # A row that matched a *different edit* is on the list because the
            # length says so; the sheet says why, or it reads as a mistake.
            notes = {r.spotify.id: f"you have a {_clock(r.collection_s).strip(' ·')} "
                                   "edit of this — this is the other one"
                     for r in rows if r.other_edit and r.collection_s}
            job = runtime.start_fetch(s, _dl_dest(), [r.spotify for r in rows], notes)
        sheet["open"] = True

        def _closed():
            sheet["open"] = False
            watched["gen"] = runtime.fetch_state["gen"]   # this render covers it
            render()
        fetch_sheet.open_sheet(job, destination=s.rb_name, on_close=_closed)

    def _sync_get_btn(n_get: int) -> None:
        """"Get 12", or — while a job runs — how far it has got, which is also
        the way back into it."""
        job = _job_of(_sel_source())
        if job is not None and job.active:
            import fetchjob as fj
            done = job.n_landed
            todo = job.count(fj.DONE, fj.QUEUED, fj.DOWNLOADING, fj.FAILED)
            get_btn.set_text(f"Downloading {done}/{todo}" if job.downloading
                             else f"Matching {len(job.items) - job.count(fj.MATCHING)}"
                                  f"/{len(job.items)}")
            get_btn.props("icon=downloading")
        else:
            get_btn.set_text(f"Get {n_get}")
            get_btn.props("icon=cloud_download")

    # What the page last drew from: the library generation a fetch moves, and
    # the selected job's own counter, so the button follows the job without
    # the whole page re-rendering on every row that changes.
    watched = {"gen": runtime.fetch_state["gen"], "rev": None}
    # While the sheet is up the page under it is not redrawn at all: a full
    # render resends the table — a player per row — twice per landed batch,
    # behind a sheet that hides it, and that was half of what made the sheet
    # lag while it worked. Closing the sheet renders once, with everything.
    sheet = {"open": False}

    def _watch_fetch():
        if sheet["open"]:
            return
        if runtime.fetch_state["gen"] != watched["gen"]:
            watched["gen"] = runtime.fetch_state["gen"]
            render()
            return
        job = _job_of(_sel_source())
        rev = (job.rev, job.active) if job is not None else None
        if rev != watched["rev"]:
            watched["rev"] = rev
            s = _sel_source()
            if s:
                n_get = len([r for r in _sel_rows() if r.needs_source and r.spotify])
                _sync_get_btn(n_get)
                get_btn.set_visibility(bool(n_get) or _fetching(s))
    ui.timer(1.0, _watch_fetch)

    # ==================================================================
    # ② file — say where a track goes
    # ==================================================================

    def do_file():
        picked = list(table.selected or [])
        if not picked:
            toast("Tick the tracks to file first", type="warning")
            return
        target = (dest_select.value or "").strip()
        if not target:
            toast("Pick a playlist for them", type="warning")
            return
        paths = [Path(r["path"]) for r in picked if r.get("path")]
        if not paths:
            toast("Those rows have no file yet — get them first", type="warning")
            return
        moved, problems = destinations.assign(paths, target, runtime._dl_root())
        # A name rekordbox hasn't got yet is a real answer, not a mistake: it
        # will exist the first time this is imported. Remember it so the folder
        # doesn't read as homeless again the moment we re-scan.
        if target.lower() not in _known():
            destinations.declare(target)
        # A moved file's `Track` still points at where it was; `refresh_batches`
        # builds a second one for the new path and the old one lingers.
        runtime.forget_tracks([p for p in paths if not p.exists()])
        runtime.refresh_batches()
        table.selected = []
        render()
        if problems:
            toast(f"Filed {len(moved)}; {len(problems)} couldn't move — "
                  f"{problems[0][1]}", type="warning", timeout=12000)
        else:
            toast(f"Filed {len(moved)} into “{target}”. They're ready to send.",
                  type="positive")
        # The pile these were judged against just changed, so the cached answer
        # is about a library that no longer exists. Re-ask quietly — the counts
        # move on their own rather than the view blanking mid-job.
        ui.timer(0.05, lambda: scan_duplicates(), once=True)

    # ==================================================================
    # ②b already have it — the answer that isn't a destination
    # ==================================================================

    # Whether a scan is actually in flight. Separate from `duplicates_stale()`,
    # which only says the cache has no current answer — a scan that *failed*
    # leaves it stale forever, and "checking…" next to a number nothing is
    # working on is a worse lie than saying nothing.
    scanning = {"now": False}

    async def scan_duplicates(announce: bool = False):
        """Ask the collection whether it already holds what's arriving.

        A fuzzy pass over rekordbox per row — ~2s for a thousand — so it runs
        off the event loop, once, and the answer is cached in `runtime` until
        the library or the folders change under it. Runs unprompted because the
        question is not optional: the default action on this screen is to file
        these into playlists, and filing a copy of something rekordbox already
        has is the one mistake this page can make that quietly damages the
        collection rather than just cluttering it.
        """
        if scanning["now"]:
            return
        homeless = incoming.owed(_lane(), "destination")
        if not homeless:
            runtime.save_duplicates({})
            return
        n = notification(f"Checking {len(homeless)} against your collection…") \
            if announce else None

        def _work():
            import dupes
            return incoming.scan_duplicates(homeless, dupes.Index(runtime.library.tracks))

        scanning["now"] = True
        runtime._safe_ui(render)       # the caption comes on with the work
        try:
            found = await run.io_bound(_work)
        except Exception as e:                       # noqa: BLE001
            # Never fatal: a failed check must not cost the page. It also must
            # not read as "nothing matched" — so nothing is cached, and the
            # views stay in their honest "we haven't asked" state.
            print(f"[incoming] duplicate scan failed: {e!r}")
            runtime._safe_ui(lambda: toast(f"Couldn't check against your "
                                           f"collection: {e}", type="warning"))
            return
        else:
            # Cached even if nobody is left to look at it — the answer is about
            # the library, not about this page, and the next visit should find
            # it done rather than start again.
            runtime.save_duplicates(found)
        finally:
            # Three seconds is long enough to click another tab, and everything
            # below touches elements that die with the client.
            scanning["now"] = False
            runtime._safe_ui(lambda: (n.dismiss() if n else None, render()))

    def confirm_discard():
        # Nothing ticked means the whole view, which is the normal case here —
        # and the one that must not go through the selection prop. See
        # `_sync_picked`.
        picked = [r for r in (table.selected or []) if r.get("path")]
        whole = not picked
        if whole:
            picked = [r for r in table.rows if r.get("path")]
        if not picked:
            toast("Nothing here to discard", type="info")
            return
        root = runtime._dl_root()
        with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[34rem]"):
            ui.label(f"Discard {'all ' if whole else ''}{len(picked)} download(s)?") \
                .classes("text-subtitle1 text-weight-bold")
            ui.label("They move to "
                     f"{root / destinations.DISCARD_DIRNAME} — nothing is deleted, "
                     "and you can drag them back out in Finder.") \
                .classes("text-caption text-grey")
            # Two signals had to agree for a row to get here, and the dialog
            # says both — naming only the weaker one undersells the check and
            # misdescribes it. The length gap is quoted from this batch rather
            # than as the rule, because the rule allows 20s and these are
            # almost always within one.
            gaps = [abs(r["delta"]) for r in picked if r.get("delta") is not None]
            how = ("same artist and title, and the two files are the same length"
                   + (f" — the biggest gap here is {max(gaps):.1f}s" if gaps else ""))
            ui.label(f"Each one matched a track rekordbox already has: {how}. "
                     "Anything that looked like a different edit has already been "
                     "kept out of this list.") \
                .classes("text-caption text-grey")
            ui.label("That is a strong match, not proof — if one of these turns "
                     "out to be a different master or version, file it instead.") \
                .classes("text-caption").style("color:#d29922")
            with ui.row().classes("justify-end w-full gap-2 q-mt-md"):
                ui.button("Cancel", on_click=d.close).props("flat color=grey")
                ui.button("Discard", icon="delete_sweep",
                          on_click=lambda: (d.close(), do_discard(picked))) \
                    .props("unelevated color=warning")
        d.open()

    def do_discard(picked: list):
        paths = [Path(r["path"]) for r in picked]
        gone, problems = destinations.discard(paths, runtime._dl_root())
        # Whatever actually left has to leave the library too, or its `Track`
        # lingers pointing at a path nothing is at any more.
        runtime.forget_tracks([p for p in paths if not p.exists()])
        runtime.refresh_batches()
        runtime.clear_duplicates()      # the pile just changed under the answer
        table.selected = []
        render()
        if problems:
            toast(f"Discarded {len(gone)}; {len(problems)} couldn't move — "
                  f"{problems[0][1]}", type="warning", timeout=12000)
        else:
            toast(f"Discarded {len(gone)} into "
                  f"{destinations.DISCARD_DIRNAME}. Re-checking what's left…",
                  type="positive")
        ui.timer(0.05, lambda: scan_duplicates(), once=True)

    # ==================================================================
    # ②c replace — you have the worse cut of this record
    # ==================================================================

    def confirm_replace():
        picked = [r for r in (table.selected or []) if r.get("rb_path")]
        whole = not picked
        if whole:
            picked = [r for r in table.rows if r.get("rb_path")]
        if not picked:
            toast("Nothing here to replace", type="info")
            return
        with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[36rem]"):
            ui.label(f"Replace {'all ' if whole else ''}{len(picked)} in rekordbox?") \
                .classes("text-subtitle1 text-weight-bold")
            ui.label("The new file goes where rekordbox already looks, so the "
                     "track keeps its playlists, rating and play history and only "
                     "the audio changes. The shorter edit is kept, not deleted — "
                     f"it moves into a “{refetch_backup_dirname()}” folder beside "
                     "it — and the swap is rolled back if the new audio doesn't "
                     "check out.") \
                .classes("text-caption text-grey")
            # The real cost, said before the click rather than discovered on
            # stage. A longer cut moves every landmark in the track.
            ui.label("Its cue points and beatgrid were set for the shorter edit, "
                     "so they will be in the wrong places — re-analyze these in "
                     "rekordbox afterwards. The Energy tag carries over and is "
                     "stale for the same reason.") \
                .classes("text-caption").style("color:#d29922")
            with ui.row().classes("justify-end w-full gap-2 q-mt-md"):
                ui.button("Cancel", on_click=d.close).props("flat color=grey")
                ui.button("Replace", icon="upgrade",
                          on_click=lambda: (d.close(), do_replace(picked))) \
                    .props("unelevated color=positive")
        d.open()

    def refetch_backup_dirname() -> str:
        import refetch
        return refetch.REPLACED_DIRNAME

    async def do_replace(picked: list):
        """Swap each longer cut in at the path rekordbox points at.

        `refetch.replace_in_place` does one file: backs the old one up, copies
        the new one over it, carries the Comments payload across and packet-
        checks the result, rolling back if it isn't clean. It reads whole files,
        so a batch runs off the event loop with a count.
        """
        pairs = [(Path(r["path"]), Path(r["rb_path"])) for r in picked
                 if r.get("path") and r.get("rb_path")]
        prog = {"done": 0, "total": len(pairs)}
        n = notification(f"Replacing 0/{len(pairs)} in rekordbox…")

        def _render():
            n.message = f"Replacing {prog['done']}/{prog['total']} in rekordbox…"
        timer = ui.timer(0.3, _render)

        def _work():
            import refetch
            done, failed = [], []
            for new, target in pairs:
                try:
                    ok, msg = refetch.replace_in_place(
                        new, target, backup_dirname=refetch.REPLACED_DIRNAME)
                except Exception as e:            # noqa: BLE001
                    ok, msg = False, str(e)
                (done if ok else failed).append((new, target, msg))
                prog["done"] += 1
            return done, failed

        try:
            done, failed = await run.io_bound(_work)
        except Exception as e:                     # noqa: BLE001
            timer.deactivate()
            runtime._safe_ui(n.dismiss)
            toast(f"Replace failed: {e}", type="negative", timeout=9000)
            return
        timer.deactivate()

        # A download that made it into the collection is now the second copy,
        # so it leaves the lane the same way any other duplicate does.
        swapped = [new for new, _t, _m in done]
        if swapped:
            destinations.discard(swapped, runtime._dl_root())
            runtime.forget_tracks([p for p in swapped if not p.exists()])
        runtime.refresh_batches()
        # Every replaced file has a new length, which is what the whole scan is
        # measured on.
        runtime.clear_duplicates()
        table.selected = []
        runtime._safe_ui(lambda: (n.dismiss(), render()))
        if failed:
            toast(f"Replaced {len(done)}; {len(failed)} left alone — "
                  f"{failed[0][2]}", type="warning", timeout=15000)
        elif done:
            toast(f"Replaced {len(done)} in rekordbox. Re-analyze them there so "
                  "the beatgrid and cues match the longer cut.",
                  type="positive", timeout=15000)
        ui.timer(0.05, lambda: scan_duplicates(), once=True)

    # ==================================================================
    # ③ send to rekordbox
    # ==================================================================

    def send():
        """One import per destination — each lands under its own playlist name,
        and one import can only carry one name."""
        items = [i for i in _items()
                 if "destination" not in i.needs and "rekordbox" in i.needs
                 and i.local_path]
        if not items:
            toast("Nothing here is ready to go over", type="info")
            return
        by_dest: dict[str, list] = {}
        for i in items:
            by_dest.setdefault(i.destination, []).append(i)
        s = _sel_source()
        if s and s.rb_name in by_dest:
            export_source(s)          # a source exports as a *set*: order + membership
            return
        if len(by_dest) == 1:
            name = next(iter(by_dest))
            export_destination(name, by_dest[name])
            return
        with ui.dialog() as d, ui.card().style("background:#16181d"):
            ui.label("Send to rekordbox").classes("text-subtitle1 text-weight-bold")
            ui.label("One import per playlist — each lands under its own name, so "
                     "they can't go over in a single drag.") \
                .classes("text-caption text-grey")
            for name, group in sorted(by_dest.items()):
                with ui.row().classes("items-center w-full gap-2 no-wrap q-mt-xs"):
                    ui.label(f"{name}  ({len(group)})") \
                        .classes("flex-grow ellipsis text-caption").style("min-width:0")
                    ui.button("Export", on_click=lambda n=name, g=group:
                              (d.close(), export_destination(n, g))) \
                        .props("unelevated dense no-caps color=primary")
            with ui.row().classes("justify-end w-full q-mt-md"):
                ui.button("Close", on_click=d.close).props("flat color=grey")
        d.open()

    # Importing an xml playlist *replaces* rekordbox's playlist of that name.
    # So every export here is written as the whole playlist — what rekordbox
    # holds now plus what's new — never as the new tracks alone, and anything
    # it would still drop is asked about before the file is written.

    def _source_named(name: str):
        key = (name or "").strip().lower()
        return next((x for x in _sources() if x.rb_name.strip().lower() == key), None)

    def export_destination(name: str, items: list):
        """A destination's new tracks, carried with the playlist they join.

        It used to write the new tracks alone under the playlist's name, so
        "Ready to send" on twenty downloads for a hundred-track playlist left
        twenty after the import. A synced playlist whose gap is pulled goes as
        its set instead — the same export its own view does, Set chips and all.
        """
        src = _source_named(name)
        if src is not None and src.spotify_playlist_id in runtime.source_rows:
            export_source(src)
            return
        new = [i.track for i in items if i.track and i.track.local_path]
        if not new:
            toast("Nothing with a file to export", type="warning")
            return
        node = runtime.library.playlist_named(name)
        playlist = runtime.library.playlist_entries(node.id) if node else []
        tracks, lost = rekordbox_io.carry(playlist, new)
        _write_playlist(name, tracks, lost, playlist,
                        re_export=lambda: export_destination(name, items))

    def export_source(s: SyncedSource):
        """A synced playlist exports as a *set* (`sync.export_tracks`): the
        Set chips honoured, ordered as the toggle beside the button says."""
        rows = runtime.source_rows.get(s.spotify_playlist_id, [])
        here = _sel_source()
        if here is not None and here.spotify_playlist_id == s.spotify_playlist_id:
            keep = _is_in_set            # the chips clicked on this view
        else:
            keep = lambda _i, r: _default_in_set(r)   # noqa: E731
        node = runtime.library.playlist_named(s.rb_name, prefer=s.paired_rb_id)
        playlist = runtime.library.playlist_entries(node.id) if node else []
        tracks, lost = export_tracks(rows, keep, playlist,
                                     order=order_toggle.value or REKORDBOX_ORDER)
        skipped = sum(1 for i, r in enumerate(rows)
                      if r.in_set != "n_a" and not keep(i, r)
                      and (r.collection_match or r.local_match))
        _write_playlist(
            s.rb_name, tracks, lost, playlist,
            note=(f"Left out {skipped} track(s) marked “not in set” — click their "
                  "Set chip to include them." if skipped else ""),
            re_export=lambda: export_source(s))

    def _why_not(t) -> str:
        """Why an xml can't name this track — the words for the confirm."""
        loc = t.rekordbox_location or ""
        if t.rekordbox_source_kind == "streaming" and ":" in loc:
            return f"{loc.split(':', 1)[0].capitalize()} stream"
        if t.rekordbox_source_kind == "foreign":
            return "a path from Windows"
        return "no file here"

    def _write_playlist(name: str, tracks: list, lost: list, playlist: list, *,
                        re_export, note: str = "", confirmed: bool = False):
        """Write `tracks` as the playlist `name`, asking first when the import
        would take tracks out of rekordbox's playlist of that name.

        A confirm and not a line in the handoff, because that dialog can be
        switched off and then says nothing — and this is the one export
        outcome that loses something.
        """
        if not tracks:
            toast("Nothing with a file to export yet", type="warning")
            return
        held = {t.rekordbox_id for t in playlist}
        new = [t for t in tracks if t.rekordbox_id not in held]
        if lost and not confirmed:
            with ui.dialog() as d, ui.card().style("background:#16181d").classes("w-[34rem]"):
                ui.label(f"This would take {len(lost)} track(s) out of “{name}”") \
                    .classes("text-subtitle1 text-weight-bold")
                ui.label("Importing replaces rekordbox's playlist of that name with "
                         "what the export carries, and an export can only name a "
                         "track by its file. These have none it can write:") \
                    .classes("text-caption text-grey")
                for t in lost[:8]:
                    ui.label(f"{t.artist} – {t.title}  ·  {_why_not(t)}") \
                        .classes("text-caption ellipsis").style("max-width:100%")
                if len(lost) > 8:
                    ui.label(f"…and {len(lost) - 8} more").classes("text-caption text-grey")
                if new:
                    ui.label(f"Sending only the {len(new)} new one(s) under another "
                             "name leaves the playlist alone — import it, then drag "
                             f"them into “{name}”.").classes("text-caption q-mt-sm")
                with ui.row().classes("justify-end w-full gap-2 q-mt-md"):
                    ui.button("Cancel", on_click=d.close).props("flat color=grey")
                    if new:
                        ui.button(f"Only the new, as “{name} (new)”",
                                  on_click=lambda: (d.close(), _write_playlist(
                                      f"{name} (new)", new, [], [],
                                      re_export=re_export, confirmed=True))) \
                            .props("unelevated no-caps color=primary")
                    ui.button("Export anyway", on_click=lambda: (d.close(), _write_playlist(
                        name, tracks, lost, playlist, re_export=re_export,
                        note=note, confirmed=True))) \
                        .props("flat no-caps color=warning")
            d.open()
            return
        try:
            out = str(runtime.export_target())
        except DriveOffline as e:
            toast(str(e), type="warning")
            return
        n = rekordbox_io.export_playlist(out, name, rekordbox_io.items_of(tracks))
        added = f" ({len(new)} new)" if playlist and new else ""
        export_handoff(
            out, f"{n} tracks{added} · playlist “{name}”", f"“{name}”",
            note=note, re_export=re_export, on_reloaded=lambda: after_reload())

    async def reload_rb():
        reload_btn.props("loading")
        try:
            stats = await reload_rekordbox()
        except Exception as e:                      # noqa: BLE001 — said, not raised
            toast(f"Couldn't read rekordbox DB: {e}", type="negative", timeout=8000)
            return
        finally:
            reload_btn.props(remove="loading")
        toast(reloaded_message(stats), type="positive")
        after_reload()

    def after_reload():
        """Re-read everything the import just changed.

        Both feeds were computed against the old collection: the folders still
        say "not in rekordbox", and a source's gap still says "missing" for
        tracks that have just landed. Re-running both is what makes the round
        trip visible — rows leave because they are done.
        """
        runtime.refresh_batches()
        for pid in list(runtime.source_rows):
            s = store.get(pid)
            if s:
                _recompute(_auto_pair(s))
        render()
        # The collection is what "already have it" is measured against, and the
        # import just changed it — so the cached answer is stale by definition.
        ui.timer(0.05, lambda: scan_duplicates(), once=True)

    # ---------------- first paint ----------------
    runtime.refresh_batches()
    if source and source in runtime.incoming_batches:
        st["sel"] = source
    elif st["sel"] not in VIEWS and not st["sel"].startswith("sp:") \
            and st["sel"] not in runtime.incoming_batches:
        st["sel"] = VIEW_HOME
    render()
    # Ask the collection what it already has, unprompted, before the first
    # filing click — after the paint, so the page opens on its counts rather
    # than on a spinner. Once per change to the library or the folders.
    if runtime.duplicates_stale():
        ui.timer(0.05, lambda: scan_duplicates(announce=True), once=True)
