"""Setline's palette, in one place.

Three surfaces speak it now — the crate dock, the acquire panel and the fill
screen — and they are meant to be *one* language, not three that drift. The
tokens are Setline's own `:root` block (its `--accent` and `--smooth` are the
exact hexes Track Studio already used, which is what made adopting the rest of
its look a matter of moving CSS rather than picking colours).

Each surface scopes them to itself rather than declaring them globally: the
pages these mount on are full of Quasar, and a `:root` variable named `--line`
is the kind of thing a component library helps itself to.

Usage — string concatenation, not an f-string, because CSS is mostly braces:

    _CSS = "<style>" + kit.scope(".ts-dock") + \"\"\"
    .ts-dock { position:fixed; ... }
    \"\"\"
"""
from __future__ import annotations

TOKENS = """
  --ground:#0c0d11; --surface:#14161b; --raised:#1c1f26; --raised-2:#242832;
  --line:#2a2e37; --line-2:#3a3f4b;
  --ink:#e8eaef; --ink-2:#a4abb7; --ink-3:#6e7582;
  --accent:#ff7a1a; --accent-ink:#160a02; --smooth:#2dd4bf; --warn:#d29922;
"""


def scope(*selectors: str) -> str:
    """The token block, declared on each of `selectors`."""
    return ", ".join(selectors) + " {" + TOKENS + "}\n"
