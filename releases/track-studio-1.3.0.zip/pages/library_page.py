"""Library page (`/`) — load tagged tracks into the domain `Library`, browse them
in a sortable table with audio preview, drive energy/vibe analysis, and manage the
rekordbox playlist tree. What has arrived but isn't ready yet lives on the
Incoming page (see `incoming`); this page is the settled collection."""
from __future__ import annotations

import time
from pathlib import Path
from urllib.parse import quote

from nicegui import run, ui

import crates
import rekordbox
import runtime
from analysis import AnalysisJob, IntegrityJob, LoudnessJob, NormalizeJob, RefetchJob
from export_ui import export_handoff
from library import file_duration, read_comment_into_track, track_key
from store import RekordboxSnapshot, save_studio_state

from . import crate_bar
from shell import apply_theme, header
import widgets
from widgets import (ENERGY_COLORS, _chip, _kv, audio_player, camelot_color,
                     resizable, sized_columns,
                     metric_bar, mood_color, render_texture_metrics,
                     valence_color)


def _fmt_len(seconds: float) -> str:
    """m:ss — so two durations can be compared at a glance rather than in ms."""
    if not seconds:
        return "—"
    return f"{int(seconds) // 60}:{int(seconds) % 60:02d}"


def _rows(filter_ids: set | None = None, filter_paths: set | None = None) -> list[dict]:
    # Which crates hold what, read once for the whole table rather than per row.
    crate_index = crates.index(crates.load())
    rows = []
    for i, t in enumerate(runtime.library.tracks):
        if filter_ids is not None and t.rekordbox_id not in filter_ids:
            continue
        if filter_paths is not None and str(t.local_path) not in filter_paths:
            continue
        key = track_key(t)
        chip, tip = crate_bar.membership(crate_index, key)
        rows.append({
            "id": i,
            "title": t.title,
            "artist": t.artist,
            "energy": t.energy if t.energy is not None else "",
            "bpm": round(t.bpm) if t.bpm else "",
            "key": t.key or "",
            "style": t.style or "",
            "status": t.sync_status,
            "rb": t.rekordbox_status,
            "rb_kind": t.rekordbox_source_kind or "",
            "rb_pls": len(t.rekordbox_playlists),
            "_path": str(t.local_path) if t.local_path else "",
            # The crate cell: what a drop would store, and what already holds
            # it. Computed here because only the page knows which library
            # track a row stands for.
            "crate_key": key,
            "in_crates": chip,
            "in_crates_full": tip,
        })
    return rows


COLUMNS = sized_columns([
    {"name": "grab", "label": "Crate", "field": "in_crates", "align": "left", "sortable": True},
    {"name": "title", "label": "Title", "field": "title", "align": "left", "sortable": True},
    {"name": "artist", "label": "Artist", "field": "artist", "align": "left", "sortable": True},
    {"name": "energy", "label": "Energy", "field": "energy", "align": "center", "sortable": True},
    {"name": "bpm", "label": "BPM", "field": "bpm", "align": "center", "sortable": True},
    {"name": "key", "label": "Key", "field": "key", "align": "center", "sortable": True},
    {"name": "style", "label": "Style", "field": "style", "align": "left", "sortable": True},
    {"name": "status", "label": "File", "field": "status", "align": "center", "sortable": True},
    {"name": "rb", "label": "Rekordbox", "field": "rb", "align": "center", "sortable": True},
    {"name": "rb_kind", "label": "RB src", "field": "rb_kind", "align": "center", "sortable": True},
    {"name": "rb_pls", "label": "RB pls", "field": "rb_pls", "align": "center", "sortable": True},
], {
    # Where each column starts; drag a header's edge to change it.
    # Sized to fit beside the drawer on a laptop screen; a fixed-layout table
    # shares out any extra width, so a bigger window only makes them roomier.
    "grab": 76, "title": 200, "artist": 150, "energy": 78, "bpm": 74, "key": 68,
    "style": 100, "status": 92, "rb": 92, "rb_kind": 82, "rb_pls": 76,
})


@ui.page("/")
def index(node: str = ""):
    """`?node=<rekordbox playlist id>` opens with that playlist pre-selected —
    how Incoming's "Show in Library" hands a paired playlist over."""
    apply_theme()
    # This visit's browser tab. A long job's result is delivered by whichever
    # Library page is on screen when it lands (see `_tick`), so a page being
    # left behind has to be able to tell that it isn't that page any more.
    client = ui.context.client
    # selection state for playlist-tree filtering
    state = {"filter_ids": None, "filter_paths": None, "filter_label": None,
             "node_id": None, "tree": None}
    header("Library")
    # The crate dock sits over the bottom of the page, so the last rows need
    # somewhere to go — the collapsed bar is 38px and the open shelf ~180px.
    ui.query("body").style("padding-bottom:190px")
    # Crating from a row changes that row's chip, so the table repaints when
    # the dock does. `refresh` is defined further down; the lambda resolves it
    # at call time, by which point it exists.
    crate_bar.mount(on_change=lambda: refresh())

    # --- left drawer: library data actions + rekordbox playlist tree ---
    with ui.left_drawer(value=True, bordered=True).props("width=280").style(
            "background:#121419; border-right:1px solid #23262d") as drawer:
        with ui.row().classes("items-center gap-1 w-full no-wrap"):
            ui.button("Reload rekordbox", icon="album",
                      on_click=lambda: load_rekordbox()) \
                .props("flat dense no-caps size=sm color=primary").classes("flex-grow")
            ui.button(icon="create_new_folder", on_click=lambda: folder_dialog()) \
                .props("flat dense round size=sm color=grey").tooltip("Add an extra folder")
        ui.separator().props("color=grey-9")
        # No "downloads" section here any more: what has arrived but isn't ready
        # lives on the Incoming page, which owns the whole arrival pipeline. This
        # page is the settled collection.
        ui.label("PLAYLISTS").classes("text-caption text-weight-bold q-my-sm") \
            .style("color:#6b7280; letter-spacing:.08em")
        ui.button("⌂ All tracks", on_click=lambda: select_node(None)) \
            .props("flat dense no-caps align=left color=primary").classes("w-full")
        tree_holder = ui.column().classes("w-full").style("margin-top:-10px")

    with ui.column().classes("w-full p-4 gap-4"):
        # --- analyze controls (act on the selected playlist) ---
        with ui.row().classes("items-center gap-3 w-full"):
            analyze_btn = ui.button("Analyze energy", icon="bolt",
                                    on_click=lambda: analyze()).props("unelevated color=primary")
            loudness_btn = ui.button("Measure loudness", icon="graphic_eq",
                                     on_click=lambda: measure_loudness()) \
                .props("outline color=primary") \
                .tooltip("EBU R128 (LUFS) across this playlist — are these mastered "
                         "at the same level?")
            problems_btn = ui.button("Check for problems", icon="health_and_safety",
                                     on_click=lambda: check_problems()) \
                .props("outline color=warning") \
                .tooltip("Does this playlist's audio actually play straight through? "
                         "Finds files stitched from stream segments, whose beatgrid "
                         "drifts and can't be fixed.")
            buildset_btn = ui.button("Build a set", icon="auto_awesome_motion",
                                     on_click=lambda: go_build_set()) \
                .props("outline color=secondary")
            # Hidden until a playlist is selected (refresh() toggles them);
            # they act on the selected scope, never the whole library.
            analyze_btn.set_visibility(False)
            loudness_btn.set_visibility(False)
            problems_btn.set_visibility(False)
            buildset_btn.set_visibility(False)
            # Settings for Analyze/Measure — meaningless without them, so they
            # follow the same scoped visibility.
            force_cb = ui.checkbox("Force re-analyze")
            rich_cb = ui.checkbox("Rich (style/mood)", value=True)
            force_cb.set_visibility(False)
            rich_cb.set_visibility(False)
            cancel_btn = ui.button("Cancel", icon="stop", on_click=lambda: do_cancel()) \
                .props("flat color=negative").classes("hidden")
        # size: the default 4px bar was near-invisible, which is half of why a job
        # at 0% looked like nothing was happening.
        analyze_prog = ui.linear_progress(value=0, show_value=False) \
            .props("instant-feedback size=10px rounded").classes("w-full hidden")
        analyze_lbl = ui.label("").classes("text-caption text-grey")

        counts_lbl = ui.label("Nothing loaded.").classes("text-caption text-grey")
        # No standing "some of these may be stitched" warning here any more: the
        # only free signal is an encoder atom, which half the honest files in a
        # library carry, so the banner cried wolf until it read as decoration.
        # See the note in `runtime` for the measurement. Stitched audio is caught
        # on arrival now, and dug out of the backlog by "Check for problems".

        # --- table ---
        table = resizable(ui.table(columns=COLUMNS, rows=[], row_key="id",
                                   pagination=25).classes("w-full"), "library")
        # The crate cell: drag handle plus what already holds this track. The
        # drag itself never reaches the server — see `crate_bar`.
        table.add_slot("body-cell-grab", f"""
            <q-td :props="props">{crate_bar.grab_cell()}</q-td>
        """)
        # energy cell: colored badge
        table.add_slot("body-cell-energy", r"""
            <q-td :props="props">
              <q-badge v-if="props.value !== ''" :style="{
                  backgroundColor: ['#888','#3b6ea5','#3b6ea5','#3b6ea5','#4a90e2',
                    '#4a90e2','#5fb454','#f0a830','#e8731c','#d83a3a','#a02020'][props.value]
                }">{{ props.value }}</q-badge>
            </q-td>
        """)
        table.add_slot("body-cell-status", r"""
            <q-td :props="props">
              <q-badge :color="{ready:'positive',untagged:'warning',missing:'grey',offline:'orange-9'}[props.value]">
                {{ props.value }}
              </q-badge>
            </q-td>
        """)
        table.add_slot("body-cell-rb", r"""
            <q-td :props="props">
              <q-badge :color="{in:'secondary',removed:'negative',absent:'grey-9'}[props.value]"
                       :text-color="props.value==='in' ? 'dark' : (props.value==='absent' ? 'grey-5' : 'white')">
                {{ props.value }}
              </q-badge>
            </q-td>
        """)

        # --- preview player ---
        preview = ui.column().classes("w-full")

        def on_row(e):
            row = e.args[1]
            preview.clear()
            t = runtime.library.tracks[row["id"]]
            with preview:
                ui.label(f"▶ {t.artist} — {t.title}").classes("text-subtitle2")
                if t.local_path:
                    audio_player(t.local_path)
                with ui.card().classes("w-full surface q-gutter-y-sm"):
                    # analysis chips
                    with ui.row().classes("items-center gap-2 wrap"):
                        ui.badge(str(t.energy) if t.energy else "?").style(
                            f"background:{ENERGY_COLORS.get(t.energy or 0, '#888')}")
                        if t.key:
                            _chip(t.key, camelot_color(t.key))
                        if t.bpm:
                            ui.label(f"{round(t.bpm)} bpm").classes("text-caption text-grey") \
                                .style("font-family:monospace")
                        dur = file_duration(t.local_path) if t.local_path else None
                        if dur:
                            m, s = divmod(int(round(dur)), 60)
                            ui.label(f"{m}:{s:02d}").classes("text-caption text-grey") \
                                .style("font-family:monospace")
                        if t.style:
                            _chip(t.style, "#2a2d35", "#cbd2da")
                        for m in (t.moods or [])[:5]:
                            _chip(m, mood_color(m))
                    if not (t.style or t.moods or t.valence is not None):
                        ui.label("No rich analysis yet — run Analyze with “Rich” on.") \
                            .classes("text-caption text-grey")
                    # metric bars (graceful when absent)
                    if t.valence is not None:
                        metric_bar("valence", (t.valence - 3.0) / 4.0,
                                   valence_color(t.valence), f"{t.valence:.2f}")
                    if t.danceability is not None:
                        metric_bar("danceability", t.danceability, "#2dd4bf",
                                   f"{t.danceability:.2f}")
                    if t.arousal is not None:
                        metric_bar("arousal", (t.arousal - 3.0) / 4.0, "#f0a830",
                                   f"{t.arousal:.2f}")
                    render_texture_metrics(t, metric_bar)
                    ui.separator().props("color=grey-9")
                    # library / rekordbox / identity
                    _kv("File", t.sync_status + (f"  ·  {t.rekordbox_source_kind}"
                                                 if t.rekordbox_source_kind else ""))
                    _kv("Rekordbox", t.rekordbox_status
                        + (f"  ·  ★{t.rekordbox_rating}" if t.rekordbox_rating else ""))
                    if t.rekordbox_playlists:
                        _kv("Playlists", ", ".join(t.rekordbox_playlists))
                    if t.isrc:
                        _kv("ISRC", t.isrc)
                    if t.local_path:
                        _kv("Path", str(t.local_path))

        table.on("rowClick", on_row)

        def refresh():
            table.rows = _rows(state["filter_ids"], state["filter_paths"])
            table.update()
            # Analyze / Measure act on the *selected* scope; on "All tracks" (no
            # playlist or batch selected) they'd run over the whole library, which
            # is never what you want and is an easy mis-click — so hide them until
            # something is selected.
            scoped = state["filter_ids"] is not None or state["filter_paths"] is not None
            analyze_btn.set_visibility(scoped)
            loudness_btn.set_visibility(scoped)
            problems_btn.set_visibility(scoped)
            buildset_btn.set_visibility(scoped)
            force_cb.set_visibility(scoped)
            rich_cb.set_visibility(scoped)
            preview.clear()
            c = runtime.library.counts()
            rb_in = sum(1 for t in runtime.library.tracks if t.in_rekordbox)
            rb_removed = sum(1 for t in runtime.library.tracks if t.removed_from_rekordbox)
            scope = (f"▶ {state['filter_label']} ({len(table.rows)})   |   "
                     if state["filter_label"] else "")
            counts_lbl.set_text(
                scope
                + f"{c['total']} tracks  ·  {c['ready']} ready  ·  {c['untagged']} untagged  "
                f"·  {c['missing']} missing"
                + (f"  ·  {c['offline']} on a drive that isn't connected" if c["offline"] else "")
                + f"   |   rekordbox: {rb_in} in"
                + (f"  ·  {rb_removed} removed" if rb_removed else "")
            )

        # Which button spins for which job. A *kind* rather than the element
        # itself, because the page that started a job is often not the page that
        # has to show it running: come back to Library mid-check and these
        # buttons are brand new objects. Normalize borrows the loudness button —
        # it's fired from a dialog that closes behind it, so that's the only
        # anchor left on screen, and it's the same family of work.
        JOB_BUTTONS = {"analyze": analyze_btn, "loudness": loudness_btn,
                       "normalize": loudness_btn, "problems": problems_btn,
                       "refetch_plan": problems_btn, "refetch_apply": problems_btn}

        # This visit's half of a job: which button is spinning. The job itself
        # lives in `runtime.job_state`, which outlives the page, and `job_timer`
        # (created below, with `_tick`) is what watches it.
        job_ui = {"btn": None}

        def _job_ui_start(kind: str, msg: str) -> None:
            """Enter the "a long job is running" state.

            Every long job routes through here so they all *look* the same: the
            triggering button spins, Cancel appears, and the bar starts
            indeterminate — a determinate bar sitting at 0 while a job partitions
            its work reads as "nothing is happening", which is exactly what made
            normalize (fired from a dialog, so no visible button) look frozen.

            Also how a page re-joins a job it didn't start (`_attach_job`).
            """
            btn = JOB_BUTTONS.get(kind)
            job_ui["btn"] = btn
            if btn:
                btn.props("loading")
            cancel_btn.classes(remove="hidden")
            analyze_prog.value = 0
            analyze_prog.props("indeterminate")
            analyze_prog.classes(remove="hidden")
            analyze_lbl.set_text(msg)
            job_timer.activate()

        def _job_ui_end() -> None:
            btn = job_ui["btn"]
            if btn:
                btn.props(remove="loading")
            job_ui["btn"] = None
            job_timer.deactivate()
            cancel_btn.classes("hidden")
            analyze_prog.classes("hidden")
            analyze_prog.props(remove="indeterminate")
            analyze_lbl.set_text("")

        def _attach_job() -> None:
            """Re-join a job that was started before this page was.

            Without this, a check you kicked off and then walked away from looks
            dead when you come back: the thread is still going and the result is
            still coming, but the progress bar, the Cancel button and the report
            all belonged to the page you left. The timer takes it from here —
            including delivering a result that landed while you were away.
            """
            if runtime.job_state["job"] is not None:
                _job_ui_start(runtime.job_state["kind"], runtime.job_state["msg"])

        def _scope_tracks():
            """Tracks targeted by Analyze: current batch / playlist selection, else all."""
            if state["filter_paths"] is not None:
                paths = state["filter_paths"]
                return [t for t in runtime.library.tracks if str(t.local_path) in paths]
            if state["filter_ids"] is not None:
                ids = state["filter_ids"]
                return [t for t in runtime.library.tracks if t.rekordbox_id in ids]
            return list(runtime.library.tracks)

        async def hydrate_selection(node_id):
            """Background-read file Comments for a playlist's untagged tracks."""
            tracks = [t for t in runtime.library.tracks_in_playlist(node_id)
                      if t.local_path and t.energy is None]
            if not tracks:
                return

            def work():
                for t in tracks:
                    read_comment_into_track(t)
            await run.io_bound(work)
            refresh()

        def go_build_set():
            if state["node_id"]:
                ui.navigate.to(f"/build?node={quote(str(state['node_id']))}")
            else:
                # A download folder is no longer something this page selects —
                # it lives in Incoming, which has its own way into Build.
                ui.notify("Select a playlist first", type="warning")

        def select_node(node_id):
            state["filter_paths"] = None
            state["node_id"] = node_id
            if node_id is None:
                state["filter_ids"] = None
                state["filter_label"] = None
            else:
                node = runtime.library.rekordbox_index.get(node_id)
                state["filter_ids"] = node.all_track_ids() if node else None
                state["filter_label"] = node.name if node else None
            refresh()
            if node_id:
                ui.timer(0.05, lambda: hydrate_selection(node_id), once=True)

        def _tick():
            # Keep this cheap: only the progress bar + label. Rebuilding the whole
            # library table here (thousands of rows, 2.5×/s) starved the event loop
            # and dropped the websocket ("connection lost"). The table refreshes
            # once when the job finishes.
            #
            # This is also what delivers the result, rather than the handler that
            # started the job: that handler belongs to one particular page, and
            # the page on screen when a long job lands is frequently a different
            # one. A page the user has left must not claim the report and render
            # it into a tab that's about to be deleted — hence the socket check.
            if not client.has_socket_connection:
                return
            st = runtime.job_state
            job = st["job"]
            if job is None:                  # another tab delivered it
                runtime._safe_ui(_job_ui_end)
                return
            if st["report"]:
                snap = dict(st)
                runtime._safe_ui(lambda: _deliver(snap))
                return

            def _update():
                if not job.total:
                    return          # still partitioning — keep the spinner + message
                analyze_prog.props(remove="indeterminate")
                analyze_prog.value = job.fraction
                analyze_lbl.set_text(
                    f"{st['msg']}  ·  {job.done}/{job.total}"
                    + (f"  ·  {job.current[:50]}" if job.current else "")
                    + (f"  ·  {len(job.errors)} errors" if job.errors else ""))
            runtime._safe_ui(_update)

        def _outcome(head: str, job) -> str:
            return (head + (f", {len(job.errors)} errors" if job.errors else "")
                    + (" (cancelled)" if job.cancelled else ""))

        def _deliver(snap: dict) -> None:
            """Show what a finished job produced, then hand the slot back.

            The slot is released in a `finally`, and only while this tab is still
            there: a report that never reached a screen is worth keeping for the
            next page, but one that failed to draw on a live page has to be let
            go, or it would redraw itself every 0.4s forever.
            """
            job, kind = snap["job"], snap["kind"]
            tracks, scope = snap["tracks"], snap["scope"]
            try:
                _job_ui_end()
                if kind != "refetch_plan":      # nothing about the library changed
                    refresh()
                if kind == "analyze":
                    ui.notify(_outcome(f"Tagged {job.tagged}", job),
                              type="positive" if not job.errors else "warning")
                elif kind == "loudness":
                    ui.notify(_outcome(f"Measured {job.measured}", job),
                              type="positive" if not job.errors else "warning")
                    show_loudness_report(tracks)
                elif kind == "normalize":
                    ui.notify(_outcome(f"Normalized {job.fixed}", job),
                              type="positive" if not job.errors else "warning")
                    show_loudness_report(tracks)        # re-measured levels
                elif kind == "problems":
                    n = len(job.stitched)
                    ui.notify(
                        (f"{n} track(s) have stitched audio — re-download them"
                         if n else "No stitched audio found")
                        + (" (cancelled)" if job.cancelled else ""),
                        type="warning" if n else "positive", timeout=9000)
                    show_problems_report(job, tracks, scope)
                elif kind == "refetch_plan":
                    show_refetch_plan(job)
                elif kind == "refetch_apply":
                    msg = f"Replaced {job.replaced} of {job.total}"
                    if job.errors:
                        msg += f" — {job.errors[0][0]}: {job.errors[0][1]}"
                    ui.notify(msg + (". Re-analyze them in rekordbox (the grid is "
                                     "cached)." if job.replaced else ""),
                              type="positive" if job.replaced and not job.errors
                              else "warning", timeout=15000)
            finally:
                if client.has_socket_connection:
                    runtime.clear_job()

        # Anchored here, in the page's own column, rather than created by
        # whichever handler starts a job: NiceGUI builds an element in the
        # *sender's* parent slot, so a timer started from a dialog would belong
        # to that dialog. One per visit, switched on and off by `_job_ui_*`.
        job_timer = ui.timer(0.4, _tick, active=False)

        def show_loudness_report(tracks):
            """Median + MAD over integrated LUFS: how consistently is this playlist
            mastered, and which tracks sit off the centre? (Same robust-stats shape
            as the loudness outlier table — median/MAD resist a few wild files.)"""
            vals = [(t, t.lufs) for t in tracks if t.lufs is not None]
            if not vals:
                ui.notify("No loudness data to report", type="warning")
                return
            lufs = sorted(v for _, v in vals)
            n = len(lufs)
            median = lufs[n // 2] if n % 2 else (lufs[n // 2 - 1] + lufs[n // 2]) / 2
            devs = sorted(abs(v - median) for v in lufs)
            mad = devs[n // 2] if n % 2 else (devs[n // 2 - 1] + devs[n // 2]) / 2
            spread = 1.4826 * mad or ((lufs[-1] - lufs[0]) / 6) or 1e-6

            rows = []
            off_tracks = []
            for t, v in sorted(vals, key=lambda kv: kv[1]):
                delta = v - median
                is_off = abs(delta / spread) >= 2.5 or abs(delta) >= 2.0
                if is_off:
                    off_tracks.append(t)
                rows.append({
                    "title": t.title or (t.local_path.name if t.local_path else ""),
                    "artist": t.artist or "",
                    "lufs": f"{v:.2f}",
                    "delta": f"{delta:+.2f}",
                    "tp": (f"{t.true_peak:+.2f}" if t.true_peak is not None else "—"),
                    "lra": (f"{t.lra:.1f}" if t.lra is not None else "—"),
                    "off": is_off,
                    "clip": (t.true_peak or -99) > 0.0,
                })
            outliers = len(off_tracks)
            clipping = sum(1 for r in rows if r["clip"])

            with ui.dialog().props("full-width") as d, \
                    ui.card().style("background:#16181d; max-width:72rem; width:100%"):
                ui.label("Loudness report").classes("text-subtitle1 text-weight-bold")
                ui.label(
                    f"{n} tracks  ·  median {median:.2f} LUFS  ·  range "
                    f"{lufs[0]:.2f} → {lufs[-1]:.2f} ({lufs[-1] - lufs[0]:.2f} LU)  ·  "
                    f"{outliers} off-centre  ·  {clipping} above 0 dBTP"
                ).classes("text-caption text-grey")
                ui.label(
                    "Club masters sit around −9 to −5 LUFS; don't normalize a DJ "
                    "library to the −14 streaming target. Rows >2 LU from the median "
                    "are flagged; TP above 0 means inter-sample clipping."
                ).classes("text-caption text-grey")
                cols = [
                    {"name": "title", "label": "Title", "field": "title", "align": "left", "sortable": True},
                    {"name": "artist", "label": "Artist", "field": "artist", "align": "left", "sortable": True},
                    {"name": "lufs", "label": "LUFS", "field": "lufs", "align": "right", "sortable": True},
                    {"name": "delta", "label": "Δ median", "field": "delta", "align": "right", "sortable": True},
                    {"name": "lra", "label": "LRA", "field": "lra", "align": "right", "sortable": True},
                    {"name": "tp", "label": "dBTP", "field": "tp", "align": "right", "sortable": True},
                ]
                tbl = ui.table(columns=cols, rows=rows, row_key="title",
                               pagination=25).classes("w-full")
                tbl.add_slot("body-cell-delta", r"""
                    <q-td :props="props">
                      <q-badge :color="props.row.off ? 'warning' : 'grey-9'"
                               :text-color="props.row.off ? 'dark' : 'grey-5'">
                        {{ props.value }}</q-badge>
                    </q-td>
                """)
                tbl.add_slot("body-cell-tp", r"""
                    <q-td :props="props">
                      <span :style="{color: props.row.clip ? '#f85149' : '#9aa0a8'}">
                        {{ props.value }}</span>
                    </q-td>
                """)
                with ui.row().classes("justify-end w-full gap-2"):
                    if off_tracks:
                        ui.button(f"Normalize {len(off_tracks)} outlier(s)", icon="tune",
                                  on_click=lambda: normalize_outliers(off_tracks, median, tracks, d)) \
                            .props("unelevated color=primary") \
                            .tooltip(f"Bakes in an EBU R128 gain → {median:.1f} LUFS; "
                                     "originals backed up, then re-measured")
                    ui.button("Close", on_click=d.close).props("flat color=grey")
            d.open()

        def normalize_outliers(off_tracks, target, scope_tracks, parent):
            """Confirm, then loudness-normalize the flagged outliers toward the
            playlist median. Only these hand-picked tracks are touched — never a
            whole-playlist sweep — and each original is backed up first."""
            if not off_tracks:
                return
            with ui.dialog() as cd, ui.card().style("background:#16181d").classes("w-[42rem]"):
                ui.label(f"Normalize {len(off_tracks)} off-centre track(s)") \
                    .classes("text-subtitle1 text-weight-bold")
                ui.label(
                    f"Applies a linear gain so each track hits {target:.2f} LUFS (the "
                    "playlist median) — baked into the audio, not a tag. Each original "
                    "is backed up to .loudness_backup/ beside it, then re-encoded in "
                    "place, so this isn't instant. Afterwards, re-analyze these tracks "
                    "in rekordbox so its waveform / Auto Gain matches the new level."
                ).classes("text-caption text-grey")
                with ui.column().classes("w-full gap-0").style("max-height:16rem; overflow:auto"):
                    for t in off_tracks:
                        gain = target - t.lufs
                        nm = t.title or (t.local_path.name if t.local_path else "")
                        ui.label(f"{t.artist} — {nm}   ·   {t.lufs:.2f} → {target:.2f} LUFS "
                                 f"({gain:+.2f} dB)").classes("text-caption")

                def do_norm():
                    cd.close()
                    parent.close()
                    if runtime.job_running():
                        ui.notify("A job is already running", type="warning")
                        return
                    job = NormalizeJob(target_lufs=target)
                    msg = (f"Normalizing {len(off_tracks)} track(s) → "
                           f"{target:.1f} LUFS")
                    # The report afterwards is over the whole playlist, not just
                    # the outliers — the point is to see them back in the middle.
                    runtime.start_job(job, "normalize", msg,
                                      lambda: job.run(off_tracks),
                                      scope=state["filter_label"] or "",
                                      tracks=scope_tracks)
                    _job_ui_start("normalize", msg)
                    ui.notify(f"Normalizing {len(off_tracks)} track(s)… "
                              "this keeps running if you leave the page.")

                with ui.row().classes("justify-end w-full gap-2"):
                    ui.button("Cancel", on_click=cd.close).props("flat color=grey")
                    ui.button(f"Normalize {len(off_tracks)}", icon="tune",
                              on_click=do_norm).props("unelevated color=primary")
            cd.open()

        def show_problems_report(job, tracks, scope=""):
            """What the check found, and the only thing that fixes it.

            Stitched audio can't be repaired — the audio is already duplicated or
            missing — so this offers no "fix" button, only the evidence and the
            paths. Levels sit in the same window because they're the other thing
            that's wrong with your *files* rather than your set.

            `scope` is the playlist the check *ran* on, which isn't necessarily
            the one selected now: a check you left running is free to land after
            you've clicked somewhere else.
            """
            import integrity
            stitched = job.stitched
            other = [f for f in job.findings if f.verdict != integrity.STITCHED]
            # Same responsive width as the refetch dialog: the rows carry a
            # player now, and a fixed rem width would overflow the 1024 window.
            with ui.dialog() as d, ui.card().style(
                    "background:#16181d; width:min(80rem, 94vw); max-width:none"):
                ui.label("Check for problems").classes("text-subtitle1 text-weight-bold")
                ui.label(f"{scope or 'library'} · {job.done} file(s) checked, "
                         f"{job.probed} needed a full read"
                         + (f", {len(job.errors)} unreadable" if job.errors else "")) \
                    .classes("text-caption text-grey")

                if not job.findings:
                    with ui.row().classes("items-center gap-2 q-mt-md"):
                        ui.icon("check_circle").style("color:#3fb950")
                        ui.label("Every file plays straight through.").classes("text-caption")
                else:
                    if stitched:
                        ui.separator().props("color=grey-9").classes("q-mt-sm")
                        ui.label(f"STITCHED AUDIO — {len(stitched)}") \
                            .classes("text-caption text-weight-bold") \
                            .style("color:#f85149; letter-spacing:.08em")
                        ui.label("Built from ~5s stream segments, with a timestamp jump at "
                                 "every join. The beatgrid drifts and cannot be corrected — "
                                 "the only fix is re-downloading (Beatport quality “medium”). "
                                 "Rekordbox showing 133.xx where the tag says 133 is the "
                                 "same symptom.") \
                            .classes("text-caption text-grey")
                        _problem_rows(stitched)
                        _problem_actions(d, stitched, "stitched")
                    if other:
                        ui.separator().props("color=grey-9").classes("q-mt-sm")
                        ui.label(f"DISCONTINUOUS — {len(other)}") \
                            .classes("text-caption text-weight-bold") \
                            .style("color:#d29922; letter-spacing:.08em")
                        ui.label("Timestamp jumps, but not the regular segment pattern. "
                                 "Play them: a jump you can't hear may just be an edit "
                                 "in the track, and a big one you can hear is a damaged "
                                 "file worth re-downloading.") \
                            .classes("text-caption text-grey")
                        _problem_rows(other)
                        _problem_actions(d, other, "discontinuous")

                # Levels used to sit here too, on the theory that they're the
                # other thing wrong with your *files* rather than your set. In
                # practice it made the dialog answer a question nobody asked:
                # this one says whether the audio plays straight through, and a
                # LUFS number next to that reads as part of the verdict. Loudness
                # has its own button in the toolbar, and its report opens itself
                # when a measurement finishes.
                # Actions live under the section they act on now, not down here:
                # with two kinds of damage listed, one "Re-download" in the
                # footer couldn't say which set it meant.
                with ui.row().classes("justify-end w-full gap-2 q-mt-md"):
                    ui.button("Close", on_click=d.close).props("flat color=grey")
            d.open()

        def _problem_rows(findings) -> None:
            """One row per damaged file, each playable.

            The player isn't decoration: "discontinuous" means the audio jumps
            but not on the segment pattern, and the only way to tell a damaged
            file from a track that simply has an edit in it is to hear it. The
            section said "worth a listen" long before there was anything to
            listen with.
            """
            for f in findings[:60]:
                with ui.row().classes("items-center gap-2 no-wrap w-full q-py-xs") \
                        .style("border-bottom:1px solid #1e2127"):
                    beats = f.beats_off
                    ui.label(f"{f.worst_ms:.0f}ms").classes("text-caption") \
                        .style("font-family:monospace; width:4.5rem; text-align:right;"
                               "color:#f85149" if f.worst_ms > 100 else
                               "font-family:monospace; width:4.5rem; text-align:right;"
                               "color:#d29922")
                    ui.label(f"{beats:.2f} beats" if beats else "—") \
                        .classes("text-caption text-grey") \
                        .style("width:5rem; font-family:monospace")
                    ui.label(f.path.name).classes("flex-grow ellipsis") \
                        .style("min-width:0").tooltip(str(f.path))
                    if f.tag_bpm and f.grid_bpm:
                        ui.badge(f"{f.tag_bpm:.0f} → {f.grid_bpm:.2f}") \
                            .props("color=grey-8") \
                            .tooltip("the BPM the file claims, vs what rekordbox measured")
                    ui.label(f"{f.events} jump(s)").classes("text-caption text-grey no-wrap") \
                        .style("width:5.5rem; text-align:right")
                    with ui.element("div").style("width:220px; flex:0 0 auto"):
                        audio_player(f.path, compact=True)
            if len(findings) > 60:
                ui.label(f"… and {len(findings) - 60} more — use Copy paths for the full list.") \
                    .classes("text-caption text-grey")

        def _problem_actions(d, findings, what: str) -> None:
            """The same two moves for either kind of damage.

            Discontinuous files used to get none: the section described them,
            told you to listen, and stopped. Whatever the pattern of the jumps,
            what you can do about a file whose audio is wrong is the same —
            fetch it again, or go and look at it yourself.
            """
            with ui.row().classes("items-center gap-2 q-mt-xs q-mb-sm"):
                ui.button(f"Re-download {len(findings)}", icon="cloud_download",
                          on_click=lambda: (d.close(), plan_refetch(findings))) \
                    .props("outline dense no-caps color=primary") \
                    .tooltip("Find these on Beatport and swap clean copies in at the "
                             "same paths — you confirm each match first")
                ui.button("Copy paths", icon="content_copy",
                          on_click=lambda: (
                              ui.clipboard.write("\n".join(str(f.path) for f in findings)),
                              ui.notify(f"{len(findings)} path(s) copied"))) \
                    .props("flat dense no-caps color=grey") \
                    .tooltip(f"every {what} file's full path, for the Finder")

        def plan_refetch(findings):
            """Look each broken track up on Beatport, then show what would happen."""
            if runtime.job_running():
                ui.notify("A job is already running", type="warning")
                return
            job = RefetchJob()
            msg = f"Finding {len(findings)} on Beatport"
            runtime.start_job(job, "refetch_plan", msg,
                              lambda: job.run_plan(findings))
            _job_ui_start("refetch_plan", msg)

        def _refetch_side(heading: str, colour: str) -> None:
            ui.label(heading).classes("text-caption text-weight-bold") \
                .style(f"color:{colour}; letter-spacing:.08em; font-size:10px")

        def _refetch_card(c, boxes) -> None:
            """One local file beside the Beatport track that would replace it.

            Two sides, each labelled and each playable, because "review" is a
            question you answer with your ears: the numbers can only say the
            name scores 100 and the length is off by 2.7s, and that describes
            both an extended mix (wrong) and a stitched file missing a few
            seconds of audio (right). Thirty seconds of each settles it.

            The local title comes off the file's *tags*, not its filename — a
            store download is called "01. Landmine Feat. Blak Trash.m4a", which
            drops the artist and is the one thing there is to compare.
            """
            import refetch
            ok = c.verdict == refetch.CONFIDENT
            # "different edit" is red, not amber: amber is "you decide", and this
            # one is not on offer. See `Candidate.replaceable`.
            badge_colour = {refetch.CONFIDENT: "positive",
                            refetch.DIFFERENT_EDIT: "negative"}.get(c.verdict, "warning")
            with ui.card().classes("w-full surface q-pa-sm q-mb-xs").props("flat"):
                with ui.row().classes("items-center gap-2 no-wrap w-full"):
                    cb = ui.checkbox(value=ok).props("dense")
                    cb.set_enabled(c.replaceable)
                    boxes[c.path] = cb
                    ui.badge("match" if ok else c.verdict).props(f"color={badge_colour}")
                    ui.label(c.local_display).classes("flex-grow ellipsis text-weight-medium") \
                        .style("min-width:0").tooltip(str(c.path))
                    ui.label(f"{c.worst_ms:.0f}ms jump").classes("text-caption text-grey no-wrap") \
                        .tooltip("the worst timestamp discontinuity found in this file")
                if c.reason:
                    ui.label(f"Needs a listen — {c.reason}.") \
                        .classes("text-caption").style("color:#d29922")
                with ui.row().classes("items-start gap-4 no-wrap w-full q-mt-xs"):
                    with ui.column().classes("gap-1").style("width:50%; min-width:0"):
                        _refetch_side("YOUR FILE · STITCHED", "#f85149")
                        ui.label(c.path.name).classes("text-caption text-grey ellipsis") \
                            .style("min-width:0").tooltip(str(c.path))
                        ui.label(_fmt_len(c.local_s)).classes("text-caption text-grey") \
                            .style("font-family:monospace")
                        audio_player(c.path, compact=True)
                    with ui.column().classes("gap-1").style("width:50%; min-width:0"):
                        _refetch_side("BEATPORT · REPLACEMENT", "#3fb950")
                        if not c.beatport_id:
                            ui.label("No match — this one can't be re-downloaded here.") \
                                .classes("text-caption text-grey")
                            return
                        ui.label(c.display).classes("text-caption ellipsis") \
                            .style("min-width:0")
                        ui.label(f"{_fmt_len(c.beatport_s)}  ({c.delta_s:+.1f}s)"
                                 + (f"  ·  {c.bpm} BPM" if c.bpm else "")
                                 + f"  ·  name {c.score:.0f}/100") \
                            .classes("text-caption text-grey").style("font-family:monospace")
                        if c.sample_url:
                            widgets.preview_player(c.sample_url)
                            # The transport's clock is the *clip's* length, and
                            # next to a full-length player on the other side that
                            # reads as the track being the wrong length. Say which
                            # is which rather than making the numbers agree.
                            ui.label(f"preview clip — the full track is "
                                     f"{_fmt_len(c.beatport_s)}") \
                                .classes("text-caption text-grey") \
                                .style("font-size:10px; line-height:1")
                        else:
                            ui.label("no clip for this one").classes("text-caption text-grey")

        def show_refetch_plan(job):
            """The matches, each with a tick — nothing is replaced unconfirmed.

            Confident matches start ticked; anything the search was unsure about
            starts unticked and says why. The asymmetry is the point: a wrong
            replacement puts a different record under a track rekordbox still
            recognises, and nothing downstream would ever flag it.
            """
            import refetch
            n_conf, n_all = len(job.confident), len(job.candidates)
            n_none = sum(1 for c in job.candidates if c.beatport_id is None)
            n_edit = sum(1 for c in job.candidates
                         if c.verdict == refetch.DIFFERENT_EDIT)
            # Widest dialog in the app, and sized against the viewport rather
            # than in rem: two playable columns side by side need the room, but
            # the window shrinks to 1024 (`window.py`), where a fixed 62rem
            # would already be wider than the space it has.
            with ui.dialog() as d, ui.card().style(
                    "background:#16181d; width:min(80rem, 94vw); max-width:none"):
                ui.label("Re-download and replace").classes("text-subtitle1 text-weight-bold")
                ui.label(f"{n_conf} of {n_all} matched confidently"
                         + (f" · {n_none} not on Beatport" if n_none else "")
                         + (f" · {n_edit} only there as a different edit" if n_edit else "")
                         + ". Each file is backed up beside itself, replaced at the same "
                         "path so rekordbox keeps the track, then checked — and rolled "
                         "back if the new copy isn't actually clean.") \
                    .classes("text-caption text-grey")
                # Nothing auto-ticked is the normal case, not a failure — say so
                # here rather than leaving a dialog that looks like it did nothing.
                if not n_conf and n_all:
                    ui.label("Nothing is ticked, so nothing will be replaced until you "
                             "tick it. Play both sides of a row to decide.") \
                        .classes("text-caption").style("color:#d29922")
                if job.errors:
                    ui.label(f"{len(job.errors)} lookup error(s)").classes("text-caption") \
                        .style("color:#d29922")

                boxes = {}
                # Scrolled, not grown: a checked playlist can be thirty of these
                # and the action buttons have to stay reachable.
                with ui.column().classes("w-full gap-0 q-mt-sm") \
                        .style("max-height:58vh; overflow-y:auto"):
                    for c in job.candidates:
                        _refetch_card(c, boxes)

                with ui.row().classes("justify-end w-full gap-2 q-mt-md"):
                    ui.button("Cancel", on_click=d.close).props("flat color=grey")
                    def _go_apply():
                        chosen = [c for c in job.candidates
                                  if boxes[c.path].value and c.replaceable]
                        d.close()
                        apply_refetch(chosen)
                    ui.button("Download and replace", icon="cloud_download",
                              on_click=_go_apply) \
                        .props("unelevated no-caps color=primary")
            d.open()

        def apply_refetch(candidates):
            if not candidates:
                ui.notify("Nothing ticked", type="warning")
                return
            if runtime.job_running():
                ui.notify("A job is already running", type="warning")
                return
            job = RefetchJob()
            # A fresh folder per run, and a hidden one. Sharing the "Beatport"
            # batch folder meant beatportdl found the track already sitting
            # there from an earlier attempt and skipped it — and a skipped
            # download lands no new file, so the pairing had nothing to find
            # and said "no download matched this track" about a track that had
            # downloaded perfectly well the first time. An empty folder can't
            # be skipped. The dot keeps these out of the Incoming lane
            # (`scan_download_batches` ignores dotfolders): they're scratch for
            # a swap, not tracks you're deciding about.
            dest = (runtime._dl_root() / ".refetch"
                    / time.strftime("%Y%m%d-%H%M%S"))
            msg = f"Re-downloading {len(candidates)}"
            runtime.start_job(job, "refetch_apply", msg,
                              lambda: job.run_apply(candidates, dest))
            _job_ui_start("refetch_apply", msg)
            ui.notify(f"Re-downloading {len(candidates)} track(s)… "
                      "this keeps running if you leave the page.")

        def check_problems():
            if runtime.job_running():
                ui.notify("A job is already running", type="warning")
                return
            tracks = [t for t in _scope_tracks() if t.local_path]
            if not tracks:
                ui.notify("No local files in scope to check", type="warning")
                return
            job = IntegrityJob()
            scope = state["filter_label"] or "whole library"
            msg = f"Checking audio · {scope}"
            runtime.start_job(job, "problems", msg, lambda: job.run(tracks),
                              scope=scope, tracks=tracks)
            _job_ui_start("problems", msg)
            ui.notify(f"Checking {len(tracks)} track(s) in {scope}… this keeps "
                      "running if you leave the page — the report is waiting "
                      "for you when you come back.", timeout=9000)

        def measure_loudness():
            if runtime.job_running():
                ui.notify("A job is already running", type="warning")
                return
            tracks = [t for t in _scope_tracks() if t.local_path]
            if not tracks:
                ui.notify("No local files in scope to measure", type="warning")
                return
            job = LoudnessJob(force=force_cb.value)
            scope = state["filter_label"] or "whole library"
            msg = f"Measuring loudness · {scope}"
            runtime.start_job(job, "loudness", msg, lambda: job.run(tracks),
                              scope=scope, tracks=tracks)
            _job_ui_start("loudness", msg)
            ui.notify(f"Measuring loudness for {len(tracks)} tracks in {scope}… "
                      "this keeps running if you leave the page.")

        def analyze():
            if runtime.job_running():
                ui.notify("Analysis already running", type="warning")
                return
            tracks = [t for t in _scope_tracks() if t.local_path]
            if not tracks:
                ui.notify("No local files in scope to analyze", type="warning")
                return
            job = AnalysisJob(force=force_cb.value, rich=rich_cb.value)
            scope = state["filter_label"] or "whole library"
            msg = f"Analyzing energy · {scope}"
            runtime.start_job(job, "analyze", msg, lambda: job.run(tracks),
                              scope=scope, tracks=tracks)
            _job_ui_start("analyze", msg)
            ui.notify(f"Analyzing {len(tracks)} tracks in {scope}… this keeps "
                      "running if you leave the page.")

        def do_cancel():
            job = runtime.job_state["job"]
            if job:
                job.cancel()
                ui.notify("Cancelling after current track…")

        def build_tree():
            tree_holder.clear()
            nodes = runtime.library.playlist_tree_nodes()
            if not nodes:
                return
            with tree_holder:
                tree = ui.tree(nodes, label_key="label", node_key="id",
                               on_select=lambda e: select_node(e.value)).classes("w-full")
                tree.props("dense no-connectors")
                state["tree"] = tree

        def reveal_in_tree(node_id: str) -> None:
            """Expand the node's ancestors and highlight it, so a deep-linked
            playlist is actually visible in the tree rather than buried in a
            collapsed folder."""
            tree = state.get("tree")
            if not tree:
                return
            chain, cur = [], runtime.library.rekordbox_index.get(node_id)
            while cur is not None and cur.parent_id:
                cur = runtime.library.rekordbox_index.get(cur.parent_id)
                if cur is None:
                    break
                chain.append(cur.id)
            if chain:
                tree.expand(chain)
            tree.select(node_id)

        def add_folder(folder: str):
            """Additively load an extra folder (staging / non-rekordbox tracks)."""
            if not folder:
                return
            p = Path(folder).expanduser()
            if not p.is_dir():
                ui.notify(f"Not a folder: {p}", type="negative")
                return
            n = runtime.library.add_folder(p)
            save_studio_state(p, bool(runtime.library.rekordbox_index))
            refresh()
            ui.notify(f"Added {n} tracks from {p.name}", type="positive")

        def folder_dialog():
            with ui.dialog() as d, ui.card().style("background:#16181d"):
                ui.label("Add an extra folder").classes("text-subtitle1 text-weight-bold")
                ui.label("Audio files not in rekordbox (e.g. a download folder). "
                         "Added on top of the current library.").classes("text-caption text-grey")
                inp = ui.input("Folder path", placeholder="/path/to/tracks") \
                    .props("outlined dense").classes("w-96")
                if runtime.library.folder:
                    inp.value = str(runtime.library.folder)
                with ui.row().classes("justify-end w-full gap-2"):
                    ui.button("Cancel", on_click=d.close).props("flat color=grey")
                    ui.button("Add", on_click=lambda: (add_folder(inp.value), d.close())) \
                        .props("unelevated color=primary")
            d.open()

        def load_rekordbox():
            try:
                col = rekordbox.from_live()
            except Exception as e:
                ui.notify(f"Couldn't read rekordbox DB: {e}", type="negative", timeout=8000)
                return
            stats = runtime.library.merge_rekordbox(col, snapshot=RekordboxSnapshot())
            save_studio_state(runtime.library.folder, True)
            build_tree()
            runtime.refresh_batches()      # imported tracks now count as "in"
            # Every source's gap was computed against the collection that just
            # changed, so its "have it / missing" answers are stale. Dropping
            # them makes Incoming re-pull rather than show yesterday's answer.
            runtime.source_rows.clear()
            refresh()
            ui.notify(
                f"Rekordbox: {stats['matched']} matched, {stats['added']} added"
                + (f", {stats['removed']} removed" if stats['removed'] else ""),
                type="positive",
            )

        # --- render already-loaded state (restored by _bootstrap at startup) ---
        if runtime.library.rekordbox_roots:
            build_tree()
        runtime.refresh_batches()
        if runtime.library.tracks:
            refresh()
        # …and re-join a job still running from an earlier visit, or pick up the
        # report of one that finished while this page didn't exist.
        _attach_job()

        # --- deep link: /?node=<id> (Incoming's "Show in Library") ---
        if node:
            if node in runtime.library.rekordbox_index:
                select_node(node)
                reveal_in_tree(node)
            else:
                ui.notify("That playlist isn't in the loaded rekordbox library — "
                          "try Reload rekordbox.", type="warning")
