"""Sync page (`/sync`) — pull a Spotify source, diff it against rekordbox + local
files, resolve & download the gap via Beatport, toggle per-track set membership,
and export the reconciled playlist to the rekordbox XML."""
from __future__ import annotations

import time
from pathlib import Path
from urllib.parse import quote

from nicegui import run, ui

import bpdl
import rekordbox_io
import runtime
from export_ui import export_handoff
from sources import SourceStore, SyncedSource
from sync import compute_sync, summarize
from widgets import player_vue

from shell import apply_theme, header, settings_dialog


SYNC_COLUMNS = [
    {"name": "title", "label": "Title", "field": "title", "align": "left", "sortable": True},
    {"name": "artist", "label": "Artist", "field": "artist", "align": "left", "sortable": True},
    {"name": "pipeline", "label": "Pipeline", "field": "pipeline", "align": "center", "sortable": True},
    {"name": "set", "label": "Set", "field": "set", "align": "center", "sortable": True},
    {"name": "preview", "label": "Preview", "field": "audio", "align": "left"},
    {"name": "match", "label": "rekordbox match", "field": "match", "align": "left", "sortable": True},
]


@ui.page("/sync")
def sync_page():
    apply_theme()
    header("Sync")
    store = SourceStore()
    # `previewing`: row indices with a Beatport lookup in flight, so the button
    # can spin. Transient UI state, unlike `preview_url`, which lives on the row.
    state = {"source": None, "rows": [], "filter": "all", "set_override": {},
             "previewing": set()}

    # --- left drawer: bound sources ---
    with ui.left_drawer(value=True, bordered=True).props("width=300").style(
            "background:#121419; border-right:1px solid #23262d"):
        with ui.row().classes("items-center justify-between w-full"):
            ui.label("SYNC SOURCES").classes("text-caption text-weight-bold") \
                .style("color:#6b7280; letter-spacing:.08em")
            ui.button(icon="add", on_click=lambda: add_source_dialog()) \
                .props("flat dense round color=primary")
        sources_holder = ui.column().classes("w-full gap-1")

    with ui.column().classes("w-full p-4 gap-4"):
        title_lbl = ui.label("Select or add a Spotify source").classes("text-h6")
        summary_lbl = ui.label("").classes("text-caption text-grey")
        with ui.row().classes("items-center gap-2 w-full"):
            for key, lbl in (("all", "All"), ("missing", "Missing"),
                             ("to_add", "Not in set"), ("only_rb", "Not in Spotify"),
                             ("review", "Review")):
                ui.button(lbl, on_click=lambda k=key: set_filter(k)) \
                    .props("flat dense no-caps color=primary")
            ui.space()
            library_btn = ui.button("Show in Library", icon="library_music",
                                    on_click=lambda: go_to_library()) \
                .props("flat dense no-caps color=primary") \
                .tooltip("Open this source's paired rekordbox playlist in the "
                         "Library view (analyze, loudness, build a set)")
            library_btn.set_visibility(False)
            relink_btn = ui.button("Re-link rb", icon="link",
                                   on_click=lambda: relink_dialog()) \
                .props("flat dense no-caps color=grey") \
                .tooltip("Re-point this source at a rekordbox playlist "
                         "(use if the pairing went stale after a rename/re-import)")
            relink_btn.set_visibility(False)
            export_btn = ui.button("Export to rekordbox", icon="ios_share",
                                   on_click=lambda: export_to_rekordbox()) \
                .props("outline color=primary")
            export_btn.set_visibility(False)
            dl_btn = ui.button("Resolve & download missing", icon="cloud_download",
                               on_click=lambda: resolve_download()).props("unelevated color=primary")
            dl_btn.set_visibility(False)
        # where Beatport downloads land (root + per-playlist subfolder) + config
        with ui.row().classes("items-center gap-2 w-full"):
            ui.icon("download").classes("text-grey")
            dl_dest_lbl = ui.label("").classes("text-caption text-grey")
            ui.button(icon="settings", on_click=lambda: settings_dialog()) \
                .props("flat dense round size=sm color=grey") \
                .tooltip("Settings (download root, inbox folder)")
        table = ui.table(columns=SYNC_COLUMNS, rows=[], row_key="id",
                         pagination=50).classes("w-full")
        table.add_slot("body-cell-pipeline", r"""
            <q-td :props="props">
              <q-badge :color="{in_rekordbox:'positive',downloaded:'info',missing:'negative'}[props.value]"
                       :text-color="props.value==='downloaded' ? 'dark' : 'white'">
                {{ props.value === 'in_rekordbox' ? 'in rekordbox' : props.value }}
              </q-badge>
            </q-td>
        """)
        # Mark rows that live in the rekordbox set but not the Spotify source.
        table.add_slot("body-cell-title", r"""
            <q-td :props="props">
              {{ props.value }}
              <q-badge v-if="props.row.only_rb" color="deep-orange-10"
                       text-color="orange-3" class="q-ml-sm">not in Spotify</q-badge>
            </q-td>
        """)
        # The Set chip is the per-track export decision: click to flip a track
        # in/out of the exported set (downloads default in, removals default out).
        table.add_slot("body-cell-set", r"""
            <q-td :props="props">
              <q-badge v-if="props.value !== 'n_a'"
                       :color="{in:'secondary',out:'grey-9'}[props.value]"
                       :text-color="props.value==='in' ? 'dark' : 'grey-5'"
                       class="cursor-pointer"
                       @click="() => $parent.$emit('toggle_set', props.row.id)">
                {{ props.value === 'in' ? 'in set' : 'not in set' }}
                <q-icon name="swap_horiz" size="13px" class="q-ml-xs" />
              </q-badge>
              <span v-else style="color:#555">—</span>
            </q-td>
        """)
        # Seekable preview per row (review fuzzy matches by ear) — the same
        # transport the Library and Build pages use, fixed to the column width
        # so the scrub bar doesn't stretch with the title beside it.
        #
        # A row with no file of its own gets a button instead: the tracks you
        # are about to *buy* are exactly the ones you most want to hear first,
        # and they are the only rows the old preview column had nothing for.
        # One click resolves that single track on Beatport and fills the same
        # transport with the store's clip.
        table.add_slot("body-cell-preview", f"""
            <q-td :props="props">
              <div v-if="props.row.audio" style="width:240px">
                {player_vue("props.row.audio")}
              </div>
              <q-btn v-else-if="props.row.can_preview"
                     dense flat no-caps size="sm" color="primary"
                     icon="play_circle_outline" label="preview"
                     :loading="props.row.previewing"
                     @click="() => $parent.$emit('preview_row', props.row.id)" />
              <span v-else style="color:#555">—</span>
            </q-td>
        """)

        def _toggle_set(e):
            i = int(e.args)
            if i >= len(state["rows"]) or state["rows"][i].in_set == "n_a":
                return
            state["set_override"][i] = not _is_in_set(i, state["rows"][i])
            render()
        table.on("toggle_set", _toggle_set)

        async def _preview_row(e):
            """Resolve one row on Beatport and hand its clip to the transport.

            Deliberately one track at a time: `resolve` is a catalog search per
            track, and a missing playlist is fifty of them — a cost worth paying
            for the row you're curious about and not for the other forty-nine.
            The result is remembered on the row either way, so a track Beatport
            doesn't carry stops offering the button rather than asking again.
            """
            i = int(e.args)
            rows = state["rows"]
            if i >= len(rows):
                return
            r = rows[i]
            if not r.spotify or r.preview_url or r.preview_checked:
                return
            state["previewing"].add(i)
            render()
            try:
                res = await run.io_bound(lambda: bpdl.resolve([r.spotify]))
                bt = res[0].beatport if res else None
                r.preview_url = bt.sample_url if bt else None
                r.preview_checked = True
            except Exception as err:            # noqa: BLE001
                # Not `preview_checked` — a network blip should leave the button
                # there to try again, unlike "Beatport hasn't got it".
                ui.notify(f"Couldn't reach Beatport: {err}", type="negative")
            finally:
                state["previewing"].discard(i)
                render()
            if r.preview_checked and not r.preview_url:
                ui.notify(f"No Beatport clip for “{r.spotify.name}”", type="info")
        table.on("preview_row", _preview_row)

    def _default_in_set(r) -> bool:
        """Whether a row belongs in the exported set by default.
        Downloads are added; tracks pulled out of the rekordbox set are left out."""
        if r.in_set == "in":
            return True
        if r.pipeline == "downloaded":
            return True                 # freshly downloaded → add to the set
        if r.needs_add_to_set:
            return False                # in rekordbox but removed from set → leave out
        return True

    def _is_in_set(i, r) -> bool:
        """Per-track export decision, honouring any manual toggle."""
        return state["set_override"].get(i, _default_in_set(r))

    def sync_rows():
        out = []
        for i, r in enumerate(state["rows"]):
            if state["filter"] == "missing" and not r.needs_source:
                continue
            if state["filter"] == "to_add" and not r.needs_add_to_set:
                continue
            if state["filter"] == "review" and r.collection != "review":
                continue
            if state["filter"] == "only_rb" and r.in_spotify:
                continue
            m = r.collection_match
            sp = r.spotify
            p = _row_path(r)
            out.append({
                "id": i,
                "title": sp.name if sp else (m.title if m else ""),
                "artist": (", ".join(sp.artists) if sp else (m.artist if m else "")),
                "pipeline": r.pipeline,
                "set": ("n_a" if r.in_set == "n_a"
                        else ("in" if _is_in_set(i, r) else "out")),
                "only_rb": not r.in_spotify,
                # A local file if we have one, else whatever Beatport clip has
                # been fetched for this row — the transport can't tell them
                # apart, and shouldn't.
                "audio": (f"/media?path={quote(str(p))}" if p
                          else (r.preview_url or "")),
                "can_preview": bool(not p and not r.preview_url
                                    and not r.preview_checked and r.spotify),
                "previewing": i in state["previewing"],
                "match": (f"{m.artist} - {m.title}  ({r.collection_score:.0f})" if m else ""),
            })
        return out

    def _dl_dest() -> Path:
        """Where this source's downloads land: <root>/<playlist-subfolder>, named
        after the *paired rekordbox* playlist (see `SyncedSource.rb_name`)."""
        root = runtime._dl_root()
        s = state["source"]
        return root / s.rb_name.replace("/", "-") if s else root

    def update_dl_dest() -> None:
        if state["source"]:
            dl_dest_lbl.set_text(f"Downloads → {_dl_dest()}")
        else:
            dl_dest_lbl.set_text(f"Download root → {runtime._dl_root()}")

    def render():
        table.rows = sync_rows()
        table.update()
        update_dl_dest()
        s = state["source"]
        if not s:
            return
        stale = bool(s.paired_rb_id) and s.paired_rb_id not in runtime.library.rekordbox_index
        pair_txt = (f"   ↔ rb: {s.paired_rb_name}" if s.paired_rb_name else "   (no paired set)")
        if stale:
            pair_txt = f"   ⚠ rb: {s.paired_rb_name} (not found — Re-link rb)"
        title_lbl.set_text(f"♫ {s.last_name}{pair_txt}")
        summ = summarize(state["rows"])
        summary_lbl.set_text(
            f"{summ['total']} tracks  ·  {summ['have']} in rekordbox  ·  {summ['review']} review  "
            f"·  {summ['downloaded']} downloaded  ·  {summ['missing']} missing  ·  {summ['to_add']} not in set"
            + (f"  ·  {summ['only_rb']} not in Spotify" if summ["only_rb"] else "")
        )
        dl_btn.set_visibility(summ["missing"] > 0)
        has_local = any(_row_path(r) for r in state["rows"])
        export_btn.set_visibility(has_local)
        relink_btn.set_visibility(True)   # available whenever a source is open
        relink_btn.props(f"color={'negative' if stale else 'grey'}")
        # Only meaningful once the source resolves to a real rekordbox playlist.
        library_btn.set_visibility(bool(s.paired_rb_id) and not stale)

    def _row_path(r):
        """The local file backing this row: rekordbox match or freshly downloaded."""
        if r.collection_match and r.collection_match.local_path:
            return r.collection_match.local_path
        if r.local_match and r.local_match.local_path:
            return r.local_match.local_path
        return None

    def _row_track(r):
        if r.collection_match and r.collection_match.local_path:
            return r.collection_match
        return r.local_match

    def set_filter(k):
        state["filter"] = k
        render()

    def go_to_library():
        """Jump to the Library view with this source's paired rekordbox playlist
        already selected — the hand-off from "synced" to "analyze / loudness"."""
        s = state["source"]
        if not s or not s.paired_rb_id:
            ui.notify("This source has no paired rekordbox playlist — use “Re-link rb”",
                      type="warning")
            return
        if s.paired_rb_id not in runtime.library.rekordbox_index:
            ui.notify(f"Paired playlist “{s.paired_rb_name}” isn't in the loaded "
                      "rekordbox library — reload it in Library first.", type="warning")
            return
        ui.navigate.to(f"/?node={quote(str(s.paired_rb_id))}")

    def export_to_rekordbox():
        s = state["source"]
        if not s:
            return
        # Decide membership first, then order: keep the rekordbox playlist's own
        # order for set tracks (so tracks dropped from Spotify keep their spot),
        # and append new/re-added tracks at the end in Spotify order.
        kept = []          # (row_index, row)
        skipped_removed = 0
        for i, r in enumerate(state["rows"]):
            if not _row_path(r):
                continue
            if r.in_set != "n_a" and not _is_in_set(i, r):
                skipped_removed += 1
                continue
            kept.append((i, r))

        # The leaf playlist's track_ids preserve rekordbox's own ordering.
        node = runtime.library.rekordbox_index.get(s.paired_rb_id) if s.paired_rb_id else None
        rb_pos = {tid: k for k, tid in enumerate(node.track_ids)} if node else {}

        def _order(item):
            i, r = item
            sm = r.set_match
            if sm is not None and sm.rekordbox_id in rb_pos:
                return (0, rb_pos[sm.rekordbox_id])   # in the set → keep rb order
            return (1, i)                             # new / re-added → after, Spotify order
        kept.sort(key=_order)

        items = []
        for i, r in kept:
            t = _row_track(r)
            sp = r.spotify
            items.append({
                "name": (t.title if t else "") or (sp.name if sp else ""),
                "artist": (t.artist if t else "")
                          or (", ".join(sp.artists) if sp else ""),
                "location": Path(_row_path(r)),
                "bpm": t.bpm if t else None,
                "key": t.key if t else None,
                "genre": (t.style if t else "") or "",
            })
        if not items:
            ui.notify("No tracks with local files to export yet", type="warning")
            return
        out = str(runtime.export_path())
        n_written = rekordbox_io.export_playlist(out, s.rb_name, items)
        export_handoff(
            out, f"{n_written} tracks · playlist “{s.rb_name}”", f"“{s.rb_name}”",
            note=(f"Left out {skipped_removed} track(s) marked “not in set” — "
                  "click their Set chip to include them."
                  if skipped_removed else ""),
            re_export=export_to_rekordbox,
            # Re-open the source after the reload: compute_sync now sees the
            # imported playlist, _auto_pair binds to it, and "in set" lights up.
            on_reloaded=lambda: open_source(s))

    async def resolve_download():
        rows = [r for r in state["rows"] if r.needs_source]
        if not rows:
            ui.notify("Nothing missing to download", type="info")
            return
        sp_tracks = [r.spotify for r in rows]

        def _recompute():
            state["rows"] = compute_sync(
                [row.spotify for row in state["rows"]],
                runtime.library, paired_rb_id=state["source"].paired_rb_id)
            render()

        # Live progress for both phases. The worker (inside run.io_bound) only
        # writes plain fields into `prog`; this timer, on the main loop, renders
        # them into the notification — the same thread-safe split the analysis job
        # uses. The download binary is opaque until it exits, so we gauge its
        # progress by counting audio files as they land in `dest`.
        prog = {"phase": "resolve", "done": 0, "total": len(sp_tracks),
                "found": 0, "current": "", "dest": None, "start": 0.0}
        n = ui.notification("① Resolving on Beatport…", spinner=True, timeout=None)

        def _render_prog():
            if prog["phase"] == "download" and prog["dest"]:
                files = [p for p in Path(prog["dest"]).rglob("*")
                         if p.suffix.lower() in bpdl.AUDIO_EXTS
                         and p.stat().st_mtime >= prog["start"] - 2]
                prog["done"] = len(files)
                if files:
                    prog["current"] = max(files, key=lambda p: p.stat().st_mtime).stem
            cur = f"  ·  {prog['current'][:46]}" if prog["current"] else ""
            if prog["phase"] == "resolve":
                n.message = (f"① Resolving on Beatport  {prog['done']}/{prog['total']}"
                             f"  ·  {prog['found']} matched{cur}")
            else:
                n.message = (f"② Downloading from Beatport  "
                             f"{prog['done']}/{prog['total']}{cur}")
        timer = ui.timer(0.3, _render_prog)

        def _on_resolve(done, total, found, label):
            prog.update(done=done, total=total, found=found, current=label)

        # ── ① Resolve on Beatport ────────────────────────────────────────────
        try:
            resolutions = await run.io_bound(
                lambda: bpdl.resolve(sp_tracks, progress=_on_resolve))
        except Exception as e:
            timer.deactivate()
            n.dismiss()
            ui.notify(f"Beatport error: {e}", type="negative", timeout=8000)
            return
        high = [r for r in resolutions if r.hit and r.confidence == "high"]
        review = [r for r in resolutions if r.hit and r.confidence != "high"]
        none = [r for r in resolutions if not r.hit]
        if not high:
            timer.deactivate()
            n.dismiss()
            ui.notify(f"No high-confidence Beatport matches "
                      f"({len(review)} need review, {len(none)} not found)", type="warning")
            return

        # ── ② Download via beatportdl ────────────────────────────────────────
        ids = [r.beatport.id for r in high]
        # Organize downloads by playlist (first download); rekordbox dedupes by
        # path on import, and resolve() only targets tracks missing from rekordbox.
        dest = _dl_dest()
        dest.mkdir(parents=True, exist_ok=True)
        prog.update(phase="download", done=0, total=len(high), current="",
                    dest=str(dest), start=time.time())
        try:
            new_files, _log = await run.io_bound(bpdl.download, ids, dest)
        except Exception as e:
            timer.deactivate()
            n.dismiss()
            ui.notify(f"Download error: {e}", type="negative", timeout=8000)
            return
        timer.deactivate()
        from library import track_from_file
        new_tracks = [track_from_file(p) for p in new_files]
        runtime.library.tracks.extend(new_tracks)
        runtime.refresh_batches()   # files on disk now → Library's Incoming lane sees them

        # Same check the Download page runs: a file whose audio isn't continuous
        # should be caught as it lands, not on the night you play it.
        try:
            import integrity
            bad = integrity.verify_downloads(new_files)
        except Exception as e:      # never fatal — a false alarm must not cost a download
            print(f"[sync] integrity check failed: {e!r}")
            bad = []
        if bad:
            ui.notify(f"⚠ {len(bad)} of {len(new_files)} downloaded file(s) have "
                      f"discontinuous audio — \u201c{bad[0].path.name}\u201d: "
                      f"{bad[0].summary}. Check Library \u2192 Check for problems.",
                      type="warning", timeout=20000)

        # Energy/vibe analysis is a Library concern, not a sync step: the new
        # files surface under Library → Downloads, where "Analyze energy" tags
        # them. Sync stops at "downloaded".
        def _finish():
            _recompute()    # files now present → rows flip to "downloaded"
            n.dismiss()
            ui.notify(
                f"Downloaded {len(new_files)} → {dest}. Analyze them under "
                f"Library → Downloads, then “Export to rekordbox”."
                + (f"  ({len(review)} need review, {len(none)} not found)"
                   if (review or none) else ""),
                type="positive", timeout=12000)
        runtime._safe_ui(_finish)

    def open_source(s: SyncedSource):
        if not any(t.in_rekordbox for t in runtime.library.tracks):
            ui.notify("Load rekordbox first (Library tab)", type="warning")
            return
        # Always work from the persisted source. The sidebar buttons close over
        # the objects `render_sources()` captured when the page was built, so a
        # pairing made since then lives only on disk — opening the stale object
        # would drop it and let `_auto_pair` re-bind by the Spotify name.
        s = store.get(s.spotify_playlist_id) or s
        runtime.refresh_batches()   # pick up already-downloaded files → gap shows "downloaded"
        n = ui.notification(f"Pulling “{s.last_name}” from Spotify…", spinner=True, timeout=None)
        try:
            tracks = runtime._sp().playlist_tracks(s.spotify_playlist_id)
        except Exception as e:
            n.dismiss()
            ui.notify(f"Spotify error: {e}", type="negative", timeout=8000)
            return
        s = _auto_pair(s)
        state["source"] = s
        state["rows"] = compute_sync(tracks, runtime.library, paired_rb_id=s.paired_rb_id)
        state["filter"] = "all"
        state["set_override"] = {}   # per-track decisions are source-specific
        state["previewing"] = set()  # indices into the rows we just replaced
        n.dismiss()
        render()

    def _auto_pair(s: SyncedSource) -> SyncedSource:
        """Bind to a rekordbox playlist whose name matches the source (so importing
        the exported XML + reloading rekordbox lights up 'in set'). Also self-heals
        a *stale* pairing whose id no longer exists (e.g. after a re-import), as
        long as a playlist still matches the name."""
        if s.paired_rb_id and s.paired_rb_id in runtime.library.rekordbox_index:
            return s   # pairing still resolves — leave it
        # Heal by the *paired* playlist's name when we have one: matching on the
        # Spotify name would rebind to the wrong playlist whenever the pairing
        # was to a differently-named set (typically the Spotify-named playlist a
        # previous export created).
        target = s.rb_name.strip().lower()
        # Match a playlist OR a folder by name — the flat build export names the
        # set *folder* after the source, and a folder exposes all its tracks. Prefer a
        # real playlist when both share the name.
        matches = [(nid, node) for nid, node in runtime.library.rekordbox_index.items()
                   if node.name.strip().lower() == target]
        matches.sort(key=lambda kv: kv[1].is_folder)   # playlists (False) before folders
        if matches:
            nid, node = matches[0]
            s.paired_rb_id, s.paired_rb_name = nid, node.name
            store.upsert(s)
            kind = "folder" if node.is_folder else "playlist"
            ui.notify(f"Auto-paired to rekordbox {kind} “{node.name}”", type="info")
        return s

    def relink_dialog():
        """Re-point the current source at a rekordbox playlist (fixes a pairing
        gone stale after a re-import or rename)."""
        s = state["source"]
        if not s:
            return
        with ui.dialog() as d, ui.card().classes("w-96").style("background:#16181d"):
            ui.label("Re-link rekordbox playlist").classes("text-subtitle1 text-weight-bold")
            ui.label(f"Source: {s.last_name}").classes("text-caption text-grey")
            rb_opts = {None: "— none —"}
            for nid, node in runtime.library.rekordbox_index.items():
                rb_opts[nid] = f"📁 {node.name}  (set folder)" if node.is_folder else node.name
            cur = s.paired_rb_id if s.paired_rb_id in rb_opts else None
            sel = ui.select(rb_opts, label="rekordbox playlist", value=cur,
                            with_input=True).props("outlined dense").classes("w-full")

            def confirm():
                s.paired_rb_id = sel.value
                s.paired_rb_name = (runtime.library.rekordbox_index[sel.value].name
                                    if sel.value else None)   # clean name, not the label
                store.upsert(s)
                d.close()
                render_sources()   # drop the sidebar's pre-relink snapshots
                open_source(s)     # re-pull + recompute against the new pairing
            with ui.row().classes("justify-end w-full gap-2"):
                ui.button("Cancel", on_click=d.close).props("flat color=grey")
                ui.button("Re-link", on_click=confirm).props("unelevated color=primary")
        d.open()

    def render_sources():
        sources_holder.clear()
        with sources_holder:
            srcs = store.list()
            if not srcs:
                ui.label("No sources yet — click +").classes("text-caption text-grey")
            for s in srcs:
                active = state["source"] and state["source"].spotify_playlist_id == s.spotify_playlist_id
                with ui.row().classes("items-center w-full no-wrap"):
                    ui.button(s.last_name, on_click=lambda s=s: open_source(s)) \
                        .props("flat dense no-caps align=left"
                               + (" color=primary" if active else " color=white")) \
                        .classes("flex-grow")
                    ui.button(icon="close", on_click=lambda s=s: remove_source(s)) \
                        .props("flat dense round size=sm color=grey")

    def remove_source(s: SyncedSource):
        store.remove(s.spotify_playlist_id)
        if state["source"] and state["source"].spotify_playlist_id == s.spotify_playlist_id:
            state["source"] = None
            state["rows"] = []
            render()
        render_sources()

    async def add_source_dialog():
        with ui.dialog() as dialog, ui.card().classes("w-96").style("background:#16181d"):
            ui.label("Add Spotify source").classes("text-subtitle1 text-weight-bold")
            body = ui.column().classes("w-full gap-2")
            with body:
                with ui.row().classes("items-center gap-2 q-py-md"):
                    ui.spinner(size="sm")
                    ui.label("Loading playlists from Spotify…").classes("text-grey")
        dialog.open()

        # Fetch off the event loop so the dialog paints immediately.
        try:
            playlists = await run.io_bound(lambda: runtime._sp().list_playlists())
        except Exception as e:
            body.clear()
            with body:
                ui.label(f"Spotify error: {e}").classes("text-negative")
                ui.button("Close", on_click=dialog.close).props("flat")
            return

        body.clear()
        with body:
            sp_opts = {p.id: f"{p.name}  ({p.track_count})" for p in playlists}
            rb_opts = {None: "— none —"}
            for nid, node in runtime.library.rekordbox_index.items():
                rb_opts[nid] = f"📁 {node.name}  (set folder)" if node.is_folder else node.name
            sp_sel = ui.select(sp_opts, label="Spotify playlist", with_input=True) \
                .props("outlined dense").classes("w-full")
            ui.label("Exports create a rekordbox playlist named after this "
                     "source and link to it automatically.") \
                .classes("text-caption text-grey")
            # Pairing is an outcome, not a decision — a first-timer has no
            # rekordbox playlist yet, so the question would be unanswerable.
            # It only matters when the playlist already exists under a
            # *different* name (a manual import), hence the collapsed ask.
            with ui.expansion("Already have this playlist in rekordbox?") \
                    .props("dense header-class=text-caption").classes("w-full"):
                rb_sel = ui.select(rb_opts, label="Link to existing rekordbox playlist",
                                   value=None, with_input=True) \
                    .props("outlined dense").classes("w-full")
                ui.label("Only needed if it goes by a different name there — "
                         "same-name playlists link up on their own.") \
                    .classes("text-caption text-grey")

            def confirm():
                if not sp_sel.value:
                    ui.notify("Pick a Spotify playlist", type="warning")
                    return
                name = next((p.name for p in playlists if p.id == sp_sel.value), "")
                store.upsert(SyncedSource(
                    spotify_playlist_id=sp_sel.value,
                    last_name=name,
                    paired_rb_id=rb_sel.value,
                    paired_rb_name=(runtime.library.rekordbox_index[rb_sel.value].name
                                    if rb_sel.value else None),   # clean name, not the label
                ))
                dialog.close()
                render_sources()
                ui.notify(f"Added “{name}”", type="positive")

            with ui.row().classes("justify-end w-full gap-2"):
                ui.button("Cancel", on_click=dialog.close).props("flat color=grey")
                ui.button("Add", on_click=confirm).props("unelevated color=primary")

    render_sources()
    update_dl_dest()
