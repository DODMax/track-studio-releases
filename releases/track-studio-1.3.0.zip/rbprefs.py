"""Read-only view of rekordbox's own preferences (`rekordbox3.settings`).

The one-time "point rekordbox's xml view at our export file" setup happens
inside rekordbox's Preferences — but rekordbox persists those preferences in a
plain XML file that pyrekordbox can locate. Reading it turns the scariest piece
of onboarding from a paragraph of instructions into a verifiable check:

- ``bridgeImportedLibraryFile`` — the xml path set under Preferences → Advanced
  → Database → "rekordbox xml" → Imported Library (i.e. what rekordbox watches).
- ``showRbXml`` — whether Preferences → View → Layout → "rekordbox xml" is
  ticked (without it the sidebar tree, and thus the import flow, is invisible).

Strictly read-only: rekordbox rewrites this file itself (on preference changes
and on quit), so we never write to it — a mismatch is fixed either by adopting
rekordbox's path as our export file (`store.save_export_file`) or by the user
changing it in rekordbox. A change made in rekordbox may not land on disk until
rekordbox flushes its settings, hence every UI around this offers "check again".
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass
class XmlView:
    """Where rekordbox's xml view stands relative to our export file.

    `state` is one of:
    - ``ok``           — watching our export file, sidebar tree visible
    - ``tree_hidden``  — watching our file, but the sidebar tree is not shown
    - ``mismatch``     — watching a *different* xml file (`watched`)
    - ``unconfigured`` — no Imported Library xml set at all
    - ``unknown``      — couldn't locate/read the preferences (see `detail`)
    """
    state: str
    watched: Path | None
    detail: str

    @property
    def ok(self) -> bool:
        return self.state == "ok"


# One parsed settings file, keyed by (path, mtime) — the check runs on every
# page render for the header badge, and the file only changes when rekordbox
# writes preferences, so a stale-proof cache makes it effectively free.
_cache: dict = {"key": None, "vals": {}}


def _settings_file() -> Path | None:
    """The current rekordbox version's `rekordbox3.settings`, or None.

    pyrekordbox knows the per-OS Pioneer application dir; inside it each major
    version keeps its own `rekordbox<N>` folder — pick the highest that actually
    has a settings file (an upgrade leaves the old folder behind).
    """
    from pyrekordbox.config import get_pioneer_app_dir  # deferred, may raise

    root = Path(get_pioneer_app_dir())
    versions = []
    for d in root.iterdir():
        m = re.fullmatch(r"rekordbox(\d+)", d.name)
        if m and (d / "rekordbox3.settings").is_file():
            versions.append((int(m.group(1)), d / "rekordbox3.settings"))
    return max(versions)[1] if versions else None


def _read(path: Path) -> dict[str, str]:
    key = (str(path), path.stat().st_mtime_ns)
    if _cache["key"] != key:
        import xml.etree.ElementTree as ET

        vals: dict[str, str] = {}
        for el in ET.parse(path).getroot().iter("VALUE"):
            name, val = el.get("name"), el.get("val")
            if name and val is not None:
                vals[name] = val
        _cache.update(key=key, vals=vals)
    return _cache["vals"]


def _same_file(a: str, b: str) -> bool:
    return (os.path.realpath(os.path.expanduser(a))
            == os.path.realpath(os.path.expanduser(b)))


def evaluate(export_file: Path | str) -> XmlView:
    """Compare rekordbox's xml-view preferences against our export file."""
    try:
        path = _settings_file()
    except Exception as e:
        return XmlView("unknown", None,
                       f"couldn't locate rekordbox's preferences: {e}")
    if path is None:
        return XmlView("unknown", None,
                       "no rekordbox preferences found on this machine")
    try:
        vals = _read(path)
    except Exception as e:
        return XmlView("unknown", None, f"couldn't read {path.name}: {e}")

    watched_raw = (vals.get("bridgeImportedLibraryFile") or "").strip()
    if not watched_raw:
        return XmlView("unconfigured", None,
                       "rekordbox has no Imported Library xml file set")
    watched = Path(watched_raw)
    if not _same_file(str(export_file), watched_raw):
        return XmlView("mismatch", watched,
                       f"rekordbox is watching a different file: {watched}")
    if str(vals.get("showRbXml", "")).strip() != "1":
        return XmlView("tree_hidden", watched,
                       "rekordbox is watching this file, but the «rekordbox xml» "
                       "sidebar tree is switched off")
    return XmlView("ok", watched, "rekordbox is watching this file")


if __name__ == "__main__":
    from runtime import export_path

    v = evaluate(export_path())
    print(f"export file : {export_path()}")
    print(f"state       : {v.state}")
    print(f"watched     : {v.watched}")
    print(f"detail      : {v.detail}")
