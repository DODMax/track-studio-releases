"""Replace a stitched file with a clean one — the action behind "Check for problems".

`integrity` says a file's audio isn't continuous. Nothing can repair that: the
audio is already duplicated or missing. The only fix is fetching the track again
from the store and swapping it in **at the same path**, because rekordbox keys
its collection on file location — a clean copy at a *new* path imports as a
second entry and splits the play evidence `history`/`mixmodel` run on, which is
the whole reason `dupes` exists.

Identity is the hard part. Beatport's own downloads carry no ISRC, so there's
nothing to match on but text and numbers, and getting it wrong is worse than the
glitch: it silently swaps the record under a track rekordbox still thinks it
knows. So three signals have to agree, and anything short of that is left for a
human:

- **name**, via `match.match_track` — title and artist scored independently, so
  a remix never collapses into the original it's named after;
- **duration**, the strongest one. A stitched file's length is off by only tens
  of milliseconds, so ±2s cleanly separates a rendition from a different record;
- **BPM**, to break ties between otherwise equal candidates.

Duration is also read as a *kind* of answer, not just a ranking. The catalog does
not always carry the version you own — measured here, a 6:04 "Baiana" whose only
Space Motion entry across 150 search results was a 3:28 radio edit — and the
ranking, having nothing better, offers it. Past `EDIT_DIFFERENCE_S` that is not a
worse copy of your track but a different record, and saying so is the whole job:
it is named, coloured and explained rather than left to read as a routine
"review". It is still yours to tick, like everything else here.

Every replacement is backed up first, then packet-checked, and rolled back if the
"clean" copy isn't actually clean. Leaf module: no UI, no `runtime`.
"""
from __future__ import annotations

import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

BACKUP_DIRNAME = ".broken_backup"
# The same swap, used for a different reason: the file being set aside is not
# damaged, it is simply the shorter edit of a record you now have in full. It
# gets its own folder so someone hunting for it later isn't told their audio
# was broken when it never was.
REPLACED_DIRNAME = ".replaced"
DURATION_TOLERANCE_S = 2.0
SEARCH_LIMIT = 15
NAME_CONFIDENT = 88.0
# Past this, the best hit is not a worse copy of your track — it is a different
# edit, and offering it as a "replacement" is the one failure this module exists
# to prevent. A stitched file's length is off by tens of milliseconds and two
# pressings of the same mix by a second or two, while a radio edit against an
# extended is minutes: measured here, a 6:04 file whose only Beatport entry was
# a 3:28 radio edit, presented as merely "needs a listen". Nothing legitimate
# lands in between, so the gap is wide on purpose.
EDIT_DIFFERENCE_S = 20.0
# Pairing a *delivered* file back to the candidate we asked for is a different
# question from matching a candidate, and gets its own numbers: the name carries
# it (beatportdl writes artist and title into the filename), and length only
# vetoes something that plainly isn't the same recording.
PAIR_NAME_CUTOFF = 70.0
PAIR_LENGTH_GUARD_S = 45.0

CONFIDENT, REVIEW, DIFFERENT_EDIT, NOT_FOUND = (
    "confident", "review", "different edit", "not found")


def _mmss(seconds: float) -> str:
    return f"{int(seconds) // 60}:{int(seconds) % 60:02d}"


@dataclass
class Candidate:
    """A Beatport track that might be the clean version of a local file."""
    path: Path                      # the local file to replace
    artist: str
    title: str
    local_s: float
    beatport_id: Optional[int] = None
    display: str = ""
    beatport_s: float = 0.0
    bpm: Optional[int] = None
    score: float = 0.0
    worst_ms: float = 0.0           # carried from the finding, for ordering
    # The store's clip for the candidate, so "review" can mean *listen to both*
    # rather than compare two strings. Free — it rides in on the same search hit.
    sample_url: Optional[str] = None

    @property
    def delta_s(self) -> float:
        return self.beatport_s - self.local_s

    @property
    def verdict(self) -> str:
        """Safe to replace without a human looking at it?"""
        if self.beatport_id is None:
            return NOT_FOUND
        if abs(self.delta_s) > EDIT_DIFFERENCE_S:
            return DIFFERENT_EDIT
        if self.score >= NAME_CONFIDENT and abs(self.delta_s) <= DURATION_TOLERANCE_S:
            return CONFIDENT
        return REVIEW

    @property
    def replaceable(self) -> bool:
        """Is there anything to download for this row?

        Only that — a verdict never disqualifies a row, it only argues against
        it. Even `DIFFERENT_EDIT`, which is the loudest thing this module says,
        is still yours to tick: a clean radio edit can genuinely beat a broken
        extended, and the store's advertised length is not always right about
        which is which. `dupes` takes the same line for the same reason — it
        warns and gets out of the way, because the person has context the
        numbers don't.
        """
        return self.beatport_id is not None

    @property
    def local_display(self) -> str:
        """What the file says it *is* — not what it's called on disk.

        The two differ more often than not: a store download is named
        "01. Landmine Feat. Blak Trash.m4a", which drops the artist entirely
        and is the one thing you need to compare against a Beatport title.
        """
        if self.artist and self.title:
            return f"{self.artist} - {self.title}"
        return self.path.name

    @property
    def reason(self) -> str:
        """Why this one needs a human. Empty when it doesn't.

        The thresholds are the module's, not the reader's: "-2.7s · name 100"
        only means something if you happen to know that names pass at 88 and
        lengths at ±2s. A near-perfect match rejected on a 0.7s margin should
        say so, because that is exactly the case where a listen settles it.
        """
        if self.beatport_id is None:
            return "nothing on Beatport matched the artist and title in its tags"
        if self.verdict == CONFIDENT:
            return ""
        if self.verdict == DIFFERENT_EDIT:
            return (f"the closest thing Beatport has is a different edit — "
                    f"{_mmss(self.beatport_s)} against your {_mmss(self.local_s)}, so "
                    "swapping it in would put another record under this track")
        bits = []
        if self.score < NAME_CONFIDENT:
            bits.append(f"the name matches only {self.score:.0f} of 100")
        if abs(self.delta_s) > DURATION_TOLERANCE_S:
            bits.append(f"it runs {abs(self.delta_s):.1f}s "
                        f"{'longer' if self.delta_s > 0 else 'shorter'}")
        return " and ".join(bits)

    @property
    def detail(self) -> str:
        if self.beatport_id is None:
            return "no Beatport match"
        return f"{self.display} · {self.delta_s:+.1f}s · name {self.score:.0f}"


def read_local(path: Path) -> tuple[str, str, float, Optional[int]]:
    """(artist, title, duration, bpm) off the file's own tags."""
    from mutagen import File as MutagenFile
    f = MutagenFile(path)
    if f is None:
        return "", "", 0.0, None
    tags = f.tags or {}
    if path.suffix.lower() == ".m4a":
        artist = (tags.get("\xa9ART") or [""])[0]
        title = (tags.get("\xa9nam") or [""])[0]
        bpm = (tags.get("tmpo") or [None])[0]
    else:
        artist = tags.get("TPE1").text[0] if tags.get("TPE1") else ""
        title = tags.get("TIT2").text[0] if tags.get("TIT2") else ""
        bpm = tags.get("TBPM").text[0] if tags.get("TBPM") else None
    return str(artist), str(title), float(f.info.length), (int(bpm) if bpm else None)


def find_on_beatport(path: Path) -> Candidate:
    """The best Beatport candidate for one local file. Never raises."""
    import bpdl
    from match import match_track, prep_choices

    artist, title, duration, bpm = read_local(Path(path))
    cand = Candidate(path=Path(path), artist=artist, title=title, local_s=duration)
    if not (artist and title):
        return cand
    try:
        hits = bpdl.search_tracks(f"{artist} {title}", limit=SEARCH_LIMIT)
    except Exception:
        return cand
    if not hits:
        return cand

    choices = prep_choices([(", ".join(h.artists), f"{h.name} {h.mix_name}".strip())
                            for h in hits])
    overall = match_track(artist, title, choices)
    if not overall.hit:
        return cand

    # The name match picks a *rendition*; length picks which pressing of it.
    # Among hits scoring about as well as the best, take the closest length.
    best_key = None
    for i, h in enumerate(hits):
        one = match_track(artist, title, [choices[i]])
        if not one.hit or one.score < overall.score - 6:
            continue
        delta = abs((h.length_ms or 0) / 1000 - duration)
        bpm_off = abs((h.bpm or 0) - bpm) if (bpm and h.bpm) else 99
        key = (delta > DURATION_TOLERANCE_S, bpm_off > 1, delta)
        if best_key is None or key < best_key:
            best_key = key
            cand.beatport_id, cand.display = h.id, h.display
            cand.beatport_s = (h.length_ms or 0) / 1000
            cand.bpm, cand.score = h.bpm, one.score
            cand.sample_url = h.sample_url
    return cand


def plan(findings) -> list[Candidate]:
    """A Candidate per finding, worst damage first. One Beatport search each."""
    out = []
    for f in findings:
        c = find_on_beatport(f.path)
        c.worst_ms = getattr(f, "worst_ms", 0.0)
        out.append(c)
    out.sort(key=lambda c: -c.worst_ms)
    return out


def replace_in_place(new_file: Path, target: Path,
                     backup_dirname: str = BACKUP_DIRNAME) -> tuple[bool, str]:
    """Swap `new_file` in at `target`. Returns (ok, message).

    The original is moved aside, never deleted — a wrong match has to be
    undoable. The Comments payload is carried across because that tag *is* the
    database (see CLAUDE.md) and a fresh download has none; it was computed on
    the broken audio, so re-analysing is worth it, but dropping it silently
    would be worse. Finally the replacement is packet-checked, and rolled back
    if it isn't actually clean — "downloaded again" is not the same as "fixed".

    `backup_dirname` names where the displaced file lands. Incoming passes
    `REPLACED_DIRNAME` when the swap is an *upgrade* rather than a repair: the
    same mechanism, but the file being set aside is a shorter edit, and filing
    it under "broken" would be a claim about it that isn't true.
    """
    import integrity

    new_file, target = Path(new_file), Path(target)
    backup_dir = target.parent / backup_dirname
    backup_dir.mkdir(exist_ok=True)
    backup = backup_dir / target.name

    comment = None
    if target.suffix.lower() == ".m4a":
        try:
            from mutagen.mp4 import MP4
            comment = (MP4(target).tags or {}).get("\xa9cmt")
        except Exception:
            comment = None
    try:
        shutil.move(str(target), str(backup))
        shutil.copy2(str(new_file), str(target))
    except OSError as e:
        return False, f"could not swap: {e}"

    if comment:
        try:
            from mutagen.mp4 import MP4
            t = MP4(target)
            t["\xa9cmt"] = comment
            t.save()
        except Exception:
            pass                      # the audio is what mattered

    check = integrity.packet_check(target, sample_seconds=0)
    if check.breaks:
        shutil.move(str(backup), str(target))
        return False, f"replacement still broken ({check.breaks} breaks) — rolled back"
    return True, "replaced"


def _plain_stem(stem: str) -> str:
    """A downloaded file's name without beatportdl's leading track number."""
    return re.sub(r"^\s*\d+\s*[.\-_]\s*", "", stem).strip()


def pair_downloads(files: list[Path], candidates: list[Candidate]) -> dict:
    """Map each downloaded file to the candidate it satisfies.

    beatportdl names by its own template, not by track id, so the download has
    to be recognised rather than looked up.

    **The name decides it and length only breaks ties**, which is the opposite
    of how this started and the fix for a real failure. Length used to *gate*
    the pairing at ±2s against the candidate's **advertised** length — and the
    advertised length is not the length of the file the store sends. Measured
    here: "Now Or Never (TRYM Remix)" is listed at 315.0s and delivered at
    317.4s, so a clean, correct, freshly-downloaded replacement was thrown away
    and reported as "no download matched this track" — with the broken file
    left in place and the good one abandoned in the staging folder.

    `DURATION_TOLERANCE_S` is sized for comparing one real duration against
    another (your file against the catalog) and has no business here, where one
    side is the store's own rounded metadata. Length is still consulted, to
    order ties and to veto something that isn't the same recording at all.
    """
    from match import best_match, normalize
    from mutagen import File as MutagenFile

    usable = [c for c in candidates if c.beatport_id]
    if not (files and usable):
        return {}

    lengths: dict = {}
    for f in files:
        try:
            lengths[f] = MutagenFile(f).info.length
        except Exception:
            lengths[f] = None
    choices = [normalize("", c.display) for c in usable]

    # Every pairing either signal vouches for, best first: name score down,
    # then length agreement up.
    scored: list[tuple[float, float, Path, Candidate]] = []
    for f in files:
        q = normalize("", _plain_stem(f.stem))
        flen = lengths.get(f)
        for ci, c in enumerate(usable):
            m = best_match(q, [choices[ci]], cutoff=PAIR_NAME_CUTOFF)
            delta = abs(flen - c.beatport_s) if flen else None
            if delta is not None and delta > PAIR_LENGTH_GUARD_S:
                continue                    # not the same recording at all
            if not m.hit and (delta is None or delta > DURATION_TOLERANCE_S):
                continue                    # neither signal vouches for it
            scored.append((-(m.score if m.hit else 0.0),
                           delta if delta is not None else 1e6, f, c))

    scored.sort(key=lambda t: (t[0], t[1]))
    out: dict = {}
    took_file, took_cand = set(), set()
    for _score, _delta, f, c in scored:
        if f in took_file or c.path in took_cand:
            continue
        out[c.path] = f
        took_file.add(f)
        took_cand.add(c.path)
    return out
