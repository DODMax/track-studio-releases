"""Rekordbox state — parse a collection.xml export into track + playlist state.

Rekordbox exports its library via `File → Export Collection in xml format`. The
file lists every track in the COLLECTION (with rekordbox's own BPM/key/rating)
and the playlist tree under PLAYLISTS, where each playlist entry references a
track by TrackID.

This is read-only and the *current* snapshot only. The "was in rekordbox but got
removed" signal is computed one level up (Library), by diffing this snapshot
against the previously-persisted one.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from urllib.parse import unquote, urlparse


@dataclass
class RekordboxTrack:
    track_id: str
    name: str
    artist: str
    location: Optional[Path]          # absolute local path (None for streaming entries)
    bpm: Optional[float]
    key: Optional[str]                # rekordbox "Tonality" (Camelot or classical)
    genre: str
    rating: int                       # 0..5 stars
    play_count: int
    date_added: str
    playlists: list[str] = field(default_factory=list)
    # richer fields available from the live DB (empty when parsed from XML)
    comment: str = ""                 # rekordbox "Commnt" — where our Energy tag lands
    color: str = ""
    my_tags: list[str] = field(default_factory=list)
    raw_path: str = ""                # original FolderPath string, before OS normalization

    @property
    def source_kind(self) -> str:
        """How this entry is stored: a local file, a foreign-OS path, or streaming."""
        p = self.raw_path or (str(self.location) if self.location else "")
        if p.startswith(("/Users", "/Volumes")):
            return "local"
        if p.startswith(("C:", "D:", "E:")):
            return "foreign"          # legacy Windows path — file not here
        if ":" in p and not p.startswith("/"):
            return "streaming"        # e.g. tidal:tracks:123
        return "unknown"

    @property
    def is_local_file(self) -> bool:
        return self.source_kind == "local" and self.location is not None


@dataclass
class RekordboxPlaylist:
    """A node in the rekordbox playlist tree (folder or playlist)."""
    id: str
    name: str
    parent_id: str
    seq: int
    is_folder: bool
    is_smart: bool
    track_ids: list[str] = field(default_factory=list)   # leaf playlists only
    children: list["RekordboxPlaylist"] = field(default_factory=list)

    def all_track_ids(self) -> set[str]:
        """Track ids in this node and (for folders) all descendants."""
        ids = set(self.track_ids)
        for ch in self.children:
            ids |= ch.all_track_ids()
        return ids

    @property
    def kind(self) -> str:
        return "folder" if self.is_folder else ("smart" if self.is_smart else "playlist")


@dataclass
class RekordboxCollection:
    tracks: dict[str, RekordboxTrack]      # by track_id
    source: Path
    playlist_roots: list[RekordboxPlaylist] = field(default_factory=list)
    playlist_index: dict[str, RekordboxPlaylist] = field(default_factory=dict)

    def by_location(self) -> dict[Path, RekordboxTrack]:
        return {t.location: t for t in self.tracks.values() if t.location}


def _decode_location(loc: str) -> Optional[Path]:
    """`file://localhost/Users/x/a.mp3` -> Path('/Users/x/a.mp3')."""
    if not loc:
        return None
    parsed = urlparse(loc)
    path = unquote(parsed.path)
    return Path(path) if path else None


def _norm_rating(raw: str) -> int:
    """Rekordbox stores rating as 0/51/102/153/204/255 -> 0..5 stars."""
    try:
        return round(int(raw) / 51)
    except (ValueError, TypeError):
        return 0


def parse_collection(xml_path: Path) -> RekordboxCollection:
    """Parse a rekordbox collection.xml into tracks (with playlist membership)."""
    xml_path = Path(xml_path)
    root = ET.parse(xml_path).getroot()

    tracks: dict[str, RekordboxTrack] = {}
    coll = root.find("COLLECTION")
    if coll is not None:
        for el in coll.findall("TRACK"):
            tid = el.get("TrackID", "")
            if not tid:
                continue
            bpm = el.get("AverageBpm")
            loc = _decode_location(el.get("Location", ""))
            tracks[tid] = RekordboxTrack(
                track_id=tid,
                name=el.get("Name", ""),
                artist=el.get("Artist", ""),
                location=loc,
                bpm=float(bpm) if bpm else None,
                key=el.get("Tonality") or None,
                genre=el.get("Genre", ""),
                rating=_norm_rating(el.get("Rating", "0")),
                play_count=int(el.get("PlayCount", "0") or 0),
                date_added=el.get("DateAdded", ""),
                comment=el.get("Comments", ""),
                raw_path=str(loc) if loc else "",
            )

    # Walk the playlist tree; leaf NODEs (Type="1") hold <TRACK Key="TrackID"/>.
    playlists_root = root.find("PLAYLISTS")
    if playlists_root is not None:
        _walk_playlists(playlists_root, [], tracks)

    return RekordboxCollection(tracks=tracks, source=xml_path)


def db_file() -> Optional[Path]:
    """Where the live database is: the Settings override, else wherever
    rekordbox's own preferences put it. None if neither says.

    The override is labelled a *folder*, and pyrekordbox's first argument is the
    `master.db` file, so a folder is completed to the file inside it. Passed
    through as typed, a folder could never have opened. While its drive is
    unplugged there is nothing to ask, so a path not ending in `.db` is taken to
    be the folder it was labelled as.
    """
    from store import load_studio_state
    override = load_studio_state().get("rekordbox_db_path")
    if override:
        p = Path(override).expanduser()
        return p if p.suffix == ".db" else p / "master.db"
    try:
        from pyrekordbox.config import get_config
        cfg = get_config("rekordbox7") or get_config("rekordbox6") or {}
    except Exception:
        return None
    return Path(cfg["db_path"]) if cfg.get("db_path") else None


def from_live() -> RekordboxCollection:
    """Read the *live* rekordbox 6/7 database read-only via pyrekordbox.

    This is the primary source — always current, no manual export. Safe to call
    while rekordbox is open (we never write). BPM is stored x100 in the DB.
    """
    from pyrekordbox import Rekordbox6Database

    import drives
    path = db_file()
    if drives.offline(path):
        raise drives.DriveOffline(drives.volume(path))
    db = Rekordbox6Database(path) if path else Rekordbox6Database()

    tracks: dict[str, RekordboxTrack] = {}
    for c in db.get_content():
        # pyrekordbox returns soft-deleted rows that rekordbox's UI hides.
        if getattr(c, "rb_local_deleted", 0):
            continue
        tid = str(c.ID)
        raw_path = c.FolderPath or ""
        is_filelike = raw_path.startswith(("/", "C:", "D:", "E:"))
        bpm = (c.BPM / 100.0) if c.BPM else None
        tracks[tid] = RekordboxTrack(
            track_id=tid,
            name=c.Title or "",
            artist=(c.ArtistName or (c.Artist.Name if c.Artist else "") or ""),
            location=Path(raw_path) if is_filelike and raw_path.startswith("/") else None,
            bpm=bpm,
            key=(c.KeyName or (c.Key.ScaleName if c.Key else None)) or None,
            genre=c.GenreName or "",
            rating=round((c.Rating or 0) / 51) if (c.Rating or 0) > 5 else (c.Rating or 0),
            play_count=int(c.DJPlayCount or 0),
            date_added=str(c.DateCreated or ""),
            comment=c.Commnt or "",
            color=c.ColorName or "",
            my_tags=[s for s in (c.MyTagNames or "").split(",") if s] if isinstance(c.MyTagNames, str) else [],
            raw_path=raw_path,
        )

    # Build the playlist tree (folders attr=1, smart attr=4, playlist attr=0).
    index: dict[str, RekordboxPlaylist] = {}
    for pl in db.get_playlist():
        if getattr(pl, "rb_local_deleted", 0):
            continue  # hidden in rekordbox; don't show in our tree either
        pid = str(pl.ID)
        attr = pl.Attribute
        node = RekordboxPlaylist(
            id=pid,
            name=pl.Name or "",
            parent_id=str(pl.ParentID),
            seq=int(getattr(pl, "Seq", 0) or 0),
            is_folder=(attr == 1),
            is_smart=(attr == 4),
        )
        if not node.is_folder:
            try:
                songs = pl.Songs or []
            except Exception:
                songs = []
            # `Songs` comes back in row order, not the playlist's: on a playlist
            # rekordbox had just rebuilt from an import, the first ten read back
            # as positions 60, 2, 11, 20, 32… An export that keeps "rekordbox's
            # own order" read this as that order and shuffled the set it wrote.
            songs = sorted(songs, key=lambda s: getattr(s, "TrackNo", 0) or 0)
            for song in songs:
                cid = str(getattr(song, "ContentID", "") or "")
                if cid in tracks:
                    node.track_ids.append(cid)
                    tracks[cid].playlists.append(node.name)
        index[pid] = node

    # Link children to parents; roots are nodes whose parent isn't a known node.
    roots: list[RekordboxPlaylist] = []
    for node in index.values():
        parent = index.get(node.parent_id)
        if parent is not None:
            parent.children.append(node)
        else:
            roots.append(node)
    _sort_tree(roots)

    return RekordboxCollection(
        tracks=tracks, source=Path("<live>"),
        playlist_roots=roots, playlist_index=index,
    )


def _sort_tree(nodes: list[RekordboxPlaylist]) -> None:
    """Order siblings exactly like rekordbox: by Seq (folders are interleaved,
    not forced to the top), name as a stable tiebreak. Recursive."""
    nodes.sort(key=lambda n: (n.seq, n.name.lower()))
    for n in nodes:
        _sort_tree(n.children)


def _walk_playlists(node: ET.Element, path: list[str], tracks: dict[str, RekordboxTrack]) -> None:
    for child in node.findall("NODE"):
        name = child.get("Name", "")
        if child.get("Type") == "1":   # leaf playlist
            full = " / ".join(path + [name]) if path else name
            for entry in child.findall("TRACK"):
                tid = entry.get("Key", "")
                if tid in tracks:
                    tracks[tid].playlists.append(full)
        else:                          # folder node -> recurse
            _walk_playlists(child, path + [name] if name and name != "ROOT" else path, tracks)


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        col = parse_collection(Path(sys.argv[1]))
        print(f"{len(col.tracks)} tracks in {col.source.name}")
        for t in list(col.tracks.values())[:10]:
            print(f"  [{t.track_id}] {t.artist} - {t.name}  bpm={t.bpm} key={t.key} "
                  f"rating={t.rating} playlists={t.playlists} loc={t.location}")
    else:
        # Smoke test against an inline sample (proves the format parsing).
        sample = """<?xml version="1.0" encoding="UTF-8"?>
        <DJ_PLAYLISTS Version="1.0.0">
          <PRODUCT Name="rekordbox" Version="6.7.7"/>
          <COLLECTION Entries="2">
            <TRACK TrackID="101" Name="Let's Pretend" Artist="Helsloot"
                   Genre="Melodic House" AverageBpm="124.00" Tonality="12B" Rating="153"
                   PlayCount="4" DateAdded="2025-01-02"
                   Location="file://localhost/Users/me/Music/Helsloot%20-%20Let's%20Pretend.mp3"/>
            <TRACK TrackID="102" Name="Next to Me" Artist="RUFUS DU SOL"
                   Genre="Indie Dance" AverageBpm="123.00" Tonality="9A" Rating="0"
                   Location="file://localhost/Users/me/Music/next.mp3"/>
          </COLLECTION>
          <PLAYLISTS>
            <NODE Type="0" Name="ROOT" Count="1">
              <NODE Name="Warmup" Type="1" Entries="1">
                <TRACK Key="101"/>
              </NODE>
            </NODE>
          </PLAYLISTS>
        </DJ_PLAYLISTS>"""
        tmp = Path("/tmp/_rb_sample.xml")
        tmp.write_text(sample)
        col = parse_collection(tmp)
        for t in col.tracks.values():
            print(f"[{t.track_id}] {t.artist} - {t.name} | bpm={t.bpm} key={t.key} "
                  f"rating={t.rating} playlists={t.playlists} loc={t.location}")
