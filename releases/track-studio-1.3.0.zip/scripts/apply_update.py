#!/usr/bin/env python3
"""Install a staged update — the half that can't run inside the app.

Spawned detached by `updates.launch_apply`, because it has to stop the server,
replace the files that server is running from, and start it again. Stdlib only
and no project imports: it must keep working while the code around it changes.

    venv/bin/python scripts/apply_update.py --staged data/updates/1.2.0 \
        --version 1.2.0 --pid <server pid>

The contract, in order: stop → back up everything about to change → swap →
`pip install` if requirements moved → start → **prove it answers**. If the new
version doesn't come up, the backup goes back and the old one is started again,
because a DJ finding out at a gig is not an acceptable failure mode. Everything
it does is logged to data/update.log.
"""
from __future__ import annotations

import argparse
import errno
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UPDATE_DIR = ROOT / "data" / "updates"
STATE_FILE = UPDATE_DIR / "state.json"
ROLLBACK = UPDATE_DIR / "rollback"
PROTECTED = ("venv/", "data/", "models/", "beatportdl/", "exports/", "dist/",
             ".env", ".git/")


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def state() -> dict:
    try:
        return json.loads(STATE_FILE.read_text())
    except (OSError, ValueError):
        return {}


def save_state(**kw) -> None:
    st = state()
    st.update(kw)
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(st, indent=2))


def port_is_up(port: int) -> bool:
    """Is something still holding the port? Ambiguity counts as yes.

    A connect that *times out* is not evidence the port is free. A server busy
    enough not to accept within the timeout — mid-analysis, or scanning a
    library — looks identical to one that has exited, and reading that as "free"
    is how files get swapped out from under a live app: the replacement then
    can't bind, exits, and a perfectly good update rolls back. Only an explicit
    refusal means free.
    """
    with socket.socket() as s:
        s.settimeout(2.0)
        err = s.connect_ex(("127.0.0.1", port))
    if err == 0:
        return True
    return err != errno.ECONNREFUSED


def served(port: int) -> tuple[str | None, int | None]:
    """What the app on the port says it is: its version, and which process it is."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/version", timeout=2) as r:
            answer = json.loads(r.read(4096).decode())
            return answer.get("version"), answer.get("pid")
    except (urllib.error.URLError, OSError, ValueError):
        return None, None


def listeners(port: int) -> list[int]:
    """Whoever is actually holding the port, whatever we were told to stop."""
    try:
        out = subprocess.run(["lsof", f"-i:{port}", "-sTCP:LISTEN", "-t"],
                             capture_output=True, text=True, timeout=15).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    return [int(x) for x in out.split() if x.strip().isdigit()]


def _tell(pids: list[int], sig: int) -> None:
    for pid in dict.fromkeys(p for p in pids if p and p != os.getpid()):
        try:
            os.kill(pid, sig)
        except (ProcessLookupError, PermissionError):
            pass


def _is_free(port: int) -> bool:
    """Free means two independent answers agree: nothing answers, nobody holds it.

    `lsof` is the authoritative half — it names the process rather than inferring
    from a connection attempt — so a single flaky connect can no longer be the
    whole basis for overwriting a running install.
    """
    return not port_is_up(port) and not listeners(port)


def _freed(port: int, seconds: float) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        if _is_free(port):
            return True
        time.sleep(0.5)
    return _is_free(port)


def stop_server(pid: int, port: int) -> bool:
    """Free the port, and say whether it worked — nothing may be swapped until it is.

    The pid we're handed is only a hint: it's whoever asked for the update, which
    is normally the server but isn't when a release is installed from a script. The
    port is the thing that has to come free, so if the hint doesn't do it we go and
    find whatever is actually listening. Getting this wrong is how an update
    "succeeds" against the old process still answering out of memory.
    """
    _tell([pid], signal.SIGTERM)
    if _freed(port, 25):        # uvicorn closes its websockets first
        return True
    _tell(listeners(port), signal.SIGTERM)
    if _freed(port, 8):
        return True
    log("the server didn't stop on its own — killing it")
    _tell([pid] + listeners(port), signal.SIGKILL)
    return _freed(port, 10)


def start_server(port: int) -> subprocess.Popen:
    """Launch the server detached. The handle is kept, not just the pid: a process
    that has already exited is the fastest possible answer to 'did it come up?'."""
    (ROOT / "data").mkdir(exist_ok=True)
    out = (ROOT / "data" / "app.log").open("a")
    env = dict(os.environ, PATH="/opt/homebrew/bin:/usr/local/bin:" + os.environ.get("PATH", ""))
    return subprocess.Popen([sys.executable, "main.py"], cwd=str(ROOT), env=env,
                            stdout=out, stderr=out, start_new_session=True)


def wait_for(port: int, version: str, proc: subprocess.Popen, seconds: int) -> bool:
    """Up, and it's the process we just started serving the version we expect.

    Both halves are load-bearing. "The port answers" says nothing: a server that
    never stopped keeps answering. And the version it reports is read from the
    VERSION file we just replaced, so the *old* process will happily claim the new
    number — the pid is what tells the two apart.

    A version that dies on import is the common failure, and it doesn't need the
    full wait: the moment the child is gone, so is the answer.
    """
    deadline = time.time() + seconds
    while time.time() < deadline:
        got, from_pid = served(port)
        if got == version and from_pid == proc.pid:
            return True
        if proc.poll() is not None:
            log(f"it exited with status {proc.returncode} — see data/app.log")
            return False
        time.sleep(1)
    return False


def relative_files(root: Path) -> list[str]:
    return sorted(str(p.relative_to(root)) for p in root.rglob("*")
                  if p.is_file() and "__pycache__" not in p.parts)


def protected(rel: str) -> bool:
    return any(rel == g.rstrip("/") or rel.startswith(g) for g in PROTECTED)


def place(src: Path, dest: Path) -> None:
    """Write `src` to `dest` atomically — a rename, never a partial file, and a
    new inode so a process already running the old file keeps its footing."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".ts-new")
    shutil.copy2(src, tmp)
    os.replace(tmp, dest)


def back_up(rels: list[str]) -> list[str]:
    """Copy the current version of each file aside; return the ones that were
    absent (so a rollback knows to delete rather than restore them)."""
    if ROLLBACK.exists():
        shutil.rmtree(ROLLBACK)
    added = []
    for rel in rels:
        live = ROOT / rel
        if live.is_file():
            place(live, ROLLBACK / rel)
        else:
            added.append(rel)
    return added


def restore(rels: list[str], added: list[str]) -> None:
    for rel in rels:
        saved = ROLLBACK / rel
        if saved.is_file():
            place(saved, ROOT / rel)
    for rel in added:
        (ROOT / rel).unlink(missing_ok=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--staged", required=True)
    ap.add_argument("--version", required=True)
    ap.add_argument("--pid", type=int, default=0)
    ap.add_argument("--port", type=int, default=8080)
    args = ap.parse_args()

    staged = Path(args.staged).resolve()
    old_version = (ROOT / "VERSION").read_text().strip() if (ROOT / "VERSION").is_file() else "?"
    log(f"=== updating {old_version} → {args.version} from {staged}")

    incoming = [r for r in relative_files(staged) if not protected(r)]
    if not incoming or "main.py" not in incoming:
        log("nothing usable staged — aborting, the app is untouched")
        return 1

    # Files the last update installed that this one no longer ships: stale
    # modules left behind are how an app starts importing code nobody wrote.
    gone = [r for r in state().get("installed_files", [])
            if r not in incoming and not protected(r) and (ROOT / r).is_file()]

    if not stop_server(args.pid, args.port):
        log(f"port {args.port} is still held — leaving {old_version} exactly as it is")
        notify(f"Track Studio {args.version} wasn't installed: the running app wouldn't stop. "
               f"Quit it and try again — {old_version} is untouched.")
        return 1
    log(f"swapping {len(incoming)} files" + (f", removing {len(gone)}" if gone else ""))
    added = back_up(incoming + gone)

    requirements_before = (ROOT / "requirements.txt").read_bytes() if (ROOT / "requirements.txt").is_file() else b""
    try:
        for rel in incoming:
            place(staged / rel, ROOT / rel)
        for rel in gone:
            (ROOT / rel).unlink(missing_ok=True)
    except OSError as e:
        log(f"the swap failed ({e}) — putting the old files back")
        restore(incoming + gone, added)
        start_server(args.port)
        return 1

    requirements_after = (ROOT / "requirements.txt").read_bytes() if (ROOT / "requirements.txt").is_file() else b""
    if requirements_after != requirements_before:
        # `venv/bin/pip` carries the path the venv was created at, which breaks
        # the moment the folder moves; `python -m pip` never does.
        log("requirements changed — installing")
        r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-r", "requirements.txt"],
                           cwd=str(ROOT), capture_output=True, text=True)
        if r.returncode != 0:
            log(f"pip failed:\n{r.stdout[-2000:]}\n{r.stderr[-2000:]}")

    log("starting the new version")
    started = start_server(args.port)
    if wait_for(args.port, args.version, started, 120):
        log(f"=== {args.version} is up")
        save_state(installed_files=incoming, installed_at=time.time(),
                   previous_version=old_version, available=None, last_error=None)
        shutil.rmtree(staged, ignore_errors=True)
        refresh_app_bundle()
        return 0

    log("the new version never answered — rolling back")
    stop_server(started.pid, args.port)
    restore(incoming + gone, added)
    back = start_server(args.port)
    ok = wait_for(args.port, old_version, back, 90)
    save_state(available=None, last_error=f"{args.version} failed to start; rolled back to {old_version}")
    notify(f"Track Studio {args.version} didn't start. "
           + (f"Version {old_version} is back up." if ok
              else f"Rolled back to {old_version} — open Track Studio to restart it."))
    return 1


def refresh_app_bundle() -> None:
    """Keep /Applications in step: the bundle bakes the version and the launcher.

    Best effort by design — a stale icon is a blemish, a failed update is not.
    """
    if not Path("/Applications/Track Studio.app").exists():
        return
    try:
        subprocess.run(["bash", "scripts/build_app.sh", "--install"], cwd=str(ROOT),
                       capture_output=True, text=True, timeout=180)
        log("rebuilt /Applications/Track Studio.app")
    except Exception as e:                      # noqa: BLE001
        log(f"couldn't rebuild the app bundle ({e}) — harmless, the update is in")


def notify(message: str) -> None:
    try:
        subprocess.run(["osascript", "-e",
                        f'display alert "Track Studio" message "{message}"'],
                       capture_output=True, timeout=30)
    except Exception:                           # noqa: BLE001
        pass


if __name__ == "__main__":
    sys.exit(main())
