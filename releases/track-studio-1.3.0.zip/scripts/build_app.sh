#!/bin/bash
# Build "Track Studio.app" — a tiny launcher bundle so the NiceGUI tool shows
# up in Finder / Spotlight / the Dock like a native app (same pattern as the
# Lazada Prices.app). It does NOT bundle Python; the launcher just starts the
# existing venv server on demand and opens the browser.
#
#   ./scripts/build_app.sh            # build into dist/
#   ./scripts/build_app.sh --install  # build, then copy to /Applications
#
# Re-run after moving the project (the project path is baked into the launcher).
set -euo pipefail

PROJECT="$(cd "$(dirname "$0")/.." && pwd)"
PORT=8080
# The one place the version lives; the updater reads the same file, so Get Info
# and the app can't disagree about what's installed.
VERSION="$(tr -d '[:space:]' < "$PROJECT/VERSION" 2>/dev/null || echo 0.0.0)"
APP="$PROJECT/dist/Track Studio.app"
CONTENTS="$APP/Contents"

rm -rf "$APP"
mkdir -p "$CONTENTS/MacOS" "$CONTENTS/Resources"

# --- Info.plist (a real windowed app now: it owns a Dock icon, not a browser tab) ---
cat > "$CONTENTS/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>
    <string>Track Studio</string>
    <key>CFBundleDisplayName</key>
    <string>Track Studio</string>
    <key>CFBundleIdentifier</key>
    <string>com.dodmax.trackstudio</string>
    <key>CFBundleExecutable</key>
    <string>launcher</string>
    <key>CFBundleVersion</key>
    <string>$VERSION</string>
    <key>CFBundleShortVersionString</key>
    <string>$VERSION</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleIconFile</key>
    <string>AppIcon</string>
    <key>NSHighResolutionCapable</key>
    <true/>
    <key>LSArchitecturePriority</key>
    <array>
        <string>arm64</string>
        <string>x86_64</string>
    </array>
</dict>
</plist>
PLIST

# --- launcher: start the server if the port is down, then open the window ---
cat > "$CONTENTS/MacOS/launcher" <<LAUNCHER
#!/bin/bash
# Open Track Studio: starts the server in the background if it isn't already
# running, then opens the app window on it. The window is a separate process
# from the server on purpose — closing it leaves an analysis running.
set -u

# LaunchServices sometimes runs script bundles under Rosetta, which makes the
# (universal) Python pick x86_64 and crash on the venv's arm64 modules.
if [[ "\$(sysctl -n sysctl.proc_translated 2>/dev/null)" == "1" ]]; then
    exec arch -arm64 /bin/bash "\$0" "\$@"
fi

PROJECT="$PROJECT"
PORT=$PORT
URL="http://localhost:\${PORT}"

# Spotlight/Finder launches get the bare GUI PATH — add Homebrew (arm64 +
# Intel) so the server finds ffmpeg & friends.
export PATH="/opt/homebrew/bin:/usr/local/bin:\$PATH"

cd "\$PROJECT" || {
    osascript -e "display alert \"Track Studio\" message \"Project folder not found at \$PROJECT\""
    exit 1
}

if ! lsof -i:\${PORT} -sTCP:LISTEN -t >/dev/null 2>&1; then
    mkdir -p data
    nohup "\$PROJECT/venv/bin/python" main.py >> data/app.log 2>&1 &
    disown
fi

# The window waits for the server itself, and is what macOS sees as the app:
# run it in the foreground so the Dock icon, ⌘Tab and the menu bar are ours.
exec "\$PROJECT/venv/bin/python" window.py
LAUNCHER
chmod +x "$CONTENTS/MacOS/launcher"

# --- icon ---
"$PROJECT/venv/bin/python" "$PROJECT/scripts/make_icon.py" "$PROJECT/dist"
iconutil -c icns "$PROJECT/dist/Track Studio.iconset" \
    -o "$CONTENTS/Resources/AppIcon.icns"
rm -rf "$PROJECT/dist/Track Studio.iconset"

echo "Built: $APP"

if [[ "${1:-}" == "--install" ]]; then
    rm -rf "/Applications/Track Studio.app"
    cp -R "$APP" "/Applications/Track Studio.app"
    # refresh Launch Services so Spotlight/Finder pick it up immediately
    /System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister \
        -f "/Applications/Track Studio.app" 2>/dev/null || true
    echo "Installed: /Applications/Track Studio.app"
fi
