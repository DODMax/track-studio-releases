#!/usr/bin/env python3
"""Find tracks whose audio is stitched together — the files whose beatgrid drifts.

A store-encoded AAC file steps exactly 1024 samples per packet, from the first to
the last. A file fetched over HLS is a few hundred ~5-second segments remuxed
into one container, and every join carries a timestamp discontinuity: a gap that
inserts time, or an overlap that swallows it. Measured on this library, up to
93ms at a time — a fifth of a beat at 133 BPM. Rekordbox lays a grid on the
intro, the audio then wanders out from under it, and no amount of re-gridding
fixes a track whose beats genuinely aren't evenly spaced.

Three signals. The first two are free and only decide what's worth probing; the
third is the one that decides anything.

1. **The encoder atom.** A store-encoded download carries no encoder tag at all;
   a remux is stamped by whatever wrote it (`Lavf…` for ffmpeg). This is what
   makes the pre-filter safe to trust.
2. **The BPM tell.** Beatport ships an integer BPM in the file's own tag. Ask
   rekordbox what it *measured* from the audio and a stitched track comes back
   133.xx against a flat 133, because the beats really aren't where a constant
   tempo would put them. Both numbers are read, never recomputed. Kept for the
   explanation it gives, not for its recall: on one folder it alone missed two
   of nineteen stitched files, one of them gridded at exactly 137.00. Which is
   why it's ORed with the encoder signal rather than trusted alone.
3. **The packet check.** Count timestamp steps that aren't one frame. This is
   proof, it costs an ffprobe per file, and it runs only where 1 or 2 point.

Usage:
    venv/bin/python scripts/find_broken_audio.py [FOLDER ...] [options]

    --full        packet-check every file, skipping the free pre-filter
    --sample N    seconds to probe per file (default 90; 0 = whole file)
    --csv PATH    write the findings for triage
    --quiet       summary only

With no FOLDER, scans the library's own folders (rekordbox + the download root).
Read-only: it never touches a file. Re-download anything it finds at `medium`
quality — see `bpdl.BROKEN_QUALITIES`.
"""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import integrity
from integrity import packet_check  # noqa: F401  (re-exported for refetch_broken)

AUDIO_EXTS = {".m4a", ".mp3", ".flac"}
DEFAULT_SAMPLE_SECONDS = integrity.DEFAULT_SAMPLE_SECONDS


def grid_bpms() -> dict[str, float]:
    """What rekordbox measured, by file path — the other half of the BPM tell."""
    try:
        import rekordbox
        col = rekordbox.from_live()
    except Exception as e:
        print(f"  (rekordbox unavailable, BPM tell disabled: {e})", file=sys.stderr)
        return {}
    # `tracks` is keyed by track id, and the file path is `location` — a
    # streaming entry has none, which is why this filters rather than maps.
    return {str(t.location).lower(): float(t.bpm)
            for t in col.tracks.values() if t.location and t.bpm}




def default_folders() -> list[Path]:
    import runtime
    from store import load_studio_state
    folders = []
    root = runtime._dl_root()
    if root.is_dir():
        folders.append(root)
    folder = load_studio_state().get("folder")
    if folder and Path(folder).is_dir():
        folders.append(Path(folder))
    return folders or [Path.home() / "Music"]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folders", nargs="*", type=Path)
    ap.add_argument("--full", action="store_true",
                    help="packet-check everything, skipping the BPM pre-filter")
    ap.add_argument("--sample", type=int, default=DEFAULT_SAMPLE_SECONDS,
                    help="seconds probed per file (0 = whole file)")
    ap.add_argument("--csv", type=Path)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    folders = args.folders or default_folders()
    files = sorted({p for d in folders for p in Path(d).rglob("*")
                    if p.suffix.lower() in AUDIO_EXTS and not p.name.startswith(".")})
    if not files:
        print(f"No audio under: {', '.join(str(f) for f in folders)}")
        return 1
    print(f"{len(files)} file(s) under {', '.join(str(f) for f in folders)}")

    grid = {} if args.full else grid_bpms()
    if grid:
        print(f"rekordbox knows the measured BPM of {len(grid)} of them")

    findings: list[Finding] = []
    checked = skipped = 0
    for i, path in enumerate(files, 1):
        tag_bpm = grid_bpm = None
        encoder = ""
        if not args.full:
            suspect, tag_bpm, encoder = integrity.worth_probing(path, grid.get(str(path).lower()))
            grid_bpm = grid.get(str(path).lower())
            if not suspect:
                skipped += 1
                continue
        f = packet_check(path, args.sample)
        f.tag_bpm, f.grid_bpm = tag_bpm, grid_bpm
        f.encoder = encoder or f.encoder
        checked += 1
        if f.breaks:
            findings.append(f)
        if not args.quiet and i % 200 == 0:
            print(f"  … {i}/{len(files)}  probed={checked}  found={len(findings)}",
                  flush=True)

    findings.sort(key=lambda f: (-f.worst_ms, -f.breaks))
    stitched = [f for f in findings if f.verdict == integrity.STITCHED]
    print(f"\n{'=' * 66}")
    print(f"{len(stitched)} stitched (re-download these), "
          f"{len(findings) - len(stitched)} otherwise discontinuous, "
          f"{checked} probed, {skipped} cleared without probing")
    print(f"{'=' * 66}\n")

    if not args.quiet and findings:
        print(f"{'worst':>8} {'breaks':>7} {'every':>7}  {'tag':>5} {'grid':>7}  file")
        for f in findings[:40]:
            every = f"{f.period_s:.1f}s" if f.period_s else "—"
            tag = f"{f.tag_bpm:.0f}" if f.tag_bpm else "—"
            gridb = f"{f.grid_bpm:.2f}" if f.grid_bpm else "—"
            print(f"{f.worst_ms:>7.0f}ms {f.breaks:>7} {every:>7}  "
                  f"{tag:>5} {gridb:>7}  {f.path.parent.name}/{f.path.name[:44]}")
        if len(findings) > 40:
            print(f"  … and {len(findings) - 40} more")
        by_folder = Counter(f.path.parent.name for f in findings)
        print("\nby folder:")
        for folder, n in by_folder.most_common(15):
            print(f"  {n:>4}x  {folder}")

    if args.csv:
        with open(args.csv, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["verdict", "breaks", "events", "worst_ms", "period_s",
                        "tag_bpm", "grid_bpm", "encoder", "path"])
            for f in findings:
                w.writerow([f.verdict, f.breaks, f.events, round(f.worst_ms, 1),
                            f.period_s, f.tag_bpm, f.grid_bpm, f.encoder, f.path])
        print(f"\n-> {args.csv}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
