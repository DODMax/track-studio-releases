"""One-time: put this library's re-downloaded tracks over another drive's stitched copies.

Two libraries grew from the same bad downloads (see `bpdl.BROKEN_QUALITIES`), so
the same tracks are stitched on both. This library's copies have since been
re-fetched clean; the other drive's have not, and the clean audio is already
here. Nothing needs downloading — it needs carrying across.

Replacing happens **at the other drive's own path**, through
`refetch.replace_in_place`, which is the whole reason this is a few lines rather
than a program: it moves the old file aside into `.broken_backup`, copies the
clean one in, carries the target's Comments payload (that tag is the database —
their analysis, not ours), packet-checks the result and rolls back if the copy
isn't actually clean. Their rekordbox keys on file location, so leaving the path
alone keeps the track, its cues and its play history attached. It will want a
re-analysis afterwards, because rekordbox caches the beatgrid.

**Identity is the dangerous part, and a filename is not identity.** Both
libraries name files the way Beatport does, so "01. Cybernetic.m4a" exists on
both drives — and also collides with a different release's first track. Measured
on the pair this was written for: 1007 filenames matched, and 82 of them were
not the same recording, including two tracks whose durations agreed to within
0.1s while being completely different records ("Talking (Extended Mix)" against
"Like A Dream (Extended Version)"). So a swap needs all four:

1. the same filename, compared NFC-folded — an external volume and HFS+
   disagree about how to spell an accent;
2. durations within `DURATION_TOLERANCE_S`, theirs being a shade shorter
   because stitching swallows time;
3. artist and title agreeing under `match.match_track`, which strips generic
   qualifiers ("Original Mix") while keeping a remixer's name, so a title tag
   that merely drops "(Original Mix)" still matches;
4. the same remix credit (`dupes.remix_tag`), because a long title can clear
   the name bar with a whole remix attribution bolted on.

And one more, which is about intent rather than identity: their file has to
actually be stitched. A clean copy is left alone.

Dry run by default. `--apply` is the only thing that writes.

    venv/bin/python scripts/fix_shared_drive.py --theirs "/Volumes/Their HD/Tracks"
    venv/bin/python scripts/fix_shared_drive.py --theirs "…" --apply
"""
from __future__ import annotations

import argparse
import os
import sys
import time
import unicodedata
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import integrity                                             # noqa: E402
import refetch                                               # noqa: E402
from dupes import remix_tag                                  # noqa: E402
from match import match_track, prep_choices                  # noqa: E402

AUDIO = (".m4a", ".mp3")
NAME_CUTOFF = 88.0
# Wider than `refetch.DURATION_TOLERANCE_S`, and for a reason: there the two
# sides are your file and the catalog's idea of it, here one side is *stitched*,
# and stitching doesn't just jitter a length — it swallows seconds. Measured on
# this pair of drives, four tracks scoring a flat 100/100 on the name with
# identical remix credits were 2.5 to 3.1s apart, one of them the very track
# whose re-download this script exists to carry over. Ten gives that room while
# staying far below any real difference of edit (a radio against an extended is
# minutes). The name is the primary key regardless; this only vetoes.
DURATION_TOLERANCE_S = 10.0
BACKUP_DIRNAME = refetch.BACKUP_DIRNAME


def _key(name: str) -> str:
    """A filename as both filesystems would agree to spell it."""
    return unicodedata.normalize("NFC", name).lower()


def _walk(root: Path) -> list[Path]:
    """Every audio file under `root`, skipping dotfolders.

    `os.walk` rather than `rglob`: an external volume can hand back a directory
    entry it then refuses to stat (one did, on a long non-ASCII name), and
    `rglob` turns that into an exception that kills the whole scan.
    """
    out: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root, onerror=lambda e: None):
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        out += [Path(dirpath) / fn for fn in filenames
                if fn.lower().endswith(AUDIO) and not fn.startswith(".")]
    return out


def redownloaded(root: Path) -> list[Path]:
    """The tracks this library has already re-fetched.

    A `.broken_backup` twin is the proof: `refetch.replace_in_place` puts the
    file it replaced there and nothing else does, so a file sitting beside its
    own backup is one that was stitched and now isn't. That is a far tighter
    definition of "my clean copy" than "any file that passes a packet check".
    """
    out: list[Path] = []
    for dirpath, _dirnames, filenames in os.walk(root, onerror=lambda e: None):
        if os.path.basename(dirpath) != BACKUP_DIRNAME:
            continue
        parent = Path(dirpath).parent
        out += [parent / fn for fn in filenames
                if fn.lower().endswith(AUDIO) and (parent / fn).exists()]
    return out


def read_tags(path: Path) -> tuple[str, str, float]:
    """(artist, title, seconds) off the file itself. ('', '', 0.0) if unreadable."""
    try:
        from mutagen import File as MutagenFile
        f = MutagenFile(path)
        tags = f.tags or {}
        if path.suffix.lower() == ".m4a":
            artist = (tags.get("\xa9ART") or [""])[0]
            title = (tags.get("\xa9nam") or [""])[0]
        else:
            artist = tags.get("TPE1").text[0] if tags.get("TPE1") else ""
            title = tags.get("TIT2").text[0] if tags.get("TIT2") else ""
        return str(artist), str(title), float(f.info.length)
    except Exception:
        return "", "", 0.0


def same_recording(mine: tuple[str, str, float],
                   theirs: tuple[str, str, float]) -> str:
    """"" when these are the same record, else why they aren't."""
    m_artist, m_title, m_len = mine
    t_artist, t_title, t_len = theirs
    if not (m_len and t_len):
        return "could not read one of the files"
    # Name first, because it is the signal that actually separates records, and
    # because asking it first makes the refusals legible: a pair that is both
    # differently named *and* a different length should say the former.
    if not match_track(m_artist, m_title,
                       prep_choices([(t_artist, t_title)]), cutoff=NAME_CUTOFF).hit:
        return f"tags name another track ({t_artist} - {t_title})"
    if remix_tag(m_title) != remix_tag(t_title):
        return "a different remix of the same title"
    if abs(t_len - m_len) > DURATION_TOLERANCE_S:
        return f"same name but {t_len - m_len:+.0f}s — a different edit"
    return ""


def plan_one(mine: Path, theirs: Path) -> tuple[bool, str]:
    """Should `theirs` be replaced by `mine`? Returns (yes, reason-if-not)."""
    verdict = integrity.packet_check(theirs, integrity.DEFAULT_SAMPLE_SECONDS).verdict
    if verdict == integrity.CLEAN:
        return False, "their copy already plays straight through"
    why = same_recording(read_tags(mine), read_tags(theirs))
    return (False, why) if why else (True, "")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--mine", default=str(Path.home() / "Tracks"),
                    help="this library's root (default: ~/Tracks)")
    ap.add_argument("--theirs", required=True, help="the other drive's music root")
    ap.add_argument("--apply", action="store_true",
                    help="actually replace; without it nothing is written")
    ap.add_argument("--limit", type=int, default=0, help="stop after N replacements")
    args = ap.parse_args()

    mine_root, theirs_root = Path(args.mine), Path(args.theirs)
    if not theirs_root.is_dir():
        print(f"not a directory: {theirs_root}")
        return 2

    print(f"scanning {mine_root} …")
    clean = redownloaded(mine_root)
    print(f"  {len(clean)} re-downloaded track(s) to offer")
    print(f"scanning {theirs_root} …")
    by_name: dict[str, list[Path]] = defaultdict(list)
    for p in _walk(theirs_root):
        by_name[_key(p.name)].append(p)
    print(f"  {sum(len(v) for v in by_name.values())} audio file(s) there")

    pairs = [(m, t) for m in clean for t in by_name.get(_key(m.name), [])]
    print(f"\nchecking {len(pairs)} same-named pair(s)…")

    todo, skipped = [], defaultdict(int)
    for i, (m, t) in enumerate(pairs, 1):
        ok, why = plan_one(m, t)
        if ok:
            todo.append((m, t))
        else:
            skipped[why.split(" (")[0]] += 1
        if i % 100 == 0 or i == len(pairs):
            print(f"  {i}/{len(pairs)}", end="\r", flush=True)

    print(f"\n\nWOULD REPLACE: {len(todo)}")
    for why, n in sorted(skipped.items(), key=lambda kv: -kv[1]):
        print(f"  skipped — {why}: {n}")

    if not args.apply:
        print("\nDry run. Nothing was written. Re-run with --apply to do it.")
        for m, t in todo[:5]:
            print(f"  {t}")
            print(f"    ← {m}")
        if len(todo) > 5:
            print(f"  … and {len(todo) - 5} more")
        return 0

    log = Path(__file__).resolve().parent.parent / "data" / "shared_drive_fix.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    done = failed = 0
    started = time.time()
    with log.open("a") as fh:
        fh.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M')} {theirs_root} ===\n")
        for i, (m, t) in enumerate(todo, 1):
            if args.limit and done >= args.limit:
                break
            ok, msg = refetch.replace_in_place(m, t)
            done += ok
            failed += (not ok)
            fh.write(f"{'ok ' if ok else 'FAIL'} {t}  <- {m}  ({msg})\n")
            fh.flush()
            if not ok:
                print(f"\n  FAILED {t.name}: {msg}")
            print(f"  {i}/{len(todo)}  replaced {done}, failed {failed}",
                  end="\r", flush=True)

    print(f"\n\nreplaced {done}, failed {failed}, in {time.time() - started:.0f}s")
    print(f"originals kept beside each file in {BACKUP_DIRNAME}/")
    print(f"log: {log}")
    print("\nTheir rekordbox caches the beatgrid, so the swapped tracks need "
          "“Analyze” (or Reload Tag + re-grid) there before the new audio is used.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
