"""Generate Track Studio's app icon (.iconset of PNGs) for iconutil.

On-brand: a warm orange rounded square with a white "energy arc" area chart
(the set's shape — the app's visual signature) and energy-colored dots.

    venv/bin/python scripts/make_icon.py [out_dir]

Writes <out_dir>/Track Studio.iconset/icon_*.png at every size macOS wants.
The build script then runs `iconutil -c icns` over that folder.
"""
from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image, ImageDraw

# Energy palette (matches main.py ENERGY_COLORS) for the dots along the arc.
DOTS = ["#4a90e2", "#5fb454", "#f0a830", "#e8731c", "#d83a3a", "#f0a830", "#5fb454"]
S = 1024  # master render size


def _rounded_mask(size: int, radius_frac: float = 0.225) -> Image.Image:
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    r = int(size * radius_frac)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=r, fill=255)
    return mask


def _vgradient(size: int, top: tuple, bot: tuple) -> Image.Image:
    base = Image.new("RGB", (size, size), top)
    px = base.load()
    for y in range(size):
        f = y / (size - 1)
        col = tuple(int(top[i] + (bot[i] - top[i]) * f) for i in range(3))
        for x in range(size):
            px[x, y] = col
    return base


def render(size: int = S) -> Image.Image:
    # warm orange gradient background, clipped to a rounded square
    bg = _vgradient(size, (0xFF, 0x8A, 0x2B), (0xE8, 0x66, 0x14))
    icon = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    icon.paste(bg, (0, 0), _rounded_mask(size))

    d = ImageDraw.Draw(icon)

    # energy arc across the lower-middle: white area chart + stroke + dots
    pts_n = [0.30, 0.55, 0.42, 0.70, 0.95, 0.78, 0.58]  # normalized heights (0 low..1 high)
    pad = size * 0.16
    usable_w = size - pad * 2
    top_y = size * 0.30
    base_y = size * 0.74
    xs = [pad + usable_w * (i / (len(pts_n) - 1)) for i in range(len(pts_n))]
    ys = [base_y - (base_y - top_y) * h for h in pts_n]

    # filled area under the curve (translucent white)
    area = [(xs[0], base_y)] + list(zip(xs, ys)) + [(xs[-1], base_y)]
    d.polygon(area, fill=(255, 255, 255, 60))
    # the curve
    d.line(list(zip(xs, ys)), fill=(255, 255, 255, 235),
           width=int(size * 0.028), joint="curve")
    # energy dots
    r = size * 0.030
    for (x, y), hexcol in zip(zip(xs, ys), DOTS):
        c = tuple(int(hexcol[i:i + 2], 16) for i in (1, 3, 5))
        d.ellipse([x - r, y - r, x + r, y + r], fill=c + (255,),
                  outline=(255, 255, 255, 255), width=int(size * 0.006))

    # baseline tick (a subtle "deck" line)
    d.line([(pad, base_y), (size - pad, base_y)],
           fill=(255, 255, 255, 90), width=int(size * 0.008))
    return icon


def main() -> None:
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("dist")
    out_dir.mkdir(parents=True, exist_ok=True)
    iconset = out_dir / "Track Studio.iconset"
    iconset.mkdir(exist_ok=True)

    master = render(S)
    # (size, suffix) entries macOS expects in an .iconset
    targets = [
        (16, "icon_16x16.png"), (32, "icon_16x16@2x.png"),
        (32, "icon_32x32.png"), (64, "icon_32x32@2x.png"),
        (128, "icon_128x128.png"), (256, "icon_128x128@2x.png"),
        (256, "icon_256x256.png"), (512, "icon_256x256@2x.png"),
        (512, "icon_512x512.png"), (1024, "icon_512x512@2x.png"),
    ]
    for px, name in targets:
        master.resize((px, px), Image.LANCZOS).save(iconset / name)
    print(f"wrote {iconset} ({len(targets)} sizes)")


if __name__ == "__main__":
    main()
