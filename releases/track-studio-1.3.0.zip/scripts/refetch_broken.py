#!/usr/bin/env python3
"""Match the files `find_broken_audio.py` flagged back to Beatport, and replace them.

The scanner says *which* files are stitched. This says *what to do about it*: find
each one on Beatport, download a clean copy at `medium`, and swap it in at the
same path so rekordbox keeps the track — its id, its cues, its play history, its
playlist memberships. A copy at a new path would import as a second entry and
split the play evidence `mixmodel` runs on (see `dupes.py`).

Identity is the hard part, because these files carry no ISRC — Beatport's own
downloads don't embed one. So it matches on three things and refuses to guess:

- **name**, via `match.match_track` (title and artist scored independently, so a
  remix never collapses into the original it's named after);
- **duration**, the strongest signal — a stitched file's length is off by only
  tens of milliseconds, so ±2s separates a rendition from a different record;
- **BPM**, as a tiebreak among otherwise equal candidates.

Anything short of a confident match is written out as `review` and skipped. A
wrong auto-replace is worse than the glitch it fixes: it silently swaps the
record under a track rekordbox still thinks it knows.

Usage:
    venv/bin/python scripts/refetch_broken.py BROKEN.csv [options]

    --plan-only     just write the match plan (default; nothing is downloaded)
    --apply         download the confident matches and replace them in place
    --limit N       only handle the first N files (start small)
    --min-severity  skip findings whose worst break is under N ms (default 0)
    --out PATH      where the plan goes (default: alongside the input)

Always dry-run first. `--apply` backs every original up to a `.broken_backup`
folder beside it before writing, and verifies the replacement reads 0 breaks.
"""
from __future__ import annotations

import argparse
import csv
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

BACKUP_DIRNAME = ".broken_backup"
DURATION_TOLERANCE_S = 2.0
LOOSE_TOLERANCE_S = 4.0
SEARCH_LIMIT = 15


@dataclass
class Candidate:
    beatport_id: int
    display: str
    length_s: float
    bpm: Optional[int]
    score: float
    delta_s: float

    @property
    def verdict(self) -> str:
        """Confident enough to replace a file without a human looking at it?"""
        if self.score >= 88 and abs(self.delta_s) <= DURATION_TOLERANCE_S:
            return "confident"
        if self.score >= 78 and abs(self.delta_s) <= LOOSE_TOLERANCE_S:
            return "review"
        return "review"


def read_local(path: Path) -> tuple[str, str, float, Optional[int]]:
    """(artist, title, duration, bpm) straight off the file's own tags."""
    from mutagen import File as MutagenFile
    f = MutagenFile(path)
    if f is None:
        return "", "", 0.0, None
    tags = f.tags or {}
    if path.suffix.lower() == ".m4a":
        artist = (tags.get("\xa9ART") or [""])[0]
        title = (tags.get("\xa9nam") or [""])[0]
        bpm = (tags.get("tmpo") or [None])[0]
    else:
        artist = tags.get("TPE1").text[0] if tags.get("TPE1") else ""
        title = tags.get("TIT2").text[0] if tags.get("TIT2") else ""
        bpm = tags.get("TBPM").text[0] if tags.get("TBPM") else None
    return str(artist), str(title), float(f.info.length), (int(bpm) if bpm else None)


def find_on_beatport(artist: str, title: str, duration: float,
                     bpm: Optional[int]) -> Optional[Candidate]:
    """The best Beatport candidate for a local file, or None."""
    import bpdl
    from match import match_track, prep_choices

    if not (artist and title):
        return None
    try:
        hits = bpdl.search_tracks(f"{artist} {title}", limit=SEARCH_LIMIT)
    except Exception as e:
        print(f"    search failed: {e}", file=sys.stderr)
        return None
    if not hits:
        return None

    choices = prep_choices([(", ".join(h.artists), f"{h.name} {h.mix_name}".strip())
                            for h in hits])
    m = match_track(artist, title, choices)
    if not m.hit:
        return None

    # The name match picks a *rendition*; duration picks the right one of them.
    # Prefer the closest-length hit among those whose name scores as well.
    best, best_key = None, None
    for i, h in enumerate(hits):
        mi = match_track(artist, title, [choices[i]])
        if not mi.hit or mi.score < m.score - 6:
            continue
        delta = (h.length_ms or 0) / 1000 - duration
        bpm_off = abs((h.bpm or 0) - bpm) if (bpm and h.bpm) else 99
        key = (abs(delta) > DURATION_TOLERANCE_S, bpm_off > 1, abs(delta))
        if best_key is None or key < best_key:
            best, best_key = Candidate(h.id, h.display, (h.length_ms or 0) / 1000,
                                       h.bpm, mi.score, delta), key
    return best


def packet_breaks(path: Path) -> int:
    """Reuse the scanner's proof step, so 'fixed' means the same thing here."""
    from find_broken_audio import packet_check
    return packet_check(path, 0).breaks


def replace_in_place(new_file: Path, target: Path) -> str:
    """Swap `new_file` in at `target`, keeping rekordbox's entry and the tags it owns.

    The Comments payload is carried across because that tag *is* the database
    (see CLAUDE.md) and a fresh download has none. It was computed on the broken
    audio, so it's worth re-analysing — but dropping it silently would be worse.
    """
    from mutagen.mp4 import MP4
    backup = target.parent / BACKUP_DIRNAME
    backup.mkdir(exist_ok=True)
    comment = None
    if target.suffix.lower() == ".m4a":
        comment = (MP4(target).tags or {}).get("\xa9cmt")
    shutil.move(str(target), str(backup / target.name))
    shutil.copy2(str(new_file), str(target))
    if comment:
        t = MP4(target)
        t["\xa9cmt"] = comment
        t.save()
    breaks = packet_breaks(target)
    if breaks:
        shutil.move(str(backup / target.name), str(target))   # roll back
        return f"replacement still has {breaks} breaks — rolled back"
    return "replaced"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("csv_in", type=Path)
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--limit", type=int)
    ap.add_argument("--min-severity", type=float, default=0.0)
    ap.add_argument("--out", type=Path)
    args = ap.parse_args()

    rows = [r for r in csv.DictReader(args.csv_in.open())
            if r["verdict"] == "STITCHED"
            and float(r["worst_ms"] or 0) >= args.min_severity]
    rows.sort(key=lambda r: -float(r["worst_ms"] or 0))
    if args.limit:
        rows = rows[:args.limit]
    print(f"{len(rows)} stitched file(s) to match\n")

    plan, counts = [], {"confident": 0, "review": 0, "not found": 0, "missing": 0}
    for i, r in enumerate(rows, 1):
        path = Path(r["path"])
        if not path.exists():
            counts["missing"] += 1
            continue
        artist, title, duration, bpm = read_local(path)
        cand = find_on_beatport(artist, title, duration, bpm)
        verdict = cand.verdict if cand else "not found"
        counts[verdict] = counts.get(verdict, 0) + 1
        plan.append({
            "verdict": verdict,
            "worst_ms": r["worst_ms"],
            "artist": artist, "title": title,
            "local_s": f"{duration:.1f}",
            "beatport_id": cand.beatport_id if cand else "",
            "beatport": cand.display if cand else "",
            "bp_s": f"{cand.length_s:.1f}" if cand else "",
            "delta_s": f"{cand.delta_s:+.1f}" if cand else "",
            "score": f"{cand.score:.0f}" if cand else "",
            "path": str(path),
        })
        print(f"  [{i}/{len(rows)}] {verdict:<10} {artist} - {title[:38]}"
              + (f"  ->  {cand.display[:44]} ({cand.delta_s:+.1f}s)" if cand else ""))

    out = args.out or args.csv_in.with_name(args.csv_in.stem + "_plan.csv")
    with out.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(plan[0].keys()) if plan else ["verdict"])
        w.writeheader()
        w.writerows(plan)
    print(f"\n{counts}\n-> {out}")

    if not args.apply:
        print("\nPlan only. Re-run with --apply to download and replace the "
              "confident matches (review rows are never touched).")
        return 0

    import bpdl
    confident = [p for p in plan if p["verdict"] == "confident"]
    if not confident:
        print("Nothing confident enough to replace.")
        return 0
    if bpdl.get_quality() in bpdl.BROKEN_QUALITIES:
        print(f"REFUSING: beatportdl quality is {bpdl.get_quality()}")
        return 1

    staging = Path(args.csv_in.parent / "refetch_staging")
    staging.mkdir(exist_ok=True)
    print(f"\nDownloading {len(confident)} at '{bpdl.get_quality()}' -> {staging}")
    files, log = bpdl.download([int(p["beatport_id"]) for p in confident], staging)
    print(f"  got {len(files)} file(s)")
    if not files:
        print(bpdl.failure_reason(log))
        return 1

    # beatportdl names by its own template, so pair downloads back to plan rows
    # by duration — the same signal that identified them in the first place.
    from mutagen import File as MutagenFile
    remaining = list(files)
    for p in confident:
        want = float(p["bp_s"])
        best = min(remaining, key=lambda f: abs(MutagenFile(f).info.length - want),
                   default=None)
        if best is None or abs(MutagenFile(best).info.length - want) > 2.0:
            print(f"  no download matched {p['beatport']} — skipped")
            continue
        remaining.remove(best)
        print(f"  {replace_in_place(best, Path(p['path']))}: {Path(p['path']).name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
