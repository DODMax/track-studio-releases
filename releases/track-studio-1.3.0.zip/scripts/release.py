#!/usr/bin/env python3
"""Cut a release — build the zip, sign it, write the manifest.

Publishing is then a commit in GitHub Desktop: the releases folder is an
ordinary public repo, and `raw.githubusercontent.com` is the whole "update
server". Nothing here talks to GitHub.

    venv/bin/python scripts/release.py 1.2.0 --notes "what changed"
    venv/bin/python scripts/release.py 1.2.0-beta1 --channel beta
    venv/bin/python scripts/release.py keygen        # once, ever

The payload is built from `git ls-files` **as the files stand in the working
tree**, so a release can be tested before it is committed — the run says so when
the tree is dirty. Tracked files only is what keeps the venv, the models, your
.env and your drafts out of a zip that gets unpacked over someone's install.

Try it before you publish it, with no server anywhere:

    TRACK_STUDIO_FEED=file:///Users/you/Code/track-studio-releases  (in .env)
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import signing  # noqa: E402  — after sys.path, so this runs from anywhere

KEY_PATH = Path.home() / ".config" / "track-studio" / "release_key"
DEFAULT_OUT = ROOT.parent / "track-studio-releases"


def git(*args: str) -> str:
    return subprocess.run(["git", *args], cwd=str(ROOT), capture_output=True,
                          text=True, check=True).stdout.strip()


def keygen() -> int:
    """Make the signing key. The private half never leaves this machine."""
    if KEY_PATH.exists():
        pub = signing.public_from_secret(signing.unb64(KEY_PATH.read_text()))
        print(f"A key already exists at {KEY_PATH}")
        print(f"public key: {signing.b64(pub)}")
        return 0
    KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
    secret = os.urandom(32)
    KEY_PATH.write_text(signing.b64(secret) + "\n")
    os.chmod(KEY_PATH, 0o600)
    print(f"Private key written to {KEY_PATH} (keep it; back it up offline).")
    print(f"Put this in updates.RELEASE_PUBLIC_KEY:\n  {signing.b64(signing.public_from_secret(secret))}")
    return 0


def payload_files() -> list[str]:
    """Everything git would keep: tracked, plus new files it isn't ignoring.

    Tracked alone is the obvious rule and the wrong one — a release cut before
    the commit would quietly ship without its newest modules and refuse to
    install. Ignored paths stay out, which is what keeps the venv, the models,
    the .env and the local state out of a zip that gets unpacked over someone's
    install.
    """
    listed = git("ls-files").splitlines() + git("ls-files", "--others", "--exclude-standard").splitlines()
    return sorted({f for f in listed if (ROOT / f).is_file()})


def build_zip(version: str, dest: Path) -> tuple[str, int]:
    files = payload_files()
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel in files:
            zf.write(ROOT / rel, rel)
    raw = dest.read_bytes()
    return hashlib.sha256(raw).hexdigest(), len(raw)


def notes_since(commit: str | None) -> str:
    """Release notes from the commit subjects since the last release."""
    if not commit:
        return ""
    try:
        return git("log", "--no-merges", "--format=- %s", f"{commit}..HEAD")
    except subprocess.CalledProcessError:
        return ""


def main() -> int:
    if len(sys.argv) > 1 and sys.argv[1] == "keygen":
        return keygen()

    ap = argparse.ArgumentParser(description="Build and sign a Track Studio release")
    ap.add_argument("version", help='e.g. 1.2.0 (the number the app compares)')
    ap.add_argument("--channel", default="stable", choices=("stable", "beta"))
    ap.add_argument("--notes", default=None, help="markdown; default: commits since the last release")
    ap.add_argument("--notes-file", default=None)
    ap.add_argument("--out", default=os.environ.get("TRACK_STUDIO_RELEASES", str(DEFAULT_OUT)))
    ap.add_argument("--base-url", default=None,
                    help="where the zip will be readable; default: the manifest's own folder")
    args = ap.parse_args()

    if not KEY_PATH.exists():
        print(f"No signing key at {KEY_PATH} — run: {sys.argv[0]} keygen", file=sys.stderr)
        return 2
    secret = signing.unb64(KEY_PATH.read_text())
    pub = signing.b64(signing.public_from_secret(secret))

    import updates
    if pub != updates.RELEASE_PUBLIC_KEY:
        print("This key doesn't match updates.RELEASE_PUBLIC_KEY — the app would "
              f"refuse the release.\n  key here: {pub}\n  app trusts: {updates.RELEASE_PUBLIC_KEY}",
              file=sys.stderr)
        return 2

    out = Path(args.out).expanduser()
    (out / "releases").mkdir(parents=True, exist_ok=True)
    manifest_path = out / f"{args.channel}.json"
    previous = {}
    if manifest_path.is_file():
        try:
            previous = json.loads(manifest_path.read_text())
        except ValueError:
            pass

    if not updates.is_newer(args.version, previous.get("version", "0.0.0")):
        print(f"{args.version} is not newer than the published {previous.get('version')} "
              "— the app would never offer it.", file=sys.stderr)
        return 2

    dirty = git("status", "--porcelain")
    (ROOT / "VERSION").write_text(args.version + "\n")

    zip_name = f"track-studio-{args.version}.zip"
    zip_path = out / "releases" / zip_name
    digest, size = build_zip(args.version, zip_path)
    signature = signing.b64(signing.sign(secret, signing.release_message(args.version, digest)))

    base = (args.base_url or f"{_repo_raw_url(out)}").rstrip("/")
    notes = args.notes
    if notes is None and args.notes_file:
        notes = Path(args.notes_file).read_text()
    if notes is None:
        notes = notes_since(previous.get("commit"))

    manifest = {
        "version": args.version,
        "pub_date": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "notes": notes,
        "commit": git("rev-parse", "HEAD"),
        "platforms": {
            "darwin": {"url": f"{base}/releases/{zip_name}", "sha256": digest,
                       "size": size, "signature": signature},
        },
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

    print(f"VERSION  → {args.version}")
    print(f"zip      → {zip_path}  ({size / 1024:.0f} KB)")
    print(f"manifest → {manifest_path}")
    if dirty:
        print("\nNote: the working tree is dirty, so the zip holds uncommitted work.\n"
              "      Commit it before publishing or the release can't be reproduced:\n"
              + "\n".join("        " + line for line in dirty.splitlines()[:10]))
    print("\nTo try it before anyone else gets it, put this in .env and restart:\n"
          f"  TRACK_STUDIO_FEED=file://{out}")
    print("\nTo publish: commit and push the releases repo in GitHub Desktop.")
    return 0


def _repo_raw_url(out: Path) -> str:
    """The raw.githubusercontent URL of the releases repo, read off its remote."""
    try:
        url = subprocess.run(["git", "remote", "get-url", "origin"], cwd=str(out),
                             capture_output=True, text=True, check=True).stdout.strip()
        branch = subprocess.run(["git", "symbolic-ref", "--short", "HEAD"], cwd=str(out),
                                capture_output=True, text=True, check=True).stdout.strip() or "main"
    except (subprocess.CalledProcessError, FileNotFoundError):
        return f"file://{out}"
    slug = url.removeprefix("git@github.com:").removeprefix("https://github.com/").removesuffix(".git")
    return f"https://raw.githubusercontent.com/{slug}/{branch}"


if __name__ == "__main__":
    sys.exit(main())
