"""The board: Setline, running inside this app, against this library.

Track Studio stops having a set builder of its own and serves Setline's board at
`/board` instead ([0002](docs/proposals/0002-setline-becomes-the-set-builder.md)).
It is not a port and not a lookalike: it is Setline's own server package and its
own built Svelte app, mounted into NiceGUI's FastAPI app — one process, one port,
one window — on a SQLite file of its own. The shared online Setline keeps
running for everyone without Track Studio, so this is a *second instance of the
same schema* ([0003](docs/proposals/0003-solo-setline-and-the-shared-one.md)),
and three rules from there shape everything below:

- **Nothing local crosses.** A library file enters Setline's catalog as the
  record it is (title, artists, ISRC, Beatport id). The file behind it is this
  module's own note — `ts_library_links`, a table Setline's schema doesn't know
  — and what only this machine knows (energy, style, the sleeve out of the
  file's tags) rides beside a track on the board as `track.local`, never in a
  column. Columns replicate; a path is someone's disk.
- **Every change to a night goes through `api_board.apply_change`** — the one
  door — including the ones made from Track Studio's own UI (the crate dock,
  `crates.py`). Otherwise the change log has holes and the board is silently
  out of date.
- **The instance acts as a person** (`.setline_local.json`: one member id, one
  name, one colour, one instance id), never as a tool.

Setline lives in its own repo; `SETLINE_HOME` (default `vendor/setline`, else
`~/Code/setline`) says where. Without it — or without its built front end — the board simply isn't
mounted and the crate store stays on `.crates.json`, which is also what the
analysis workers see, since they never mount anything.
"""
from __future__ import annotations

import json
import os
import secrets
import sys
import threading
import uuid
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import quote

from config import ROOT

MOUNT = "/board"
# Where Setline is: `SETLINE_HOME`, else a copy shipped inside this install
# (`vendor/setline` — how a release will carry it), else the checkout beside this one.
SETLINE_HOME = Path(os.environ.get("SETLINE_HOME")
                    or (ROOT / "vendor" / "setline" if (ROOT / "vendor" / "setline").is_dir()
                        else Path.home() / "Code" / "setline")).expanduser()
# The board's own SQLite file. Not `.cache.sqlite`: that one is declared deletable
# and a set is not — it is a fact you made, like `.crates.json` was.
DB_PATH = Path(os.environ.get("TRACK_STUDIO_BOARD_DB") or ROOT / ".setline.sqlite").expanduser()
IDENTITY_PATH = ROOT / ".setline_local.json"
UPLOADS = ROOT / "data" / "board-uploads"
NAME = "Track Studio"

_app = None          # the mounted Setline app, once `mount` has run
_host: Optional["Host"] = None


def available() -> bool:
    """Whether the board can be served: Setline's server package and its built front end."""
    return (SETLINE_HOME / "server" / "setline" / "main.py").is_file() \
        and (SETLINE_HOME / "web" / "dist" / "index.html").is_file()


def running() -> bool:
    """Whether the board is mounted in this process — which is also when `crates` uses it."""
    return _app is not None


# ---------------------------------------------------------------- who this is

def identity() -> dict:
    """This machine's member and instance, minted once and kept.

    The member is who every change made here is credited to — the person, not
    the app — and the instance is what the change log says a change came from.
    Both outlive the board's database: delete it and you start a new history,
    still as yourself."""
    try:
        data = json.loads(IDENTITY_PATH.read_text())
    except (OSError, ValueError):
        data = {}
    name = (os.environ.get("SETLINE_NAME") or "").strip()[:24]
    changed = False
    if not data.get("member"):
        data["member"] = {"id": "ts-" + secrets.token_urlsafe(8), "name": name or "Me", "color": "#ffd166"}
        changed = True
    elif name and data["member"].get("name") != name:
        data["member"]["name"] = name      # the name you go by is yours to change
        changed = True
    if not data.get("instance"):
        data["instance"] = "ts-" + uuid.uuid4().hex[:16]
        changed = True
    if not data.get("secret"):
        data["secret"] = secrets.token_urlsafe(32)
        changed = True
    if changed:
        IDENTITY_PATH.write_text(json.dumps(data, indent=1))
    return data


# ---------------------------------------------------------------- the library

def _artists(text: str) -> list[str]:
    parts = [a.strip() for a in (text or "").replace(" & ", ", ").split(",")]
    return [a for a in parts if a] or ["Unknown artist"]


def _camelot(key) -> Optional[str]:
    from microsets import _camelot_parse
    parsed = _camelot_parse(key or "")
    return f"{parsed[0]}{parsed[1]}" if parsed else None


class _Index:
    """The library, looked up the ways the board needs: by file, by key, by ISRC
    and Beatport id. Rebuilt when the library's track list changes."""

    def __init__(self) -> None:
        self.sig = None
        self.by_path: dict[str, Any] = {}
        self.by_key: dict[str, Any] = {}
        self.by_isrc: dict[str, Any] = {}
        self.by_beatport: dict[int, Any] = {}

    def fresh(self):
        import runtime
        from library import track_key
        tracks = runtime.library.tracks
        sig = (id(tracks), len(tracks))
        if sig == self.sig:
            return self
        by_path, by_key, by_isrc, by_bp = {}, {}, {}, {}
        for t in tracks:
            by_key.setdefault(track_key(t), t)
            if t.local_path:
                by_path[str(t.local_path)] = t
            # A record with a file wins the natural keys: it's the one that plays.
            if t.isrc and (t.local_path or t.isrc.upper() not in by_isrc):
                by_isrc[t.isrc.upper()] = t
            if t.beatport_id and (t.local_path or t.beatport_id not in by_bp):
                by_bp[int(t.beatport_id)] = t
        self.sig, self.by_path, self.by_key, self.by_isrc, self.by_beatport = sig, by_path, by_key, by_isrc, by_bp
        return self


def host_key(t) -> str:
    """How the board names a library track: its file, or — for one with no file
    here (a wanted Spotify row, a rekordbox entry whose file is gone) — its key."""
    from library import track_key
    return str(t.local_path) if t.local_path else "key:" + track_key(t)


# ---------------------------------------------------------------- the host

try:  # Setline on the path, if it's there; the module stays importable without it.
    if available() and str(SETLINE_HOME / "server") not in sys.path:
        sys.path.insert(0, str(SETLINE_HOME / "server"))
    from setline.local import LocalHost as _LocalHost
except Exception:  # noqa: BLE001 — no board, and everything else works
    _LocalHost = object  # type: ignore[assignment,misc]


class Host(_LocalHost):  # type: ignore[misc,valid-type]
    """What this library gives the board (Setline's `local.LocalHost`)."""

    home = "/"
    name = NAME
    many_drafts = True

    def __init__(self, ident: dict) -> None:
        from setline.auth import Member
        m = ident["member"]
        self.member = Member(id=m["id"], name=m["name"], color=m["color"], admin=True)
        self.index = _Index()
        self._links: dict[int, str] = {}      # Setline track id -> host key
        self._by_key: dict[str, int] = {}     # host key -> Setline track id
        self._loaded = False

    # -- the file behind a Setline track ----------------------------------------
    _TABLE = ("CREATE TABLE IF NOT EXISTS ts_library_links ("
              " track_id INTEGER PRIMARY KEY, key TEXT NOT NULL, isrc TEXT, beatport_id INTEGER)")

    def load_links(self, session) -> None:
        from sqlalchemy import text
        session.execute(text(self._TABLE))
        rows = session.execute(text("SELECT track_id, key FROM ts_library_links")).all()
        self._links = {int(r[0]): r[1] for r in rows}
        self._by_key = {k: i for i, k in self._links.items()}
        self._loaded = True

    def link(self, session, track_id: int, key: str) -> None:
        from sqlalchemy import text
        if not self._loaded:
            self.load_links(session)
        lt = self.library_track(key)
        session.execute(text("INSERT OR REPLACE INTO ts_library_links (track_id, key, isrc, beatport_id) "
                             "VALUES (:t, :k, :i, :b)"),
                        {"t": track_id, "k": key, "i": getattr(lt, "isrc", None),
                         "b": getattr(lt, "beatport_id", None)})
        self._links[track_id] = key
        self._by_key[key] = track_id

    def linked(self, session, key: str) -> Optional[int]:
        if not self._loaded:
            self.load_links(session)
        return self._by_key.get(key)

    def library_track(self, key: str):
        idx = self.index.fresh()
        return idx.by_key.get(key[4:]) if key.startswith("key:") else idx.by_path.get(key)

    def resolve(self, track) -> Any:
        """The library track a Setline track is: the file it was made from, else the
        same record by ISRC or Beatport id — a track found on Beatport on the board
        is still the file you own, if you own it."""
        idx = self.index.fresh()
        key = self._links.get(track.id)
        lt = self.library_track(key) if key else None
        if lt is None and track.isrc:
            lt = idx.by_isrc.get(track.isrc.upper())
        if lt is None and track.beatport_id:
            lt = idx.by_beatport.get(int(track.beatport_id))
        return lt

    # -- the library as rows ----------------------------------------------------
    def row(self, t, **extra) -> dict:
        from library import file_duration
        path = str(t.local_path) if t.local_path else None
        seconds = file_duration(t.local_path) if path else None
        return {
            "library": host_key(t), "title": t.title or "Untitled", "mix": "", "artists": _artists(t.artist),
            "bpm": round(t.bpm) if t.bpm else None, "key": _camelot(t.key), "length_ms": int((seconds or 0) * 1000),
            "genre": t.genre or t.style or None, "label": None, "isrc": t.isrc, "beatport_id": t.beatport_id,
            "energy": t.energy, "art": f"/artwork?path={quote(path, safe='')}" if path else None,
            "play": f"/media?path={quote(path, safe='')}" if path else None, **extra,
        }

    def search(self, q: str, limit: int = 40) -> list[dict]:
        import runtime
        words = [w for w in q.lower().split() if w]
        if not words:
            return []
        hits = []
        for t in runtime.library.tracks:
            if not t.local_path:
                continue  # your own files: what you can play and export
            hay = f"{t.artist} {t.title}".lower()
            if all(w in hay for w in words):
                starts = hay.startswith(words[0]) or t.title.lower().startswith(words[0])
                hits.append((0 if starts else 1, 0 if t.in_rekordbox else 1, hay, t))
            elif all(w in f"{hay} {t.genre} {t.style or ''}".lower() for w in words):
                hits.append((2, 0 if t.in_rekordbox else 1, hay, t))
        hits.sort(key=lambda h: h[:3])
        return [self.row(h[3]) for h in hits[:limit]]

    def fields(self, key: str) -> Optional[dict]:
        t = self.library_track(key)
        if t is None:
            return None
        r = self.row(t)
        # The record, as Setline will keep it — no URL that names this disk.
        return {k: r[k] for k in ("title", "mix", "artists", "bpm", "key", "length_ms", "genre", "label",
                                   "isrc", "beatport_id")} | {"art_url": None}

    # -- what the board shows and plays ----------------------------------------
    def stream(self, track) -> Optional[dict]:
        lt = self.resolve(track)
        if lt is None or not lt.local_path:
            return None
        return {"url": f"/media?path={quote(str(lt.local_path), safe='')}", "kind": "file",
                "start_ms": 0, "end_ms": None}

    def facts(self, track) -> Optional[dict]:
        lt = self.resolve(track)
        if lt is None:
            return None
        path = str(lt.local_path) if lt.local_path else None
        return {"owned": bool(path), "energy": lt.energy, "style": lt.style or None,
                "moods": list(lt.moods) or None,
                "art": f"/artwork?path={quote(path, safe='')}" if path else None}

    def night_opened(self, set_id: int) -> None:
        import runtime
        runtime.board_state["night"] = set_id

    # -- the learned model -------------------------------------------------------
    def _candidates(self):
        import runtime
        cands, _ = runtime.library.mix_tracks_from(runtime.library.tracks)
        return [c for c in cands if c.path]  # proposals you can play and export: files

    def _rows_from(self, suggestions, near: Optional[str] = None) -> list[dict]:
        idx = self.index.fresh()
        out = []
        for s in suggestions:
            t = idx.by_key.get(s.track.id)
            if t is None:
                continue
            closest = s.seed.name if getattr(s, "seed", None) is not None else near
            out.append(self.row(t, score=s.score, reason=s.reason, near=closest))
        return out

    def fill(self, crate: str, tracks: list, limit: int = 30) -> list[dict]:
        import runtime
        from library import track_key
        model = runtime.mix_model()
        held = [lt for lt in (self.resolve(t) for t in tracks) if lt is not None]
        runtime.library.hydrate_genres(held)  # the axis the ranking leans on hardest
        cands = self._candidates()
        by_id = {c.id: c for c in cands}
        seeds = [by_id[k] for k in (track_key(lt) for lt in held) if k in by_id]
        return self._rows_from(model.fill(seeds, cands, k=limit))

    def next_after(self, before, around: list, limit: int = 30) -> list[dict]:
        import runtime
        from library import Library, track_key
        cur = self.resolve(before)
        if cur is None or not cur.bpm:
            return []
        model = runtime.mix_model()
        cands = self._candidates()
        by_id = {c.id: c for c in cands}
        current = by_id.get(track_key(cur)) or Library._to_mix_track(cur)
        exclude = {track_key(lt) for lt in (self.resolve(t) for t in around) if lt is not None}
        return self._rows_from(model.next_tracks(current, cands, k=limit, exclude=exclude), near=before.title)

    # -- rekordbox --------------------------------------------------------------
    def export(self, night: str, moments: list, only: Optional[str]) -> dict:
        """The night into the one XML rekordbox's view reads (`runtime.export_path`):
        a folder named for the night, a playlist per moment led by the whole set —
        the same shape the Setline import has always written, so a re-export lands
        on the folder you delete to replace it."""
        import rbprefs
        import rekordbox_io
        import runtime
        from drives import DriveOffline
        from library import Library, track_key
        from setline.board import BoardError

        pool, by_id, missing = [], {}, []
        per_moment: list[tuple[str, list[str]]] = []
        for name, tracks in moments:
            if only is not None and name != only:
                continue
            ids: list[str] = []
            for t in tracks:
                lt = self.resolve(t)
                if lt is None or not lt.local_path:
                    missing.append(f"{', '.join(t.artists)} – {t.title}")
                    continue
                tid = track_key(lt)
                if tid not in by_id:
                    by_id[tid] = Library._to_mix_track(lt)
                    pool.append(by_id[tid])
                if tid not in ids:
                    ids.append(tid)
            if ids:
                per_moment.append((name or "—", ids))
        if not pool:
            return {"exported": 0, "missing": missing, "where": night,
                    "how": "Nothing went out: none of these tracks has a file on this machine."}
        if len(per_moment) == 1:
            playlists = [(per_moment[0][0], per_moment[0][1])]
        else:
            playlists = [("Set", [t.id for t in pool])]
            playlists += [(f"{i} · {name}", ids) for i, (name, ids) in enumerate(per_moment, 1)]
        try:
            out = runtime.export_target()
        except DriveOffline as e:
            raise BoardError(str(e)) from e
        rekordbox_io.export_folder(str(out), night, pool, playlists)
        view = rbprefs.evaluate(out)
        how = (f"In rekordbox, refresh the “rekordbox xml” tree in the sidebar and drag the “{night}” "
               "folder into your playlists — delete the previous one first if you exported before.")
        if view.state != "ok":
            how += f" (rekordbox isn't set up to read it yet: {view.detail}. Track Studio's Settings shows how.)"
        return {"exported": len(pool), "missing": missing, "where": f"the “{night}” folder", "how": how}


# ---------------------------------------------------------------- mounting

def mount(app) -> bool:
    """Serve the board at `/board` inside Track Studio's own app. False if it can't be."""
    global _app, _host
    if not available():
        print(f"[board] not mounted: no Setline at {SETLINE_HOME} (or its web/dist isn't built)")
        return False
    if _LocalHost is object:
        # Setline is there but won't import — on a Python older than 3.13, which it
        # requires. The app runs on without the board rather than not at all.
        print(f"[board] not mounted: Setline needs Python 3.13, this is {sys.version.split()[0]} "
              "(bash install.sh moves the venv over)")
        return False
    from setline.config import Settings
    from setline.main import create_app

    ident = identity()
    UPLOADS.mkdir(parents=True, exist_ok=True)
    settings = Settings(
        _env_file=None,                     # Track Studio's .env is Track Studio's
        database_url=f"sqlite:///{DB_PATH}",
        invite_code="this-machine", admin_code=ident["secret"], secret=ident["secret"],
        web_dist=SETLINE_HOME / "web" / "dist", uploads_dir=str(UPLOADS),
        instance=ident["instance"], production=False,
        # The assistant costs tokens per set and needs a key of yours; off here until asked for.
        anthropic_api_key="",
    )
    _host = Host(ident)
    _app = create_app(settings, local=_host)
    app.mount(MOUNT, _app)
    app.on_startup(_start)
    print(f"[board] Setline from {SETLINE_HOME} at {MOUNT}, data in {DB_PATH.name}")
    return True


async def _start() -> None:
    from setline.main import startup
    from starlette.concurrency import run_in_threadpool

    await startup(_app)               # a mounted app's own lifespan never runs

    def links_and_crates() -> None:
        with _app.state.db.session() as session:
            _host.load_links(session)
            session.commit()
        import_crates_json()
    await run_in_threadpool(links_and_crates)


# ---------------------------------------------------------------- the crate store
#
# `crates.py` keeps its API and stores through these once the board is mounted.
# Every write goes through Setline's door: `apply_to_shelf` for a crate's
# contents (which reaches every night using it), `apply_change` for what one
# night uses.

def _asking(op: str, payload: dict):
    from setline import api_board
    return api_board.asked.set(lambda: (f"track-studio {op}", payload))


def _shelf_change(op: str, payload: dict, apply: Callable) -> Any:
    from setline import api_board
    out: dict = {}
    token = _asking(op, payload)
    try:
        with _app.state.db.session() as session:
            api_board.apply_to_shelf(_app, session, _host.member,
                                     lambda who: apply(session, who, out), origin="track-studio")
    finally:
        api_board.asked.reset(token)
    return out.get("result")


def _night_change(night: int, op: str, payload: dict, apply: Callable) -> Any:
    from setline import api_board
    from setline import board as b
    out: dict = {}
    tokens = (b.current_set.set(night), b.current_viewer.set(None), _asking(op, payload))
    try:
        with _app.state.db.session() as session:
            api_board.apply_change(_app, session, _host.member,
                                   lambda s, who: apply(session, s, who, out), origin="track-studio")
    finally:
        b.current_set.reset(tokens[0])
        b.current_viewer.reset(tokens[1])
        api_board.asked.reset(tokens[2])
    return out.get("result")


def _item_key(track) -> str:
    """What the dock calls a crate item: the library's key for that record, else
    the Setline track's own (one found on Beatport on the board, with no file here)."""
    from library import track_key
    lt = _host.resolve(track)
    return track_key(lt) if lt is not None else f"setline:{track.id}"


def shelf(night: Optional[int] = None) -> list:
    """The crates as `crates.Crate` views: the ones a night uses, in its order, or
    the whole shelf oldest first. Each says which nights use it (`nights`)."""
    import crates
    from setline import board as b
    from setline import models as m
    from sqlalchemy import select

    with _app.state.db.session() as session:
        if night is not None:
            s = session.get(m.Set, night)
            rows = b.crates_of(session, s) if s is not None else []
        else:
            rows = b.shelf_of(session, None)
        uses: dict[str, list[int]] = {}
        for set_id, crate_id in session.execute(select(m.SetCrate.set_id, m.SetCrate.crate_id)).all():
            uses.setdefault(crate_id, []).append(set_id)
        out = []
        for c in rows:
            items = [crates.Item(id=i.id, track_key=_item_key(i.track), added_at=i.added_at.timestamp(),
                                 added_by=i.added_by or crates.LOCAL_AUTHOR, title=i.track.title,
                                 artist=", ".join(i.track.artists), bpm=i.track.bpm, key=i.track.key)
                     for i in c.items]
            out.append(crates.Crate(id=c.id, name=c.name, created_at=c.created_at.timestamp(),
                                    updated_at=max([c.created_at.timestamp()] + [x.added_at for x in items]),
                                    created_by=c.created_by or crates.LOCAL_AUTHOR, items=items,
                                    nights=uses.get(c.id, [])))
        session.commit()
    return out


def nights() -> list[tuple[int, str, bool]]:
    """(id, name, archived) of every night, newest first — for naming the open one."""
    from setline import board as b
    with _app.state.db.session() as session:
        rows = [(s.id, s.name, s.archived_at is not None) for s in b.sets_of(session)]
        session.commit()
    return rows


def _library_ref(session, who, track_key_: str):
    """A Setline track for a library key, made (and linked to its file) if new."""
    from setline import api_board
    idx = _host.index.fresh()
    lt = idx.by_key.get(track_key_)
    if lt is None:
        return None
    return api_board.library_track(_app, session, who, host_key(lt))


def create(name: str, night: Optional[int] = None, crate_id: Optional[str] = None) -> str:
    """A crate on the shelf — used by `night` from the start when one is given."""
    from setline import board as b
    from setline import models as m
    clean = " ".join((name or "").split())[:60] or "Untitled"
    cid = crate_id or uuid.uuid4().hex
    if night is not None:
        def on_night(session, s, who, out):
            b.add_crate(session, s, client_id=cid, name=clean, who=who)
            return ["started the crate ", {"b": clean}]
        _night_change(night, "crates.create", {"name": clean, "id": cid}, on_night)
        return cid

    def on_shelf(session, who, out):
        session.add(m.Crate(id=cid, name=clean, created_by=who.id))
        return None
    _shelf_change("crates.create", {"name": clean, "id": cid}, on_shelf)
    return cid


def rename(crate_id: str, name: str) -> None:
    from setline import models as m
    clean = " ".join((name or "").split())[:60]
    if not clean:
        return

    def apply(session, who, out):
        c = session.get(m.Crate, crate_id)
        if c is None or c.name == clean:
            return None
        old, c.name = c.name, clean
        return ["renamed the crate ", {"b": old}, " to ", {"b": clean}]
    _shelf_change("crates.rename", {"id": crate_id, "name": clean}, apply)


def delete(crate_id: str) -> None:
    """Off the shelf, and so off every night using it."""
    from setline import models as m

    def apply(session, who, out):
        c = session.get(m.Crate, crate_id)
        if c is None:
            return None
        name = c.name
        session.delete(c)
        return ["deleted the crate ", {"b": name}]
    _shelf_change("crates.delete", {"id": crate_id}, apply)


def add(crate_id: str, track_keys: list[str], item_ids: Optional[list[str]] = None) -> int:
    """Put library tracks in a crate; how many were new. A key the library no longer
    has is skipped — there is no record to put in."""
    from setline import board as b
    from setline import models as m

    def apply(session, who, out):
        c = session.get(m.Crate, crate_id)
        if c is None:
            out["result"] = 0
            return None
        have = {i.track_id for i in c.items}
        fresh = []
        for n, key in enumerate(track_keys):
            t = _library_ref(session, who, key)
            if t is None or t.id in have:
                continue
            have.add(t.id)
            item_id = (item_ids[n] if item_ids and n < len(item_ids) else None) or b.new_id()
            session.add(m.CrateItem(id=item_id, crate_id=c.id, track_id=t.id, added_by=who.id))
            fresh.append(t)
        out["result"] = len(fresh)
        if not fresh:
            return None
        what = {"b": b.display_title(fresh[0])} if len(fresh) == 1 else {"b": f"{len(fresh)} tracks"}
        return ["added ", what, " to ", {"b": c.name}]
    return _shelf_change("crates.add", {"id": crate_id, "keys": list(track_keys)}, apply) or 0


def remove(crate_id: str, track_keys: list[str]) -> int:
    from setline import board as b
    from setline import models as m
    wanted = set(track_keys)

    def apply(session, who, out):
        c = session.get(m.Crate, crate_id)
        if c is None:
            out["result"] = 0
            return None
        going = [i for i in c.items if _item_key(i.track) in wanted]
        for i in going:
            session.delete(i)
        out["result"] = len(going)
        if not going:
            return None
        what = {"b": b.display_title(going[0].track)} if len(going) == 1 else {"b": f"{len(going)} tracks"}
        return ["removed ", what, " from ", {"b": c.name}]
    return _shelf_change("crates.remove", {"id": crate_id, "keys": list(track_keys)}, apply) or 0


def attach(crate_id: str, night: int) -> bool:
    """This night starts using the crate (the dock's "on tonight")."""
    from setline import board as b
    from setline import models as m

    def apply(session, s, who, out):
        c = session.get(m.Crate, crate_id)
        if c is None:
            raise b.NotFound("That crate was deleted.")
        out["result"] = b.attach_crate(session, s, c, who)
        return ["put the crate ", {"b": c.name}, " on this night"] if out["result"] else None
    return bool(_night_change(night, "crates.attach", {"id": crate_id}, apply))


def detach(crate_id: str, night: int) -> None:
    from setline import board as b

    def apply(session, s, who, out):
        return ["took the crate ", {"b": b.detach_crate(session, s, crate_id).name}, " off this night"]
    _night_change(night, "crates.detach", {"id": crate_id}, apply)


# ---------------------------------------------------------------- .crates.json comes over

_IMPORT_TABLE = "CREATE TABLE IF NOT EXISTS ts_imported (id TEXT PRIMARY KEY)"
_import_lock = threading.Lock()


def import_crates_json() -> dict:
    """Bring `.crates.json`'s crates onto the board's shelf, once each.

    By id — the JSON store's uuids become the crates' and items' own — and only
    what is still live there; a crate or item already brought over is never
    brought again, so deleting one on the board doesn't resurrect it at the next
    launch. The file itself is left alone: it is the record of what was, readable
    in a text editor, and nothing writes it once the board is running.
    Returns what happened, for the log."""
    import crates
    from setline import models as m
    from sqlalchemy import text

    if not crates.CRATES_PATH.exists():
        return {}
    with _import_lock:
        old = crates.live(crates.load_json())
        with _app.state.db.session() as session:
            session.execute(text(_IMPORT_TABLE))
            done = {r[0] for r in session.execute(text("SELECT id FROM ts_imported")).all()}
            session.commit()
        report = {"crates": 0, "items": 0, "missing": 0}
        for c in old:
            todo = [i for i in c.tracks if i.id not in done]
            if c.id in done and not todo:
                continue

            def apply(session, who, out, c=c, todo=todo):
                from datetime import datetime, timezone
                crate = session.get(m.Crate, c.id)
                if crate is None and c.id not in done:
                    crate = m.Crate(id=c.id, name=c.name[:60] or "Untitled", created_by=who.id,
                                    created_at=datetime.fromtimestamp(c.created_at or 0, timezone.utc))
                    session.add(crate)
                    session.flush()
                    report["crates"] += 1
                marks = [c.id]
                have = {i.track_id for i in crate.items} if crate is not None else set()
                for item in todo:
                    marks.append(item.id)
                    t = _library_ref(session, who, item.track_key) if crate is not None else None
                    if t is None:
                        report["missing"] += 1
                        continue
                    if t.id in have:
                        continue
                    have.add(t.id)
                    session.add(m.CrateItem(id=item.id, crate_id=crate.id, track_id=t.id, added_by=who.id,
                                            added_at=datetime.fromtimestamp(item.added_at or 0, timezone.utc)))
                    report["items"] += 1
                for mark in marks:
                    session.execute(text("INSERT OR IGNORE INTO ts_imported (id) VALUES (:i)"), {"i": mark})
                return None
            _shelf_change("crates.import", {"id": c.id}, apply)
    if any(report.values()):
        print(f"[board] crates from .crates.json: {report}")
    return report


if __name__ == "__main__":       # the board against the live library, on a throwaway database
    import logging
    import tempfile
    import time

    logging.getLogger("httpx").setLevel(logging.WARNING)
    tmp = Path(tempfile.mkdtemp(prefix="board-selftest-"))
    os.environ["TRACK_STUDIO_EXPORT_FILE"] = str(tmp / "track-studio.xml")   # never rekordbox's own file
    DB_PATH = tmp / "board.sqlite"
    if not available():
        raise SystemExit(f"no Setline at {SETLINE_HOME} (or web/dist isn't built)")

    import runtime
    from fastapi.testclient import TestClient
    from setline.config import Settings
    from setline.main import create_app

    t0 = time.time()
    runtime._bootstrap()
    print(f"library: {len(runtime.library.tracks)} tracks ({time.time() - t0:.1f}s)")
    ident = identity()
    _host = Host(ident)
    _app = create_app(Settings(_env_file=None, database_url=f"sqlite:///{DB_PATH}", invite_code="self-test",
                               secret="s" * 40, web_dist=SETLINE_HOME / "web" / "dist", production=False,
                               instance=ident["instance"], anthropic_api_key=""), local=_host)
    with TestClient(_app) as c:
        def ok(r):
            assert r.status_code == 200, r.text
            return r.json()
        with _app.state.db.session() as session:
            _host.load_links(session)
            session.commit()
        print(f"me: {ok(c.get('/api/me'))['name']} · board version {ok(c.get('/api/board'))['version']}")
        hits = ok(c.get("/api/library/search", params={"q": "justice"}))["results"]
        print(f"search 'justice': {len(hits)} files, e.g. {[h['title'] for h in hits[:3]]}")
        board = ok(c.post("/api/crates", json={"id": "selftest-crate-01", "name": "Self-test"}))
        for h in hits[:3]:
            board = ok(c.post("/api/crates/selftest-crate-01/items", json={"track": {"library": h["library"]}}))
        items = board["crates"][0]["items"]
        print(f"crate: {[i['track']['title'] for i in items]} · owned {[i['track'].get('local', {}).get('owned') for i in items]}")
        t1 = time.time()
        fill = ok(c.get("/api/library/fill", params={"crate": "selftest-crate-01"}))["results"]
        print(f"fill: {len(fill)} proposals in {time.time() - t1:.1f}s, top {[(f['title'], f['score']) for f in fill[:3]]}")
        peak = next(m["id"] for m in board["moments"] if m["name"] == "Peak")
        for n, i in enumerate(items):
            board = ok(c.post("/api/entries", json={"track": {"track_id": i["track"]["id"]}, "moment": peak, "index": n}))
        nxt = ok(c.get("/api/library/next", params={"entry": board["entries"][0]["id"]}))["results"]
        print(f"next after {board['entries'][0]['track']['title']}: {[n['title'] for n in nxt[:3]]}")
        stream = ok(c.get(f"/api/tracks/{items[0]['track']['id']}/stream"))
        print(f"plays from: {stream['kind']} {stream['url'][:60]}…")
        out = ok(c.post("/api/library/export", json={}))
        print(f"export: {out['exported']} tracks as {out['where']} → {os.environ['TRACK_STUDIO_EXPORT_FILE']}")
        with _app.state.db.session() as session:
            from setline import models as m
            print(f"change log: {session.query(m.Change).count()} rows; "
                  f"paths in tracks table: {sum(1 for t in session.query(m.Track) if '/' in (t.art_url or ''))}")
