"""Send tracks prepared in Track Studio to a crate in Setline.

The other direction from `setline_import`: you dig and listen here, then send a
Build set or block to a crate in Setline, new or existing. Setline matches each
track as exactly as this side can name it (Beatport id, then ISRC, then artist
and title), types in whatever Beatport doesn't have, and makes it one change
credited to you.

Needs, in .env:
  SETLINE_URL    the Setline site, e.g. https://setline.up.railway.app
  SETLINE_TOKEN  the Setline service's SETLINE_MCP_TOKEN
  SETLINE_NAME   optional: your name in Setline, so the change is credited to you

    venv/bin/python setline_push.py     # checks the connection and lists the crates
"""
from __future__ import annotations

import os
import re

import requests

# Setline looks each track up on Beatport before it answers: allow a big block time.
TIMEOUT = 180
CAMELOT = re.compile(r"(1[0-2]|[1-9])[AB]")


class SetlineUnavailable(RuntimeError):
    """Setline isn't configured or refused; the message says what to fix."""


def configured() -> bool:
    return bool(os.environ.get("SETLINE_URL") and os.environ.get("SETLINE_TOKEN"))


def _request(method: str, path: str, **kwargs) -> dict:
    url = os.environ.get("SETLINE_URL", "").rstrip("/")
    token = os.environ.get("SETLINE_TOKEN", "")
    if not url or not token:
        raise SetlineUnavailable("Add SETLINE_URL and SETLINE_TOKEN to .env to send tracks to Setline.")
    try:
        r = requests.request(method, f"{url}{path}", headers={"Authorization": f"Bearer {token}"},
                             timeout=TIMEOUT, **kwargs)
    except requests.RequestException as exc:
        raise SetlineUnavailable(f"Couldn't reach Setline at {url}.") from exc
    if r.status_code == 401:
        raise SetlineUnavailable("Setline refused the token: SETLINE_TOKEN must match its SETLINE_MCP_TOKEN.")
    if r.status_code == 404:
        raise SetlineUnavailable("Setline isn't taking tracks: set SETLINE_MCP_TOKEN on the Setline service, "
                                 "and check SETLINE_URL.")
    if r.status_code >= 400:
        try:
            detail = r.json().get("detail")
        except ValueError:
            detail = None
        raise SetlineUnavailable(detail if isinstance(detail, str) else f"Setline answered with an error ({r.status_code}).")
    return r.json()


def crates() -> list[dict]:
    """Setline's crates, newest last: [{"name", "tracks"}]."""
    return _request("GET", "/api/import/crates")["crates"]


def payload(tracks, library_tracks) -> list[dict]:
    """Build's tracks (`microsets.Track`), with the Beatport id and ISRC the library knows for them."""
    from setline_import import set_track_id

    known: dict[str, object] = {}
    for t in library_tracks:
        known.setdefault(set_track_id(t), t)
    out = []
    for mt in tracks:
        lib = known.get(mt.id)
        key = (mt.key or "").strip().upper()
        artist = (getattr(lib, "artist", "") or mt.artist or "").strip()
        out.append({
            "beatport_id": getattr(lib, "beatport_id", None),
            "isrc": getattr(lib, "isrc", None) or None,
            "title": ((getattr(lib, "title", "") or mt.name or "Untitled").strip())[:300],
            # Split only on commas: "Above & Beyond" is one artist. Setline matches on the names together.
            "artists": [a.strip()[:120] for a in artist.split(",") if a.strip()][:10],
            "bpm": round(mt.bpm) if mt.bpm and 40 <= mt.bpm <= 250 else None,
            "key": key if CAMELOT.fullmatch(key) else None,
        })
    return out


def send(crate: str, tracks, library_tracks) -> dict:
    """Send tracks to the crate called `crate` (made if it doesn't exist). Returns Setline's summary:
    crate, created, added, already, on_beatport, typed_in (names), matched_by, credited."""
    body = {"crate": crate.strip()[:60], "by": (os.environ.get("SETLINE_NAME") or "").strip()[:24] or None,
            "tracks": payload(tracks, library_tracks)}
    if not body["tracks"]:
        raise SetlineUnavailable("Nothing to send.")
    return _request("POST", "/api/import/crate", json=body)


def describe(result: dict) -> str:
    """The summary in one sentence, for a notification."""
    added, crate = result["added"], result["crate"]
    tracks = f"{added} track{'s' if added != 1 else ''}"
    words = f"Started {crate} in Setline with {tracks}" if result["created"] else f"Added {tracks} to {crate} in Setline"
    notes = []
    if result.get("already"):
        notes.append(f"{result['already']} already there")
    if result.get("typed_in"):
        notes.append(f"{len(result['typed_in'])} not on Beatport, typed in")
    return words + (f" ({', '.join(notes)})" if notes else "") + "."


if __name__ == "__main__":
    import config

    config.load_env()
    if not configured():
        raise SystemExit("Set SETLINE_URL and SETLINE_TOKEN in .env first.")
    for c in crates():
        print(f"{c['tracks']:4d}  {c['name']}")
