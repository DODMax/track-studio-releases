"""Ed25519 signing — the trust anchor under the self-updater.

The update manifest and the zip it points at are served from the same public
place, so a hash in the manifest only proves the download wasn't truncated: it
says nothing about who wrote it. A signature made by a key that never lives in
that repo is what actually makes "a dumb file host" safe, which is the same
choice Sparkle (`sparkle:edSignature`) and Tauri's updater make.

**What is signed is `"<version>\\n<sha256-of-the-zip>"`**, not the zip alone.
Signing the payload by itself leaves the manifest free to point a version number
at any *other* validly-signed zip; binding the two means a swapped url fails the
check. `updates.verify_release` is the only reader.

Deliberately dependency-free (the RFC 8032 reference code, public domain), so
the one component that must keep working when everything else is mid-upgrade
can't be broken by a package install. Verification costs ~15 ms, once per check.
"""
from __future__ import annotations

import base64
from hashlib import sha512

# --- RFC 8032 reference implementation (ed25519), verbatim in structure -------

P = 2 ** 255 - 19
Q = 2 ** 252 + 27742317777372353535851937790883648493


def _modp_inv(x: int) -> int:
    return pow(x, P - 2, P)


D = -121665 * _modp_inv(121666) % P
_MODP_SQRT_M1 = pow(2, (P - 1) // 4, P)


def _recover_x(y: int, sign: int) -> int | None:
    if y >= P:
        return None
    x2 = (y * y - 1) * _modp_inv(D * y * y + 1)
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (P + 3) // 8, P)
    if (x * x - x2) % P != 0:
        x = x * _MODP_SQRT_M1 % P
    if (x * x - x2) % P != 0:
        return None
    if (x & 1) != sign:
        x = P - x
    return x


_G_Y = 4 * _modp_inv(5) % P
_G_X = _recover_x(_G_Y, 0)
G = (_G_X, _G_Y, 1, _G_X * _G_Y % P)

Point = tuple


def _point_add(p1: Point, p2: Point) -> Point:
    a = (p1[1] - p1[0]) * (p2[1] - p2[0]) % P
    b = (p1[1] + p1[0]) * (p2[1] + p2[0]) % P
    c = 2 * p1[3] * p2[3] * D % P
    dd = 2 * p1[2] * p2[2] % P
    e, f, g, h = b - a, dd - c, dd + c, b + a
    return (e * f, g * h, f * g, e * h)


def _point_mul(s: int, p1: Point) -> Point:
    out = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            out = _point_add(out, p1)
        p1 = _point_add(p1, p1)
        s >>= 1
    return out


def _point_equal(p1: Point, p2: Point) -> bool:
    if (p1[0] * p2[2] - p2[0] * p1[2]) % P != 0:
        return False
    return (p1[1] * p2[2] - p2[1] * p1[2]) % P == 0


def _point_compress(p1: Point) -> bytes:
    zinv = _modp_inv(p1[2])
    x = p1[0] * zinv % P
    y = p1[1] * zinv % P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _point_decompress(s: bytes) -> Point | None:
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % P)


def _sha512_modq(s: bytes) -> int:
    return int.from_bytes(sha512(s).digest(), "little") % Q


def _secret_expand(secret: bytes) -> tuple[int, bytes]:
    h = sha512(secret).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_from_secret(secret: bytes) -> bytes:
    a, _ = _secret_expand(secret)
    return _point_compress(_point_mul(a, G))


def sign(secret: bytes, msg: bytes) -> bytes:
    a, prefix = _secret_expand(secret)
    pub = _point_compress(_point_mul(a, G))
    r = _sha512_modq(prefix + msg)
    rs = _point_compress(_point_mul(r, G))
    h = _sha512_modq(rs + pub + msg)
    s = (r + h * a) % Q
    return rs + int.to_bytes(s, 32, "little")


def verify(public: bytes, msg: bytes, signature: bytes) -> bool:
    if len(public) != 32 or len(signature) != 64:
        return False
    a = _point_decompress(public)
    if not a:
        return False
    rs = signature[:32]
    s = int.from_bytes(signature[32:], "little")
    if s >= Q:
        return False
    r = _point_decompress(rs)
    if not r:
        return False
    h = _sha512_modq(rs + public + msg)
    return _point_equal(_point_mul(s, G), _point_add(r, _point_mul(h, a)))


# --- what the updater and the release script actually call -------------------

def release_message(version: str, sha256: str) -> bytes:
    """The bytes a release signature covers: the version bound to its payload."""
    return f"{version}\n{sha256}".encode()


def b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode()


def unb64(text: str) -> bytes:
    try:
        return base64.b64decode(text.strip(), validate=True)
    except Exception:
        return b""
