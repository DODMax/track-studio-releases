"""Spotify client — read the user's playlists and their tracks (with ISRC).

Uses spotipy's Authorization Code flow. The first run opens a browser for a
one-time consent; the refresh token is cached in .spotify_token.json (gitignored)
so every later run is headless.

    sp = Spotify()
    for pl in sp.list_playlists():
        print(pl.id, pl.name, pl.track_count)
    tracks = sp.playlist_tracks(playlist_id)

ISRC is the cross-platform key we match on against Beatport; it comes from each
track's external_ids.isrc.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import spotipy
from spotipy.oauth2 import SpotifyOAuth

from config import ROOT, load_env, require

# Read-only access to the signed-in user's own playlists, including private and
# collaborative ones.
SCOPES = "playlist-read-private playlist-read-collaborative"
TOKEN_CACHE = ROOT / ".spotify_token.json"


@dataclass
class SpotifyPlaylist:
    id: str
    name: str
    track_count: int
    owner: str


@dataclass
class SpotifyTrack:
    id: str
    name: str
    artists: list[str]
    isrc: Optional[str]
    duration_ms: int
    album: str
    url: str

    @property
    def display(self) -> str:
        return f"{', '.join(self.artists)} - {self.name}"


def _parse_track(item: dict) -> Optional[SpotifyTrack]:
    """Map a playlist item -> SpotifyTrack. Returns None for non-track items
    (local files, removed tracks, podcast episodes)."""
    # Spotify's /items endpoint nests the entry under "item"; older payloads
    # used "track". Accept either.
    t = item.get("track") or item.get("item") or {}
    # Local files and unavailable tracks have no id; episodes have type 'episode'.
    if not t.get("id") or t.get("type") not in (None, "track"):
        return None
    return SpotifyTrack(
        id=t["id"],
        name=t.get("name", ""),
        artists=[a.get("name", "") for a in t.get("artists", [])],
        isrc=(t.get("external_ids") or {}).get("isrc"),
        duration_ms=t.get("duration_ms", 0),
        album=(t.get("album") or {}).get("name", ""),
        url=(t.get("external_urls") or {}).get("spotify", ""),
    )


class Spotify:
    def __init__(self) -> None:
        load_env()
        auth = SpotifyOAuth(
            client_id=require("SPOTIFY_CLIENT_ID"),
            client_secret=require("SPOTIFY_CLIENT_SECRET"),
            redirect_uri=require("SPOTIFY_REDIRECT_URI"),
            scope=SCOPES,
            cache_path=str(TOKEN_CACHE),
            open_browser=True,
        )
        self._sp = spotipy.Spotify(auth_manager=auth)

    def me(self) -> str:
        return self._sp.me()["display_name"]

    def list_playlists(self) -> list[SpotifyPlaylist]:
        """All playlists visible to the user, paging through results."""
        out: list[SpotifyPlaylist] = []
        page = self._sp.current_user_playlists(limit=50)
        while page:
            for pl in page["items"]:
                # Spotify occasionally returns null / sparse entries in this list.
                if not pl or not pl.get("id"):
                    continue
                # The track count lives under `tracks.total` per the docs, but
                # this endpoint now returns it under `items.total` for some
                # accounts — accept either so the count isn't stuck at 0.
                count_obj = pl.get("tracks") or pl.get("items") or {}
                out.append(SpotifyPlaylist(
                    id=pl["id"],
                    name=pl.get("name", ""),
                    track_count=count_obj.get("total", 0),
                    owner=(pl.get("owner") or {}).get("display_name", ""),
                ))
            page = self._sp.next(page) if page.get("next") else None
        return out

    def playlist_tracks(self, playlist_id: str) -> list[SpotifyTrack]:
        """Ordered tracks of a playlist. Skips local files / unavailable items."""
        out: list[SpotifyTrack] = []
        # Limit the payload to the fields we use. The current API keys each
        # entry under "item"; request both so older/newer shapes both work.
        fields = (
            "items(item(id,name,type,duration_ms,external_ids,external_urls,"
            "artists(name),album(name))),next"
        )
        page = self._sp.playlist_items(playlist_id, fields=fields, limit=100)
        while page:
            for item in page["items"]:
                tr = _parse_track(item)
                if tr:
                    out.append(tr)
            page = self._sp.next(page) if page.get("next") else None
        return out


if __name__ == "__main__":
    import sys

    sp = Spotify()
    print(f"authenticated as: {sp.me()}", flush=True)
    pls = sp.list_playlists()
    print(f"{len(pls)} playlists:")
    for pl in pls[:30]:
        print(f"  [{pl.id}] {pl.name}  ({pl.track_count} tracks, owner={pl.owner})")

    if len(sys.argv) > 1:
        pid = sys.argv[1]
        print(f"\ntracks of {pid}:")
        for t in sp.playlist_tracks(pid):
            print(f"  {t.display}  | isrc={t.isrc} dur={t.duration_ms}ms")
