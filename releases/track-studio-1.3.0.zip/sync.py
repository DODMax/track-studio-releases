"""Sync service — compute the Spotify→rekordbox gap for a bound source.

For each track in a Spotify playlist, two independent signals:
  - Collection: is it anywhere in the rekordbox library?  have / review / missing
  - Set:        is it in the paired rekordbox playlist?     in / out / n_a

Both are fuzzy artist+title matches (rekordbox has no ISRC). `high` confidence is
trusted as a hit; `medium`/`low` is a hit flagged for review; `none` is a true
miss. The "missing from collection" rows are the download worklist.

**A name match is checked against the two lengths before it counts as "have".**
`match._norm_part` strips "Extended Mix" and "Radio Edit" as generic qualifiers
by design, so a 3½-minute edit in the collection scores 100 against the
6-minute version the playlist actually wants — and calling that "have" is how
the better record silently never gets offered. Spotify gives a duration and the
matched file has one, so `dupes.different_edit` settles it and the row goes
back on the download worklist as `other_edit`. Same blind spot that, pointed the
other way, would have had Incoming discard the extended as a duplicate.
Only when the collection's copy is the shorter one, though: the reverse (you own
the extended, the playlist has the radio edit) is "have", or the worklist fills
up with records you already own in their better cut.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from dupes import different_edit, isrc_index as _isrc_index
from library import Library, Track, file_duration
from match import Match, match_track, prep_choices
from spotify import SpotifyTrack


@dataclass
class SyncRow:
    spotify: Optional[SpotifyTrack]
    collection: str               # have / review / missing
    collection_match: Optional[Track]
    collection_score: float
    in_set: str                   # in / out / n_a
    set_match: Optional[Track]
    downloaded: bool = False      # have a local file (not yet in rekordbox)
    local_match: Optional[Track] = None   # the downloaded local Track, if any
    in_spotify: bool = True       # False = in the rekordbox set but not the Spotify source
    # A Beatport sample clip for a row we have no file for — fetched one row at
    # a time, on demand, because it costs a catalog search each and a missing
    # playlist is fifty of them. `preview_checked` is what stops a row that
    # Beatport doesn't carry from offering the button again on every re-render.
    preview_url: Optional[str] = None
    preview_checked: bool = False
    # The collection's copy is a *different edit* of this track — it matched on
    # name, but the two lengths are too far apart to be the same record (see
    # `dupes.different_edit`). Almost always a radio edit sitting where the
    # extended belongs, because `match._norm_part` strips both qualifiers as
    # noise, so the two score 100 against each other.
    other_edit: bool = False
    collection_s: Optional[float] = None   # length of the collection's copy

    @property
    def needs_source(self) -> bool:
        """Is there a record here we haven't got?

        `other_edit` counts, and that is the whole point of it: owning a
        3½-minute edit is not owning the 6-minute one, and treating it as
        "have" is how the better version silently never gets offered. This is
        the same blind spot that, pointed the other way, would have had
        Incoming discard the extended as a duplicate.
        """
        if self.other_edit:
            return True
        return self.collection == "missing" and not self.downloaded

    @property
    def needs_add_to_set(self) -> bool:
        # Have it in the library, but it's not in the paired set.
        return self.in_set == "out" and self.collection in ("have", "review")

    @property
    def pipeline(self) -> str:
        """Sourcing pipeline: missing -> downloaded -> in_rekordbox.

        A row whose collection copy is another edit isn't in rekordbox at all,
        so its download is a download. Calling it "in_rekordbox" made the
        export default it out as a track pulled from the set — the very file
        that was fetched for it, while the button counted it as ready to send.
        """
        if self.other_edit:
            return "downloaded" if self.downloaded else "missing"
        if self.collection in ("have", "review"):
            return "in_rekordbox"
        return "downloaded" if self.downloaded else "missing"


def _state_from(match: Match) -> str:
    if not match.hit:
        return "miss"
    return "ok" if match.confidence == "high" else "review"


def _length_of(track, cache: dict) -> Optional[float]:
    """A matched track's length, read once per file per `compute_sync` call.

    A playlist can match the same collection track from several rows, and a
    header read is cheap but not free.
    """
    p = track.local_path
    if not p:
        return None
    key = str(p)
    if key not in cache:
        cache[key] = file_duration(p)
    return cache[key]


def compute_sync(spotify_tracks: list[SpotifyTrack], library: Library,
                 paired_rb_id: Optional[str] = None,
                 cutoff: float = 78.0) -> list[SyncRow]:
    """Match each Spotify track against the rekordbox collection and paired set.

    Matching scores title and artist separately (see match.match_track) so a
    shared artist or a single common title word can't manufacture a match —
    genuinely different tracks fall through to 'missing' and are sourced from
    Beatport instead of being wrongly treated as already in the collection.
    """
    rb_tracks = [t for t in library.tracks if t.in_rekordbox]
    coll_choices = prep_choices((t.artist, t.title) for t in rb_tracks)
    coll_isrc = _isrc_index(rb_tracks)

    # A pairing whose playlist isn't there is a set we can't see, not an empty
    # one. Read as empty, every owned track came out "not in set", defaulted
    # out of the export, and the export carried the new downloads alone —
    # which, imported over the playlist, empties it of everything else.
    if paired_rb_id and paired_rb_id not in library.rekordbox_index:
        paired_rb_id = None
    paired_tracks = library.tracks_in_playlist(paired_rb_id) if paired_rb_id else []
    set_choices = prep_choices((t.artist, t.title) for t in paired_tracks)
    set_isrc = _isrc_index(paired_tracks)

    # Local files we have but rekordbox doesn't (e.g. freshly downloaded).
    local_tracks = [t for t in library.tracks if t.local_path and not t.in_rekordbox]
    local_choices = prep_choices((t.artist, t.title) for t in local_tracks)
    local_isrc = _isrc_index(local_tracks)

    rows: list[SyncRow] = []
    lengths: dict = {}                  # matched file path -> seconds
    matched_set_idx: set[int] = set()   # paired-set tracks covered by a Spotify row
    for sp in spotify_tracks:
        qa, qt = ", ".join(sp.artists), sp.name
        isrc = (sp.isrc or "").upper() or None   # exact id when both sides have it

        # --- collection: ISRC exact first, then fuzzy title/artist ---
        ci = coll_isrc.get(isrc) if isrc else None
        by_isrc = ci is not None
        if by_isrc:
            collection, coll_match, coll_score = "have", rb_tracks[ci], 100.0
        else:
            cm = match_track(qa, qt, coll_choices, cutoff=cutoff)
            collection = {"miss": "missing", "review": "review",
                          "ok": "have"}[_state_from(cm)]
            coll_match = rb_tracks[cm.target_index] if cm.hit else None
            coll_score = cm.score

        # --- is the collection's copy the same edit? ---
        # Only worth asking of a fuzzy hit: an ISRC match is identity. Keyed on
        # *how* it matched, never on the score — a perfect name match scores
        # 100 too, and "Beyond Beliefs" against "Beyond Beliefs (Extended Mix)"
        # is exactly the case this exists for, so a score test would skip the
        # ones that matter most. Cheap: one header read per distinct matched
        # file, cached, and only for rows that matched something at all.
        #
        # One way only: the collection's copy has to be the *shorter* one.
        # Owning the 7-minute extended is owning the record, and a playlist
        # that happens to carry the radio edit is no reason to fetch it again —
        # the fetch prefers the extended (`bpdl.version_rank`), so it would
        # download the very file you have.
        other_edit, coll_s = False, None
        if coll_match is not None and not by_isrc:
            coll_s = _length_of(coll_match, lengths)
            sp_s = sp.duration_ms / 1000.0
            other_edit = different_edit(sp_s, coll_s) and coll_s < sp_s

        # --- local downloaded files (only matters when not in rekordbox) ---
        downloaded, local_match = False, None
        if coll_match is None or other_edit:
            li = local_isrc.get(isrc) if isrc else None
            if li is not None:
                downloaded, local_match = True, local_tracks[li]
            elif local_choices:
                lm = match_track(qa, qt, local_choices, cutoff=cutoff)
                downloaded = lm.hit
                local_match = local_tracks[lm.target_index] if lm.hit else None

        # --- paired set membership ---
        if not paired_rb_id:
            in_set, set_match = "n_a", None
        else:
            si = set_isrc.get(isrc) if isrc else None
            if si is None:
                sm = match_track(qa, qt, set_choices, cutoff=cutoff)
                si = sm.target_index if sm.hit else None
            if si is not None:
                in_set, set_match = "in", paired_tracks[si]
                matched_set_idx.add(si)
            else:
                in_set, set_match = "out", None

        rows.append(SyncRow(
            spotify=sp,
            collection=collection,
            collection_match=coll_match,
            collection_score=coll_score,
            in_set=in_set,
            set_match=set_match,
            downloaded=downloaded,
            local_match=local_match,
            other_edit=other_edit,
            collection_s=coll_s,
        ))

    # Tracks in the rekordbox set that no Spotify track matched: they were taken
    # out of the Spotify source but still live in the playlist. Surface them so
    # they aren't silently clipped from the export (default: keep them).
    for idx, pt in enumerate(paired_tracks):
        if idx in matched_set_idx:
            continue
        rows.append(SyncRow(
            spotify=None,
            collection="have",
            collection_match=pt,
            collection_score=100.0,
            in_set="in",
            set_match=pt,
            in_spotify=False,
        ))
    return rows


REKORDBOX_ORDER, SPOTIFY_ORDER = "rekordbox", "spotify"


def _exported_as(row: SyncRow) -> Optional[Track]:
    """The track a row goes over as.

    A row the set already holds goes as **the set's own entry**, not whatever
    the collection match found: with two copies of a record in the collection
    the two can differ, and writing the other copy swaps the entry under the
    playlist. A file downloaded for a row whose collection copy is another
    edit goes as the download — that is what it was fetched for.
    """
    if row.in_set == "in" and row.set_match is not None:
        return row.set_match
    if row.local_match is not None and (row.other_edit or row.collection_match is None):
        return row.local_match
    return row.collection_match or row.local_match


def export_tracks(rows: list[SyncRow], keep, playlist: list[Track],
                  order: str = REKORDBOX_ORDER) -> tuple[list[Track], list[Track]]:
    """What a synced playlist's export carries, in order — and what it drops.

    `keep(i, row)` is the Set decision. `playlist` is the rekordbox playlist
    the import will replace (`Library.playlist_entries`), in its own order.

    rekordbox order keeps the playlist as it was arranged there and puts
    what's new at the end, in the source's order; Spotify order is the
    source's order, with what lives only in rekordbox at the end.

    The second list is the point of the function. Importing an xml playlist
    *replaces* the one of that name, so an entry the export doesn't carry
    leaves the playlist. That is fine when someone unticked it; it is data
    loss when it went quietly because the xml can't name it — a Tidal stream,
    a path from Windows. Those are returned so the caller can ask first.
    """
    pos: dict[str, int] = {}
    for k, t in enumerate(playlist):
        pos.setdefault(t.rekordbox_id, k)

    kept, taken_out = [], set()
    for i, r in enumerate(rows):
        t = _exported_as(r)
        if t is None:
            continue
        if r.in_set != "n_a" and not keep(i, r):
            taken_out.add(t.rekordbox_id)
            continue
        kept.append((i, r, t))

    def _rekordbox(e):
        i, _r, t = e
        return (0, pos[t.rekordbox_id]) if t.rekordbox_id in pos else (1, i)

    def _spotify(e):
        i, r, t = e
        return (0, i) if r.spotify else (1, pos.get(t.rekordbox_id, i))

    kept.sort(key=_spotify if order == SPOTIFY_ORDER else _rekordbox)
    out, seen = [], set()
    for _i, _r, t in kept:
        if t.export_location is None or id(t) in seen:
            continue
        seen.add(id(t))
        out.append(t)
    carried = {t.rekordbox_id for t in out}
    lost = [t for t in playlist
            if t.rekordbox_id not in carried and t.rekordbox_id not in taken_out]
    return out, lost


def summarize(rows: list[SyncRow]) -> dict[str, int]:
    return {
        "total": len(rows),
        "have": sum(1 for r in rows if r.collection == "have"),
        "review": sum(1 for r in rows if r.collection == "review"),
        "missing": sum(1 for r in rows if r.needs_source),
        "downloaded": sum(1 for r in rows if r.pipeline == "downloaded"),
        "to_add": sum(1 for r in rows if r.needs_add_to_set),
        "only_rb": sum(1 for r in rows if not r.in_spotify),
    }
