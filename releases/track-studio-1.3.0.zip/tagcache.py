"""What the file's tags said, so the same file is not opened twice.

`library._read_file_fields` and `library.file_duration` are the two most-called
disk reads in the app, and almost every call is a repeat: the Library table asks
for a duration per rendered row, the Build page does it again, `mixmodel`'s
build asks for a Comments string per played track, `hydrate_genres` and
`hydrate_local_energy` walk the library, the inbox scan reads every download.

Measured on this library: **~1.4 ms a file warm, ~18 ms cold** (the OS page
cache is the whole difference, so the cold number is what the first pass after a
launch actually pays — and a file on the shared drive is worse than either). Over
3 377 local files that is 5 s warm and ~60 s cold, per pass, for information that
does not change unless the file does.

So: one row per file, keyed on the path, invalidated on `(size, mtime)`. Both
things a caller might want come from the same `mutagen` open, so they are read
and stored together — a duration lookup right after a tag read costs nothing.

**Why `(size, mtime)` is the right key and not a hash.** Every way this app
changes a file moves at least one of them: `energy.write_energy` and
`write_loudness` rewrite the Comments tag, `refetch.replace_in_place` swaps the
audio, `normalize_loudness` re-encodes. There is no path where the tags change
and both the size and the mtime stay put, so a stale row cannot be served — and
the check costs one `stat`, not a read of the file it is trying to avoid reading.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import db

_SCHEMA = """
CREATE TABLE IF NOT EXISTS file_tags (
  path     TEXT PRIMARY KEY,
  size     INTEGER NOT NULL,
  mtime    REAL    NOT NULL,
  artist   TEXT,
  title    TEXT,
  comment  TEXT,
  bpm      REAL,
  key      TEXT,
  isrc     TEXT,
  genre    TEXT,
  duration REAL
);
"""

# The field order used by both the SELECT and the INSERT below. `duration` is
# last and separate from the rest because `library._read_file_fields` owns the
# other seven and this module adds that one.
_FIELDS = ("artist", "title", "comment", "bpm", "key", "isrc", "genre")


def get(path) -> Optional[dict]:
    """The cached tag fields (plus `duration`) for `path`, or None on a miss.

    A miss is the normal case the first time and is never an error: the caller
    reads the file and calls `put`. Any failure here returns None — a cache that
    raises would be worse than no cache.
    """
    p = str(Path(path))
    try:
        conn = db.connect(_SCHEMA)
        row = conn.execute(
            "SELECT size, mtime, artist, title, comment, bpm, key, isrc, genre, "
            "duration FROM file_tags WHERE path=?", (p,)).fetchone()
    except Exception:                    # noqa: BLE001 — a cache, not a fact
        return None
    if row is None:
        return None
    if not db.fresh(row[0], row[1], db.file_stamp(p)):
        return None
    out = dict(zip(_FIELDS, row[2:9]))
    out["duration"] = row[9]
    return out


def put(path, fields: dict, duration: Optional[float] = None) -> None:
    """Store one file's tag fields. Silent on failure, by the same rule as `get`."""
    p = str(Path(path))
    stamp = db.file_stamp(p)
    if stamp is None:
        return
    try:
        conn = db.connect(_SCHEMA)
        conn.execute(
            "INSERT INTO file_tags(path, size, mtime, artist, title, comment, "
            "bpm, key, isrc, genre, duration) VALUES(?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(path) DO UPDATE SET size=excluded.size, "
            "mtime=excluded.mtime, artist=excluded.artist, title=excluded.title, "
            "comment=excluded.comment, bpm=excluded.bpm, key=excluded.key, "
            "isrc=excluded.isrc, genre=excluded.genre, "
            # A duration already stored is kept when this write doesn't carry
            # one: the two readers arrive separately and neither should erase
            # what the other learned.
            "duration=COALESCE(excluded.duration, file_tags.duration)",
            (p, stamp[0], stamp[1],
             fields.get("artist"), fields.get("title"), fields.get("comment"),
             fields.get("bpm"), fields.get("key"), fields.get("isrc"),
             fields.get("genre"), duration))
        conn.commit()
    except Exception:                    # noqa: BLE001
        pass


def put_duration(path, duration: Optional[float]) -> None:
    """Store just a duration, for the reader that only wanted that.

    Kept separate from `put` so a duration read never invents empty tag fields
    for a file whose tags have not been read — an empty artist written here would
    be indistinguishable from a file that genuinely has none.
    """
    if duration is None:
        return
    p = str(Path(path))
    stamp = db.file_stamp(p)
    if stamp is None:
        return
    try:
        conn = db.connect(_SCHEMA)
        conn.execute(
            "INSERT INTO file_tags(path, size, mtime, duration) VALUES(?,?,?,?) "
            "ON CONFLICT(path) DO UPDATE SET size=excluded.size, "
            "mtime=excluded.mtime, duration=excluded.duration",
            (p, stamp[0], stamp[1], duration))
        conn.commit()
    except Exception:                    # noqa: BLE001
        pass


def forget(paths) -> int:
    """Drop rows for the given paths. For a caller that knows a file is gone."""
    ps = [(str(Path(p)),) for p in paths if p]
    if not ps:
        return 0
    try:
        conn = db.connect(_SCHEMA)
        cur = conn.executemany("DELETE FROM file_tags WHERE path=?", ps)
        conn.commit()
        return cur.rowcount or 0
    except Exception:                    # noqa: BLE001
        return 0


def count() -> int:
    try:
        return db.connect(_SCHEMA).execute(
            "SELECT COUNT(*) FROM file_tags").fetchone()[0]
    except Exception:                    # noqa: BLE001
        return 0
