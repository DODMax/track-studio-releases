"""Shared comment-tag parsing for Track Energy Tagger.

The energy tagger writes a single Comments string per track, of the form:
    Energy 07 | A 5.67 | Dance 0.95 | Valence 5.81 | Style House | Mood summer,deep

This module parses that string back into a dict.
"""
from __future__ import annotations

import re

ENERGY_RE = re.compile(r"Energy\s+(\d{1,2})", re.IGNORECASE)
AROUSAL_RE = re.compile(r"\bA\s+([-\d.]+)")
DANCE_RE = re.compile(r"\bDance\s+([\d.]+)")
VALENCE_RE = re.compile(r"\bValence\s+([-\d.]+)")
STYLE_RE = re.compile(r"\bStyle\s+([^|]+?)(?=\s*\||$)")
MOOD_RE = re.compile(r"\bMood\s+([^|]+?)(?=\s*\||$)")
# Texture descriptors (DSP, always written): brightness Hz, dynamic complexity,
# spectral complexity, onset rate. Kept in sync with energy.write_energy bits.
BRIGHT_RE = re.compile(r"\bBright\s+([\d.]+)")
DYN_RE = re.compile(r"\bDyn\s+([\d.]+)")
SPEC_RE = re.compile(r"\bSpec\s+([\d.]+)")
ONSET_RE = re.compile(r"\bOnset\s+([\d.]+)")
# EBU R128 loudness, written as its own segment by energy.write_loudness:
# integrated loudness (LUFS), loudness range (LU), true peak (dBTP).
LUFS_RE = re.compile(r"\bLUFS\s+(-?[\d.]+)")
LRA_RE = re.compile(r"\bLRA\s+([\d.]+)")
TP_RE = re.compile(r"\bTP\s+(-?[\d.]+)")
# Cross-platform provenance, stamped at sync time (see library/sync flow).
ISRC_RE = re.compile(r"\bISRC\s+([A-Z]{2}[A-Z0-9]{3}\d{7})", re.IGNORECASE)
BEATPORT_RE = re.compile(r"\bBP\s+(\d+)")
SPOTIFY_RE = re.compile(r"\bSP\s+([A-Za-z0-9]{22})")


def parse_comment(text: str) -> dict:
    """Parse the Comments tag string into structured fields.

    Missing fields are absent from the result dict (no None placeholders).
    """
    out: dict = {}
    if not text:
        return out
    if (m := ENERGY_RE.search(text)):
        out["energy"] = int(m.group(1))
    if (m := AROUSAL_RE.search(text)):
        out["arousal"] = float(m.group(1))
    if (m := DANCE_RE.search(text)):
        out["danceability"] = float(m.group(1))
    if (m := VALENCE_RE.search(text)):
        out["valence"] = float(m.group(1))
    if (m := STYLE_RE.search(text)):
        out["style"] = m.group(1).strip()
    if (m := MOOD_RE.search(text)):
        moods = [s.strip() for s in m.group(1).split(",") if s.strip()]
        if moods:
            out["moods"] = moods
    if (m := BRIGHT_RE.search(text)):
        out["brightness"] = float(m.group(1))
    if (m := DYN_RE.search(text)):
        out["dynamic_complexity"] = float(m.group(1))
    if (m := SPEC_RE.search(text)):
        out["spectral_complexity"] = float(m.group(1))
    if (m := ONSET_RE.search(text)):
        out["onset_rate"] = float(m.group(1))
    if (m := LUFS_RE.search(text)):
        out["lufs"] = float(m.group(1))
    if (m := LRA_RE.search(text)):
        out["lra"] = float(m.group(1))
    if (m := TP_RE.search(text)):
        out["true_peak"] = float(m.group(1))
    if (m := ISRC_RE.search(text)):
        out["isrc"] = m.group(1).upper()
    if (m := BEATPORT_RE.search(text)):
        out["beatport_id"] = int(m.group(1))
    if (m := SPOTIFY_RE.search(text)):
        out["spotify_id"] = m.group(1)
    return out
