"""Self-update — check a static manifest, verify a signed zip, swap, relaunch.

Modelled on Tauri's updater (a *static JSON file* as the whole endpoint) and on
Sparkle's appcast, minus the parts that need a server: no update service, no
code signing, no notarisation. A release is two files committed to a public
repo, so publishing is a commit in GitHub Desktop:

    stable.json          the manifest below
    releases/track-studio-1.2.0.zip

    {
      "version": "1.2.0",
      "pub_date": "2026-09-17T18:40:00Z",
      "notes": "- what changed\\n- and what else",
      "platforms": {
        "darwin": {"url": "https://…/track-studio-1.2.0.zip",
                   "sha256": "…", "size": 214233, "signature": "base64 ed25519"}
      }
    }

Platform keys follow Tauri's `os-arch` convention; the payload is pure Python
and arch-independent, so releases publish a bare `darwin` and the client tries
`darwin-arm64` / `darwin-x86_64` first in case that ever stops being true.

**The zip holds code only** — it is built from what git tracks or would track
(`release.payload_files`), so it can't contain a venv, the models, your `.env`,
your drafts or the rekordbox snapshot: those are all ignored paths.
`scripts/apply_update.py` does the swap from outside the server process, and
restores the previous files if the new version doesn't answer afterwards.

What is trusted: `RELEASE_PUBLIC_KEY`, baked in here. The manifest and the zip
come from the same public repo, so neither is evidence on its own — see
`signing.release_message` for what the signature actually binds.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

import signing
from config import ROOT, load_env
from store import load_studio_state

# So TRACK_STUDIO_FEED in .env is honoured wherever a check runs from — the app,
# or a release you're trying on this machine before anyone else is offered it.
load_env()

# The port the app serves on — also what the update helper polls to decide
# whether the new version came up (main.py reads it, so there is one truth).
# `TRACK_STUDIO_PORT` runs a second copy beside the one you're using — for
# trying a change against the real library without stopping the app.
PORT = int(os.environ.get("TRACK_STUDIO_PORT") or 8080)

VERSION_FILE = ROOT / "VERSION"
UPDATE_DIR = ROOT / "data" / "updates"
STATE_FILE = UPDATE_DIR / "state.json"
LOG_FILE = ROOT / "data" / "update.log"

#: Public half of the release key. The private half lives outside the repo, in
#: ~/.config/track-studio/release_key — `scripts/release.py keygen` made it.
RELEASE_PUBLIC_KEY = "iaNDXwCs9KeE6kX3zX64C/YzqSm0wKkPRVJv9U0NHFo="

#: Where manifests live. Override in .env with TRACK_STUDIO_FEED (a folder URL)
#: — used by `scripts/release.py --serve` to test a release before publishing.
FEED_BASE = "https://raw.githubusercontent.com/DODMax/track-studio-releases/main"

CHANNELS = ("stable", "beta")

#: A code-only release is a few hundred KB; anything near this is not our zip.
MAX_PAYLOAD = 64 * 1024 * 1024

#: Never let an update write here, whatever the zip says (belt and braces: the
#: zip is built from tracked files, and all of these are gitignored).
PROTECTED = ("venv/", "data/", "models/", "beatportdl/", "exports/", "dist/",
             ".env", ".git/")


# --- version ----------------------------------------------------------------

def current_version() -> str:
    try:
        return VERSION_FILE.read_text().strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def _parts(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:4])


def is_newer(candidate: str, than: str) -> bool:
    return _parts(candidate) > _parts(than)


# --- state (what the header reads; never hits the network) -------------------

def _read_state() -> dict:
    try:
        return json.loads(STATE_FILE.read_text())
    except (OSError, json.JSONDecodeError):
        return {}


def _write_state(**kw) -> dict:
    st = _read_state()
    st.update(kw)
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(st, indent=2))
    return st


def channel() -> str:
    ch = (load_studio_state().get("update_channel") or "stable").lower()
    return ch if ch in CHANNELS else "stable"


def feed_url(ch: str | None = None) -> str:
    base = (os.environ.get("TRACK_STUDIO_FEED") or FEED_BASE).rstrip("/")
    return f"{base}/{ch or channel()}.json"


def last_checked() -> float:
    return float(_read_state().get("last_check") or 0)


def available() -> dict | None:
    """The pending update, from cache — safe to call on every page render.

    None when there is none, when it is not actually newer than what's running
    (an update that already installed), or when this version was skipped.
    """
    st = _read_state()
    rec = st.get("available")
    if not rec or not is_newer(rec.get("version", ""), current_version()):
        return None
    if st.get("skipped") == rec.get("version"):
        return None
    return rec


def skip(version: str) -> None:
    """Stop offering this one. A newer version clears it by being newer."""
    _write_state(skipped=version)


# --- check ------------------------------------------------------------------

def _platform_key() -> str:
    import platform
    arch = platform.machine()
    return f"darwin-{'arm64' if arch == 'arm64' else arch}"


def _pick(manifest: dict) -> dict | None:
    plats = manifest.get("platforms") or {}
    for key in (_platform_key(), "darwin-x86_64", "darwin"):
        if key in plats:
            return plats[key]
    return None


def check(timeout: float = 8.0) -> dict | None:
    """Fetch the manifest and remember what it offers. Blocking — call off the
    UI thread (`run.io_bound`). Returns the pending update, or None.

    Network trouble is not an error worth showing: a DJ laptop is offline half
    the time. It records the attempt and leaves any previous answer standing.
    """
    url = feed_url()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "TrackStudio"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            manifest = json.loads(r.read(1 << 20).decode())
    except urllib.error.HTTPError as e:
        # 404 is the ordinary state of a channel nobody has published to yet.
        _write_state(last_check=time.time(),
                     last_error=f"nothing published on the {channel()} channel yet"
                     if e.code == 404 else f"the release feed answered {e.code}")
        return None
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError) as e:
        _write_state(last_check=time.time(),
                     last_error="couldn't reach the release feed"
                     if isinstance(e, (urllib.error.URLError, OSError))
                     else f"the release feed isn't readable ({str(e)[:80]})")
        return None

    version = str(manifest.get("version") or "")
    plat = _pick(manifest)
    if not version or not plat or not plat.get("url"):
        _write_state(last_check=time.time(), last_error="manifest has nothing for macOS")
        return None
    if not is_newer(version, current_version()):
        _write_state(last_check=time.time(), last_error=None, available=None)
        return None

    rec = {
        "version": version,
        "notes": manifest.get("notes") or "",
        "pub_date": manifest.get("pub_date") or "",
        "url": plat["url"],
        "sha256": (plat.get("sha256") or "").lower(),
        "size": int(plat.get("size") or 0),
        "signature": plat.get("signature") or "",
        "channel": channel(),
    }
    _write_state(last_check=time.time(), last_error=None, available=rec)
    return available()


# --- download + verify ------------------------------------------------------

class UpdateError(RuntimeError):
    """Refused: the download didn't match what the manifest promised."""


def verify_release(version: str, sha256: str, signature: str) -> bool:
    """Is this payload the one the key-holder published under this version?"""
    return signing.verify(signing.unb64(RELEASE_PUBLIC_KEY),
                          signing.release_message(version, sha256),
                          signing.unb64(signature))


def _download(url: str, dest: Path, expect_size: int, on_progress) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "TrackStudio"})
    got = 0
    with urllib.request.urlopen(req, timeout=30) as r, dest.open("wb") as out:
        total = expect_size or int(r.headers.get("Content-Length") or 0)
        while True:
            chunk = r.read(64 * 1024)
            if not chunk:
                break
            got += len(chunk)
            if got > MAX_PAYLOAD:
                raise UpdateError("the download is far bigger than a release should be")
            out.write(chunk)
            if on_progress and total:
                on_progress(min(got / total, 1.0))


def _safe_members(zf: zipfile.ZipFile) -> list[str]:
    """Every path in the zip, refusing the ones no update may write."""
    names = []
    for name in zf.namelist():
        if name.endswith("/"):
            continue
        p = Path(name)
        if p.is_absolute() or ".." in p.parts:
            raise UpdateError(f"the zip tries to write outside the app: {name}")
        if any(name == guard.rstrip("/") or name.startswith(guard) for guard in PROTECTED):
            raise UpdateError(f"the zip tries to write a protected path: {name}")
        names.append(name)
    return names


def prepare(rec: dict, on_progress=None) -> Path:
    """Download, verify and unpack the update into `data/updates/<version>/`.

    Nothing outside that folder is touched, so a failure here leaves the running
    app exactly as it was. Raises UpdateError with a sentence worth showing.
    """
    version = rec["version"]
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = UPDATE_DIR / f"track-studio-{version}.zip"
    try:
        _download(rec["url"], zip_path, rec.get("size") or 0, on_progress)
    except UpdateError:
        raise
    except (urllib.error.URLError, OSError) as e:
        # A pending offer outlives the check that found it: the release can be
        # withdrawn, or you're simply offline by the time you press the button.
        zip_path.unlink(missing_ok=True)
        raise UpdateError(f"couldn't download {version} — the release may have moved, "
                          "or you're offline") from e

    digest = hashlib.sha256(zip_path.read_bytes()).hexdigest()
    if rec.get("sha256") and digest != rec["sha256"]:
        zip_path.unlink(missing_ok=True)
        raise UpdateError("the download doesn't match the manifest — try again later")
    if not verify_release(version, digest, rec.get("signature", "")):
        zip_path.unlink(missing_ok=True)
        raise UpdateError("this release isn't signed by Track Studio's key — refused")

    staged = UPDATE_DIR / version
    if staged.exists():
        import shutil
        shutil.rmtree(staged)
    with zipfile.ZipFile(zip_path) as zf:
        for name in _safe_members(zf):
            zf.extract(name, staged)
            # `extractall` drops the mode, so an installer or a build script comes
            # out of an update no longer executable. The zip knows; put it back.
            mode = (zf.getinfo(name).external_attr >> 16) & 0o777
            if mode & 0o111:
                (staged / name).chmod(mode)

    if not (staged / "main.py").is_file():
        raise UpdateError("the release looks incomplete — main.py is missing")
    staged_version = (staged / "VERSION").read_text().strip() if (staged / "VERSION").is_file() else ""
    if staged_version != version:
        raise UpdateError(f"the release says {staged_version or 'nothing'}, the manifest says {version}")
    zip_path.unlink(missing_ok=True)
    return staged


def launch_apply(staged: Path, rec: dict) -> None:
    """Hand the swap to a detached helper and expect to be killed by it.

    The helper can't live in this process: it has to stop the server, replace
    the very files this process is running from, and start it again.
    """
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    log = LOG_FILE.open("a")
    subprocess.Popen(
        [sys.executable, str(ROOT / "scripts" / "apply_update.py"),
         "--staged", str(staged), "--version", rec["version"], "--pid", str(os.getpid())],
        cwd=str(ROOT), stdout=log, stderr=log, start_new_session=True,
    )


# --- the /api/version route + the background check ---------------------------

def register() -> None:
    """Routes and the periodic check. Called by main.py, once, in the server."""
    import asyncio

    from nicegui import app

    @app.get("/api/version")
    def _version():  # noqa: D401  — the update helper polls this to know we're up
        return {"version": current_version(), "pid": os.getpid()}

    async def _loop() -> None:
        # Six hours, and once shortly after launch: often enough that a release
        # reaches a laptop the same night, rare enough to be invisible.
        await asyncio.sleep(5)
        while True:
            try:
                await asyncio.get_event_loop().run_in_executor(None, check)
            except Exception:
                pass
            await asyncio.sleep(6 * 3600)

    @app.on_startup
    async def _start() -> None:
        asyncio.create_task(_loop())
