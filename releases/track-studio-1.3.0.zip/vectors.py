"""The audio embeddings — machine-only derived data, in the one place that isn't a tag.

### Why this file exists at all

Everything else the analyzer learns goes into the audio file's **Comments** tag,
and that rule is load-bearing: rekordbox's Intelligent Playlists filter on that
string, so a human and rekordbox can both read it. An embedding is 1 280 floats.
It is unreadable to both, it would be ~15 KB of text in a field meant to hold a
sentence, and rekordbox would have to parse it on every read. So this is the
**first deliberate exception** — and it is kept narrow:

- Only data that *cannot* live in a tag goes here. Energy, style, moods,
  danceability, texture all stay in the Comments tag as before.
- **This file is a cache, not a source of truth.** Delete it and you lose an
  hour of compute, never a fact about your library. Nothing reads it that
  can't cope with it being empty.

### What is stored

`energy.analyze` already computes a Discogs-EffNet embedding for every track it
analyzes — (patches, 1280) floats, one patch per ~1s of audio — feeds it to the
genre and mood heads, reads off three words, and throws the array away. What is
kept here is that array mean-pooled over patches and L2-normalized: one point
per track in the space the model was trained to put similar-sounding records
close together in. "Does this belong with this crate" then becomes a dot product
(see `mixmodel`), which is what the field actually does and which does not care
what a shop called the record — Beatport files Wolfgang Gartner's *Illmerica*
under "Mainstage", while this space puts Justice, Boys Noize and Digitalism as
its six nearest neighbours out of the whole library.

Stored as **float16**: the vectors are normalized, so the representation error is
~1e-3 and irrelevant to a ranking, and it halves the file (2.6 KB a track, ~9 MB
for a 3 500-track library). The maths is done in float32.

### Why SQLite, and why keyed on the path

SQLite because the write pattern is one row at a time over a ~1 hour pass that
the user can cancel: a single `.npz` would have to be rewritten whole on every
track, and 3 500 loose `.npy` files have nowhere to put the invalidation data.
One row per file means a cancelled pass keeps everything it finished, "what still
needs doing" is one query, and reading it all back is one `SELECT` into a
contiguous matrix.

Keyed on the **file path**, not on `library.track_key`, and that is not an
accident: `track_key` is `rekordbox_id or isrc or display`, which *changes* the
moment a downloaded track is imported into rekordbox (no id → an id). Keying
vectors on it would orphan every one of them exactly when the library grows. The
vector describes the audio, so it is keyed to the audio. A file that is *moved*
therefore loses its vector — `fingerprint` is stored so that can be repaired
without re-analyzing (match a new path by content), the day it matters.
"""
from __future__ import annotations

import hashlib
import time
from pathlib import Path
from typing import Iterable, Optional

import numpy as np

import db

PATH = db.PATH

# Which model produced the vectors in here. Changing model means every row is
# stale — the column exists so that is a query, not a guess.
MODEL = "discogs-effnet-bs64-1"
DIM = 1280
STORED_DTYPE = np.float16

# One row is one analysis of one file. The embedding is the main event, but the
# rule is **capture everything the pass produces that a tag cannot hold**: the
# library pass is ~3.4 hours, so anything not written here costs another 3.4
# hours to obtain later. The tag keeps what a human and rekordbox read (energy,
# style, moods, texture); this keeps the machine-readable rest.
_SCHEMA = """
CREATE TABLE IF NOT EXISTS vectors (
  path        TEXT PRIMARY KEY,
  size        INTEGER NOT NULL,   -- invalidation: a replaced file changes both
  mtime       REAL    NOT NULL,   --   (refetch.replace_in_place does exactly that)
  model       TEXT    NOT NULL,
  dim         INTEGER NOT NULL,
  fingerprint TEXT,               -- content hash, for relinking a moved file
  vec         BLOB    NOT NULL,
  -- The heads' full output, not just the label the tag records. The tag says
  -- "Style Electro"; this says Electro .25 / Big Beat .19 / Acid House .11,
  -- which is both a better signal and the only way to change our mind about the
  -- label later without re-analyzing the library.
  genre_probs BLOB,               -- 400 Discogs styles, float16
  mood_probs  BLOB,               -- 56 MTG-Jamendo mood/themes, float16
  voice       REAL,               -- P(voice) 0..1 — vocal vs instrumental
  analyzed_at REAL
);
CREATE INDEX IF NOT EXISTS vectors_fp ON vectors(fingerprint);
"""


def _conn():
    """This thread's handle on the shared cache file (see `db`)."""
    return db.connect(_SCHEMA)


def fingerprint(path: Path, chunk: int = 262_144) -> str:
    """Content hash from the size plus the first and last 256 KB.

    Not a full hash of the file: at ~10 MB a track that would be 35 GB of reading
    for the library. Head + tail + size collides only on files that are the same
    audio with a different middle, which is not a thing that happens by accident.
    """
    h = hashlib.sha1()
    try:
        size = path.stat().st_size
        h.update(str(size).encode())
        with open(path, "rb") as f:
            h.update(f.read(chunk))
            if size > 2 * chunk:
                f.seek(-chunk, 2)
                h.update(f.read(chunk))
    except OSError:
        return ""
    return h.hexdigest()


def pool(patches) -> Optional[np.ndarray]:
    """(patches, dims) → one L2-normalized float32 vector, or None if empty.

    Mean over patches, which is the standard pooling and also this
    representation's known weakness: a six-minute track with a long ambient
    intro averages toward the middle of itself. It is why tempo, energy and key
    stay in the scoring rather than being replaced by this.
    """
    v = np.asarray(patches, dtype=np.float32)
    if v.ndim != 2 or not len(v):
        return None
    m = v.mean(axis=0)
    n = float(np.linalg.norm(m))
    return (m / n) if n > 0 else None


def _blob(a) -> Optional[bytes]:
    """A probability vector as float16 bytes, or None."""
    if a is None:
        return None
    arr = np.asarray(a, dtype=np.float32).ravel()
    return arr.astype(STORED_DTYPE).tobytes() if arr.size else None


def put(path, vec, *, model: str = MODEL, fp: Optional[str] = None,
        genre_probs=None, mood_probs=None, voice: Optional[float] = None) -> bool:
    """Store one track's analysis. Returns False if there was nothing to store."""
    p = Path(path)
    v = np.asarray(vec, dtype=np.float32)
    if v.ndim != 1 or not v.size:
        return False
    st = db.file_stamp(p)
    if st is None:
        return False
    size, mtime = st
    with _conn() as c:
        c.execute(
            "INSERT INTO vectors(path, size, mtime, model, dim, fingerprint, vec, "
            "genre_probs, mood_probs, voice, analyzed_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(path) DO UPDATE SET "
            "size=excluded.size, mtime=excluded.mtime, model=excluded.model, "
            "dim=excluded.dim, fingerprint=excluded.fingerprint, vec=excluded.vec, "
            "genre_probs=COALESCE(excluded.genre_probs, vectors.genre_probs), "
            "mood_probs=COALESCE(excluded.mood_probs, vectors.mood_probs), "
            "voice=COALESCE(excluded.voice, vectors.voice), "
            "analyzed_at=excluded.analyzed_at",
            (str(p), size, mtime, model, int(v.size),
             fp if fp is not None else fingerprint(p),
             v.astype(STORED_DTYPE).tobytes(),
             _blob(genre_probs), _blob(mood_probs),
             float(voice) if voice is not None else None, time.time()))
    return True


def record(path, *, model: str = MODEL) -> Optional[dict]:
    """Everything stored for one file — the heads' distributions and the voice
    probability — or None if it has not been analyzed (or has changed since).

    The embedding itself is deliberately not returned here: it is read in bulk
    by `matrix`, never one at a time.
    """
    p = str(Path(path))
    try:
        row = _conn().execute(
            "SELECT size, mtime, genre_probs, mood_probs, voice, analyzed_at "
            "FROM vectors WHERE path=? AND model=?", (p, model)).fetchone()
    except Exception:                    # noqa: BLE001 — a cache, not a fact
        return None
    if row is None or not db.fresh(row[0], row[1], db.file_stamp(p)):
        return None
    unpack = lambda b: (np.frombuffer(b, dtype=STORED_DTYPE).astype(np.float32)
                        if b else None)
    return {"genre_probs": unpack(row[2]), "mood_probs": unpack(row[3]),
            "voice": row[4], "analyzed_at": row[5]}


def have(paths: Iterable, *, model: str = MODEL) -> set[str]:
    """Which of `paths` already have a *current* vector.

    Current means: same model, and the file on disk still has the size and mtime
    it had when the vector was made. A re-download through `refetch` changes
    both, so its stale vector is correctly reported as missing.
    """
    want = {str(Path(p)) for p in paths if p}
    if not want or not PATH.exists():
        return set()
    out: set[str] = set()
    with _conn() as c:
        for sp, size, mtime in c.execute(
                "SELECT path, size, mtime FROM vectors WHERE model=?", (model,)):
            if sp not in want:
                continue
            if db.fresh(size, mtime, db.file_stamp(sp)):
                out.add(sp)
    return out


def missing(paths: Iterable, *, model: str = MODEL) -> list[str]:
    """`paths` that still need a vector, in the order given."""
    ok = have(paths, model=model)
    seen, out = set(), []
    for p in paths:
        sp = str(Path(p)) if p else ""
        if not sp or sp in ok or sp in seen:
            continue
        seen.add(sp)
        out.append(sp)
    return out


def matrix(paths: Iterable, *, model: str = MODEL) -> tuple[list[str], np.ndarray]:
    """(paths that had a vector, their vectors as one float32 matrix).

    One query and one stack: 3 500 rows is ~9 MB off disk, and ranking the whole
    library against a crate afterwards is a single matrix multiply. Rows are
    returned in the order of `paths` so a caller can zip them back to its tracks.
    """
    want = {str(Path(p)) for p in paths if p}
    if not want or not PATH.exists():
        return [], np.zeros((0, DIM), dtype=np.float32)
    found: dict[str, np.ndarray] = {}
    with _conn() as c:
        for sp, dim, blob in c.execute(
                "SELECT path, dim, vec FROM vectors WHERE model=?", (model,)):
            if sp in want:
                found[sp] = np.frombuffer(blob, dtype=STORED_DTYPE,
                                          count=dim).astype(np.float32)
    keys = [str(Path(p)) for p in paths if p and str(Path(p)) in found]
    if not keys:
        return [], np.zeros((0, DIM), dtype=np.float32)
    return keys, np.stack([found[k] for k in keys])


def stats() -> dict:
    """Row count and distinct models — for the UI and for a sanity check.

    The cache file is shared with the other caches now, so its size is `db`'s to
    report rather than this table's.
    """
    if not PATH.exists():
        return {"rows": 0, "models": []}
    with _conn() as c:
        rows = c.execute("SELECT COUNT(*) FROM vectors").fetchone()[0]
        models = [m for (m,) in c.execute("SELECT DISTINCT model FROM vectors")]
    return {"rows": rows, "models": models}


class SoundSpace:
    """Every seed-to-candidate similarity, computed once, looked up per pair.

    `mixmodel.fill` scores each candidate against each crate member, so the
    similarities it needs are a full (candidates x seeds) matrix — which is one
    matrix multiply here and a dictionary lookup there, rather than a query per
    pair. For a 16-track crate against 3 500 candidates that is 56 000 numbers
    and a few milliseconds.

    `known` answers the other question the UI needs: how much of the library has
    been analyzed at all, because a ranking that can hear half the library
    should say so.
    """

    def __init__(self, seed_paths: Iterable, cand_paths: Iterable, *,
                 model: str = MODEL) -> None:
        s_keys, S = matrix(seed_paths, model=model)
        c_keys, C = matrix(cand_paths, model=model)
        self.seeds = s_keys
        self.cands = set(c_keys)
        self._s = {k: i for i, k in enumerate(s_keys)}
        self._c = {k: i for i, k in enumerate(c_keys)}
        self._m = (C @ S.T) if (len(s_keys) and len(c_keys)) else None

    def __bool__(self) -> bool:
        return self._m is not None

    def get(self, seed_path, cand_path) -> Optional[float]:
        """Cosine similarity for one pair, or None if either side is unanalyzed."""
        if self._m is None:
            return None
        si = self._s.get(str(seed_path) if seed_path else "")
        ci = self._c.get(str(cand_path) if cand_path else "")
        if si is None or ci is None:
            return None
        return float(self._m[ci, si])

    def knows(self, path) -> bool:
        return str(path) in self._c or str(path) in self._s


# Cosine similarities in this space do not use the full 0..1 range — measured
# across this library, an unrelated pair sits near 0.55 and the closest pairs
# reach ~0.90. Stretching that window is what turns a bunched 55..90 into a
# score with a usable spread; the floor and ceiling are empirical, not chosen.
SIM_FLOOR = 0.45
SIM_CEIL = 0.90


def sim_score(cos: float) -> float:
    """A cosine similarity as a 0..100 axis score (see `SIM_FLOOR`/`SIM_CEIL`)."""
    return max(0.0, min(100.0, (cos - SIM_FLOOR) / (SIM_CEIL - SIM_FLOOR) * 100.0))


if __name__ == "__main__":
    print(f"{PATH}: {stats()}")
