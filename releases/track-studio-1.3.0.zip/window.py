"""The app window — a WKWebView pointed at the local server.

Run separately from the server on purpose (`main.py` keeps serving on :8080
whether or not anyone is looking at it):

  * closing the window doesn't kill a four-hour analysis run, and opening one
    again is instant, because nothing was torn down;
  * the server can be restarted under it — by an update, or by Settings — and
    the window just reloads;
  * pywebview wants the main thread, and so does the analysis pool's parent.

    venv/bin/python window.py            # waits for the server, then opens

The window is the thing macOS sees: the launcher runs this in the foreground, so
the Dock icon, ⌘Tab and the menu bar belong to it.
"""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
from pathlib import Path

PORT = 8080
URL = f"http://127.0.0.1:{PORT}"


def server_is_up(timeout: float = 0.4) -> bool:
    with socket.socket() as s:
        s.settimeout(timeout)
        return s.connect_ex(("127.0.0.1", PORT)) == 0


def wait_for_server(seconds: int = 60) -> bool:
    """The first launch after an install pays for the imports; later ones don't."""
    deadline = time.time() + seconds
    while time.time() < deadline:
        if server_is_up():
            return True
        time.sleep(0.4)
    return False


LOCK = Path(__file__).resolve().parent / "data" / "window.pid"


def raise_existing_window() -> bool:
    """If a window is already open, bring it forward and say so.

    Opening an app that's already open should show you the app, not a second copy
    of it — and the launcher runs on every ⌘Space, so without this you'd collect
    windows. `NSRunningApplication` does the activating, which needs no
    permissions (unlike telling System Events to do it).
    """
    try:
        pid = int(LOCK.read_text().strip())
    except (OSError, ValueError):
        return False
    try:
        running = subprocess.run(["ps", "-p", str(pid), "-o", "command="],
                                 capture_output=True, text=True, timeout=10).stdout
    except (OSError, subprocess.SubprocessError):
        return False
    if "window.py" not in running:
        return False
    try:
        from AppKit import NSRunningApplication
        app = NSRunningApplication.runningApplicationWithProcessIdentifier_(pid)
        if app is None:
            return False
        app.activateWithOptions_(1 << 1)     # NSApplicationActivateIgnoringOtherApps
        print(f"brought the window at {pid} forward", flush=True)
        return True
    except Exception:                        # noqa: BLE001
        return False


def claim_identity() -> None:
    """Be Track Studio in the menu bar and the Dock, not "Python".

    The process macOS sees is the framework's `Python.app`, so it reads that
    bundle's name and icon. Both can be overridden at runtime, and nothing else
    about the app makes sense until they are: this is the difference between a
    tool you ran and an app you opened. Failure here is cosmetic — never fatal.
    """
    try:
        from AppKit import NSApplication, NSImage
        from Foundation import NSBundle
        info = NSBundle.mainBundle().infoDictionary()
        info["CFBundleName"] = "Track Studio"
        for icns in (Path("/Applications/Track Studio.app/Contents/Resources/AppIcon.icns"),
                     Path(__file__).resolve().parent / "dist" / "Track Studio.app"
                     / "Contents" / "Resources" / "AppIcon.icns"):
            if icns.is_file():
                image = NSImage.alloc().initByReferencingFile_(str(icns))
                NSApplication.sharedApplication().setApplicationIconImage_(image)
                break
    except Exception as e:                       # noqa: BLE001
        print(f"(kept the default app identity: {e})", flush=True)


def paint_the_gap(window, hex_color: str = "#0e0f13") -> None:
    """Give the webview itself the app's colour, so a page change doesn't flash white.

    pywebview's `background_color` is the *window's* — and the window is behind
    the web view, which paints its own background while a page loads. Every nav
    here is a full page load (NiceGUI serves a page per route), so that
    background is on screen for a moment each time, and WKWebView's default is
    white. `underPageBackgroundColor` is the one that shows then (macOS 12+).

    Scheduled on the main queue because AppKit views belong to it, and guarded
    because a cosmetic fix must never be the reason the app won't open.
    """
    try:
        from AppKit import NSColor
        from Foundation import NSOperationQueue

        r, g, b = (int(hex_color[i:i + 2], 16) / 255 for i in (1, 3, 5))
        color = NSColor.colorWithSRGBRed_green_blue_alpha_(r, g, b, 1.0)

        def apply() -> None:
            native = window.native
            if hasattr(native, "setBackgroundColor_"):
                native.setBackgroundColor_(color)
            # Walk down to whatever answers to the selector: the web view's place
            # in the hierarchy is pywebview's business, not ours.
            seen, queue = set(), [native.contentView() if hasattr(native, "contentView") else None]
            while queue:
                view = queue.pop(0)
                if view is None or id(view) in seen:
                    continue
                seen.add(id(view))
                if hasattr(view, "setUnderPageBackgroundColor_"):
                    view.setUnderPageBackgroundColor_(color)
                if hasattr(view, "subviews"):
                    queue.extend(view.subviews() or [])

        NSOperationQueue.mainQueue().addOperationWithBlock_(apply)
    except Exception as e:                       # noqa: BLE001
        print(f"(couldn't set the webview background: {e})", flush=True)


# A browser window's reflexes, in a window with no browser: ⌘R reloads, ⌘0/+/−
# size the page. Everything else (⌘W, ⌘Q, ⌘C, ⌘F) is Cocoa's already.
SHORTCUTS_JS = """
(() => {
  let zoom = 1;
  const apply = () => { document.body.style.zoom = zoom; };
  document.addEventListener('keydown', (e) => {
    if (!e.metaKey) return;
    if (e.key === 'r') { location.reload(); }
    else if (e.key === '0') { zoom = 1; apply(); }
    else if (e.key === '=' || e.key === '+') { zoom = Math.min(2, zoom + 0.1); apply(); }
    else if (e.key === '-') { zoom = Math.max(0.6, zoom - 0.1); apply(); }
    else return;
    e.preventDefault();
  });
})();
"""

# The window outlives the server: an update replaces it, Settings can restart it,
# and a crash takes it away. NiceGUI's page can't re-attach to a server that has
# restarted — its client is gone — so it sits on a dark "connection lost" panel
# until someone reloads. This does the reloading, once the server answers again.
RECONNECT_JS = """
(() => {
  let missing = false;
  const alive = () => fetch('/api/version', { cache: 'no-store' }).then(r => r.ok).catch(() => false);
  setInterval(async () => {
    const up = await alive();
    if (!up) { missing = true; return; }
    if (missing) location.reload();          // it went away and came back: start clean
  }, 2000);
})();
"""


def main() -> int:
    if raise_existing_window():
        return 0
    if not wait_for_server():
        print(f"no server on {PORT} after 60s — see data/app.log", file=sys.stderr)
        return 1

    claim_identity()
    LOCK.parent.mkdir(exist_ok=True)
    LOCK.write_text(str(os.getpid()))
    import webview

    window = webview.create_window(
        "Track Studio", URL,
        width=1440, height=900, min_size=(1024, 680),
        background_color="#0e0f13",   # the app's page colour, so no white flash
        text_select=True,             # it's a library: you copy paths and titles out
        confirm_close=False,
    )

    def _ready() -> None:
        # A browser window's reflexes, in a window with no browser: ⌘R reloads,
        # ⌘0/+/− size the page. Everything else (⌘W, ⌘Q, ⌘C) is Cocoa's already.
        # The first call also waits for the page, so it's where "it opened" is known.
        from Foundation import NSBundle
        name = (NSBundle.mainBundle().infoDictionary() or {}).get("CFBundleName")
        print(f"window showing {window.evaluate_js('location.href')} as {name!r}", flush=True)
        paint_the_gap(window)
        window.evaluate_js(RECONNECT_JS)
        # Every page is a fresh document, so both go back in on each one.
        window.events.loaded += lambda: (window.evaluate_js(RECONNECT_JS),
                                         window.evaluate_js(SHORTCUTS_JS))
        window.evaluate_js(SHORTCUTS_JS)

    webview.start(_ready, private_mode=False)  # keep cookies/localStorage between launches
    return 0


if __name__ == "__main__":
    sys.exit(main())
