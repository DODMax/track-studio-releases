"""YouTube / SoundCloud download — inspect audio quality, then fetch via yt-dlp.

Sibling of `bpdl.py` (the Beatport path). One library (yt-dlp) covers YouTube,
SoundCloud, and ~1800 other sites, and — crucially — exposes the available audio
formats *before* download, so the Download page can show a quality badge up front.

`probe(url)` does a metadata-only extract (no media downloaded) and returns the
best audio stream's bitrate/codec/sample-rate/size. `download(entries, dest)` then
grabs `bestaudio`, transcodes to `.m4a` via ffmpeg (the only formats our tagger +
rekordbox pipeline handle), and stamps the cleaned artist/title into the file tags.

Quality is inherently capped and lossy here — YouTube ~128-160 kbps, SoundCloud
~128 kbps mp3 / 256 kbps AAC (Go+) — always below Beatport. The pre-download
readout exists precisely so the user can judge per track.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

import drives

AUDIO_EXTS = {".m4a", ".mp3", ".opus", ".webm", ".aac", ".flac"}

# YouTube throttles the default web client's streams (frequent HTTP 403 on
# download). Offering the ios/android clients first yields un-throttled formats,
# with web as a fallback.
_YT_EXTRACTOR_ARGS = {"youtube": {"player_client": ["ios", "android", "web"]}}

# Junk commonly tacked onto YouTube/SoundCloud titles that we strip for clean tags.
_TITLE_NOISE = re.compile(
    r"\s*[\(\[]\s*(official\s+(music\s+)?video|official\s+audio|official\s+lyric[s]?"
    r"(\s+video)?|lyric[s]?(\s+video)?|audio|visualizer|hd|hq|4k|m/?v|mv|"
    r"free\s+download|out\s+now|premiere)\s*[\)\]]",
    re.IGNORECASE,
)
_TRAILING_NOISE = re.compile(r"\s*[\(\[][^)\]]*[\)\]]\s*$")


@dataclass
class MediaInfo:
    """A probed track: identity + the best available audio stream's quality."""
    url: str
    source: str                    # "youtube" / "soundcloud" / other extractor
    title: str                     # cleaned track title
    artist: str                    # cleaned / inferred artist
    raw_title: str                 # original video/track title (for reference)
    uploader: str
    duration: Optional[float]      # seconds
    abr: Optional[float]           # audio bitrate, kbps
    acodec: Optional[str]
    asr: Optional[int]             # sample rate, Hz
    filesize: Optional[int]        # bytes (may be approximate)
    thumbnail: Optional[str]       # cover-art URL (embedded on download)


def _clean_title(raw: str, uploader: str) -> tuple[str, str]:
    """Split a messy source title into (artist, title). Best-effort:
    strip `(Official Video)` / `[HD]` noise, split on the first ` - `, and fall
    back to the uploader as the artist. Always editable in the UI afterwards."""
    t = (raw or "").strip()
    t = _TITLE_NOISE.sub("", t)
    t = _TRAILING_NOISE.sub("", t).strip(" -–—")
    artist, sep, title = t.partition(" - ")
    if sep:
        return artist.strip(), title.strip()
    # No "Artist - Title" separator: use the uploader (minus a trailing "- Topic"
    # that YouTube auto-channels append) as the artist.
    up = re.sub(r"\s*-\s*Topic$", "", uploader or "", flags=re.IGNORECASE).strip()
    return up, t


def _best_audio(info: dict) -> dict:
    """Pick the highest-bitrate audio stream from an info dict's formats."""
    fmts = info.get("formats") or []
    audio_only = [f for f in fmts
                  if f.get("acodec") not in (None, "none")
                  and f.get("vcodec") in (None, "none")]
    pool = audio_only or [f for f in fmts if f.get("acodec") not in (None, "none")]

    def _rate(f):
        return f.get("abr") or f.get("tbr") or 0

    best = max(pool, key=_rate) if pool else {}
    return {
        "abr": best.get("abr") or best.get("tbr") or info.get("abr"),
        "acodec": best.get("acodec") or info.get("acodec"),
        "asr": best.get("asr") or info.get("asr"),
        "filesize": best.get("filesize") or best.get("filesize_approx"),
    }


def _thumbnail_of(info: dict) -> Optional[str]:
    """The best cover-art URL: the top-level thumbnail, else the largest listed."""
    if info.get("thumbnail"):
        return info["thumbnail"]
    thumbs = info.get("thumbnails") or []
    if not thumbs:
        return None
    best = max(thumbs, key=lambda t: (t.get("preference") or 0,
                                      (t.get("width") or 0) * (t.get("height") or 0)))
    return best.get("url")


def _source_of(info: dict) -> str:
    ex = (info.get("extractor_key") or info.get("extractor") or "").lower()
    if "youtube" in ex:
        return "youtube"
    if "soundcloud" in ex:
        return "soundcloud"
    return ex or "web"


def _to_media(info: dict) -> MediaInfo:
    raw_title = info.get("title") or ""
    uploader = info.get("uploader") or info.get("channel") or ""
    artist, title = _clean_title(raw_title, uploader)
    q = _best_audio(info)
    return MediaInfo(
        url=info.get("webpage_url") or info.get("original_url") or info.get("url") or "",
        source=_source_of(info),
        title=title or raw_title,
        artist=artist,
        raw_title=raw_title,
        uploader=uploader,
        duration=info.get("duration"),
        abr=q["abr"], acodec=q["acodec"], asr=q["asr"], filesize=q["filesize"],
        thumbnail=_thumbnail_of(info),
    )


def probe(url: str) -> list[MediaInfo]:
    """Metadata-only extract (no media downloaded). Returns one MediaInfo per
    track — a single entry for a track URL, or many for a playlist / SC set."""
    from yt_dlp import YoutubeDL  # heavy import, deferred (mirrors bpdl/essentia)

    opts = {"quiet": True, "no_warnings": True, "skip_download": True,
            "extract_flat": False, "extractor_args": _YT_EXTRACTOR_ARGS}
    with YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    if info.get("entries"):
        return [_to_media(e) for e in info["entries"] if e]
    return [_to_media(info)]


def _tag_m4a(path: Path, title: str, artist: str) -> None:
    """Stamp cleaned title/artist onto the downloaded .m4a so the Library shows
    sane names (the tagger later merges Energy into Comments, untouched here)."""
    if path.suffix.lower() != ".m4a":
        return
    try:
        from mutagen.mp4 import MP4
        m = MP4(str(path))
        if title:
            m["\xa9nam"] = [title]
        if artist:
            m["\xa9ART"] = [artist]
        m.save()
    except Exception:
        pass  # tags are a nicety; the file is still usable/analyzable


def download(entries: list[dict], dest: Path,
             progress: Optional[Callable[[int, int, float, str], None]] = None
             ) -> tuple[list[Path], str]:
    """Download each entry's best audio into `dest` as .m4a. `entries` are dicts
    {url, title, artist} (title/artist already cleaned/edited in the UI).

    `progress`, if given, is called as `progress(done, total, frac, label)` where
    `done` is the count finished, `frac` is the current file's 0..1 fraction.
    Returns (new_files, log)."""
    from yt_dlp import YoutubeDL

    dest = drives.ensure_dir(dest)
    total = len(entries)
    files: list[Path] = []
    log_lines: list[str] = []

    for i, e in enumerate(entries):
        label = f"{e.get('artist', '')} — {e.get('title', '')}".strip(" —")

        def _hook(d, _i=i, _label=label):
            if not progress:
                return
            if d.get("status") == "downloading":
                tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                got = d.get("downloaded_bytes") or 0
                frac = (got / tot) if tot else 0.0
                progress(_i, total, frac, _label)
            elif d.get("status") == "finished":
                progress(_i, total, 1.0, _label)

        opts = {
            "quiet": True, "no_warnings": True,
            "format": "bestaudio/best",
            "outtmpl": str(dest / "%(title).200B [%(id)s].%(ext)s"),
            "progress_hooks": [_hook],
            "extractor_args": _YT_EXTRACTOR_ARGS,
            "writethumbnail": True,   # fetch cover art for EmbedThumbnail below
            "postprocessors": [
                {"key": "FFmpegExtractAudio", "preferredcodec": "m4a"},
                {"key": "EmbedThumbnail", "already_have_thumbnail": False},
            ],
        }
        try:
            with YoutubeDL(opts) as ydl:
                info = ydl.extract_info(e["url"], download=True)
            path = _resolved_path(ydl, info)
            if path and path.exists():
                _tag_m4a(path, e.get("title", ""), e.get("artist", ""))
                files.append(path)
                if progress:
                    progress(i + 1, total, 1.0, label)
            else:
                log_lines.append(f"no file produced for {e['url']}")
        except Exception as ex:
            log_lines.append(f"{e['url']}: {ex}")

    return files, "\n".join(log_lines)


def _resolved_path(ydl, info: dict) -> Optional[Path]:
    """The final on-disk path after post-processing (m4a extension)."""
    rd = (info or {}).get("requested_downloads")
    if rd:
        p = rd[0].get("filepath") or rd[0].get("_filename")
        if p:
            return Path(p)
    try:
        return Path(ydl.prepare_filename(info)).with_suffix(".m4a")
    except Exception:
        return None
